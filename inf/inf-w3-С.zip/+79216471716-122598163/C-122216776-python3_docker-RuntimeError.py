def min_difference(n, m, x, y):
    total_area = n * m 
    areas = []  
    area1 = 0.5 * x * y
    areas.append(area1)

    area2 = 0.5 * (n - x) * y
    areas.append(area2)

    area3 = 0.5 * x * (m - y)
    areas.append(area3)
    

    area4 = 0.5 * (n - x) * (m - y)
    areas.append(area4)

    for area in areas:
        remaining_area = total_area - area
        diff = abs(area - remaining_area)
        min_diff = min(min_diff, diff)
    
    return min_diff


n, m = map(int, input().split())
x, y = map(int, input().split())


result = min_difference(n, m, x, y)


print(result)

