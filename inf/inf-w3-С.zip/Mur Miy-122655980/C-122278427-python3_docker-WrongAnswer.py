def min_difference(w, h, x, y):
    # Функция для вычисления площади при разрезе через (0, 0)
    def area_from_origin():
        return (x * y) / 2, (w * h) - (x * y) / 2  # Площадь одного кусочка и второго

    # Функция для вычисления площади при разрезе через (w, 0)
    def area_from_w0():
        triangle_area = (w * y) / 2
        return triangle_area, w * h - triangle_area

    # Функция для вычисления площади при разрезе через (0, h)
    def area_from_h0():
        triangle_area = ((h - y) * x) / 2
        return triangle_area, w * h - triangle_area

    # Функция для вычисления площади при разрезе через (w, h)
    def area_from_w_h():
        triangle_area = ((h - y) * (w - x)) / 2
        return triangle_area, w * h - triangle_area

    # Расчет площадей и обнаружение минимальной разницы
    differences = []
    
    for area1, area2 in [area_from_origin(),
                         area_from_w0(),
                         area_from_h0(),
                         area_from_w_h()]:
        differences.append(abs(area1 - area2))

    return min(differences)

def main():
    import sys
    input = sys.stdin.read
    w, h, x, y = map(int, input().strip().split())
    result = min_difference(w, h, x, y)
    print(int(result))

if __name__ == "__main__":
    main()