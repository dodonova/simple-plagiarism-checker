def min_difference(n, m, x, y):
    # Для каждого угла вычислим площади разрезанных кусков
    areas = []

    # 1. Разрез через угол (0, 0)
    area1 = (x * y) / 2  # Площадь треугольника
    area2 = n * m - area1  # Общая площадь - площадь треугольника
    areas.append(abs(area1 - area2))

    # 2. Разрез через угол (n, 0)
    area1 = (n - x) * y / 2  # Площадь треугольника
    area2 = n * m - area1
    areas.append(abs(area1 - area2))

    # 3. Разрез через угол (n, m)
    area1 = (n - x) * (m - y) / 2  # Площадь треугольника
    area2 = n * m - area1
    areas.append(abs(area1 - area2))

    # 4. Разрез через угол (0, m)
    area1 = x * (m - y) / 2  # Площадь треугольника
    area2 = n * m - area1
    areas.append(abs(area1 - area2))

    return min(areas)

def main():
    import sys
    input = sys.stdin.read
    data = input().strip().split()
    
    n = int(data[0])
    m = int(data[1])
    x = int(data[2])
    y = int(data[3])
    
    result = min_difference(n, m, x, y)
    print(f"{result:.6f}")

if __name__ == "__main__":
    main()