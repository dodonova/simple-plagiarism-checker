
def calculate_triangle_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def min_difference(n, m, x, y):
    total_area = n * m 

    areas = []

    area1 = calculate_triangle_area(0, 0, x, y, n, 0) 
    areas.append(abs(area1 - (total_area - area1)))  
    area1 = calculate_triangle_area(0, m, x, y, n, m)  
    areas.append(abs(area1 - (total_area - area1)))
    area1 = calculate_triangle_area(n, 0, x, y, n, m)  
    areas.append(abs(area1 - (total_area - area1)))
    area1 = calculate_triangle_area(n, m, x, y, 0, m)  
    areas.append(abs(area1 - (total_area - area1)))

    return min(areas)

n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

result = min_difference(n, m, x, y)

print(f"{result:.3f}")



