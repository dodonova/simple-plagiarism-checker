def area_triangle(base, height):
    return 0.5 * base * height

def area_rectangle(w, h):
    return w * h

def calculate_difference(n, m, x, y):
    area1 = area_triangle(x, y) + area_rectangle(n - x, m)  
    area2 = area_triangle(n - x, m - y) + area_rectangle(x, y)  
    area3 = area_triangle(x, m - y) + area_rectangle(n - x, y)  
    area4 = area_triangle(n - x, y) + area_rectangle(x, m - y)
    area5 = area_triangle(n - x, m - y) + area_rectangle(x, m) 
    area6 = area_triangle(x, y) + area_rectangle(n - x, m - y) 
    return min(abs(area1 - area2), abs(area3 - area4), abs(area5 - area6))

n, m = map(int, input().split())
x, y = map(int, input().split())

result = calculate_difference(n, m, x, y)

print(f"{result:.3f}")

