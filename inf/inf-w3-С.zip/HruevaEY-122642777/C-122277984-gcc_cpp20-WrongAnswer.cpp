#include <iostream>
#include <math.h>
#include <algorithm>
#include <vector>
#include <iomanip>
#include <set>
#include <map>
#include <deque>
#include <string>
#include <numeric>
#include <bitset>
#include <climits>
#include <cstdlib>
#include <cmath>
#include <cassert>
#include <complex>

using namespace std;
typedef long long ll;
#define all(x) x.begin(), x.end()

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    double n , m, x, y, eps = 1e-6;
    cin >> n >> m >> x >> y;
    double nx = n - x, my = m - y;
    if (nx - x >= eps) { swap(x, nx); }
    if (my - y >= eps) { swap(y, my); }
    if (m / my < n / nx)
    {
        swap(nx, my);
        swap(n, m);
        swap(x, y);
    }
    double s = x * my / y;
    double ans = (n * m) - (((x * y / 2) + (x * my) + (my * s / 2)) * 2);
    cout << ans;
    
    return 0;
}