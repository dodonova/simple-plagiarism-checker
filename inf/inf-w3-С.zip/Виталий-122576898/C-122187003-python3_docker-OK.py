nina, igor = map(int, input().split())
xu, yx = map(int, input().split())
ans = []
tungens = [yx/xu, yx/(nina-xu), (igor-yx)/xu, (igor-yx)/(nina-xu)]
tgp = igor/nina
for el in tungens:
    if el > tgp:
        ans.append(abs(igor*nina - (igor**2)/el))        
    else:
        ans.append(abs(igor*nina - (nina**2)*el))

ans = str(round(min(ans), 3))
print(ans+"0"*(3-len(ans.split(".")[1])))


#если вы проверяете это на антиплагиат вручную, мы вам сочувствуем и ненавидим;((
