# Input dimensions and coordinates
width, height = map(int, input().split())
x_coord, y_coord = map(int, input().split())

# Constant (not used in this context)
q = 3467537548654432643

# Calculate slopes and intercepts
slope1 = y_coord / x_coord
slope2 = (y_coord - height) / x_coord
slope3 = (height - y_coord) / (width - x_coord)
slope4 = -y_coord / (width - x_coord)

intercept2 = y_coord - slope2 * x_coord
intercept3 = y_coord - slope3 * x_coord
intercept4 = y_coord - slope4 * x_coord

def calculate_area(slope, intercept, x_limit, y_limit, is_special_case=False):
    if abs(slope) > y_limit / x_limit:
        x_intersect = y_limit / slope if not is_special_case else -intercept / slope
        y_intersect = y_limit if x_intersect <= x_limit else 0
        area_upper = ((x_limit - x_intersect) + x_limit) * y_limit / 2
        area_lower = (y_limit * x_intersect) / 2
    else:
        x_intersect = x_limit
        y_intersect = slope * x_limit + intercept if slope == slope2 else intercept
        area_upper = ((y_intersect) + y_limit) * x_limit / 2
        area_lower = (x_limit * (y_limit - y_intersect)) / 2
    return abs(area_upper - area_lower)

# Calculate area differences
area_diff1 = calculate_area(slope1, 0, width, height)
area_diff2 = calculate_area(slope2, intercept2, width, height)
area_diff3 = calculate_area(slope3, intercept3, width, height, is_special_case=True)
area_diff4 = calculate_area(slope4, intercept4, width, height)

# Print the minimum area difference
print(min(area_diff1, area_diff2, area_diff3, area_diff4))