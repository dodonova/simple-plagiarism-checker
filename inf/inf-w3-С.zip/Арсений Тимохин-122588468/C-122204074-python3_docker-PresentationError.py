import math

# Read coefficients from input
a, b = map(int, input().split())

# Calculate numerator and denominator
nn = a * a - 16 * b
dd = nn // 4

# Check if denominator is non-negative
if dd < 0:
    print("No solution found.")
else:
    # Calculate the square root of the denominator
    sqrt_D = int(math.isqrt(dd))

    # Calculate the sum of coefficients
    s = a // 2 + 2

    # Initialize a flag to track if a solution is found
    found = False

    # Iterate over signs
    for sign in [1, -1]:
        n_candidate = (s + sign * sqrt_D)
        if n_candidate % 2!= 0:
            continue
        n = n_candidate // 2
        m = s - n
        if n >= 1 and m >= 1:
            if n > m:
                n, m = m, n
            print(n, m)
            found = True