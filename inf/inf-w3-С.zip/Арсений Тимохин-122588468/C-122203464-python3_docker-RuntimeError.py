import math

# Read coefficients from input
coefficient_a, coefficient_b = map(int, input().split())

# Calculate numerator and denominator
numerator = coefficient_a * coefficient_a - 16 * coefficient_b
denominator = numerator // 4

# Calculate the square root of the denominator
discriminant_square_root = int(math.isqrt(denominator))

# Calculate the sum of coefficients
sum_of_coefficients = coefficient_a // 2 + 2

# Initialize a flag to track if a solution is found
solution_found = False

# Iterate over signs
for sign in [1, -1]:
    candidate_n = sum_of_coefficients + sign * discriminant_square_root
    if candidate_n % 2!= 0:
        continue
    n = candidate_n // 2
    m = sum_of_coefficients - n
    if n >= 1 and m >= 1:
        if n > m:
            n, m = m, n
        print(f"{n} {m}")
        solution_found = True
        break



# Print a message if no solution is found
if not solution_found:
    print("No solution found.")