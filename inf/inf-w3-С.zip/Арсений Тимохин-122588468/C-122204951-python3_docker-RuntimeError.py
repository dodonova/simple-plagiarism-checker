import math
a, b = ts, xs = [*map(int, input().split())]
nn = a * a - 16 * b
dd = nn // 4
sqrt_D = int(math.isqrt(dd))
s = a // 2 + 2
found = False
for sign in [1, -1]:
    n_candidate = (s + sign * sqrt_D)
    if n_candidate % 2 != 0:
        continue
    n = n_candidate // 2
    m = s - n
    if n >= 1 and m >= 1:
        if n > m:
            n, m = m, n
        print(f"{n} {m}")
        found = True
        break

