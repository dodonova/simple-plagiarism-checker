#include <iostream>
#include <cmath>
#include <iomanip>
#include <limits>

double calculateAreaDifference(int n, int m, int x, int y) {
    double minDiff = std::numeric_limits<double>::max();

    // Calculate differences for each corner
    minDiff = std::min(minDiff, std::abs(static_cast<double>(x * y) - static_cast<double>((n - x) * (m - y))));
    minDiff = std::min(minDiff, std::abs(static_cast<double>((n - x) * y) - static_cast<double>(x * (m - y))));
    minDiff = std::min(minDiff, std::abs(static_cast<double>(x * (m - y)) - static_cast<double>((n - x) * y)));
    minDiff = std::min(minDiff, std::abs(static_cast<double>((n - x) * (m - y)) - static_cast<double>(x * y)));

    return minDiff;
}

int main() {
    int n, m, x, y;
    std::cin >> n >> m >> x >> y;

    double minDiff = calculateAreaDifference(n, m, x, y);
    std::cout << std::fixed << std::setprecision(3) << minDiff << std::endl;



    return 0;
}