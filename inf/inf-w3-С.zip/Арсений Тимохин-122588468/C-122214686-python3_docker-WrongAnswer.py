# Input dimensions and coordinates
width, height = list(map(int, input().split()))
x_coord, y_coord = list(map(int, input().split()))

# Constant (not used in this context)
q = 3467537548654432643

# Slopes and intercepts of lines
slope1, slope2, slope3, slope4 = (y_coord / x_coord), ((y_coord - height) / x_coord), ((height - y_coord) / (width - x_coord)), ((-y_coord) / (width - x_coord))
intercept2 = y_coord - slope2 * x_coord
intercept3 = y_coord - slope3 * x_coord
intercept4 = y_coord - slope4 * x_coord

# Calculate area for slope1
if abs(slope1) > height / width:
    x_intersect1, y_intersect1 = height / slope1, height
    area1_upper = ((width - x_intersect1) + width) * height / 2
    area1_lower = (height * x_intersect1) / 2
    area_diff1 = abs(area1_upper - area1_lower)
else:
    x_intersect1, y_intersect1 = width, slope1 * width
    area1_upper = ((height - y_intersect1) + height) * width / 2
    area1_lower = (width * y_intersect1) / 2
    area_diff1 = abs(area1_upper - area1_lower)

# Calculate area for slope2
if abs(slope2) > height / width:
    x_intersect2, y_intersect2 = height / slope2, 0
    area2_upper = ((width - x_intersect2) + width) * height / 2
    area2_lower = (height * x_intersect2) / 2
    area_diff2 = abs(area2_upper - area2_lower)
else:
    x_intersect2, y_intersect2 = width, slope2 * width + height
    area2_upper = ((y_intersect2) + height) * width / 2
    area2_lower = (width * (height - y_intersect2)) / 2
    area_diff2 = abs(area2_upper - area2_lower)

# Calculate area for slope3
if abs(slope3) > height / width:
    x_intersect3, y_intersect3 = -intercept3 / slope3, 0
    area3_upper = ((x_intersect3) + width) * height / 2
    area3_lower = (height * (width - x_intersect3)) / 2
    area_diff3 = abs(area3_upper - area3_lower)
else:
    x_intersect3, y_intersect3 = width, intercept3
    area3_upper = ((y_intersect3) + height) * width / 2
    area3_lower = (width * (height - y_intersect3)) / 2
    area_diff3 = abs(area3_upper - area3_lower)

# Calculate area for slope4
if abs(slope4) > height / width:
    x_intersect4, y_intersect4 = (height - intercept4) / slope4, height
    area4_upper = ((x_intersect4) + width) * height / 2
    area4_lower = (height * (width - y_intersect4)) / 2
    area_diff4 = abs(area4_upper - area4_lower)
else:
    x_intersect4, y_intersect4 = 0, intercept4
    area4_upper = ((height - y_intersect4) + height) * width / 2
    area4_lower = (width * y_intersect4) / 2
    area_diff4 = abs(area4_upper - area4_lower)

# Print the minimum area difference
print(min(area_diff1, area_diff2, area_diff3, area_diff4))