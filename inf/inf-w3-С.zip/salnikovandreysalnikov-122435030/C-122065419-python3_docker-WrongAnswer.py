def calculate_min_difference(n, m, x, y):
    # Общая площадь пирога
    total_area = n * m
    
    # Инициализация минимальной разницы
    min_difference = float('inf')
    
    # Разрез через левый нижний угол (0, 0)
    area_triangle_1 = (x * y) / 2
    remaining_area_1 = total_area - area_triangle_1
    min_difference = min(min_difference, abs(remaining_area_1 - area_triangle_1))
    
    # Разрез через верхний левый угол (0, m)
    area_triangle_2 = (x * (m - y)) / 2
    remaining_area_2 = total_area - area_triangle_2
    min_difference = min(min_difference, abs(remaining_area_2 - area_triangle_2))
    
    # Разрез через верхний правый угол (n, m)
    area_triangle_3 = ((n - x) * (m - y)) / 2
    remaining_area_3 = total_area - area_triangle_3
    min_difference = min(min_difference, abs(remaining_area_3 - area_triangle_3))
    
    # Разрез через нижний правый угол (n, 0)
    area_triangle_4 = ((n - x) * y) / 2
    remaining_area_4 = total_area - area_triangle_4
    min_difference = min(min_difference, abs(remaining_area_4 - area_triangle_4))

    return min_difference

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Нахождение и вывод минимальной разницы
min_difference = calculate_min_difference(n, m, x, y)
print(f"{min_difference:.3f}")

