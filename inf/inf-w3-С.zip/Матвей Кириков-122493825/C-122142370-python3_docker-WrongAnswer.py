def min_difference(n, m, x, y):
    # Площади для каждого разреза
    area1 = 0.5 * x * y
    area2 = 0.5 * (n - x) * (m - y)
    diff1 = abs(area1 - area2)

    area1 = 0.5 * x * (m - y)
    area2 = 0.5 * (n - x) * y
    diff2 = abs(area1 - area2)

    area1 = 0.5 * (n - x) * y
    area2 = 0.5 * x * (m - y)
    diff3 = abs(area1 - area2)

    area1 = 0.5 * (n - x) * (m - y)
    area2 = 0.5 * x * y
    diff4 = abs(area1 - area2)

    # Находим минимальную разницу
    min_diff = min(diff1, diff2, diff3, diff4)
    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с точностью 3 знака после запятой
print(f"{result:.3f}")
