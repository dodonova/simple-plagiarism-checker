def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Разрез из (0, 0)
    S1_1 = 0.5 * x * y
    S2_1 = total_area - S1_1
    D1 = abs(S1_1 - S2_1)
 # Разрез из (n, 0)
    S1_2 = 0.5 * (n - x) * y
    S2_2 = total_area - S1_2 D2 = abs(S1_2 - S2_2)
 # Разрез из (0, m)
    S1_3 = 0.5 * x * (m - y)
    S2_3 = total_area - S1_3 D3 = abs(S1_3 - S2_3)
 # Разрез из (n, m)
    S1_4 = 0.5 * (n - x) * (m - y)
    S2_4 = total_area - S1_4
    D4 = abs(S1_4 - S2_4)
 # Минимальная разница return min(D1, D2, D3, D4)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Печать результата с точностью 3 знака после запятой
print(f"{result:.3f}")