def min_difference(n, m, x, y):
    total_area = n * m
    
    # Углы
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
        # Площадь треугольника
        area1 = abs(cx * y - cy * x + n * (cy - y) + m * (x - cx)) / 2
        area2 = total_area - area1
        
        diff = abs(area1 - area2)
        min_diff = min(min_diff, diff)
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с заданной точностью
print(f"{result:.9f}")