import sys
import bisect

def calculate_max_area():
    input_data = sys.stdin.read().split()
    n = int(input_data[0])
    strip_lengths = list(map(int, input_data[1:n+1]))
    
    sorted_lengths = sorted(strip_lengths)
    
    count = [0] * (n + 2)
    for k in range(1, n + 1):
        idx = bisect.bisect_left(sorted_lengths, k)
        count[k] = n - idx
    
    max_area = 0
    
    for height in range(1, n + 1):
        max_width = min(count[height] - height, n - height)
        if max_width < 1:
            continue
        
        left, right = 1, max_width
        best_width = 0
        while left <= right:
            mid = (left + right) // 2
            if count[mid] >= height:
                best_width = mid
                left = mid + 1
            else:
                right = mid - 1
        
        if best_width > 0:
            area = height * best_width
            max_area = max(max_area, area)
    
    print(max_area)

if __name__ == "__main__":
    calculate_max_area()