def calculate_min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Функция для вычисления площади треугольника по формуле Герона
    def triangle_area(a, b, c):
        s = (a + b + c) / 2
        return (s * (s - a) * (s - b) * (s - c)) ** 0.5
    
    # Вычисляем разницу для каждого варианта разрезания
    differences = []
    
    # 1. Разрез из левого нижнего угла (0, 0) через точку (x, y)
    a = ((x - 0)  2 + (y - 0)  2) ** 0.5
    b = ((n - x)  2 + (y - 0)  2) ** 0.5
    c = ((n - x)  2 + (m - y)  2) ** 0.5
    d = ((x - 0)  2 + (m - y)  2) ** 0.5
    
    area1 = triangle_area(a, b, c)
    area2 = triangle_area(a, d, c)
    differences.append(abs(area1 - area2))
    
    # 2. Разрез из левого верхнего угла (0, m) через точку (x, y)
    a = ((x - 0)  2 + (y - m)  2) ** 0.5
    b = ((n - x)  2 + (y - m)  2) ** 0.5
    c = ((n - x)  2 + (m - y)  2) ** 0.5
    d = ((x - 0)  2 + (m - y)  2) ** 0.5
    
    area1 = triangle_area(a, b, c)
    area2 = triangle_area(a, d, c)
    differences.append(abs(area1 - area2))
    
    # 3. Разрез из правого нижнего угла (n, 0) через точку (x, y)
    a = ((x - n)  2 + (y - 0)  2) ** 0.5
    b = ((n - x)  2 + (y - 0)  2) ** 0.5
    c = ((n - x)  2 + (m - y)  2) ** 0.5
    d = ((x - n)  2 + (m - y)  2) ** 0.5
    
    area1 = triangle_area(a, b, c)
    area2 = triangle_area(a, d, c)
    differences.append(abs(area1 - area2))
    
    # 4. Разрез из правого верхнего угла (n, m) через точку (x, y)
    a = ((x - n)  2 + (y - m)  2) ** 0.5
    b = ((n - x)  2 + (y - m)  2) ** 0.5
    c = ((n - x)  2 + (m - y)  2) ** 0.5
    d = ((x - n)  2 + (m - y)  2) ** 0.5
    
    area1 = triangle_area(a, b, c)
    area2 = triangle_area(a, d, c)
    differences.append(abs(area1 - area2))
    
    # Находим минимальную разницу
    min_difference = min(differences)
    
    return min_difference

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление и вывод результата
result = calculate_min_difference(n, m, x, y)
print(f"{result:.3f}")