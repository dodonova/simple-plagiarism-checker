n, m = [int(i) for i in input().split()]
x, y = [int(i) for i in input().split()]

long_x = max(x, n-x)
long_y = max(y, m-y)

triangle = long_y * n**2 / (2 * long_x)

print(round(abs(n * m - 2 * triangle), 3))