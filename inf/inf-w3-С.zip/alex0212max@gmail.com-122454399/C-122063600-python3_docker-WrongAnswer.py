# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m

# Вычисляем площади для каждого угла
def calculate_difference(n, m, x, y):
    # Разрез из (0, 0)
    area1 = 0.5 * x * y
    area2 = total_area - area1
    diff1 = abs(area1 - area2)

    # Разрез из (n, 0)
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    diff2 = abs(area1 - area2)

    # Разрез из (0, m)
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)

    # Разрез из (n, m)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)

    return min(diff1, diff2, diff3, diff4)

# Вычисляем минимальную разницу
min_diff = calculate_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{min_diff:.3f}")

