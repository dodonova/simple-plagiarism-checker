n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m

# Вычисляем площади треугольников, образованных разрезами
# через каждый из углов:
area_1 = 0.5 * x * y # разрез через (0, 0)
area_2 = 0.5 * (n - x) * y # разрез через (n, 0)
area_3 = 0.5 * x * (m - y) # разрез через (0, m)
area_4 = 0.5 * (n - x) * (m - y) # разрез через (n, m)

# Находим минимальную разницу между площадями
min_diff = min(
    abs(area_1 - (total_area - area_1)),
    abs(area_2 - (total_area - area_2)),
    abs(area_3 - (total_area - area_3)),
    abs(area_4 - (total_area - area_4))
)

print(f"{min_diff:.3f}")
