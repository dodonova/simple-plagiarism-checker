n, m = map(int, input().split())
x, y = map(int, input().split())
ans = []
sp = m*n


if n*y > x*m:
    st = m*(m*x/y)/2
    ans.append(sp-2*st)
else:
    st = n*(n*y/x)/2
    ans.append(sp- 2*st)

if n*y > x*m:
    y_0 = (n*y-m*x)/(n-x)
    st = n*(m-y_0)/2
    ans.append(sp-2*st)
else:
    x_0 = (m * x - n * y) / (m - y)
    st = m*(n-x_0)/2
    ans.append(sp- 2*st)

y = m-y
if n*y > x*m:
    st = m*(m*x/y)/2
    ans.append(sp-2*st)
else:
    st = n*(n*y/x)/2
    ans.append(sp- 2*st)

x = n-x
y = m-y
if n*y > x*m:
    st = m*(m*x/y)/2
    ans.append(sp-2*st)
else:
    st = n*(n*y/x)/2
    ans.append(sp- 2*st)

print(f"{min(ans):.3f}")
