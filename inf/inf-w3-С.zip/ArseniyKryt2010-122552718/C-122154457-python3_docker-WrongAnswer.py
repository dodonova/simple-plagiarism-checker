def calculate_difference(n, m, x, y):
    total_area = n * m
    area1 = 0.5 * x * y
    diff1 = abs(area1 - (total_area - area1))
    area2 = 0.5 * (n - x) * y
    diff2 = abs(area2 - (total_area - area2))
    area3 = 0.5 * x * (m - y)
    diff3 = abs(area3 - (total_area - area3))
    area4 = 0.5 * (n - x) * (m - y)
    diff4 = abs(area4 - (total_area - area4))
    return min(diff1, diff2, diff3, diff4)
n, m = map(int, input().split())
x, y = map(int, input().split())
min_difference = calculate_difference(n, m, x, y)
print(f"{min_difference:.3f}")