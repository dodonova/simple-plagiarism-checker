def min_difference(n,m,x,y):
    total_area = n * m
    area1 = 0.5 * x * y
    area2 = total_area - area1
    min_diff = abs(area1-area2)
    area1 = 0.5 * (n-x)*y
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1-area2))
    area1 = 0.5 * x * (m-y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    area1 = 0.5 * (n-x)*(m-y)
    area2 = total_area - areae1
    min_diff = min(min_diff, abs(area1-area2))
    return min_diff

a = int(input())
b = int(input())
X = int(input()) 
y = int(input()) 
print(min_difference(a, b, c, d)) 