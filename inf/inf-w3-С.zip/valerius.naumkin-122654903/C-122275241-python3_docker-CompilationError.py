n, m = map(int, input().split())
x, y = map(int, input().split())
if 2*x > n:
    if 2*y > m:
        if y/x > m/n:
           print(n*m-x/y*m**2)
        else:
           
            