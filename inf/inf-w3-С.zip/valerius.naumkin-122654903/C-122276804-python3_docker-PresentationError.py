n, m = map(int, input().split())
x, y = map(int, input().split())
if 2*x > n:
    if 2*y > m:
        if y/x > m/n:
           print(n*m-x/y*m**2)
        else:
           print(n*m-y/x*n**2)
    else:
        if (m-y)/x > m/n:
           print(n*m-x/(m-y)*m**2)
        else:
           print(n*m-(m-y)/x*n**2)
        
           
            