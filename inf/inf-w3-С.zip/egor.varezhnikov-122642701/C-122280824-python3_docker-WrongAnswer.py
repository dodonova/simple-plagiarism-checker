def min_difference(n, m, x, y):
    areas = [
        x * y,                     
        x * (m - y),               
        (n - x) * y,              
        (n - x) * (m - y)         
    ]
    
    total_area = n * m
    min_diff = float('inf') 
    for area in areas:
        diff = abs(total_area - 2 * area)
        if diff < min_diff:
            min_diff = diff
    
    return min_diff
with open("input.txt", "r") as f:
    n, m = map(int, f.readline().split())
    x, y = map(int, f.readline().split())
result = min_difference(n, m, x, y)
with open("output.txt", "w") as f:
    f.write(f"{result:.3f}")
