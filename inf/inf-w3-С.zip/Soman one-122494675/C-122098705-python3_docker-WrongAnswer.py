def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def min_difference(n, m, x, y):

    total_area = n * m
    

    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        

        area1 = area_of_triangle(cx, cy, x, y, cx + (cy == 0) * n, cy + (cx == 0) * m)
        area2 = total_area - area1
        
        diff = abs(area1 - area2)
        min_diff = min(min_diff, diff)
    
    return min_diff


n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

result = min_difference(n, m, x, y)

print(f"{result:.6f}")