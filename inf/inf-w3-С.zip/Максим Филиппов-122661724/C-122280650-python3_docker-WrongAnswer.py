def calculate_area_difference(n, m, x, y):
    # Инициализация переменной для хранения минимальной разницы
    min_difference = float('inf')

    # Проверяем разрез из каждого угла
    # Угол (0, 0)
    area1 = 0.5 * x * y
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))

    # Угол (0, m)
    area1 = 0.5 * x * (m - y)
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))

    # Угол (n, 0)
    area1 = 0.5 * (n - x) * y
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))

    # Угол (n, m)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))
    
    return min_difference

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение минимальной разницы площадей
result = calculate_area_difference(n, m, x, y)

# Вывод результата с точностью 3 цифры после запятой
print(f"{result:.3f}")
