n, m = map(int, input().split())
x, y = map(int, input().split())
a = min(x, n - x, y, m - y)
b = n * m - a * a
print("{:.3f}".format(b / 2))