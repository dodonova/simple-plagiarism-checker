def min_difference(n, m, x, y):
    # Общая площадь пирога
    total_area = n * m
    
    # Углы
    corners = [
        (0, 0),    # Левый нижний угол
        (0, m),    # Левый верхний угол
        (n, 0),    # Правый нижний угол
        (n, m)     # Правый верхний угол
    ]
    
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
        # Площадь треугольника с вершинами (cx, cy), (x, y), (cx, m) или (n, cy)
        if cx == 0 and cy == 0:  # Левый нижний угол
            triangle_area = 0.5 * x * y
        elif cx == 0 and cy == m:  # Левый верхний угол
            triangle_area = 0.5 * x * (m - y)
        elif cx == n and cy == 0:  # Правый нижний угол
            triangle_area = 0.5 * (n - x) * y
        elif cx == n and cy == m:  # Правый верхний угол
            triangle_area = 0.5 * (n - x) * (m - y)
        
        # Площадь оставшейся части пирога
        remaining_area = total_area - triangle_area
        
        # Разница между площадями
        diff = abs(triangle_area - remaining_area)
        
        # Обновляем минимальную разницу
        min_diff = min(min_diff, diff)
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Нахождение минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{result:.3f}")