def area(x1, y1, x2, y2, x3, y3):
    """Вычисляет площадь треугольника по координатам вершин."""
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0)

def min_area_diff(n, m, x, y):
    """
    Находит минимальную разницу площадей между двумя частями пирога 
    после разрезания.
    """
    total_area = n * m

    # Вариант 1: Режем из левого верхнего угла
    area1 = area(0, 0, n, 0, x, y)
    diff1 = abs(area1 - (total_area - area1))

    # Вариант 2: Режем из правого верхнего угла
    area2 = area(n, m, n, 0, x, y)
    diff2 = abs(area2 - (total_area - area2))

    # Вариант 3: Режем из левого нижнего угла
    area3 = area(0, 0, 0, m, x, y)
    diff3 = abs(area3 - (total_area - area3))

    # Вариант 4: Режем из правого нижнего угла
    area4 = area(n, m, 0, m, x, y)
    diff4 = abs(area4 - (total_area - area4))

    return min(diff1, diff2, diff3, diff4)

# Считываем входные данные
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисляем и выводим результат
result = min_area_diff(n, m, x, y)
print(f"{result:.3f}")