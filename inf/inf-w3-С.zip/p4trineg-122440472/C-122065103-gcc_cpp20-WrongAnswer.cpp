#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>

using namespace std;

double min_difference(int n, int m, int x, int y) {
    double min_diff = numeric_limits<double>::max();

    // 1. Левый нижний угол (0, 0)
    double area1 = 0.5 * x * y;
    double area2 = n * m - area1;
    min_diff = min(min_diff, abs(area1 - area2));

    // 2. Правый нижний угол (n, 0)
    area1 = 0.5 * (n - x) * y;
    area2 = n * m - area1;
    min_diff = min(min_diff, abs(area1 - area2));

    // 3. Левый верхний угол (0, m)
    area1 = 0.5 * x * (m - y);
    area2 = n * m - area1;
    min_diff = min(min_diff, abs(area1 - area2));

    // 4. Правый верхний угол (n, m)
    area1 = 0.5 * (n - x) * (m - y);
    area2 = n * m - area1;
    min_diff = min(min_diff, abs(area1 - area2));

    return min_diff;
}

int main() {
    int n, m, x, y;
    
    // Чтение входных данных
    cin >> n >> m >> x >> y;

    // Вычисление минимальной разницы
    double result = min_difference(n, m, x, y);

    // Вывод результата с точностью 3 знака после запятой
    cout << fixed << setprecision(3) << result << endl;

    return 0;
}