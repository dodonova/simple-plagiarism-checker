def calculate_area_difference(n, m, x, y):
    """
    Вычисляет минимальную разницу площадей кусков пирога
    после разрезания одним прямым разрезом через угол и точку свечи.

    Args:
        n (int): Длина пирога.
        m (int): Ширина пирога.
        x (int): Координата x свечи.
        y (int): Координата y свечи.

    Returns:
        float: Минимальная разница площадей.
    """

    min_difference = float('inf')

    # Проверяем разрез из каждого угла
    for corner_x, corner_y in [(0, 0), (n, 0), (0, m), (n, m)]:
        # Площадь треугольника
        triangle_area = 0.5 * abs((corner_x - x) * (corner_y - y))
        # Площадь всего пирога
        total_area = n * m
        # Площадь четырехугольника
        quadrilateral_area = total_area - triangle_area
        # Разница площадей
        difference = abs(triangle_area - quadrilateral_area)

        # Обновляем минимальную разницу
        min_difference = min(min_difference, difference)

    return min_difference

# Читаем входные данные
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисляем и выводим результат
min_area_difference = calculate_area_difference(n, m, x, y)
print(f"{min_area_difference:.3f}")



