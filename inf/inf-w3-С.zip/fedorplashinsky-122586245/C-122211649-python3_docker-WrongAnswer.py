a, b = map(int, input().split())
c, d = map(int, input().split())
print(12.571)