nm=input().split()
for i in range(0,2):
	nm[1]=int(nm[1])
    xy=input().split()
    for i in range(0,2):
    xy[i]=int(xy[i])
if nm[0]<nm[1]:
	nm.sort(reverse=True)
    xy.append(xy[1])
    xy.append(xy[0])
    del xy[:2]
k1=xy[1]/xy[0]
k2(nm[0]-xy[0]/xy[1])
k3=(nm[0]-xy[0]/(nm[1]-xy[1])
k4(nm[1]-xy[1])/xy[0]
S1=0.5*nm[0]*k1*nm[0]
S2=0.5*nm[1]*k2*nm[1]
S3=0.5(nm[1]*k3*nm[1]
S4=0.5*nm[0]*k4*nm[0]
S=[abs(nm[0]*nm[1]-2*s1), abs(nm[0]*nm[1]-2*s2), abs(nm[0]*nm[1]-2*s3, abs(nm[0]*nm[1]-2*s4)]
print(f'{min(s):.3f}')
