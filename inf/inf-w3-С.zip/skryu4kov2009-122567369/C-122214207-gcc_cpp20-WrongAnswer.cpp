#include <iostream>
#include <cmath>
#include <algorithm>

int main() {
    int numberOfPoints, maxValue;
    std::cin >> numberOfPoints >> maxValue;
    int xCoordinate, yCoordinate;
    std::cin >> xCoordinate >> yCoordinate;
    
    long long constantValue = 3467537548654432643;
    double slope1 = static_cast<double>(yCoordinate) / xCoordinate;
    double slope2 = static_cast<double>(yCoordinate - maxValue) / xCoordinate;
    double slope3 = static_cast<double>(maxValue - yCoordinate) / (numberOfPoints - xCoordinate);
    double slope4 = static_cast<double>(-yCoordinate) / (numberOfPoints - xCoordinate);
    
    double intercept2 = yCoordinate - slope2 * xCoordinate;
    double intercept3 = yCoordinate - slope3 * xCoordinate;
    double intercept4 = yCoordinate - slope4 * xCoordinate;
    
    double result;
    
    if (std::abs(slope1) > static_cast<double>(maxValue) / numberOfPoints) {
        double intersectionX1 = static_cast<double>(maxValue) / slope1;
        double intersectionY1 = static_cast<double>(maxValue);
        double sum1 = ((numberOfPoints - intersectionX1) + numberOfPoints) * maxValue / 2;
        double sum2 = (maxValue * intersectionX1) / 2;
        result = std::abs(sum1 - sum2);
    } else {
        double intersectionX1 = numberOfPoints;
        double intersectionY1 = slope1 * numberOfPoints;
        double sum1 = ((maxValue - intersectionY1) + maxValue) * numberOfPoints / 2;
        double sum2 = (numberOfPoints * intersectionY1) / 2;
        result = std::abs(sum1 - sum2); //ayq
    }

    double result1;
    
    if (std::abs(slope2) > static_cast<double>(maxValue) / numberOfPoints) {
        double intersectionX2 = static_cast<double>(maxValue) / slope2;
        double intersectionY2 = 0;
        double sum21 = ((numberOfPoints - intersectionX2) + numberOfPoints) * maxValue / 2;
        double sum22 = (maxValue * intersectionX2) / 2;
        result1 = std::abs(sum21 - sum22);
    } else {
        double intersectionX2 = numberOfPoints;
        double intersectionY2 = slope2 * numberOfPoints + maxValue;
        double sum21 = (intersectionY2 + maxValue) * numberOfPoints / 2;
        double sum22 = (numberOfPoints * (maxValue - intersectionY2)) / 2;
        result1 = std::abs(sum21 - sum22);
    }

    double result2;
    
    if (std::abs(slope3) > static_cast<double>(maxValue) / numberOfPoints) {
        double intersectionX3 = (-intercept3) / slope3;
        double intersectionY3 = 0;
        double sum31 = ((intersectionX3) + numberOfPoints) * maxValue / 2;
        double sum32 = (maxValue * (numberOfPoints - intersectionX3)) / 2;
        result2 = std::abs(sum31 - sum32);
    } else {
        double intersectionX3 = numberOfPoints;
        double intersectionY3 = intercept3;
        double sum31 = ((maxValue - intersectionY3) + numberOfPoints) * maxValue / 2;
        double sum32 = (numberOfPoints * (maxValue - intersectionY3)) / 2;
        result2 = std::abs(sum31 - sum32);
    }

    double result3;
    
    if (std::abs(slope4) > static_cast<double>(maxValue) / numberOfPoints) {
        double intersectionX4 = (maxValue - intercept4) / slope4;
        double intersectionY4 = maxValue;
        double sum41 = ((intersectionX4) + numberOfPoints) * maxValue / 2;
        double sum42 = (maxValue * (numberOfPoints - intersectionY4)) / 2;
        result3 = std::abs(sum41 - sum42);
    } else {
        double intersectionX4 = 0;
        double intersectionY4 = intercept4;
        double sum41 = ((maxValue - intersectionY4) + maxValue) * numberOfPoints / 2;
        double sum42 = (numberOfPoints * intersectionY4) / 2;
        result3 = std::abs(sum41 - sum42);
    }

    std::cout << std::min({result, result1, result2, result3}) << std::endl;

    return 0;
}