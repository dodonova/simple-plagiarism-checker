def minimal_area_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m

    # Возможные разрезы и их вычисления
    area_differences = []

    # 1. Отрез через (0, 0)
    S1 = 0.5 * x * y
    S2 = total_area - S1
    area_differences.append(abs(S1 - S2))

    # 2. Отрез через (0, m)
    S1 = 0.5 * x * (m - y)
    S2 = total_area - S1
    area_differences.append(abs(S1 - S2))

    # 3. Отрез через (n, 0)
    S1 = 0.5 * (n - x) * y
    S2 = total_area - S1
    area_differences.append(abs(S1 - S2))

    # 4. Отрез через (n, m)
    S1 = 0.5 * (n - x) * (m - y)
    S2 = total_area - S1
    area_differences.append(abs(S1 - S2))

    # Минимальная разница между площадями
    return min(area_differences)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение минимальной разницы
result = minimal_area_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{result:.3f}")