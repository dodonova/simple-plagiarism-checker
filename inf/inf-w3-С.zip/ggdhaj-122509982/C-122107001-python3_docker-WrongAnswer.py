def min_difference(n, m, x, y):
    # Площадь пирога
    total_area = n * m

    # Площади, разделенные прямыми, проходящими через углы и точку (x, y)
    # Углы: (0, 0), (n, 0), (0, m), (n, m)

    # Площадь кусочка в 1-й четверти (угол (0, 0))
    area1 = (x * y) / 2

    # Площадь кусочка во 2-й четверти (угол (n, 0))
    area2 = (n * y - (x * y) / 2)

    # Площадь кусочка в 3-й четверти (угол (0, m))
    area3 = (x * (m - y)) / 2

    # Площадь кусочка в 4-й четверти (угол (n, m))
    area4 = (n * (m - y) - (x * (m - y)) / 2)

    # Рассчитываем разницу в площадях между кусками
    differences = [
        abs((area1 + area4) - (area2 + area3)),
        abs((area2 + area3) - (area1 + area4)),
        abs((area1 + area2) - (area3 + area4)),
        abs((area3 + area4) - (area1 + area2))
    ]

    return min(differences)

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение минимальной разницы и вывод
result = min_difference(n, m, x, y)
print(f"{result:.3f}")