def min_difference(n, m, x, y):
    areas = []
    
    # Прямая через A(0, 0)
    area1 = (x * y) / 2
    area2 = (n * m - area1)
    areas.append(abs(area1 - area2))
    
    # Прямая через B(n, 0)
    area1 = ((n - x) * y) / 2
    area2 = (n * m - area1)
    areas.append(abs(area1 - area2))
    
    # Прямая через C(n, m)
    area1 = ((n - x) * (m - y)) / 2
    area2 = (n * m - area1)
    areas.append(abs(area1 - area2))
    
    # Прямая через D(0, m)
    area1 = (x * (m - y)) / 2
    area2 = (n * m - area1)
    areas.append(abs(area1 - area2))
    
    return min(areas)

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получаем ответ
result = min_difference(n, m, x, y)
print(result)