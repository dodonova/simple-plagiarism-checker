# Чтение размеров пирога и координат свечки
n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь пирога
total_area = n * m

# Функция для вычисления площади одного из кусочков
def area_of_piece(x1, y1, x2, y2):
    return abs(x2 - x1) * abs(y2 - y1)

# Инициализация минимальной разницы
min_difference = float('inf')

# Пробегаем по всем углам пирога
corners = [(0, 0), (n, 0), (0, m), (n, m)]

for cx, cy in corners:
    # Площадь кусочка, образованного разрезом через (cx, cy) и свечку (x, y)
    piece1_area = area_of_piece(cx, cy, x, y)
    piece2_area = total_area - piece1_area

    # Вычисляем разницу между площадями
    difference = abs(piece1_area - piece2_area)

    # Обновляем минимальную разницу
    min_difference = min(min_difference, difference)

# Вывод минимальной разницы с нужной точностью
print(f"{min_difference:.6f}")