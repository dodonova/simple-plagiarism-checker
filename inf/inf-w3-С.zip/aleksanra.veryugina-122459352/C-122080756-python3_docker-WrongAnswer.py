n, m = map(int, input().split())
x, y = map(int, input().split())

s1 = n*n*y/x/2
s2 = n*m - s1
s_a = abs(s1-s2)

y1 = n-x
#x1 = y
x1 = m-y
s1 = m*m*y1/x1/2
s2 = n*m - s1
s_b = abs(s1-s2)

y1 = n-x
x1 = y
#x1 = m-y
s1 = m*m*y1/x1/2
s2 = n*m - s1
s_b2 = abs(s1-s2)




#y1 = m-x
#x1 = n-y
#s1 = m*m*y1/x1/2
y1 = m-y
x1 = n-x
s1 = n*n*y1/x1/2
s2 = n*m - s1
s_c = abs(s1-s2)

y1 = m-y
x1 = x
s1 = n*n*y1/x1/2
s2 = n*m - s1
s_d = abs(s1-s2)


y1 = y
x1 = n-x
s1 = n*n*y1/x1/2
s2 = n*m - s1
s_e = abs(s1-s2)


y1 = m-y
x1 = n-x
s1 = n*n*y1/x1/2
s2 = n*m - s1
s_e2 = abs(s1-s2)




s = min(s_a, s_b, s_b2, s_c, s_d, s_e, s_e2)

print(s)