n, m = input().split()
x, y = input().split()
n, m, x, y = int(n), int(m), int(x), int(y)

square = n * m

difference1 = square - n * n / x * y
difference2 = square - n * n / x * (m - y)
difference3 = square - m * m / y * x
difference4 = square - m * m / y * (n - x)
differences1 = [difference1, difference2, difference3, difference4]

differences2 = []
for difference in differences1:
    if difference >= 0:
        differences2.append(difference)

print(round(min(differences2), 3))
