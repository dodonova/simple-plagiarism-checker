x1, y1 = map(int, input().split())
x2, y2 = map(int, input().split())


def get(x, y):
    x = x1 - x
    y = y1 - y
    if x != 0:
        y = abs(y1 - y2) * (x1 / x2)
    else:
        x = abs(x1 - x2) * (y1 / y2)
    S_tre = x * y / 2
    S_chet = x1 * y1 - S_tre
    return abs(S_tre - S_chet)


angles = ((0, 0), (0, y1), (x1, 0), (x1, y1))
print(int((min([get(*e) for e in angles]) * 1000 + 0.5)) / 1000)
