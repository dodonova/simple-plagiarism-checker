def calculate_area_difference(n, m, x, y):
    total_area = n * m
    areas = []
    area1 = (x * y) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    area1 = ((n - x) * y) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    area1 = (x * (m - y)) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    area1 = ((n - x) * (m - y)) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    return min(areas)

def main():
    n, m = map(int, input().split())
    x, y = map(int, input().split())
    min_difference = calculate_area_difference(n, m, x, y)
    print(f"{min_difference:.3f}")

if __name__ == "__main__":
    main()
