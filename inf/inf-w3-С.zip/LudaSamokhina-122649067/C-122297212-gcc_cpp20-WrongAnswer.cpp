#include <iostream>

using namespace std;

int main()
{
    int x,y,m,n,nm,ny,mx,m_y,n_x,t,nx,my;
    double d1=0,d2=0;
    cin >> n >> m>> x>> y;
    nm=n*m;
    nx=n*y;
    mx=m*x;
    m_y=m-y;
    n_x=n-x;
    t=mx-ny;
    if(t>0)//mx>ny
        d1=min(m*t/m_y,n*t/x);
    else
        d1=min(-m*t/y,-n*t/n_x);
    t=nx+my-nm;
    if(t>0)//mx>ny
        d2=min(m*t/m_y,n*t/x);
    else
        d2=min(-m*t/m_y,-n*t/n_x);
    cout << min(d1,d2);
    return 0;
}
