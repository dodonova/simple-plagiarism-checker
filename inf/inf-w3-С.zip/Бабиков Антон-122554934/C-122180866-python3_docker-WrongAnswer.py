def area_difference(n, m, x, y):
    
    angles = [(0, 0), (0, m), (n, 0), (n, m)]
    minD = float('inf')

    for corner in angles:
        cx, cy = corner
        
        area1 = abs(cx * y - cy * x) / 2
        area2 = (n * m) - area1
        diff = abs(area1 - area2)
        minD = min(minD, diff)

    return minD


n, m = map(int, input().split())
x, y = map(int, input().split())


result = area_difference(n, m, x, y)
print(result)