def area_difference(n, m, x, y):
    ang = [(0, 0), (0, m), (n, 0), (n, m)]
    minD = float('inf')

    for corner in angles:
        cx, cy = crn

        ar1 = abs(cx * y - cy * x) / 2
        ar2 = (n * m) - ar1
        diff = abs(ar1 - ar2)
        minD = min(minD, diff)

    return minD


n, m = map(int, input().split())
x, y = map(int, input().split())


res = area_difference(n, m, x, y)
print(res)