def area_difference(a, b, c, d):
    angles = [(0, 0), (0, b), (a, 0), (a, b)]
    min_diff = float('inf')

    for corner in angles:
        cx, cy = corner
        area1 = abs(cx * d - cy * c) / 2
        area2 = (a * b) - area1
        diff = abs(area1 - area2)
        min_diff = min(min_diff, diff)

    return min_diff


a, b = map(int, input().split())
c, d = map(int, input().split())


result = area_difference(a, b, c, d)
print(f"{result:.3f}")