n, m = map(int, input().split())
x, y = map(int, input().split())
total_area = n * m
triangle_area = 0.5 * x * y
other_triangle_area = total_area - triangle_area
difference = abs(triangle_area - other_triangle_area)

print(difference)