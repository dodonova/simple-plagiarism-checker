def area_split(n, m, cx, cy):
    total_area = n * m
    corners = [(0, 0), (0, m), (n, 0), (n, m)]

    min_difference = float('inf')

    for (corner_x, corner_y) in corners:
        dx = corner_x - cx
        dy = corner_y - cy
        s1 = abs(dx * cy + corner_x * (m - cy) + n * (corner_y - dy)) / 2
        s2 = total_area - s1

        difference = abs(s1 - s2)
        min_difference = min(min_difference, difference)

    return min_difference
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())
result = area_split(n, m, x, y)
print(f"{result:.3f}")