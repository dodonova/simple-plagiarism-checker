x_piroga, y_piroga = map(int, input().split())
x_svechi, y_svechi = map(int, input().split())
sp = x_piroga * y_piroga
k1, k2, k3, k4 = (x_svechi/y_svechi, (x_piroga-x_svechi)/y_svechi, (x_piroga-x_svechi)/(y_piroga-y_svechi),
                  x_svechi/(y_piroga-y_svechi))
s11_s12, s21_s22, s31_s32, s41_s42 = (-(y_piroga**2*k1/2)+(sp - (y_piroga**2*k1/2)), -(y_piroga**2*k2/2)+
                                      (sp - (y_piroga**2*k2/2)), -(x_piroga**2/(2*k3))+(sp - x_piroga**2/(2*k3)),
                                      -(x_piroga**2/(2*k4))+(sp - x_piroga**2/(2*k4)))
otvet = round(min(abs(s11_s12), abs(s21_s22), abs(s31_s32), abs(s41_s42)), 3)
if otvet % 1 == 0:
    print(f'{otvet}00')
elif int(otvet % 0.1) == 0:
    print(f'{otvet}00')
elif int(otvet % 0.01) == 0:
    print(f'{otvet}0')
else:
    print(otvet)