def minimum_difference(n, m, x, y):
    # Площадь пирога
    total_area = n * m

    # Площади двух частей при различных разрезах
    areas = [
        abs((x * m) / 2.0 - (total_area - (x * m) / 2.0)),    # Срез через (0,0)
        abs((x * (m - y) / 2.0) - (total_area - (x * (m - y) / 2.0))),    # Срез через (0,m)
        abs(((n - x) * y / 2.0) - (total_area - ((n - x) * y / 2.0))),    # Срез через (n,0)
        abs(((n - x) * (m - y) / 2.0) - (total_area - ((n - x) * (m - y) / 2.0)))     # Срез через (n,m)
    ]

    # Минимальная разница
    return min(areas)

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Нахождение минимальной разницы
result = minimum_difference(n, m, x, y)

# Вывод результата с точностью до трех знаков
print(f"{result:.3f}")


