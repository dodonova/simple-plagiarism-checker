def minimum_difference(n, m, x, y):
    areas = []
    
    # Рассмотрим разрез из угла (0, 0)
    area1 = x * y
    area2 = n * m - area1
    areas.append(abs(area1 - area2))
    
    # Рассмотрим разрез из угла (n, 0)
    area1 = (n - x) * y
    area2 = n * m - area1
    areas.append(abs(area1 - area2))
    
    # Рассмотрим разрез из угла (n, m)
    area1 = (n - x) * (m - y)
    area2 = n * m - area1
    areas.append(abs(area1 - area2))
    
    # Рассмотрим разрез из угла (0, m)
    area1 = x * (m - y)
    area2 = n * m - area1
    areas.append(abs(area1 - area2))
    
    return min(areas)

# Чтение данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Нахождение минимальной разницы
result = minimum_difference(n, m, x, y)

# Вывод результата
print(f"{result:.3f}")
