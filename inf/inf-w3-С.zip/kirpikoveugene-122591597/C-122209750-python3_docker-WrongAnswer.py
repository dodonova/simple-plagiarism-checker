def find_minimum_difference(n, m, x, y):
    # Calculate the areas of two pieces
    area1 = x * m / 2
    area2 = y * n / 2

    # Calculate the difference
    diff = abs(area1 - area2)
    
    return diff

# Input: sizes of the pie and candle coordinates
n, m = 8, 5
x, y = 7, 2

# Output: minimum difference
print(f"{find_minimum_difference(n, m, x, y):.3f}")

