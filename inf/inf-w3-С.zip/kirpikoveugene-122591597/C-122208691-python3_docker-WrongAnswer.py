def minimum_difference(n, m, x, y):
    # Площади от вертикальных разрезов
    diff1 = abs(n * y - (n * m - n * y))
    diff2 = abs(x * m - (n * m - x * m))
    
    return min(diff1, diff2) / 2

# Чтение данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Нахождение минимальной разницы
result = minimum_difference(n, m, x, y)

# Вывод результата
print(f"{result:.3f}")
