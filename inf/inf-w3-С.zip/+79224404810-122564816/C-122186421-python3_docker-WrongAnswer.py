def area(a, b, c, d):
    return 0.5 * abs(a * d - b * c)

def min_difference(n, m, x, y):
    # Углы: (0, 0), (0, m), (n, m), (n, 0)
    corners = [(0, 0), (0, m), (n, m), (n, 0)]
    
    min_diff = float('inf')
    
    for cx, cy in corners:
        # Площадь треугольника, образованного углом и свечкой
        triangle_area = area(cx, cy, x, y)
        
        # Площадь всего пирога
        total_area = n * m
        
        # Площадь второй части
        second_area = total_area - triangle_area
        
        # Разница
        diff = abs(second_area - triangle_area)
        
        # Проверяем минимальную разницу
        min_diff = min(min_diff, diff)
    
    return min_diff

# Ввод данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Расчет минимальной разницы
difference = min_difference(n, m, x, y)

# Вывод результата с точностью до 3 знаков после запятой
print(f"{difference:.3f}")
