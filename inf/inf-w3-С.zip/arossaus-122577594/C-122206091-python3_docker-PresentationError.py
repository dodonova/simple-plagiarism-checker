def min_difference(n, m, x, y):
    total_area = n * m
    area1 = 0.5 * x * y
    area2 = total_area - area1
    min_diff = abs(area1 - area2)
    return min_diff


n, m = map(int, input("Введите ширину и высоту пирога: ").split())
x, y = map(int, input("Введите координаты свечки (x y): ").split())


print(f"{min_difference(n, m, x, y):.3f}")