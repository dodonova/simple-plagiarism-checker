def min_difference(n, m, x, y):


  Returns:

  area1 = 0.5 * x * y
 (n * m - area1)   area1
  min_diff = min(abs(area1 - (n * m - area1)), abs((n * m - area1) - area1))

  return min_diff

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вывод результата
print(f"{min_difference(n, m, x, y):.3f}")
