def main():
    # Ввод значений
    n, m, x1, y1 = map(float, input("Введите n, m, x1, y1 через пробел: ").strip().split())
    
    # Общая площадь
    s = n * m
    
    # Вычисление площади s1
    if n * y1 / x1 <= m:
        s1 = (n * n * y1 / x1)
    else:
        s1 = (m * m * x1 / y1)

    # Вычисление площади s2
    if (m - y1) * n / x1 >= 0:
        s2 = n * (m - y1) * n / x1
    else:
        s2 = (m * m * x1 / (m - y1))

    # Вычисление площади s3
    temp_s3 = (n - x1) * (n * (m - y1) / (n - x1) - m) / (m - y1)
    if temp_s3 >= 0:
        s3 = m * (n - temp_s3)
    else:
        s3 = (n * n * (m - y1) / (n - x1))

    # Вычисление площади s4
    temp_s4 = -1 * (n - x1) * (m - n * y1 / (n - x1)) / y1
    if temp_s4 >= 0:
        s4 = m * (n + temp_s4)
    else:
        s4 = (n * n * y1 / (n - x1))

    # Находим минимальное отклонение
    min_difference = min(abs(s - s1), abs(s - s2), abs(s - s3), abs(s - s4))

    # Вывод результата с заданной точностью
    print(f"{min_difference:.6f}")

if __name__ == "__main__":
    main()
