n,m=map(int,input().split())
x,y=map(int,input().split())
p=[]
if ((n*y)/x)<=m:
    t=(n*(m*x-n*y))/x
    p.append(t)
else:
    t=(m*(n*y-m*x))/y
    p.append(t)
if ((n*y)/(n-x))<=m:
    t=(n*(m*n-m*x-2*n*y))/(n-x)
    p.append(t)
else:
    t=(m*n*y-2*m*m*(n-x))/y
    p.append(t)
if ((n*(y-m)+m*x)/x)>=0:
    t=(m*n*x-2*n*n*(m-y))/x
    p.append(t)
else:
    t=(m*n*(m-y)-2*m*m*x)/(m-y)
    p.append(t)
if (((n*(y-m))/(n-x))+m)>=0:
    t=(m*n*(n-x)-2*n*n*(m-y))/(n-x)
    p.append(t)
else:
    t=(m*n*(m-y)-2*m*m*(n-x))/(m-y)
    p.append(t)
print(min(p))