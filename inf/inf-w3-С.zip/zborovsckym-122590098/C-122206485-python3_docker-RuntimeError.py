def calculate_min_difference(x1, y1, x2, y2, x_candle, y_candle):
  area = (x2 - x1) * (y2 - y1)
  if x1 <= x_candle <= x2 and y1 <= y_candle <= y2:
    area1 = (x_candle - x1) * (y2 - y1)
    area2 = (x2 - x_candle) * (y2 - y1)
    diff1 = abs(area1 - area2)
    area1 = (x2 - x1) * (y_candle - y1)
    area2 = (x2 - x1) * (y2 - y_candle)
    diff2 = abs(area1 - area2)
    return min(diff1, diff2)
  else:
    return 0
x1, y1 = map(int, input().split())
x2, y2 = map(int, input().split())
x_candle, y_candle = map(int, input().split())
min_difference = calculate_min_difference(x1, y1, x2, y2, x_candle, y_candle)
print(f"{min_difference:.3f}")