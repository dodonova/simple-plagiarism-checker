import java.util.Scanner;

public class PieCut {
    public static double calculateArea(double x1, double y1, double x2, double y2, double x3, double y3) {
        return Math.abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0;
    }

    public static double findMinimumDifference(int n, int m, int x, int y) {
        int[][] corners = {{0, 0}, {n, 0}, {0, m}, {n, m}};
        double fullArea = n * m;
        double minDifference = Double.MAX_VALUE;
        
        for (int[] corner : corners) {
            double triangleArea = calculateArea(corner[0], corner[1], x, y, n, m);
            double remainingArea = fullArea - triangleArea;
            double difference = Math.abs(remainingArea - triangleArea);
            minDifference = Math.min(minDifference, difference);
        }
        
        return minDifference;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        System.out.printf("%.3f%n", findMinimumDifference(n, m, x, y));
    }
}