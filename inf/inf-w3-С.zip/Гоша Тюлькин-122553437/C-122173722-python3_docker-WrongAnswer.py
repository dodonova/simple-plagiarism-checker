def min_difference(n, m, x, y):
    # Общая площадь пирога
    total_area = n * m
    
    # Вычисляем площади кусочков при разрезах
    areas = []

    # Разрез через (0, 0)
    area1 = (x * y) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Разрез через (0, m)
    area1 = (x * (m - y)) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Разрез через (n, 0)
    area1 = ((n - x) * y) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Разрез через (n, m)
    area1 = ((n - x) * (m - y)) / 2
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Возвращаем минимальную разницу
    return min(areas)

# Ввод данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с точностью 3 знака после запятой
print(f"{result:.3f}")