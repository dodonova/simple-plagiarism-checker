n, m = map(float, input().split())
x, y = map(float, input().split())

# Вычисляем разницу площадей для каждого угла
dA1 = abs(n * m - x * y)
dA2 = abs(n * m - (n - x) * y)
dA3 = abs(n * m - x * (m - y))
dA4 = abs(n * m - (n - x) * (m - y))

# Находим минимальную разницу
min_difference = min(dA1, dA2, dA3, dA4)

# Выводим результат с точностью до трех знаков после запятой
print(f"{min_difference:.3f}")