#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double number1, number2, number3, number4;
    cin >> number1 >> number2;
    cin >> number3 >> number4;

    double long1 = number1 - number3 > number3 ? number1 - number3 : number3;
    double high = number2 - number4 > number4 ? number2 - number4 : number4;
    double sqere1 = high / long1 * number1 * number1 * 0.5;
    double sqere2 = number1 * number2 - sqere1;
    double result = sqere1 - sqere2 >= 0 ? sqere1 - sqere2 : -1 * (sqere1 - sqere2);
    
    cout << round(result * 1000) / 1000 << endl;
    
    return 0;
}