def min_difference(n, m, x, y):
    A1 = 0.5 * (n - x) * y
    B1 = 0.5 * x * y
    diff1 = abs(A1 - B1)
    
    A2 = 0.5 * x * (m - y)
    B2 = 0.5 * (n - x) * (m - y)
    diff2 = abs(A2 - B2)
    
    A3 = 0.5 * (n - x) * (m - y)
    B3 = 0.5 * x * (m - y)
    diff3 = abs(A3 - B3)
    
    A4 = 0.5 * x * y
    B4 = 0.5 * (n - x) * y
    diff4 = abs(A4 - B4)
    
    return min(diff1, diff2, diff3, diff4)
n, m = map(int, input().split())
x, y = map(int, input().split())
print(f"{min_difference(n, m, x, y):.3f}")
