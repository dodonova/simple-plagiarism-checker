import math

def get_cut_line(n, m, x, y):
    if x == n or y == m:
        return [(x, y)]
    dx = abs(x - n // 2)
    dy = abs(y - m // 2)
    if dx == 0:
        line = [(n // 2, y), (n, y)]
    elif dy == 0:
        line = [(x, m // 2), (x, m)]
    else:
        angle = math.atan2(dy, dx)
        d = max(dx, dy)
        distance = d / math.sin(angle)
        point = (distance * math.cos(angle) + n // 2, distance * math.sin(angle) + m // 2)
        line = [(point[0], point[1]), (n, m)]
    return line

def difference_between_areas(n, m, cut_line):
    area1 = abs(n * m - ((n - cut_line[0][0]) * (m - cut_line[0][1])) - ((n - cut_line[1][0]) * (m - cut_line[1][1])))
    area2 = abs(n * m - ((n - cut_line[0][0]) * (m - cut_line[0][1])) + ((n - cut_line[1][0]) * (m - cut_line[1][1])))
    return min(area1, area2) - max(area1, area2)

def main():
    import sys
    input = sys.stdin.read
    data = input().strip()
    n, m = map(int, data.split())
    x, y = map(int, data.split())
    
    cut_line = get_cut_line(n, m, x, y)
    minimum_difference = difference_between_areas(n, m, cut_line)
    
    print(f"{minimum_difference:.3f}")

if __name__ == "__main__":
    main()