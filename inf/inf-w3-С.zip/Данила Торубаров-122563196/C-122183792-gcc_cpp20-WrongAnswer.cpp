#include <iostream>
#include <cmath>
using namespace std;
int main () {
    float n, m, x, y;
    cin >> n >> m >> x >> y;
    float tg=y/x;
    float h=tg*n;
    float s1=h*n;
    float s2=((m-h)+m)/2*n;
    float res1=abs(s2-s1);
    float tg1=(m-y)/x;
    float h1=tg1*n;
    float s3=n*h1;
    float s4=((m-h1)+m)/2*n;
    float res2=abs(s4-s3);
    float tg2=(n-x)/(m-y);
    float h2=tg2*m;
    float s5=m*h2;
    float s6=(n+(n-h2))/2*m;
    float res3=abs(s6-s5);
    float tg3=(n-x)/y;
    float h3=tg3*m;
    float s7=m*(n-h3);
    float s8=(n+n-h)/2*m;
    float res4=abs(s8-s7);
    cout << min(min(res1,res2),min(res3,res4));
    return 0;
}