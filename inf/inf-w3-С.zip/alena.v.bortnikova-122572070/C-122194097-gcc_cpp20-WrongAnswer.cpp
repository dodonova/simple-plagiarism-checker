#include "bits/stdc++.h"
using namespace std;
int main() {
    float n, m, x, y;
    cin>>n>>m>>x>>y;
    float s_min;
    for(int i=0; i<4; i++){
        float X,Y;
        if(i==0) X=0, Y=0;
        else if(i==1) X=n-1, Y=0;
        else if(i==2) X=n-1, Y=m-1;
        else if(i==3) X=0, Y=m-1;
        float k=(Y-y)/(X-x), b=Y-k*X;
        float y1; if(Y==0) y1=m; else y1=0;
        float x1=(y1-b)/k;
        float s;
        if(x1>=0) s=x1*m;
        else{
            if(y1>Y) y1=(y1-Y)*n/(n+x1)+Y;
            else y1=Y-(Y-y1)/(n+x1)*n;
            s=y1*n;
        }
        if(i==0 or s<s_min) s_min=s;
    }
    cout<<s_min<<setprecision(4);
}