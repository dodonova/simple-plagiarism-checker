#include<iostream>
using namespace std;
int main()
{
 int m, n, x, y, X, Y;
 double a, a1;
 cin >> m >> n;
 cin >> X >> Y;
 x = X;
 y = Y;
 if (x > y) a = m*n - 2*(  ( ((x*y)/2) * (m*m) )/(x*x)  );
 else a = m*n - 2*(  ( ((x*y)/2) * (n*n) )/(y*y)  );

 x = m - X;
 y = Y;
 if (x > y) a1 = m*n - 2*(  ( ((x*y)/2) * (m*m) )/(x*x)  );
 else a1 = m*n - 2*(  ( ((x*y)/2) * (n*n) )/(y*y)  );
 if(a1 < a) a = a1;

 x = X;
 y = n - Y;
 if (x > y) a1 = m*n - 2*(  ( ((x*y)/2) * (m*m) )/(x*x)  );
 else a1 = m*n - 2*(  ( ((x*y)/2) * (n*n) )/(y*y)  );
 if(a1 < a) a = a1;

 x = m - X;
 y = n - Y;
 if (x > y) a1 = m*n - 2*(  ( ((x*y)/2) * (m*m) )/(x*x)  );
 else a1 = m*n - 2*(  ( ((x*y)/2) * (n*n) )/(y*y)  );
 if(a1 < a) a = a1;

 cout << a;
}