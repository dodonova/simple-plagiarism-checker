#include<iostream>
using namespace std;
int main()
{
 double m, n, x, y, X, Y;
 double a, a1, s;
 cin >> m >> n >> X >> Y;
 x = X;
 y = Y;
 s = x*y/2;
 if (x < y) { a = m*n - 2*(  ( s * (m*m) )/(x*x)  );}
 else {a = m*n - 2*(  ( s * (n*n) )/(y*y)  );}

 x = m - X;
 y = Y;
 s = x*y/2;
 if (x < y) {a1 = m*n - 2*(  ( s * (m*m) )/(x*x)  );}
 else {a1 = m*n - 2*(  ( s * (n*n) )/(y*y)  );}
 if(a1 < a) {a = a1;}

 x = X;
 y = n - Y;
 s = x*y/2;
 if (x < y) {a1 = m*n - 2*(  ( s * (m*m) )/(x*x)  );}
 else {a1 = m*n - 2*(  ( s * (n*n) )/(y*y)  );}
 if(a1 < a) {a = a1;}

 x = m - X;
 y = n - Y;
 s = x*y/2;
 if (x < y) {a1 = m*n - 2*(  ( s * (m*m) )/(x*x)  );}
 else {a1 = m*n - 2*(  ( s * (n*n) )/(y*y)  );}
 if(a1 < a) {a = a1;}

 cout << a;
}