n, m = list(map(int, input().split()))
x, y =list(map(int, input().split()))
q = 3467537548654432643
a1,a2,a3,a4=(y/x), ((y-m)/x), ((m-y)/(n-x)), ((-y)/(n-x))
b2 = y-a2*x
b3 = y-a3*x
b4 = y - a4*x
if abs(a1) > m/n:
    x1, y1 = m/a1, m
    s11 = ((n-x1) + (n)) * m / 2
    s12 = (m * x1) / 2
    r = abs(s11 - s12)
else:
    x1, y1 = n, a1*n
    s11 = ((m-y1)+(m))*n/2
    s12 = (n*y1)/2
    r = abs(s11-s12)#ayq


if abs(a2) > m/n:
    x2, y2 = (m)/a2, 0
    s21 = ((n-x2) + (n)) * m / 2
    s22 = (m * x2) / 2
    r1 = abs(s21 - s22)

else:
    x2, y2 = n, a2*n+m
    s21 = ((y2) + (m)) * n / 2
    s22 = (n * (m-y2)) / 2
    r1 = abs(s21 - s22)


if abs(a3) > m/n:
    x3, y3 = (-b3)/a3, 0
    s31 = ((x3) + (n)) * m / 2
    s32 = (m * (n-x3)) / 2
    r2 = abs(s31 - s32)

else:
    x3, y3 = n, b3
    s31 = ((y3) + (m)) * n / 2
    s32 = (n * (m-y3)) / 2
    r2 = abs(s31 - s32)

if abs(a4) > m/n:
    x4, y4 = (m-b4)/a4, m
    s41 = ((x4) + (n)) * m / 2
    s42 = (m * (n-y4)) / 2
    r3 = abs(s41 - s42)

else:
    x4, y4 = 0, b4
    s41 = ((m - y4) + (m)) * n / 2
    s42 = (n * y4) / 2
    r3 = abs(s41 - s42)

print(min(r,r1,r2,r3))