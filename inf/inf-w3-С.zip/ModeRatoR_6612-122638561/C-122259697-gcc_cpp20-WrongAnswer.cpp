#include <iostream>
#include <iomanip>

using namespace std;

double mainFunc() {
    int n, m;
    cin >> n >> m;
    int x, y;
    cin >> x >> y;
    
    double x1 = static_cast<double>(m) * x / y;
    double y1 = static_cast<double>(n) * y / x;
    double x2 = (-static_cast<double>(m) * x) / (y - m);
    double y2 = n * static_cast<double>(y - m) / x + m;
    
    double p, r;
    if (x1 == n) {
        return 0;
    } else if (x1 < n) {
        p = (2 * n - x1) * m / 2;
    } else {
        p = (2 * m - y1) * n / 2;
    }

    if (x2 == n) {
        return 0;
    } else if (x2 < n) {
        r = (2 * n - x2) * m / 2;
    } else {
        r = (y2 + m) * n / 2;
    }
    
    return min(abs(n * m - 2 * p), abs(n * m - 2 * r));
}

int main() {
    cout << fixed << setprecision(3) << mainFunc() << endl;
    return 0;
}