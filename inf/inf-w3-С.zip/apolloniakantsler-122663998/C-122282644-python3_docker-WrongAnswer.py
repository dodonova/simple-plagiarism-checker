def min_difference(a, b):
    min_diff = float('inf')
    
    for x in range(a + 1):
        for y in range(b + 1):
            # Проверяем только если свечка внутри пирога
            if x == 0 and y == 0:
                continue
            
            # Площадь всего пирога
            total_area = a * b
            
            # Находим пересечения
            if x > 0:
                y_intersect = (b * x) / y if y != 0 else float('inf')
                if 0 <= y_intersect <= b:
                    area1 = (x * y_intersect) / 2
                    area2 = total_area - area1
                    diff = abs(area1 - area2)
                    min_diff = min(min_diff, diff)
            
            if y > 0:
                x_intersect = (a * y) / x if x != 0 else float('inf')
                if 0 <= x_intersect <= a:
                    area1 = (y * x_intersect) / 2
                    area2 = total_area - area1
                    diff = abs(area1 - area2)
                    min_diff = min(min_diff, diff)

    return min_diff

# Чтение входных данных
a, b = map(int, input().strip().split())
result = min_difference(a, b)

# Вывод результата
print(result)