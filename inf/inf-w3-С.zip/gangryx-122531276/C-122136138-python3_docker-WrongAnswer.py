def calculate_area_difference(n, m, x, y):

    total_area = n * m
    
    area1 = x * y
    area2 = total_area - area1
    diff1 = abs(area1 - area2)
    
    area1 = (n - x) * y
    area2 = total_area - area1
    diff2 = abs(area1 - area2)
    
    area1 = x * (m - y)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)
    
    area1 = (n - x) * ( m - y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)
    
    return min(diff1, diff2, diff3, diff4)
    
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

min_difference = calculate_area_difference(n, m, x, y)

print(f"{min_difference:.3f}")