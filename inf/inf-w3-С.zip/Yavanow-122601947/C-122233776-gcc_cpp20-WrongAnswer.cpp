#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    double n, m, x, y;
    cin >> n >> m >> x >> y;
    
    vector<pair<double, double>> corners = {
        {0.0, 0.0},
        {n, 0.0},
        {0.0, m},
        {n, m}
    };
    
    double total_area = n * m;
    double min_diff = 10^18;
    
    for(auto &c: corners){
        double c_x = c.first;
        double c_y = c.second;
        double dx = x - c_x;
        double dy = y - c_y;
        double t_x, t_y;
        
        if(dx > 10^-9){
            t_x = (n - c_x)/dx;
        }
        else{
            t_x = (-c_x)/dx;
        }
        
        if(dy > 10^-9){
            t_y = (m - c_y)/dy;
        }
        else{
            t_y = (-c_y)/dy;
        }
        
        double area1;
        if(t_x < t_y - 10^-9){
            // Exits on vertical side
            double y_exit = c_y + t_x * dy;
            area1 = 0.5 * n * y_exit;
        }
        else{
            // Exits on horizontal side
            double x_exit = c_x + t_y * dx;
            area1 = 0.5 * m * x_exit;
        }
        
        double diff = abs(total_area - 2.0 * area1);
        if(diff < min_diff){
            min_diff = diff;
        }
    }
    
    cout << fixed << setprecision(3) << min_diff;
}