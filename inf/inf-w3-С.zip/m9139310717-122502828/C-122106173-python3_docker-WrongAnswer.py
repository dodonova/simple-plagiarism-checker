def min_difference(n, m, x, y):
    # Функция для нахождения площади треугольника
    def triangle_area(x1, y1, x2, y2):
        return abs(x1 * (y - y2) + x * (y2 - y1) + x2 * (y1 - y)) / 2
    
    # Площадь пирога
    total_area = n * m
    
    # Возможные разрезы
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    min_diff = float('inf')
    
    for (x1, y1) in corners:
        # Площадь треугольника
        area1 = triangle_area(x1, y1, x, y)
        
        # Площадь второй части
        area2 = total_area - area1
        
        # Обновляем минимальную разницу
        min_diff = min(min_diff, abs(area1 - area2))
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата
print(f"{result:.3f}")