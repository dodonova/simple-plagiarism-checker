n, m = map(int, input().split())
x, y = map(int, input().split())

def line(p1, p2):
A = (p1[1] - p2[1])
B = (p2[0] - p1[0])
C = (p1[0]*p2[1] - p2[0]*p1[1])
return A, B, C

def intersect(l1, l2):
D  = l1[0] * l2[1] - l1[1] * l2[0]
 Dx = l1[2] * l2[1] - l1[1] * l2[2]
 Dy = l1[0] * l2[2] - l1[2] * l2[0]
if D!= 0:
    x = Dx / D
    y = Dy / D
    return x,y
else:
    return False

p1 = (0, 0)
p2 = (n, 0)
p3 = (n, m)
p4 = (0, m)
p5 = (x, y)

l1 = line(p1, p3)
l2 = line(p2, p4)
r = intersect(l1, l2)

if r:
    px, py = r
    area1 = px * py
    area2 = (n * m) - area1
    diff = abs(area1 - area2)
    print('%.3f' % diff)
else:
    print("No intersection")