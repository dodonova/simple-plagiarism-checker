def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Список для хранения разниц
    differences = []
    
    # 1. Разрез из левого нижнего угла (0, 0)
    area1 = 0.5 * x * y
    area2 = total_area - area1
    differences.append(abs(area1 - area2))
    
    # 2. Разрез из правого нижнего угла (n, 0)
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    differences.append(abs(area1 - area2))
    
    # 3. Разрез из левого верхнего угла (0, m)
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    differences.append(abs(area1 - area2))
    
    # 4. Разрез из правого верхнего угла (n, m)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    differences.append(abs(area1 - area2))
    
    # Минимальная разница
    return min(differences)

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Получение результата
result = min_difference(n, m, x, y)

# Вывод результата с точностью 3 знака после запятой
print(f"{result:.3f}")
