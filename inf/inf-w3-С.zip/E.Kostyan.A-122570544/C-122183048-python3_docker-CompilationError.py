	n, m = map(int, input().split())
    # Читаем координаты свечки
    x, y = map(int, input().split())
    min_difference = float('inf')
    area1 = 0.5 * x * y
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))
    area1 = 0.5 * x * (m - y)
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))
    area1 = 0.5 * (n - x) * y
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))
    area1 = 0.5 * (n - x) * (m - y)
    area2 = n * m - area1
    min_difference = min(min_difference, abs(area1 - area2))
    print(f"{min_difference:.3f}")
if __name__ == "__main__":
    main()
