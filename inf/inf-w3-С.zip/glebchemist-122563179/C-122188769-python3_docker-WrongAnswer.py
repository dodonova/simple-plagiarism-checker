a,b = map(int, input().split())
c,d = map(int, input().split())
if (((d/b)>(c/a))or(d>c)): a,b,c,d=b,a,d,c
if (a-c>c): c=a-c;
if (b-d>d): d=b-d;
y=(d/c)*a
y=(b-y)*a;
print(f"{y:.{3}f}")