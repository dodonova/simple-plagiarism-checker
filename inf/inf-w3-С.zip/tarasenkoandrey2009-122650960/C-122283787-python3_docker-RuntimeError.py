def min_area_difference(n, m, x, y):
    total_area = n * m

    area1 = 0.5 * x * y
    area2 = total_area - area1
    diff1 = abs(area1 - area2)

    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    diff2 = abs(area1 - area2)

    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)

    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)

    min_diff = min(diff1, diff2, diff3, diff4)
    
    return min_diff

n, m, x, y = map(int, input("Введите n, m, x, y через пробел: ").split())
result = min_area_difference(n, m, x, y)
print(f"Минимальная разница площадей: {result}")