morzhx, morzhy = map(int, input().split())
xor, yaz = map(int, input().split())
outizm = list()

slave1 = (xor * yaz / 2) * (morzhx - xor) ** 2
master2 = morzhx * morzhy - slave1
outizm.append(abs(slave1 - master2))
# print(slave1, master2)



print(min(outizm))
