import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class WordFinder {

    // Метод для подсчета символов в строке
    private static Map<Character, Integer> getCharacterCount(String str) {
        Map<Character, Integer> charCount = new HashMap<>();
        for (char c : str.toCharArray()) {
            charCount.put(c, charCount.getOrDefault(c, 0) + 1);
        }
        return charCount;
    }

    // Метод для поиска слов
    private static List<String> findWords(String mixedString, List<String> words) {
        Map<Character, Integer> mixedCounter = getCharacterCount(mixedString);
        List<String> result = new ArrayList<>();

        for (int length = 5; length <= 8; length++) {
            List<List<String>> combinations = generateCombinations(words, length);
            for (List<String> combo : combinations) {
                String combinedString = String.join("", combo);
                if (getCharacterCount(combinedString).equals(mixedCounter)) {
                    Collections.sort(combo); // Сортируем найденные слова
                    return combo; // Возвращаем найденную комбинацию
                }
            }
        }

        return result; // Возвращаем пустой список, если ничего не найдено
    }

    // Метод для генерации всех комбинаций слов заданной длины
    private static List<List<String>> generateCombinations(List<String> words, int length) {
        List<List<String>> result = new ArrayList<>();
        generateCombinationsHelper(words, length, new ArrayList<>(), result, 0);
        return result;
    }

    private static void generateCombinationsHelper(List<String> words, int length,
            List<String> current, List<List<String>> result, int start) {
        if (current.size() == length) {
            result.add(new ArrayList<>(current));
            return;
        }

        for (int i = start; i < words.size(); i++) {
            current.add(words.get(i));
            generateCombinationsHelper(words, length, current, result, i + 1);
            current.remove(current.size() - 1);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Чтение смешанной строки
        String mixedString = scanner.nextLine().trim();
        
        // Чтение количества слов
        int n = Integer.parseInt(scanner.nextLine().trim());
        
        // Чтение списка слов
        List<String> words = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            words.add(scanner.nextLine().trim());
        }
        
        // Поиск слов
        List<String> result = findWords(mixedString, words);
        
        // Вывод результата
        if (!result.isEmpty()) {
            for (String word : result) {
                System.out.println(word);
            }
        } else {
            System.out.println("No combinations found");
        }

        scanner.close();
    }
}
