#include <iostream>
#include <iomanip>
#include <cmath> // Для fabs

int main() {
    // Ввод размеров пирога
    int n, m;
    std::cin >> n >> m;

    // Ввод координат свечки
    int x, y;
    std::cin >> x >> y;

    // Минимальная разница между площадями
    double min_difference = std::numeric_limits<double>::max();

    // Разрез через нижний левый угол (0, 0)
    double area1 = x * y; // Площадь левого куска
    double area2 = (n - x) * (m - y); // Площадь правого куска
    min_difference = std::min(min_difference, std::fabs(area1 - area2));

    // Разрез через нижний правый угол (n, 0)
    area1 = (n - x) * y; // Площадь левого куска
    area2 = x * (m - y); // Площадь правого куска
    min_difference = std::min(min_difference, std::fabs(area1 - area2));

    // Разрез через верхний левый угол (0, m)
    area1 = x * (m - y); // Площадь левого куска
    area2 = (n - x) * y; // Площадь правого куска
    min_difference = std::min(min_difference, std::fabs(area1 - area2));

    // Разрез через верхний правый угол (n, m)
    area1 = (n - x) * (m - y); // Площадь левого куска
    area2 = x * y; // Площадь правого куска
    min_difference = std::min(min_difference, std::fabs(area1 - area2));

    // Вывод минимальной разницы с точностью 3 знака после запятой
    std::cout << std::fixed << std::setprecision(3) << min_difference << std::endl;

    return 0;
}