def can_form_from_letters(available, word):
    """Check if we can form 'word' from 'available' letters."""
    for char in word:
        if word.count(char) > available.count(char):
            return False
    return True

def find_words(letters, word_list, current_words):
    if not letters:
        return current_words
   
    for word in word_list:
        if can_form_from_letters(letters, word):
            remaining_letters = list(letters)
            for char in word:
                remaining_letters.remove(char)
            result = find_words(remaining_letters, word_list, current_words + [word])
            if result:
                return result
   
    return None

def main():
    scrambled_letters = input().strip()
    n = int(input().strip())
    words = [input().strip() for _ in range(n)]
   
    words.sort()
   
    result = find_words(list(scrambled_letters), words, [])
   
    if result:
        for word in sorted(result):
            print(word)

if __name__ == "__main__":
    main()