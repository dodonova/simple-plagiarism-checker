
from collections import Counter

def can_form_from_letters(available, word):
    """Проверяем, можем ли сформировать слово из доступных букв."""
    available_count = Counter(available)
    word_count = Counter(word)
    return all(word_count[char] <= available_count[char] for char in word_count)

def find_words(letters, word_list):
    result = []
    for word in word_list:
        if can_form_from_letters(letters, word):
            result.append(word)
    return result

def main():
    scrambled_letters = input().strip()
    n = int(input().strip())
    words = [input().strip() for _ in range(n)]

    words = sorted(set(words))

    result = find_words(scrambled_letters, words)

    if result:
        for word in sorted(result):
            print(word)

if __name__ == "__main__":
    main()