on , om = map(int , input().split())
ox , oy = map(int , input().split())
s = om*on
razn = []
#правый верхний
def add_razn(m,n,x,y):
    n_n = m/(m - y)*(n-x)
    # print(n_n)
    if n_n < n:
        razn.append((n-n_n)*m/2)

    else:
        n_m = (m-y)*n/(n-x)
        # print(n_m)
        razn.append(n*(m-n_m)/2)
add_razn(om,on,ox,oy)
add_razn(om,on,on-ox,om-oy)

print(min(razn))