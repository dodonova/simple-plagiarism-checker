def minimum_difference(n, m, x, y):
    total_area = n * m
    
    diff1 = abs(total_area - x * y)
    diff2 = abs(total_area - (n - x) * y)
    diff3 = abs(total_area - x * (m - y))
    diff4 = abs(total_area - (n - x) * (m - y))

    min_diff = min(diff1, diff2, diff3, diff4)

    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

result = minimum_difference(n, m, x, y)
print(f"{result:.3f}")