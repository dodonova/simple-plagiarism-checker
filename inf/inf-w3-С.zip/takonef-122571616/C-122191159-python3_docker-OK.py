m, n = map(int, input().split())
x, y = map(int, input().split())

# def tr_area(x1, y1, x2, y2, x3, y3):
#     return (x1*y2 - x2*y1 + x2*y3 - x3*y2 + x3*y1 - x1*y3)/2
def line(x1, y1, x2, y2):
    return y2 - y1, x1 - x2, x2*y1 - x1*y2

S = n*m

a, b, c = line(0, 0, x, y)
yc = -(a*m+c)/b
xc = -(b*n+c)/a
if xc > m:
    ar = m*yc/2
else:
    ar = n*xc/2
diff1 = abs(S - 2*ar)

a, b, c = line(0, n, x, y)
yc = -(a*m+c)/b
xc = -c/a
if xc > m:
    ar = m*(n-yc)/2
else:
    ar = n*xc/2
diff2 = abs(S - 2*ar)

a, b, c = line(m, n, x, y)
yc = -c/b
xc = -c/a
if xc < 0:
    ar = m*(n-yc)/2
else:
    ar = n*(m-xc)/2
diff3 = abs(S - 2*ar)

a, b, c = line(m, 0, x, y)
yc = -c/b
xc = -(b*n+c)/a
if xc < 0:
    ar = m*yc/2
else:
    ar = n*(m-xc)/2 
diff4 = abs(S - 2*ar)

print(format(min(diff1, diff2, diff3, diff4), '.3f'))