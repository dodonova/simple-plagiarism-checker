n, m = map(int, input().split())
x, y = map(int, input().split())
dlx = n - x
dly = m - y
print(dlx,dly)
dlx, x = sorted([x, dlx])
dly, y = sorted([y, dly])
print(dlx,dly,x,y)
y1 = y * n / x
x1 = x * m / y
if y1 >= m:
    dl = m * (n - x1)
if x1 >= n:
    dl = n * (m - y1)
print(dl)