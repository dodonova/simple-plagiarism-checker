def min_difference(n, m, x, y):
    total_area = n * m
    
    area1 = 0.5 * x * y
    area2 = total_area - area1
    diff1 = abs(area1 - area2)
    
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    diff2 = abs(area1 - area2)

    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)

    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)

    return min(diff1, diff2, diff3, diff4)

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_difference(n, m, x, y)
print(f"{result:.3f}")