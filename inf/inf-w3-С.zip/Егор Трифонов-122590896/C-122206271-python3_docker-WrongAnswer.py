def area_triangle(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def min_area_diff(n, m, x, y):
    # Полная площадь пирога
    total_area = n * m

    # Возможные разрезы через четыре угла пирога
    # Угол (0, 0)
    area1 = area_triangle(0, 0, x, y, n, 0) + area_triangle(0, 0, x, y, 0, m)
    
    # Угол (n, 0)
    area2 = area_triangle(n, 0, x, y, 0, 0) + area_triangle(n, 0, x, y, n, m)
    
    # Угол (0, m)
    area3 = area_triangle(0, m, x, y, 0, 0) + area_triangle(0, m, x, y, n, m)
    
    # Угол (n, m)
    area4 = area_triangle(n, m, x, y, 0, m) + area_triangle(n, m, x, y, n, 0)
    
    # Найдем минимальную разницу между двумя частями
    diff1 = abs(total_area - 2 * area1)
    diff2 = abs(total_area - 2 * area2)
    diff3 = abs(total_area - 2 * area3)
    diff4 = abs(total_area - 2 * area4)
    
    # Возвращаем минимальную разницу
    return min(diff1, diff2, diff3, diff4)

# Ввод данных
try:
    with open("input.txt", "r") as file:
        n, m = map(int, file.readline().split())
        x, y = map(int, file.readline().split())
except FileNotFoundError:
    n, m = map(int, input().split())
    x, y = map(int, input().split())

# Поиск минимальной разницы
result = min_area_diff(n, m, x, y)

# Вывод результата
try:
    with open("output.txt", "w") as file:
        file.write(f"{result:.3f}\n")
except FileNotFoundError:
    print(f"{result:.3f}")