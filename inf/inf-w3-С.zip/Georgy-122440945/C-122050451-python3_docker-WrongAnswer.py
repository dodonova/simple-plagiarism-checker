def calculate_min_difference(n, m, x, y):
    total_area = n * m
    
    # Определяем площади 
    areas = []
    
    # Треугольник от (0, 0)
    area1 = (x * y) / 2
    remaining1 = total_area - area1
    areas.append(abs(area1 - remaining1))
    
    # Треугольник от (n, 0)
    area2 = (n - x) * y / 2
    remaining2 = total_area - area2
    areas.append(abs(area2 - remaining2))
    
    # Треугольник от (0, m)
    area3 = x * (m - y) / 2
    remaining3 = total_area - area3
    areas.append(abs(area3 - remaining3))
    
    # Треугольник от (n, m)
    area4 = (n - x) * (m - y) / 2
    remaining4 = total_area - area4
    areas.append(abs(area4 - remaining4))
    
    # Возвращаем 
    return min(areas)

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисляем минимальную разницу
min_difference = calculate_min_difference(n, m, x, y)


print(f"{min_difference:.3f}")