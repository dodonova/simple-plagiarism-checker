import java.util.Scanner;

public class PieCutting {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Чтение размеров пирога
        int n = scanner.nextInt();
        int m = scanner.nextInt();

        // Чтение координат свечи
        int x = scanner.nextInt();
        int y = scanner.nextInt();

        // Площади кусочков для каждого из четырех возможных разрезов
        double minDifference = Double.MAX_VALUE;

        // Разрез из нижнего левого угла (0, 0)
        double area1 = x * y;
        double area2 = n * m - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // Разрез из нижнего правого угла (n, 0)
        area1 = (n - x) * y;
        area2 = n * m - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // Разрез из верхнего левого угла (0, m)
        area1 = x * (m - y);
        area2 = n * m - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // Разрез из верхнего правого угла (n, m)
        area1 = (n - x) * (m - y);
        area2 = n * m - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // Выводим результат с точностью не менее трех знаков после десятичной точки
        System.out.printf("%.10f\n", minDifference);
    }
}