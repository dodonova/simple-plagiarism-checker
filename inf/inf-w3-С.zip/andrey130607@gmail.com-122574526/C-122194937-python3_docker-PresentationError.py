from math import *
n,m = map(int,input().split())
x,y = map(int,input().split())
ox, oy = x,0
if y > m/2 :
    gip1 = sqrt(x**2+y**2)
    dlinan = sqrt(ox ** 2 + oy ** 2)
    cosa = dlinan / gip1
    a = acos(cosa)
    gip = max(m, n) / cosa
    stor_m = sqrt(gip ** 2 - max(m, n) ** 2)
    s = (max(m, n) * stor_m) / 2
    print(f'{(n * m - s - s):.4f}')
elif y < m/2:
    gip1 = sqrt(x ** 2 +  (m- y) ** 2)
    dlinan = sqrt(ox ** 2 + oy ** 2)
    cosa = dlinan / gip1
    a = acos(cosa)
    gip = max(m, n) / cosa
    stor_m = sqrt(gip ** 2 - max(m, n) ** 2)
    s = (max(m, n) * stor_m) / 2
    print(f'{(n * m - s - s):.4f}')
elif y == n/2 and x== n/2:
    print(f'{0:.4f}')



# tga = tan(a)

# s = (n**2 * tga) /2

