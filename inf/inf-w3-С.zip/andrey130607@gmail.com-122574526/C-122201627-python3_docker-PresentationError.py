from math import *
n,m = map(int,input().split())
x,y = map(int,input().split())
ox, oy = x,0
if y > m/2 and x > n/2 :
    gip1 = sqrt(x**2+y**2)
    dlinan = sqrt(ox ** 2 + oy ** 2)
    cosa = dlinan / gip1
    gip = n / cosa
    stor_m = sqrt(gip ** 2 - n ** 2)
    s = (n * stor_m) / 2
    print(f'{(n * m - s - s):.3f}')
elif y < m/2 and x >n/2:
    gip1 = sqrt(x ** 2 +  (m- y) ** 2)
    dlinan = sqrt(ox ** 2 + oy ** 2)
    cosa = dlinan / gip1
    gip = n / cosa
    stor_m = sqrt(gip ** 2 - n ** 2)
    s = (n * stor_m) / 2
    print(f'{(n * m - s - s):.3f}')
elif y > m/2 and x <n/2:
    gip1 = sqrt((n-x) ** 2 +  y ** 2)
    dlinan = sqrt((n-ox) ** 2 + oy ** 2)
    cosa = dlinan / gip1
    gip = n / cosa
    stor_m = sqrt(gip ** 2 -  n ** 2)
    s = ( n * stor_m) / 2
    print(f'{(n * m - s - s):.3f}')
elif y < m/2 and x <n/2:
    gip1 = sqrt((n-x) ** 2 +  (m-y) ** 2)
    dlinan = sqrt((n-ox) ** 2 + oy ** 2)
    cosa = dlinan / gip1
    gip = n / cosa
    stor_m = sqrt(gip ** 2 -  n ** 2)
    s = ( n * stor_m) / 2
    print(f'{(n * m - s - s):.3f}')
elif y == n/2 and x== n/2:
    print(f'{0:.3f}')




