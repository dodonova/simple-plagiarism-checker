N, M = map(int, input().split())
X, Y = map(int, input().split())
if X * M / (M - Y) <= N:
    _1 = abs(2 * (X * M ** 2) / (2 * (M - Y)) - (2 * N - (X * M) / (M - Y)) / 2 * M)
else:
    _1 = abs((M + N * ((Y - M) / X) + M) / 2 * N - N * (M - N * ((Y - M) / X) - M) / 2)
if N - (N * Y + M * X) / (Y - M) >= 0:
    _2 = abs((N - (N * Y + M * X) / (Y - M)) * M / 2 - (N * Y + M * X) / (Y - M) * N * M / 2)
print(min(_1, _2))