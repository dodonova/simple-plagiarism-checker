def find(a, b):
    for n in range(1, a1 + 3): 
        m = (a1 // 2) + 2 - n
        if m < n:
            continue
        
        if (n - 1) * (m - 1) == b:
            return n, m
    
    return None

a1, b = map(int, input().strip().split())
result = find(a1, b)

if result:
    print(result[0], result[1])
else:
    print("No solution")