def get_area(x1, y1, x2, y2):
 return abs(x1 * y2 - x2 * y1) / 2

def get_min_difference(n, m, x, y):
 area = n * m
 min_area = min(x * m, y * n, (n - x) * m, (m - y) * n)
 max_area = area - min_area
 return abs(max_area - min_area)

n, m = map(int, input().split())
x, y = map(int, input().split())

min_diff = get_min_difference(n, m, x, y)

print(f"{min_diff:.3f}")
