import sys
import math

def compute_area(polygon):
    area = 0
    n = len(polygon)
    for i in range(n):
        x_i, y_i = polygon[i]
        x_next, y_next = polygon[(i+1)%n]
        area += x_i * y_next - x_next * y_i
    return abs(area) / 2

def find_intersection(x0, y0, x1, y1, n, m):
    intersections = []
    dx = x1 - x0
    dy = y1 - y0
    if dx == 0:
        xs = [x0]
    else:
        xs = [0, n]
    if dy == 0:
        ys = [y0]
    else:
        ys = [0, m]

    for x_edge in xs:
        if dx != 0:
            t = (x_edge - x0) / dx
            y_edge = y0 + t * dy
            if 0 <= t <= 1 or (x_edge == x1 and y_edge == y1):
                if 0 <= y_edge <= m:
                    if (x_edge, y_edge) != (x0, y0):
                        intersections.append((x_edge, y_edge))
    for y_edge in ys:
        if dy != 0:
            t = (y_edge - y0) / dy
            x_edge = x0 + t * dx
            if 0 <= t <= 1 or (x_edge == x1 and y_edge == y1):
                if 0 <= x_edge <= n:
                    if (x_edge, y_edge) != (x0, y0):
                        intersections.append((x_edge, y_edge))
    intersections = list(set(intersections))
    intersections = [p for p in intersections if p != (x0, y0)]
    if not intersections:
        return None
    return intersections[0]

def main():
    import sys
    import math
    n, m = map(int, sys.stdin.readline().split())
    x, y = map(float, sys.stdin.readline().split())
    total_area = n * m
    min_diff = float('inf')

    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    edges = [((0,0),(n,0)), ((n,0),(n,m)), ((n,m),(0,m)), ((0,m),(0,0))]
    for corner in corners:
        x0, y0 = corner
        if (x0 == x and y0 == y):
            continue
        intersection = find_intersection(x0, y0, x, y, n, m)
        if not intersection:
            continue
        x1, y1 = intersection
        polygon = []
        polygon.append((x0, y0))
        polygon.append((x, y))
        polygon.append((x1, y1))
        rect_points = [(0,0), (n,0), (n,m), (0,m)]
        index_corner = rect_points.index((x0,y0))
        index_inter = None
        if (x1,y1) in rect_points:
            index_inter = rect_points.index((x1,y1))
        else:
            if x1 == 0 or x1 == n:
                if y1 == 0:
                    index_inter = rect_points.index((x1,0))
                elif y1 == m:
                    index_inter = rect_points.index((x1,m))
                else:
                    if x1 == n:
                        index_inter = 1
                    else:
                        index_inter = 3
            elif y1 == 0 or y1 == m:
                if x1 == 0:
                    index_inter = rect_points.index((0,y1))
                elif x1 == n:
                    index_inter = rect_points.index((n,y1))
                else:
                    if y1 == m:
                        index_inter = 2
                    else:
                        index_inter = 0
        if (index_inter - index_corner) % 4 == 1 or (index_inter - index_corner) % 4 == -3:
            indices = range(index_corner, index_inter+1)
        else:
            indices = list(range(index_corner, index_inter-4,-1))
        for i in indices[1:]:
            polygon.append(rect_points[i%4])
        area_piece = compute_area(polygon)
        diff = abs(total_area - 2*area_piece)
        if diff < min_diff:
            min_diff = diff
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()