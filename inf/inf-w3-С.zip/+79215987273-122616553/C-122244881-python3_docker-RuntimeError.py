n,m=map(int,input().split())
x,y=map(int,input().split())
trm=max(0.5*n*n*y/x,0.5*m*m(n-x)/y,0.5*m*m*(n-x)/(m-y),0.5*n*n*(m-y)/x)
smn=m*n-2*trm
n1=3
template='{:.'+str(n1)+'f}'
print(template.format(smn))