
def min_area_difference(n, m, x, y):
    total_area = n * m
    min_diff = float("inf")

    # Угол 1: (0, 0)
    S1 = 0.5 * x * y
    S2 = total_area - S1
    min_diff = min(min_diff, abs(S1 - S2))

    # Угол 2: (n, 0)
    S1 = 0.5 * (n - x) * y
    S2 = total_area - S1
    min_diff = min(min_diff, abs(S1 - S2))

    # Угол 3: (0, m)
    S1 = 0.5 * x * (m - y)
    S2 = total_area - S1
    min_diff = min(min_diff, abs(S1 - S2))

    # Угол 4: (n, m)
    S1 = 0.5 * (n - x) * (m - y)
    S2 = total_area - S1
    min_diff = min(min_diff, abs(S1 - S2))

    return min_diff

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Выводим результат
result = min_area_difference(n, m, x, y)
print(f"{result:.3f}")
