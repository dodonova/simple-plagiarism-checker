n = int(input())
strip_lengths = list(map(int, input().split()))

strip_lengths.sort(reverse=True)
max_rectangle_area = 0

for height in range(1, n + 1):
    min_length_for_height = strip_lengths[height - 1] if height <= n else 0

    vertical_count = min(min_length_for_height, n - height)

    remaining_lengths = strip_lengths[height:]
    count_vertical = 0
    for length in remaining_lengths:
        if length >= height:
            count_vertical += 1
        else:
            break

    vertical_count = min(vertical_count, count_vertical)
    area = height * vertical_count 
    if area > max_rectangle_area:
        max_rectangle_area = area

    if vertical_count == 0:
        break

print(max_rectangle_area)
