def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    n = int(data[0])
    m = int(data[1])
    x = int(data[2])
    y = int(data[3])
    
    min_diff = float('inf')
    
    corners = [
        (0, 0),   
        (n, 0),   
        (0, m),  
        (n, m)    
    ]
    
    for corner in corners:
        cx, cy = corner
        

        triangle_area = area_of_triangle(cx, cy, x, y, n, m)  
        remaining_area = n * m - triangle_area  
        
        diff = abs(triangle_area - remaining_area)
        min_diff = min(min_diff, diff)
    
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()