def triangle_area(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def get_difference(n, m, x, y, corner_x, corner_y):
    total_area = n * m
    
    triangle = triangle_area(corner_x, corner_y, x, y, corner_x, y)
    
    if corner_y == m:
        triangle = triangle_area(corner_x, corner_y, x, y, x, m)
    elif corner_y == 0:
        triangle = triangle_area(corner_x, corner_y, x, y, x, 0)
        
    other_part = total_area - triangle
    
    return abs(other_part - triangle)

def solve(n, m, x, y):
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    min_diff = float('inf')
    
    for corner_x, corner_y in corners:
        diff = get_difference(n, m, x, y, corner_x, corner_y)
        min_diff = min(min_diff, diff)
    
    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

print("{:.3f}".format(solve(n, m, x, y)))