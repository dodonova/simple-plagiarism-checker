def min_difference(n, m, x, y):
    area1 = (x * y) / 2
    area2 = ((n - x) * y) / 2
    area3 = (x * (m - y)) / 2
    area4 = ((n - x) * (m - y)) / 2

    total_area = n * m

    piece1 = area1 + area2
    piece2 = area3 + area4

    difference = abs(piece1 - piece2)

    return round(difference, 3)

n, m = map(int, input().split())
x, y = map(int, input().split())

print(min_difference(n, m, x, y))