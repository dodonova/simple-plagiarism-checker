def triangle_area(x1, y1, x2, y2, x3, y3):
    # Calculate the area of a triangle using the determinant method
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def find_minimal_difference(n, m, x, y):
    total_area = n * m  # Total area of the pie
    min_difference = float('inf')  # Start with a very high difference

    # Define corners of the pie
    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    
    for cx, cy in corners:
        # Calculate the area of the triangle formed with (cx, cy) and the candle (x, y)
        area_triangle = triangle_area(cx, cy, 0, 0, x, y)
        area_remaining = total_area - area_triangle  # Remaining area of the pie
        difference = abs(area_triangle - area_remaining)  # Calculate the difference
        
        # Update minimum difference
        min_difference = min(min_difference, difference)

    return min_difference

# Read input values
n, m = map(int, input().split())
x, y = map(int, input().split())

# Calculate and print the result
result = find_minimal_difference(n, m, x, y)
print(f"{result:.3f}")
