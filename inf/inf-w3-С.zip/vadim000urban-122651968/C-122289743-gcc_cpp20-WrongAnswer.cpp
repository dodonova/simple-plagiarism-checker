#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

double find_minimal_difference(int n, int m, int x, int y) {
    double total_area = n * m;
    double min_difference = 1e9; // A large number

    // Define corners of the pie
    int corners[4][2] = {{0, 0}, {0, m}, {n, 0}, {n, m}};

    for (int i = 0; i < 4; i++) {
        int cx = corners[i][0];
        int cy = corners[i][1];

        // Calculate area of the triangle
        double triangle_area = abs(cx * (y - cy) + x * (cy - 0)) / 2.0;
        double remaining_area = total_area - triangle_area;
        double difference = abs(triangle_area - remaining_area);
        min_difference = min(min_difference, difference);
    }

    return min_difference;
}

int main() {
    int n, m, x, y;
    cin >> n >> m >> x >> y;

    double result = find_minimal_difference(n, m, x, y);
    cout << fixed << setprecision(3) << result << endl;

    return 0;
}
