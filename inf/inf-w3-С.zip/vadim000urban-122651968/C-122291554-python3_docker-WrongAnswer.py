def triangle_area(x1, y1, x2, y2, x3, y3):
    # Calculate the area of the triangle using the determinant method
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def minimal_difference(n, m, x, y):
    total_area = n * m  # Total area of the pie
    min_diff = float('inf')  # Initialize minimum difference to a large value
    
    # Define corners of the pie
    corners = [(0, 0), (0, m), (n, 0), (n, m)]

    for cx, cy in corners:
        # Calculate the area of the triangle formed by the corner and the candle
        triangle_area_value = triangle_area(cx, cy, 0, 0, x, y)
        remaining_area = total_area - triangle_area_value  # Area of the other piece
        
        # Calculate the difference in areas
        diff = abs(triangle_area_value - remaining_area)
        min_diff = min(min_diff, diff)  # Update minimum difference if needed
        
    return min_diff

# Read input
n, m = map(int, input().split())
x, y = map(int, input().split())

# Calculate and print the result
result = minimal_difference(n, m, x, y)
print(f"{result:.3f}")
