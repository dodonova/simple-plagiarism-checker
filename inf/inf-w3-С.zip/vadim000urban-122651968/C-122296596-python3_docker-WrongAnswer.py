def compute_diff(n, m, x0, y0, corner):
    """
    Computes the absolute difference between the areas of the two pieces
    obtained by cutting the pie from the given corner through the candle.
    """
    x1, y1 = corner
    dx = x0 - x1
    dy = y0 - y1

    # Calculate the parameter t for the intersection with rectangle boundaries
    t_x = (n - x1) / dx if dx > 0 else (0 - x1) / dx if dx < 0 else float('inf')
    t_y = (m - y1) / dy if dy > 0 else (0 - y1) / dy if dy < 0 else float('inf')

    # Find the smallest positive t to get the first intersection
    t_min = min(t_x, t_y)

    # Calculate intersection point
    x_int = x1 + dx * t_min
    y_int = y1 + dy * t_min

    # Check if the intersection point is within the boundaries
    if not (0 <= x_int <= n and 0 <= y_int <= m):
        return float('inf')  # Intersection outside the rectangle

    # Compute the area of the triangle formed by the corner and the intersection point
    area = 0.5 * abs((x1 - x_int) * (y1 - y_int))
    total_area = n * m
    diff = abs(total_area - 2 * area)
    
    return diff

# Read input values
n, m = map(float, input().split())
x0, y0 = map(float, input().split())

# Define all four corners of the rectangle
corners = [(0, 0), (n, 0), (0, m), (n, m)]

# Initialize the minimal difference to a large number
min_diff = float('inf')

# Iterate through each corner to compute the minimal difference
for corner in corners:
    diff = compute_diff(n, m, x0, y0, corner)
    min_diff = min(min_diff, diff)

# Output the result with three decimal places
print(f"{min_diff:.3f}")
