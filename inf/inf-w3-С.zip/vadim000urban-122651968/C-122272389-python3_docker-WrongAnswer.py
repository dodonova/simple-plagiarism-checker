def calculate_min_diff(width, height, x_candle, y_candle):
    # Определим координаты всех углов пирога
    corners = [(0, 0), (0, height), (width, 0), (width, height)]
    min_area_diff = float('inf')  # Изначально устанавливаем разницу как бесконечную

    # Проходим по каждому углу пирога
    for i in range(len(corners)):
        corner_x, corner_y = corners[i]
        # Вычисляем площадь треугольника между углом и точкой свечи
        current_area = abs(corner_x * y_candle - corner_y * x_candle) / 2.0
        remaining_area = (width * height) - current_area  # Оставшаяся площадь
        area_diff = abs(current_area - remaining_area)  # Разница между площадями
        # Обновляем минимальную разницу, если найдено лучшее решение
        if area_diff < min_area_diff:
            min_area_diff = area_diff

    return min_area_diff

# Ввод данных
n_pie, m_pie = map(int, input().split())  # Размеры пирога
x_s, y_s = map(int, input().split())  # Положение свечи

# Вывод минимальной разницы между частями
result = calculate_min_diff(n_pie, m_pie, x_s, y_s)
print(f"{result:.3f}")
