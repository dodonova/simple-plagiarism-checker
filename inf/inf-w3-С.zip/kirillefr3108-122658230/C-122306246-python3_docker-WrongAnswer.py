pie1, pie2 = map(int, input().split())
candle1, candle2 = map(int, input().split())

def f(x, y, a, b, st):
    if st == '<':
        return x * b < y * a
    elif st == '>':
        return x * b > y * a
    else:
        return x * b == y * a
    
def g(x, y, a, b, st):
    if st == '<':
        return x*(-1)*b + a*b < y*a
    elif st == '>':
        return x * (-1) * b + a * b > y * a
    else:
        return x * (-1) * b + a * b == y * a
    
def otv(p):
    print(str((float(pie2 * pie1 - 2 * p)))+'000')

if f(candle1, candle2, pie1, pie2, '<') and g(candle1, candle2, pie1, pie2, '<'):
    print('0.000')
else:
    if f(candle1, candle2, pie1, pie2, '<') and g(candle1, candle2, pie1, pie2, '<'):
        p = max(
            (pie1 * pie1 * (pie2 - candle2)) / (2 * candle1), 
            ((pie2 - candle2) * pie1 * pie1) / (2 * (pie1 - candle1)), 
            ((pie1 - candle1) * pie2 * pie2) / (2 * candle2), 
            (candle1 * pie2 * pie2) / (2 * candle2)
            )
        
        otv(p)

    elif f(candle1, candle2, pie1, pie2, '>') and g(candle1, candle2, pie1, pie2, '<'):
        p = max(
            (pie2 * pie2 * (pie1 - candle1)) / (2 * candle2), 
            ((pie1 - candle1) * pie2 * pie2) / (2 * (pie2 - candle2)), 
            (candle2 * pie1 * pie1) / (2 * candle1), 
            ((pie2 - candle2) * pie1 * pie1) / (2 * candle1)
            )
        
        otv(p)

    elif f(candle1, candle2, pie1, pie2, '>') and g(candle1, candle2, pie1, pie2, '>'):
        p = max(
            (candle2 * pie1 * pie1) / (2 * candle1), 
            (candle2 * pie1 * pie1) / (2 * (pie1 - candle1)), 
            (candle1 * pie2 * pie2) / (2 * (pie2 - candle2)), 
            ((pie1 - candle1) * pie2 * pie2) / (2 * (pie2 - candle2))
            )
        
        otv(p)

    else:
        p = max((candle1 * pie2 * pie2) / (2 * candle2), 
                (candle1 * pie2 * pie2) / (2 * (pie2 - candle2)), 
                ((pie2 - candle2) * pie1 * pie1) / (2 * (pie1 - candle1)), 
                (candle2 * pie1 * pie1) / (2 * (pie1 - candle1))
                )
        
        otv(p)