#include <iostream>
#include <cmath>
#include <iomanip>

double triangle_area(int x1, int y1, int x2, int y2, int x3, int y3) {
    return fabs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0;
}

int main() {
    int n, m, x, y;
    std::cin >> n >> m >> x >> y;

    // Площади треугольников от углов до свечки
    double full_area = n * m;
    double min_diff = full_area;

    int corners[4][2] = {{0, 0}, {n, 0}, {0, m}, {n, m}};
    
    for (int i = 0; i < 4; ++i) {
        int x1 = corners[i][0];
        int y1 = corners[i][1];
        
        // Площадь треугольника, образованного углом и точкой со свечкой
        double area = triangle_area(x1, y1, x, y, n, m);
        double diff = fabs(full_area - 2 * area);

        // Обновить минимальную разницу
        if (diff < min_diff) {
            min_diff = diff;
        }
    }

    // Выводим ответ с точностью три знака после запятой
    std::cout << std::fixed << std::setprecision(3) << min_diff << std::endl;

    return 0;
}
