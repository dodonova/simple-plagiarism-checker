def find_dimensions(a, b):
    # Расчет суммы n + m
    n_plus_m = a // 2 + 2
    for n in range(2, n_plus_m):
        if (n - 1) * (n_plus_m - n - 1) == b:
            m = n_plus_m - n
            return min(n, m), max(n, m)

# Чтение входных данных
a, b = map(int, input().split())

# Получение размеров и вывод результата
n, m = find_dimensions(a, b)
print(n, m)