def min_difference(n, m, x, y):
    total_area = n * m

    corners = [
        (0, 0),  # из угла (0, 0)
        (n, 0),  # из угла (n, 0)
        (0, m),  # из угла (0, m)
        (n, m)   # из угла (n, m)
    ]
    
    min_diff = float('inf')
    
    for cx, cy in corners:
        area_triangle = 0.5 * abs(cx * y - cy * x)
        
        area_remaining = total_area - area_triangle
        
        diff = abs(area_triangle - area_remaining)
        
        min_diff = min(min_diff, diff)

    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_difference(n, m, x, y)


print(f"{result:.3f}")
