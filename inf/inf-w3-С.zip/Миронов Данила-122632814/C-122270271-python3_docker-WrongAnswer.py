def min_area_difference(n, m, x, y):
    total_area = n * m

    area1_a = (x * y) / 2
    area2_a = total_area - area1_a
    diff_a = abs(area1_a - area2_a)

    area1_b = ((n - x) * y) / 2
    area2_b = total_area - area1_b
    diff_b = abs(area1_b - area2_b)

    area1_c = (x * (m - y)) / 2
    area2_c = total_area - area1_c
    diff_c = abs(area1_c - area2_c)

    area1_d = ((n - x) * (m - y)) / 2
    area2_d = total_area - area1_d
    diff_d = abs(area1_d - area2_d)

    return min(diff_a, diff_b, diff_c, diff_d)

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_area_difference(n, m, x, y)
print(f"{result:.3f}")

