a = int(input())
lengths = list(map(int, input().split()))

lengths.sort(reverse=True)
max_area = 0

for h in range(1, a + 1):
    min_length_h = lengths[h - 1] if h <= a else 0
    v = min(min_length_h, a - h)

    # Находим количество вертикальных полосок длиной не меньше h
    vertical_lengths = lengths[h:]
    count_v = 0
    for l in vertical_lengths:
        if l >= h:
            count_v += 1
        else:
            break

    v = min(v, count_v)
    area = h * v

    if area > max_area:
        max_area = area

    if v == 0:
        break

print(max_area)