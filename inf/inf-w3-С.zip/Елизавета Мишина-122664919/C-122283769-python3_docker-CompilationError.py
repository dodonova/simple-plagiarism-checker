#include <iostream>
#include <cmath>
using namespace std;

int main() {
	double n = 0;
	double m = 0;
	double x = 0;
	double y = 0;
	

	cin >> n >> m;
	cin >> x >> y;

	double k1 = y / x;
	double k2 = abs(y / (x - n));
	double STk = n / ((k2 * n) / m);
	double k3 = abs(((y-m) / (x)));
	double k4 = abs(((y-m) / (x - n)));
	double STk4 = n / ((k4 * n) / m);

	double S1t = (n * (n*k1)) / 2;
	double S1trap = n*m - S1t;
	double res1 = abs(S1trap - S1t);

	double S2t = (m * STk) / 2;
	double S2trap = n * m - S2t;
	double res2 = abs(S2trap - S2t);

	double S3t = (n * (n * k3)) / 2;
	double S3trap = n * m - S3t;
	double res3 = abs(S3trap - S3t);

	double S4t = (m * STk4) / 2;
	double S4trap = n * m - S4t;
	double res4 = abs(S4trap - S4t);

	double min12 = min(res1, res2);
	double min34 = min(res3, res4);

	double otv = round(min(min12, min34) * 1000) / 1000;
	if (otv == 0) {
		cout << "0.000";
	}
	else {
		cout << otv;
	}

	return 0;
}