import sys

def read_input():
    data = sys.stdin.read().split()
    n, m = map(float, data[:2])
    x, y = map(float, data[2:4])
    return n, m, x, y

def find_intersection(n, m, corner, x, y):
    x1, y1 = corner
    dx = x - x1
    dy = y - y1
    intersections = []

    
    if dx != 0:
        t = (n - x1) / dx
        if t > 0:
            y_inter = y1 + t * dy
            if 0 <= y_inter <= m:
                intersections.append(((n, y_inter), 'right'))

    
    if dx != 0:
        t = (0 - x1) / dx
        if t > 0:
            y_inter = y1 + t * dy
            if 0 <= y_inter <= m:
                intersections.append(((0, y_inter), 'left'))

    
    if dy != 0:
        t = (m - y1) / dy
        if t > 0:
            x_inter = x1 + t * dx
            if 0 <= x_inter <= n:
                intersections.append(((x_inter, m), 'top'))

    
    if dy != 0:
        t = (0 - y1) / dy
        if t > 0:
            x_inter = x1 + t * dx
            if 0 <= x_inter <= n:
                intersections.append(((x_inter, 0), 'bottom'))

    
    intersections = [ (pt, side) for pt, side in intersections if not (abs(pt[0]-x) < 1e-9 and abs(pt[1]-y) < 1e-9) ]

    return intersections[0] if intersections else None

def get_bordering_corner(corner, side, n, m):
    corner_side_map = {
        (0.0, 0.0): {'right': (n, 0.0), 'top': (0.0, m)},
        (n, 0.0): {'left': (0.0, 0.0), 'top': (n, m)},
        (0.0, m): {'right': (n, m), 'bottom': (0.0, 0.0)},
        (n, m): {'left': (0.0, m), 'bottom': (n, 0.0)}
    }
    return corner_side_map.get(corner, {}).get(side)

def shoelace(vertices):
    n = len(vertices)
    sum1 = sum(vertices[i][0] * vertices[(i + 1) % n][1] for i in range(n))
    sum2 = sum(vertices[i][1] * vertices[(i + 1) % n][0] for i in range(n))
    return abs(sum1 - sum2) / 2.0

def main():
    n, m, x, y = read_input()
    corners = [(0.0, 0.0), (n, 0.0), (0.0, m), (n, m)]
    minimal_diff = float('inf')
    total_area = n * m

    for corner in corners:
        result = find_intersection(n, m, corner, x, y)
        if result is None:
            continue
        intersection, side = result
        bordering_corner = get_bordering_corner(corner, side, n, m)
        if bordering_corner is None:
            continue
        
        
        vertices = [corner, (x, y), intersection, bordering_corner]
        area = shoelace(vertices)
        diff = abs(total_area - 2 * area)
        if diff < minimal_diff:
            minimal_diff = diff

    
    print(f"{minimal_diff:.3f}")

if __name__ == "__main__":
    main()