
def main():
    import sys
    input = sys.stdin.read
    data = input().strip().split()
    
    n = int(data[0])  # ширина пирога
    m = int(data[1])  # высота пирога
    x = int(data[2])  # координата свечки по x
    y = int(data[3])  # координата свечки по y

    # Углы пирога
    corners = [
        (0, 0),    # Левый нижний угол
        (0, m),    # Левый верхний угол
        (n, m),    # Правый верхний угол
        (n, 0)     # Правый нижний угол
    ]

    min_difference = float('inf')

    for corner in corners:
        cx, cy = corner
        
        # Площадь всего пирога
        total_area = n * m
        
        # Площадь части пирога, куда попадает свеча
        # Формула площади треугольника: 0.5 * основание * высота
        # Площадь треугольника (c1):
        triangle_area = abs(cx * (y - cy) + x * (cy - 0) + 0 * (0 - y)) / 2.0
        
        # Площадь второго куска пирога
        second_piece_area = total_area - triangle_area
        
        # Разница между площадями
        difference = abs(triangle_area - second_piece_area)
        
        # Обновляем минимальную разницу
        min_difference = min(min_difference, difference)

    print(f"{min_difference:.3f}")

if __name__ == "__main__":
    main()


