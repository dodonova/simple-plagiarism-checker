n, m = map(int, input().split(' '))
x, y = map(int, input().split(' '))
s = []
if (x / y * m) <= n:
    y1 = m
    x1 = (x / y) * m
elif (x / y * m) > n:
    x1 = n
    y1 = y / x * n

s11 = y1 * x1 * 0.5
s12 = m * n - s11
s.append(abs(s12-s11))
if y *(n / (n - x)) <= m:
    x2 = 0
    y2 = y *(n / (n - x))
elif y *(n / (n - x)) > m:
    y2 = m
    x2 = (m * (x - n)) / y + n
s21 = (n-x2) * 0.5 * y2
s22 = m * n - s21
s.append(abs(s22 - s21))
if ((-m) * (x - n)) / (y - m) + n >= 0:
    y3 = 0
    x3 = m * (n - x) / (y - m) + n
elif ((-m) * (x - n)) / (y - m) + n < 0:
    x3 = 0
    y3 = m * (n - x) / (x - n) + m
s31 = (m - y3) * 0.5 * (n - x3)
s32 = m * n - s31
s.append(abs(s32-s31))
if m * x / (m - y) <= n:
    x4 = m * x / (m - y)
    y4 = 0
elif m * x / (m - y) > n:
    x4 = n
    y4 = (y - m) * n / x + m
s41 = (m - y4) * 0.5 * x4
s42 = m * n - s41
s.append(abs(s42-s41))
print(f'{min(s):.3f}')