#include <iostream>
#include <cmath>

using namespace std;

int main() {
  int n, m, x, y;
  cin >> n >> m >> x >> y;

  // Площадь всего пирога
  double totalArea = n * m;

  // Площадь треугольника, который получит Карлсон, если разрезать из левого верхнего угла
  double triangleArea1 = 0.5 * n * y;

  // Площадь треугольника, который получит Карлсон, если разрезать из правого нижнего угла
  double triangleArea2 = 0.5 * m * x;

  // Площадь треугольника, который получит Карлсон, если разрезать из левого нижнего угла
  double triangleArea3 = 0.5 * (n - x) * y;

  // Площадь треугольника, который получит Карлсон, если разрезать из правого верхнего угла
  double triangleArea4 = 0.5 * (m - y) * x;

  // Находим минимальную разницу площадей
  double minDifference = min({
    abs(totalArea - 2 * triangleArea1),
    abs(totalArea - 2 * triangleArea2),
    abs(totalArea - 2 * triangleArea3),
    abs(totalArea - 2 * triangleArea4)
  });

  cout << fixed << setprecision(3) << minDifference << endl;

  return 0;
}
