def triangle_area(x1, y1, x2, y2, x3, y3):
    """Вычисляет площадь треугольника по координатам его вершин."""
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def line_intersection(cx, cy, x, y, n, m):
    """Находит точку пересечения прямой через (cx, cy) и (x, y) с границами прямоугольника."""
    dx = x - cx
    dy = y - cy
    intersections = []

    # Избегаем деления на ноль
    if dx != 0:
        # Пересечение с правой стороной (x = n)
        t = (n - cx) / dx
        if t > 1e-9:
            iy = cy + t * dy
            if 0 <= iy <= m:
                intersections.append((n, iy))
        # Пересечение с левой стороной (x = 0)
        t = (0 - cx) / dx
        if t > 1e-9:
            iy = cy + t * dy
            if 0 <= iy <= m:
                intersections.append((0, iy))

    if dy != 0:
        # Пересечение с верхней стороной (y = m)
        t = (m - cy) / dy
        if t > 1e-9:
            ix = cx + t * dx
            if 0 <= ix <= n:
                intersections.append((ix, m))
        # Пересечение с нижней стороной (y = 0)
        t = (0 - cy) / dy
        if t > 1e-9:
            ix = cx + t * dx
            if 0 <= ix <= n:
                intersections.append((ix, 0))

    # Удаляем точку свечи, если она попадает
    intersections = [pt for pt in intersections if not (abs(pt[0] - x) < 1e-9 and abs(pt[1] - y) < 1e-9)]
    
    if not intersections:
        return None  # Пересечение не найдено
    
    # Выбираем ближайшее пересечение
    min_dist = float('inf')
    intersection_point = None
    for pt in intersections:
        dist = (pt[0] - cx)*2 + (pt[1] - cy)*2
        if dist < min_dist:
            min_dist = dist
            intersection_point = pt
    return intersection_point

def compute_polygon_area(cx, cy, x, y, ix, iy, n, m):
    """Вычисляет площадь части пирога, ограниченной разрезом и границами."""
    # Определяем направление обхода границ
    # Начинаем от (cx, cy), идём к (x, y), затем к (ix, iy)
    # Далее идём вдоль границ до возвращения к (cx, cy)
    
    # Определяем список вершин
    vertices = []
    vertices.append((cx, cy))
    vertices.append((x, y))
    vertices.append((ix, iy))
    
    # Определяем направление обхода
    # Находим угол разреза относительно оси
    import math
    angle = math.atan2(iy - cy, ix - cx)
    
    # Определяем порядок обхода границ
    # Если угол между 0 и 180 градусами, обход по часовой стрелке
    # Иначе против часовой стрелки
    if 0 <= angle <= math.pi:
        # Обход по часовой стрелке
        if ix == n:
            # Пересечение с правой стороной, продолжаем вверх до (n,m)
            vertices.append((n, m))
            vertices.append((0, m))
            vertices.append((0, 0))
        elif ix == 0:
            # Пересечение с левой стороной, продолжаем вниз до (0,0)
            vertices.append((0, 0))
            vertices.append((n, 0))
            vertices.append((n, m))
        elif iy == m:
            # Пересечение с верхней стороной, продолжаем вправо до (n,m)
            vertices.append((n, m))
            vertices.append((n, 0))
            vertices.append((0, 0))
        elif iy == 0:
            # Пересечение с нижней стороной, продолжаем влево до (0,0)
            vertices.append((0, 0))
            vertices.append((0, m))
            vertices.append((n, m))
    else:
        # Обход против часовой стрелки
        if ix == n:
            # Пересечение с правой стороной, продолжаем вниз до (n,0)
            vertices.append((n, 0))
            vertices.append((0, 0))
            vertices.append((0, m))
        elif ix == 0:
            # Пересечение с левой стороной, продолжаем вверх до (0,m)
            vertices.append((0, m))
            vertices.append((n, m))
            vertices.append((n, 0))
        elif iy == m:
            # Пересечение с верхней стороной, продолжаем влево до (0,m)
            vertices.append((0, m))
            vertices.append((0, 0))
            vertices.append((n, 0))
        elif iy == 0:
            # Пересечение с нижней стороной, продолжаем вправо до (n,0)
            vertices.append((n, 0))
            vertices.append((n, m))
            vertices.append((0, m))
    
    # Закрываем многоугольник
    # Применяем формулу Шёнрёса
    area = 0
    for i in range(len(vertices)):
        x1, y1 = vertices[i]
        x2, y2 = vertices[(i +1) % len(vertices)]
        area += (x1 * y2 - x2 * y1)
    area = abs(area) /2
    return area

def min_area_difference(n, m, x, y):
    total_area = n * m
    min_diff = float('inf')
    
    corners = [
        (0, 0),
        (n, 0),
        (n, m),
        (0, m)
    ]
    
    for (cx, cy) in corners:
        if cx == x and cy == y:
            continue  # Точка свечи совпадает с углом, пропускаем
        # Найти вторую точку пересечения
        intersection = line_intersection(cx, cy, x, y, n, m)
        if not intersection:
            continue  # Пересечение не найдено, пропускаем
        ix, iy = intersection
        # Вычислить площадь одной из частей
        area = compute_polygon_area(cx, cy, x, y, ix, iy, n, m)
        # Разница площадей
        diff = abs(total_area - 2 * area)
        if diff < min_diff:
            min_diff = diff
    return min_diff

def main():
    import sys
    n, m = map(int, sys.stdin.readline().split())
    x, y = map(int, sys.stdin.readline().split())
    diff = min_area_difference(n, m, x, y)
    print(f"{diff:.3f}")

if _name_ == "_main_":
    main()