n, m = map(int, input().split())
x, y = map(int, input().split())

area_small = x * y

area_big = (n - x) * (m - y)

diff = abs(area_big - area_small)
print(diff)