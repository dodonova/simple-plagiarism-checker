n, m = map(int, input().split())
x, y = map(int, input().split())


a_values = [
    y / x,
    (y - m) / x,
    (m - y) / (n - x),
    -y / (n - x)
]


b_values = [
    0,
    y - a_values[1] * x,
    y - a_values[2] * x,
    y - a_values[3] * x
]

results = []


def calculate_area(n, m, x, y, a, b):
    if abs(a) > m / n:
        x_intercept = (m - b) / a
        area1 = ((x_intercept + n) * m) / 2
        area2 = (m * (n - x_intercept)) / 2
    else:
        x_intercept = n
        y_intercept = a * x_intercept + b
        area1 = ((y_intercept + m) * x_intercept) / 2
        area2 = (x_intercept * (m - y_intercept)) / 2
    return abs(area1 - area2)

for i in range(4):
    if i == 0:
        results.append(calculate_area(n, m, x, y, a_values[i], b_values[i]))
    else:
        results.append(calculate_area(n, m, 0, 0, a_values[i], b_values[i]))

print(min(results))
