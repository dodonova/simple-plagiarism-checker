import math
def calculate_min_difference(n, m, x, y):
    difference = ((n - x) * (m - y) / 2) - (x * y / 2)
    root = math.sqrt((difference**2) + (x * y))
    min_difference = abs(root - difference)
    return round(min_difference, 3)
n, m = map(int, input().split())
x, y = map(int, input().split())