n, m = [int(x) for x in input().split()]
x, y = [int(x) for x in input().split()]
s = n * m
tgalpha = x / y
s1 = 0.5 * m * m * tgalpha
ds1 = abs(s - 2 * s1)
tgalpha = x / (m - y)
s2 = 0.5 * m * m * tgalpha
ds2 = abs(s - 2 * s2)
tgalpha = (n - x) / (m - y)
s3 = 0.5 * m * m * tgalpha
ds3 = abs(s - 2 * s3)
tgalpha = y / (n - x)
s4 = 0.5 * n * n * tgalpha
ds4 = abs(s - 2 * s4)
print(round(min([ds1, ds2, ds3, ds4]), 3))
