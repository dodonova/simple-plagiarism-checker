def min_area_difference(n, m, x, y):
 
    min_diff = float('inf') # Задаем начальное значение min_diff как бесконечность

    # Разрез от (0, 0)
    S1 = 0.5 * x * y
    S2 = n * m - S1
    min_diff = min(min_diff, abs(S1 - S2))

    # Разрез от (n, 0)
    S1 = 0.5 * (n - x) * y
    S2 = n * m - S1
    min_diff = min(min_diff, abs(S1 - S2))

    # Разрез от (0, m)
    S1 = 0.5 * x * (m - y)
    S2 = n * m - S1
    min_diff = min(min_diff, abs(S1 - S2))

    # Разрез от (n, m)
    S1 = 0.5 * (n - x) * (m - y)
    S2 = n * m - S1
    min_diff = min(min_diff, abs(S1 - S2))

    return min_diff

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы и вывод результата
result = min_area_difference(n, m, x, y)
print(f"{result:.3f}")

