def read_cake_dimensions(file):
    cakes = []
    for _ in range(8):
        dimensions = file.readline().strip().split()
        cakes.append((int(dimensions[0]), int(dimensions[1])))
    return cakes

def find_candle_position(file):
    x, y = map(int, file.readline().strip().split())
    return (x, y)

def main():
    import sys

    # Для использования ввода через файл
    input_file_name = 'input.txt'  # использовать data из input.txt
    output_file_name = 'output.txt'  # запись в output.txt

    with open(input_file_name, 'r') as input_file:
        cakes = read_cake_dimensions(input_file)
        candle_position = find_candle_position(input_file)

    # логику обработки 
    results = []
    
    # вывод в output.txt
    with open(output_file_name, 'w') as output_file:
        # пример вывода
        for cake in cakes:
            if candle_position[0] <= cake[0] and candle_position[1] <= cake[1]:
                results.append(f"Candle can fit in ({cake[0]}, {cake[1]})")
            else:
                results.append(f"Candle can't fit in ({cake[0]}, {cake[1]})")
        
        output_file.write("\n".join(results))

# Убедитесь, что программа будет запущена как основной модуль
if __name__ == '__main__':
    main()