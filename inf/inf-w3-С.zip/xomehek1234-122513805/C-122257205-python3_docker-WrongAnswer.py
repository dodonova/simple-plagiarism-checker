def dif (candlex,candley,col,st):
    d1 = (((candlex - 0) ** 2 + (candley - 0) ** 2) ** 0.5, 0)
    d2 = (((candlex - 0) ** 2 + (candley - col) ** 2) ** 0.5, 1)
    d3 = (((candlex - st) ** 2 + (candley - 0) ** 2) ** 0.5, 2)
    d4 = (((candlex -  st) ** 2 + (candley - col) ** 2) ** 0.5, 3)
    m1 = max([d1, d2, d3, d4])[1]
    match m1:
        case 0:
            if candley / candlex > col / st:
                return(round(float(col * (st- ((col * candlex) / candley))), 3))
            elif candley / candlex < col / st:
                return(round(float(st * (col - ((st * candley) / candlex))), 3))
            else:
                return('0.000')
        case 1:
            if candlex / (col - candley) > st / col:
                a = (col * (st - candley)) / candlex
                return(round(float(col * (st - a)), 3))
            elif candlex / (col - candley) < st / col:
                return(round(float(col * (st - ((col * candlex) / (col - candley)))), 3))
            else:
                return('0.000')
        case 2:
            if (st - candlex) / (col - candley) > st / col:
                return(round(float(st * (col - ((st * (col - candley)) / (st - candlex)))), 3))
            elif (st - candlex) / (col - candley) < st / col:
                return(round(float(col * (st - ((col * (st - candlex)) / (col - candley)))), 3))
            else:
                return('0.000')
        case 3:
            if candley / (st - candlex) < col / st:
                return (round(float(col * (st - ((col * (st - candlex)) / candley)))))
            elif candley / (st - candlex) > col / st:
                return(round(float(st * (col - ((st * candley) / (col - candlex)))), 3))
            else:
                return('0.000')

col, st = list(map(int, input().split()))
candlex, candley =  list(map(int, input().split()))
print(dif(candlex, candley, col, st))
