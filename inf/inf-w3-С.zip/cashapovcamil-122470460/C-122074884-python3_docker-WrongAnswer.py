def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def min_difference(n, m, x, y):
    total_area = n * m
    
    min_diff = float('inf')
    
    # Разрез через левый нижний угол
    area1 = area_of_triangle(0, 0, x, y, n, 0)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез через правый нижний угол
    area1 = area_of_triangle(n, 0, x, y, n, m)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез через левый верхний угол
    area1 = area_of_triangle(0, m, x, y, 0, 0)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез через правый верхний угол
    area1 = area_of_triangle(n, m, x, y, 0, m)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{result:.3f}")