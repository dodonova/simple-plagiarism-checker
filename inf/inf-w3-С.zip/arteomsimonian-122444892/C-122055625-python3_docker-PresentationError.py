def calculate_min_difference(n, m, x, y):
    total_area = n * m
    differences = []

    area1 = x * y
    area2 = total_area - area1
    differences.append(abs(area1 - area2))

    area1 = x * (m - y)
    area2 = total_area - area1
    differences.append(abs(area1 - area2))

    area1 = (n - x) * y
    area2 = total_area - area1
    differences.append(abs(area1 - area2))

    area1 = (n - x) * (m - y)
    area2 = total_area - area1
    differences.append(abs(area1 - area2))

    return min(differences)

n, m = map(int, input("Введите размеры пирога (n m): ").split())
x, y = map(int, input("Введите координаты свечи (x y): ").split())

min_difference = calculate_min_difference(n, m, x, y)

print(f"{min_difference:.3f}")