def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0)

def calculate_areas(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Возможные разрезы
    areas = []
    
    # Разрез через (0, 0)
    area1 = area_of_triangle(0, 0, n, 0, x, y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    # Разрез через (n, 0)
    area1 = area_of_triangle(n, 0, n, m, x, y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    # Разрез через (n, m)
    area1 = area_of_triangle(n, m, 0, m, x, y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    # Разрез через (0, m)
    area1 = area_of_triangle(0, m, 0, 0, x, y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    return min(areas)

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
min_difference = calculate_areas(n, m, x, y)

# Вывод результата с точностью 3 знака после запятой
print(f"{min_difference:.3f}")
