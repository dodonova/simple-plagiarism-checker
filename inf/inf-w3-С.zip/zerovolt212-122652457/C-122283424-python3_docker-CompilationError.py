n, m = map(int, input("Введите размеры пирога (n m): ").split())
x, y = map(int, input("Введите координаты свечи (x y): ").split())

total_area = n * m

differences = []

differences.append(abs(x * y - (total_area - x * y)))
differences.append(abs(x * (m - y) - (total_area - x * (m - y))))
differences.append(abs((n - x) * (m - y) - (total_area - (n - x) * (m - y))))
differences.append(abs((n - x) * y - (total_area - (n - x) * y))
min_difference = min(differences)

print(f"{min_difference:.3f}")