def calculate_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    n = int(data[0])
    m = int(data[1])
    x = int(data[2])
    y = int(data[3])
    
    total_area = n * m
    min_difference = float('inf')
    
    # Углы пирога
    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    
    for corner in corners:
        cx, cy = corner
        
        # Площадь треугольника
        triangle_area = calculate_area(cx, cy, x, y, cx + (n if cx == 0 else -n), cy + (m if cy == 0 else -m))
        
        # Площадь второй части
        other_area = total_area - triangle_area
        
        # Разница между частями
        difference = abs(triangle_area - other_area)
        
        # Обновляем минимальную разницу
        if difference < min_difference:
            min_difference = difference
    
    # Форматируем вывод до трех знаков после запятой
    print(f"{min_difference:.3f}")

if __name__ == "__main__":
    main()
