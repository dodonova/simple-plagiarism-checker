#include <bits/stdc++.h>

using namespace std;

using dbl = long double;

struct Pt {
    dbl x, y;
};

dbl n, m;

struct Gvec {
    dbl x, y;

    Gvec(Pt a, Pt b) : x(b.x - a.x), y(b.y - a.y) {
    }

    dbl operator%(const Gvec &other) const {
        return x * other.y - other.x * y;
    }
};

dbl getS(vector<Pt> &vec) {
    dbl ans = 0;
    for (int i = 1; i + 1 < int(vec.size()); ++i) {
        Gvec v = Gvec(vec[0], vec[i]);
        Gvec v1 = Gvec(vec[0], vec[i + 1]);
        ans += v % v1;
    }
    return ans;
}

dbl check(int A, int B, int C, int A1, int B1, int C1, Pt p, dbl x1, dbl y1) {
    dbl xk = dbl(-C * B1 + C1 * B) / (dbl(1) * (A * B1 - A1 * B));
    dbl yk = dbl(-A * C1 + A1 * C) / (dbl(1) * (A * B1 - A1 * B));
    if (0 <= xk && xk <= n && 0 <= yk && yk <= m) {
        vector<Pt> vec = {{p.x, p.y}, {xk, yk}, {x1, y1}};
        dbl S = abs(getS(vec)) / 2;
        dbl SB = dbl(n * m) - S;
        return abs(n * m - 2 * S);
    } else return 1e9;
}

dbl getAns(Pt a, Pt b) {
    int A = b.y - a.y;
    int B = a.x - b.x;
    int C = b.x * a.y - a.x * b.y;
    dbl ans = 1e9;
    ans = min(ans, check(A, B, C, 0, 1, 0, a, n, 0));
    ans = min(ans, check(A, B, C, 0, 1, -m, a, n, m));
    ans = min(ans, check(A, B, C, 1, 0, 0, a, 0, m));
    ans = min(ans, check(A, B, C, 1, 0, -n, a, n, m));
    return ans;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
#ifdef _DEBUG
    freopen("input.txt", "r", stdin);
#endif
    Pt p;
    cin >> n >> m >> p.x >> p.y;
    dbl ans = 1e9;
    ans = min(ans, getAns({0, 0}, p));
    ans = min(ans, getAns({n, 0}, p));
    ans = min(ans, getAns({m, m}, p));
    ans = min(ans, getAns({0, m}, p));
    cout << fixed << setprecision(3);
    cout << ans;
}
