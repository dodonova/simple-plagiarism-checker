x1, y1 = [float(i) for i in input().split()]
x2, y2 = [float(i) for i in input().split()]
S = x1 * y1
def mat(x1, y1, x2, y2):
    k = (y1 - y2) / (x1 - x2)
    b = y2 - k * x2
    return k, b

x1, y1 = map(float, input().split()) #размеры прямоугольного пирога
x2, y2 = map(float, input().split()) #координаты свечки
a = x1 * y1
k, b = mat(0, y1, x2, y2)
x3 = (0 - b) / k
y3 =  k * x1 + b
if x3 <= x1:
    a = min(a, (x1 - x3) * y1)
else:
    a = min(a, x1 * y3)
k, b = mat(x1, 0, x2, y2)
x3 = (y1 - b) / k
y3 = b
if x3 >= 0:
    a = min(a, x3 * y1)
else:
    a = min(a, x1 * (y1 - y3))
k, b = mat(x1, y1, x2, y2)
x3 = - (b / k)
y3 = b
if x3 >= 0:
    a = min(a, x3 * y1)
else:
    a = min(a, x1 * y3)
k, b = mat(0, 0, x2, y2)
x3 = (y1 - b) / k
y3 =  k * x1 + b
if x3 <= x1:
    a = min(a, (x1 - x3) * y1)
else:
    a = min(a, x1 * (y1 - y3))

print('%.3f' % a)