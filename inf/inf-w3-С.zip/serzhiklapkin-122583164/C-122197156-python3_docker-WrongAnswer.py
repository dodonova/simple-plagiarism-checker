femto, behelit = map(int, input().split())
piece, deku = map(int, input().split())
minimal = behelit*femto
for i in range(4):
    if i == 0:
        x = femto
        y = (deku/piece)*x
    elif i == 1:
        y = behelit
        x = ((femto-piece)/deku)*y
    elif i == 2:
        y = behelit
        x = ((femto-piece)/(behelit-deku))*y
    elif i == 3:
        x = femto
        y = ((behelit-deku)/piece)*x
    home = (behelit*femto - (x*y)/2) - (x*y)/2
    if home < minimal:
        minimal = home
print(f"{minimal:.3f}")
