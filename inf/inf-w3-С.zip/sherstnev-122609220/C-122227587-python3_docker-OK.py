def main():
    size, candle = list(map(lambda a: int(a), input().split(" "))), list(map(lambda a: int(a), input().split(" ")))

    outcomes = [(0, 0), (0, size[1]), (size[0], size[1]), (size[0], 0)]

    start_size = size[0] * size[1]
    s1, s2, s3, s4 = 0, 0, 0, 0

    for x, y in outcomes:
        if x == 0 and y == 0:
            s1 = start_size - 2 * (candle[0] * candle[1] / 2) * (size[0] / candle[0]) ** 2

            if s1 < 0:
                s1 = start_size - 2 * (candle[0] * candle[1] / 2) * (size[1] / candle[1]) ** 2

        if x == 0 and y == size[1]:
            s2 = start_size - 2 * (candle[0] * (size[1] - candle[1]) / 2) * (size[0] / candle[0]) ** 2

            if s2 < 0:
                s2 = start_size - 2 * (candle[0] * (size[1] - candle[1]) / 2) * (size[1] / (size[1] - candle[1])) ** 2
        if x == size[0] and y == size[1]:
            s3 = start_size - 2 * ((size[0] - candle[0]) * (size[1] - candle[1]) / 2) * (
                    size[1] / (size[1] - candle[1])) ** 2

            if s3 < 0:
                s3 = start_size - 2 * ((size[0] - candle[0]) * (size[1] - candle[1]) / 2) * (
                        size[0] / (size[0] - candle[0])) ** 2
        if x == size[0] and y == 0:
            s4 = start_size - 2 * (((size[0] - candle[0]) * candle[1] / 2) * (size[1] / candle[1]) ** 2)

            if s4 < 0:
                s4 = start_size - 2 * (((size[0] - candle[0]) * candle[1] / 2) * (size[0] / (size[0] - candle[0])) ** 2)

    print(round(min(s1, s2, s3, s4), 3))


main()
