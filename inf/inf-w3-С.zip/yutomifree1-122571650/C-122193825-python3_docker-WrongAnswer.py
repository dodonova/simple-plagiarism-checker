def calculate_area_difference(n, m, x, y, x1, y1):
    # Общая площадь пирога
    total_area = n * m

    # Площади треугольников для каждого угла
    if x1 == 0 and y1 == 0:
        area1 = 0.5 * x * y
    elif x1 == 0 and y1 == m:
        area1 = 0.5 * x * (m - y)
    elif x1 == n and y1 == 0:
        area1 = 0.5 * (n - x) * y
    elif x1 == n and y1 == m:
        area1 = 0.5 * (n - x) * (m - y)

    area2 = total_area - area1

    return abs(area1 - area2)

def find_minimum_difference(n, m, x, y):
    # Проверяем разрезы через все четыре угла
    differences = [
        calculate_area_difference(n, m, x, y, 0, 0),
        calculate_area_difference(n, m, x, y, 0, m),
        calculate_area_difference(n, m, x, y, n, 0),
        calculate_area_difference(n, m, x, y, n, m)
    ]
    return min(differences)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
min_difference = find_minimum_difference(n, m, x, y)

# Вывод результата
print(f"{min_difference:.3f}")