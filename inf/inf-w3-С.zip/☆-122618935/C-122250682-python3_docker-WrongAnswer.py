a, b = map(int, input().split())
x, y = map(int, input().split())
s1 = ((b-y)/x)*(a**2)/2
s2 = (a-x)/(b-y)
s2 = s2*(y**2)/2
s3 = ((b-y)/x)*(a**2)/2
s4 = ((a-x)/y)*(b**2)/2
s = a*b
ss = [s-2*s1,s-2*s2, s-2*s3, s-2*s4]
print(round(min(ss), 3))
