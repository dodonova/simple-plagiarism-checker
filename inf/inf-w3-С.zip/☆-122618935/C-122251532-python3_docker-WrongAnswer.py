a, b = map(int, input().split())
x, y = map(int, input().split())
import math
b = abs(b)
s1 = ((b-y)/x)*(a**2)/2
s2 = (a-x)/(b-y)
s2 = s2*(b**2)/2
s3 = ((b-y)/x)*(a**2)/2
s4 = ((a-x)/y)*(b**2)/2
s = a*b
ss = [abs(s-2*s1),abs(s-2*s2), abs(s-2*s3), abs(s-2*s4)]

print(round(min(ss), 3))
