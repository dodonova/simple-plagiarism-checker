n, m = map(int, input().split())
x, y = map(int, input().split())

dp = [[0 for _ in range(m)] for _ in range(n)]
dp[0][0] = 1

for i in range(n):
    for j in range(m):
        if i > 0:
            dp[i][j] += dp[i-1][j]
        if j > 0:
            dp[i][j] += dp[i][j-1]

print(dp[x-1][y-1])