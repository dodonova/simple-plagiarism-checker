n, m = map(int, input().split())
x, y = map(int, input().split())

if x >= n/2:
    x = n - x
if y >= m/2:
    y = m - y

min_diff = min(x * m, y * n) / 2

print('{:.3f}'.format(min_diff))