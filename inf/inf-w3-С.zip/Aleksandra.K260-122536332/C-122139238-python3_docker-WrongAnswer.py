def minimal_difference(n, m, x, y):
    # Общая площадь пирога
    total_area = n * m

    # Разделяем по разным углам:
    # 1. (0, 0) -> (x, y)
    area1 = 0.5 * x * y
    area2 = total_area - area1
    diff1 = abs(area1 - area2)
    
    # 2. (n, 0) -> (x, y)
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    diff2 = abs(area1 - area2)

    # 3. (n, m) -> (x, y)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)

    # 4. (0, m) -> (x, y)
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)

    # Найдем минимальную разницу
    min_diff = min(diff1, diff2, diff3, diff4)
    
    return min_diff

# Чтение входных данных
import sys
input = sys.stdin.read
data = input().splitlines()
n, m = map(int, data[0].split())
x, y = map(int, data[1].split())

# Рассчитываем минимальную разницу
result = minimal_difference(n, m, x, y)

# Выводим результат
print(f"{result:.3f}")



