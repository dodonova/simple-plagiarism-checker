def min_area_difference(n, m, x, y):
    def triangle_area(a, b, c):
        return abs(a[0] * (b[1] - c[1]) + b[0] * (c[1] - a[1]) + c[0] * (a[1] - b[1])) / 2

    def find_min_diff():
        min_diff = float('inf')

        corners = [(0, 0), (n, 0), (0, m), (n, m)]

        for corner in corners:
            dx = corner[0] - x
            dy = corner[1] - y

            if dx != 0:
                slope = dy / dx
                intercept = corner[1] - slope * corner[0]

                # Найдем пересечение с границами прямоугольника
                if slope > 0:
                    intersection_x = max(0, min(n, (m - intercept) // slope))
                    intersection_y = slope * intersection_x + intercept
                else:
                    intersection_x = max(0, min(n, (-intercept) // slope))
                    intersection_y = slope * intersection_x + intercept

                # Рассчитаем площади треугольников
                area1 = triangle_area(corner, (intersection_x, intersection_y), (x, y))
                area2 = triangle_area(corner, (intersection_x, intersection_y), (n, m)) + triangle_area(
                    (intersection_x, intersection_y), (0, m), (x, y))
                total_area = n * m
                diff = abs(total_area - 2 * (area1 + area2))

                min_diff = min(min_diff, diff)
				print(min_diff)

        return min_diff

    return find_min_diff()