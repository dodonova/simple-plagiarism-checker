def calculate_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def minimum_difference(n, m, x, y):
    # Список координат углов пирога
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    total_area = n * m
    
    min_difference = float('inf')
    
    for corner in corners:
        cx, cy = corner
        area1 = calculate_area(cx, cy, x, y, (0 if cx == n else n, 0 if cy == m else m))
        area2 = total_area - area1
        difference = abs(area1 - area2)
        if difference < min_difference:
            min_difference = difference
    
    return min_difference

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = minimum_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{result:.10f}")
