#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

double calculate_area_difference(int n, int m, int x, int y) {
    double min_difference = double(n * m); // Максимальная возможная разница

    // Угол (0, 0)
    double area1 = (x * y) / 2.0;
    double area2 = n * m - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Угол (0, m)
    area1 = (x * (m - y)) / 2.0;
    area2 = n * m - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Угол (n, 0)
    area1 = ((n - x) * y) / 2.0;
    area2 = n * m - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Угол (n, m)
    area1 = ((n - x) * (m - y)) / 2.0;
    area2 = n * m - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    return min_difference;
}

int main() {
    int n, m;
    cin >> n >> m; // Ввод размеров пирога
    int x, y;
    cin >> x >> y; // Ввод координат свечки

    // Получение минимальной разницы и вывод результата
    double result = calculate_area_difference(n, m, x, y);
    cout << fixed << setprecision(3) << result << endl;

    return 0;
}