def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m min_diff = float('inf')  # Инициализируем минимальную разницу # Разрез через (0, 0)
    area1 = x * y area2 = total_area - area1 min_diff = min(min_diff, abs(area1 - area2))

    # Разрез через (n, 0)
    area1 = (n - x) * y area2 = total_area - area1 min_diff = min(min_diff, abs(area1 - area2))

    # Разрез через (0, m)
    area1 = x * (m - y)
    area2 = total_area - area1 min_diff = min(min_diff, abs(area1 - area2))

    # Разрез через (n, m)
    area1 = (n - x) * (m - y)
    area2 = total_area - area1 min_diff = min(min_diff, abs(area1 - area2))

    return min_diff

# Ввод данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Получение результата
result = min_difference(n, m, x, y)
print(f"{result:.10f}")

