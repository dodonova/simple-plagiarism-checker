mn = input().split()
for i in range(len(mn)):
    mn[i] = int(mn[i])
xy = input().split()
for i in range(len(xy)):
    xy[i] = int(xy[i])
m = mn[1]
n = mn[0]
x = xy[0]
y = xy[1]
kd02 = m / n
kd13 = -m / n
k0 = y / x
if k0 <= kd02:
    y0 = k0 * n
    razn0 = m * n - y0 * n
else:
    x0 = m / k0
    razn0 = m * n - x0 * n
k1 = (y - m) / x
if k1 <= kd13:
    x1 = -m / k1
    razn1 = m * n - m * x1
else:
    y1 = k1 * n + m
    razn1 = m * n - n * (m - y1)
k2 = (y - m) / (x - n)
if k2 >= kd02:
    b2 = y - k2 * x
    x2 = -b2 / k2
    razn2 = m * n - (n - x2) * m
else:
    b2 = y - k2 * x
    y2 = b2
    razn2 = m * n - n * (m - y2)
k3 = y / (x - n)
if k3 >= kd13:
    b3 = -n * k3
    y3 = b3
    razn3 = m * n - n * y3
else:
    b3 = y - k3 * x
    x3 = (m - b3) / k3
    razn3 = m * n - m * (n - x3)
razn = sorted((razn0, razn1, razn2, razn3))
itog = razn[0]
itog = round(itog, 3)
print(itog)
