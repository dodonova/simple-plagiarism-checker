def area_diff(n, m, x, y):
    # Вычисляем площади для всех возможных углов разреза
    # Угол (0, 0) -> нижний левый угол
    S1 = 0.5 * x * y
    S2 = n * m - S1
    diff1 = abs(S1 - S2)

    # Угол (n, 0) -> нижний правый угол
    S1 = 0.5 * (n - x) * y
    S2 = n * m - S1
    diff2 = abs(S1 - S2)

    # Угол (0, m) -> верхний левый угол
    S1 = 0.5 * x * (m - y)
    S2 = n * m - S1
    diff3 = abs(S1 - S2)

    # Угол (n, m) -> верхний правый угол
    S1 = 0.5 * (n - x) * (m - y)
    S2 = n * m - S1
    diff4 = abs(S1 - S2)

    # Возвращаем минимальную разницу
    return min(diff1, diff2, diff3, diff4)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Выводим минимальную разницу
print(f"{area_diff(n, m, x, y):.3f}")
