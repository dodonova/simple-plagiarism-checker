def min_difference_area(n, m, x, y):
    
    total_area = n * m

  
    areas = []

   
    area_a1 = 0.5 * x * y
    area_b1 = total_area - area_a1
    areas.append(abs(area_a1 - area_b1))

   
    area_a2 = 0.5 * (n - x) * y
    area_b2 = total_area - area_a2
    areas.append(abs(area_a2 - area_b2))

 
    area_a3 = 0.5 * x * (m - y)
    area_b3 = total_area - area_a3
    areas.append(abs(area_a3 - area_b3))

 
    area_a4 = 0.5 * (n - x) * (m - y)
    area_b4 = total_area - area_a4
    areas.append(abs(area_a4 - area_b4))

    
    return min(areas)


n, m = map(int, input().split())
x, y = map(int, input().split())


result = min_difference_area(n, m, x, y)
print(f"{result:.3f}")
