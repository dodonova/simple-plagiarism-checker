using System;

class Program
{
    static void Main()
    {
        // Ввод размеров пирога
        string[] dimensions = Console.ReadLine().Split();
        double n = double.Parse(dimensions[0]);
        double m = double.Parse(dimensions[1]);

        // Ввод координат свечки
        string[] candlePosition = Console.ReadLine().Split();
        double sx = double.Parse(candlePosition[0]);
        double sy = double.Parse(candlePosition[1]);

        double minDifference = double.MaxValue;

        // Проверяем все четыре угла
        // 1. Нижний левый угол (0, 0)
        CalculateMinDifference(0, 0, sx, sy, n, m, ref minDifference);

        // 2. Верхний левый угол (0, m)
        CalculateMinDifference(0, m, sx, sy, n, m, ref minDifference);

        // 3. Нижний правый угол (n, 0)
        CalculateMinDifference(n, 0, sx, sy, n, m, ref minDifference);

        // 4. Верхний правый угол (n, m)
        CalculateMinDifference(n, m, sx, sy, n, m, ref minDifference);

        // Вывод результата с точностью до трех знаков после запятой
        Console.WriteLine($"{minDifference:F3}");
    }

    static void CalculateMinDifference(double cornerX, double cornerY, double sx, double sy, double n, double m, ref double minDifference)
    {
        // Площадь всего пирога
        double totalArea = n * m;

        // Площадь треугольника
        double triangleArea = Math.Abs(cornerX * (sy - cornerY) + sx * (cornerY - 0) + 0 * (cornerY - sy)) / 2;
        
        // Площадь оставшегося куска
        double remainingArea = totalArea - triangleArea;

        // Разница между кусками
        double difference = Math.Abs(triangleArea - remainingArea);
        
        // Обновляем минимальную разницу
        if (difference < minDifference)
            minDifference = difference;
    }
}