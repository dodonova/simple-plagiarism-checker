a,b=map(int,input().split())
x2,y2=map(int,input().split())
s1=a*(a*y2/x2)/2
s2=b*((a-x2)*b/y2)/2
s3=b*(-b*(x2-a)/(y2-b))/2
s4=a*(a*(b-y2)/x2)/2
s=a*b
tot=str(round(min(abs(s-s1-s1),abs(s-s2-s2),abs(s-s3-s3),abs(s-s4-s4)),3)).split('.')
while len(tot[1])<3:
    tot[1]+='0'
print('.'.join(tot))