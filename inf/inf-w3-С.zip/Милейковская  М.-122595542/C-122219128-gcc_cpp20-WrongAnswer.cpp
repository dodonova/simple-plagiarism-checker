#include <bits/stdc++.h>
using namespace std;

#define int long long

signed main() {
    long double n, m, x, y;
    cin >> n >> m >> x >> y;
    long double mn = 1e9;
    vector <long double> check = {(n * n * y) / (2 * x), (n * n * (m - y)) / (2 * x), (m * m * (n - x)) / (2 * y), (m * m * (n - x)) / (2 * (m - y))};
    for (auto it : check) {
        auto cur = n * m - it;
        mn = min(mn, abs(cur - it));
    }
    cout << fixed << setprecision(3);
    cout << mn;
}
