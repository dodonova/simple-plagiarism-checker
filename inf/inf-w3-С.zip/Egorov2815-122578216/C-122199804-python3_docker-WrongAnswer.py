def max_weaving_area(a):
    n = len(a)
    
    # Сортируем полоски по длине в порядке убывания
    a.sort(reverse=True)
    
    # Префиксные суммы
    prefix_sum = [0] * (n + 1)
    for i in range(1, n + 1):
        prefix_sum[i] = prefix_sum[i - 1] + a[i - 1]
    
    max_area = 0
    
    # Пробуем разные разделения полосок на две группы
    for k in range(n + 1):
        sum_yellow = prefix_sum[k]  # Сумма длин желтых
        sum_green = prefix_sum[n] - sum_yellow  # Сумма длин зеленых
        area = 2 * min(sum_yellow, sum_green)
        max_area = max(max_area, area)
    
    return max_area

# Чтение входных данных
import sys

input_data = sys.stdin.read()
a = list(map(int, input_data.split()))

# Вычисление максимальной площади
result = max_weaving_area(a)

# Вывод результата
print(result)
