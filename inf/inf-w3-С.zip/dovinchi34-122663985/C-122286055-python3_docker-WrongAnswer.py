# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление площадей частей пирога
left_area = x * m
right_area = (n - x) * m
bottom_area = n * y
top_area = n * (m - y)
diagonal_area = (x * y) + ((n - x) * (m - y))

# Нахождение минимальной разницы площадей
min_diff = min(abs(left_area - right_area), abs(bottom_area - top_area), abs(diagonal_area - (n * m - diagonal_area)))

# Вывод результата
print(f"{min_diff:.3f}")