def area_difference(n, m, x, y):
    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    min_diff = float('inf')

    for cx, cy in corners:
        area1 = abs(cx * y - cy * x) / 2
        total_area = n * m
        area2 = total_area - area1
        diff = abs(area1 - area2)
        min_diff = min(min_diff, diff)

    return min_diff

n, m = map(int, input("Введите размеры прямоугольника (n m): ").split())
x, y = map(int, input("Введите координаты точки (x y): ").split())

result = area_difference(n, m, x, y)
print(f"{result:.3f}")
