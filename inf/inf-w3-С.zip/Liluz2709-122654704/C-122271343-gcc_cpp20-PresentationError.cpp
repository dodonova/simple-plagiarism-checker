#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

int main() {
    string mixed_string;
    cin >> mixed_string;

    int n;
    cin >> n;

    vector<string> words(n);
    for (int i = 0; i < n; ++i) {
        cin >> words[i];
    }

    map<char, int> mixed_counts;
    for (char c : mixed_string) {
        mixed_counts[c]++;
    }

    vector<string> result;
    for (int i = 5; i <= 8; ++i) {
        for (int j = 0; j < (1 << n); ++j) {
            if (__builtin_popcount(j) != i) continue; // Проверка на количество слов в комбинации

            vector<string> current_combo;
            string combined_string = "";
            for (int k = 0; k < n; ++k) {
                if ((j >> k) & 1) {
                    current_combo.push_back(words[k]);
                    combined_string += words[k];
                }
            }

            map<char, int> combo_counts;
            for (char c : combined_string) {
                combo_counts[c]++;
            }

            if (combo_counts == mixed_counts) {
                result = current_combo;
                break;
            }
        }
        if (!result.empty()) break;
    }

    sort(result.begin(), result.end());
    for (const string& word : result) {
        cout << word << endl;
    }

    return 0;
}