#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

int main() {
    double n, m, x, y;
    cin >> n >> m >> x >> y;

    double tr1 = x * y / 2;
    double ot1 = n * m - tr1;
    double r1 = abs(tr1 - ot1);

    double tr2;
    if (x != n) {
        double k = y / (n - x);
        if (k != 0) {
            tr2 = (m / k) * m / 2;
        } else {
            tr2 = 0;
        }
    } else {
        tr2 = m * n / 2;
    }
    double ot2 = n * m - tr2;
    double r2 = abs(tr2 - ot2);

    double tr3;
    if (x != n) {
        double k = (y - m) / (x - n);
        if (k != 0) {
            double intersecX = m / k;
            if (intersecX >= 0 && intersecX <= n) {
                tr3 = intersecX * m / 2;
            } else {
                tr3 = n * m / 2;
            }
        } else {
            tr3 = n * m / 2;
        }
    } else {
        tr3 = n * m / 2;
    }
    double ot3 = n * m - tr3;
    double r3 = abs(tr3 - ot3);

    double tr4;
    if (x != 0) {
        double k = (m - y) / x;
        if (k != 0) {
            double intersecY = k * n;
            if (intersecY >= 0 && intersecY <= m) {
                tr4 = n * intersecY / 2;
            } else {
                tr4 = n * m / 2;
            }
        } else {
            tr4 = 0;
        }
    } else {
        tr4 = n * m / 2;
    }
    double ot4 = n * m - tr4;
    double r4 = abs(tr4 - ot4);

    cout << min({r1, r2, r3, r4}) << endl;
    return 0;
}
