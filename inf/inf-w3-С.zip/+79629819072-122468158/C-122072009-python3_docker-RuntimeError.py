python
n, m = map(int, input().split())
x, y = map(int, input().split())

total_area = n * m

def triangle_area(x1, y1, x2, y2):
    return abs(x1 * y2 - x2 * y1) / 2

areas = [
    triangle_area(0, 0, x, y),
    triangle_area(n, 0, x, y),
    triangle_area(0, m, x, y),
    triangle_area(n, m, x, y)
]

min_difference = float('inf')
for area in areas:
    piece1 = area
    piece2 = total_area - piece1
    difference = abs(piece1 - piece2)
    min_difference = min(min_difference, difference)

print(f"{min_difference:.3f}")