def min_area_difference(n, m, x, y):
 area_top_left = 0.5 * x * y
 area_top_right = 0.5 * (n - x) * y
 area_bottom_left = 0.5 * x * (m - y)
 area_bottom_right = 0.5 * (n - x) * (m - y)
 min_diff = min(
   abs(area_top_left - (n * m - area_top_left)),
   abs(area_top_right - (n * m - area_top_right)),
   abs(area_bottom_left - (n * m - area_bottom_left)),
   abs(area_bottom_right - (n * m - area_bottom_right))
 )
 return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())
print(min_area_difference(n, m, x, y))