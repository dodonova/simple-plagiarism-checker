n, m = map(int, input().split())
x, y = map(int, input().split())

raise Exception(n, m, x, y)

def formula(x1, y1, x2, y2):
    k = (y1 - y2) / (x1 - x2)
    b = y2 - k * x2
    return k, b
    
def formula2(x1, y1, x2, y2):
    k = (x1 - x2) / (y1 - y2)
    b = x2 - k * y2
    return k, b

area = n * m

k1, b1 = formula(0, 0, x, y)
area1 = n * (k1 * n + b1) * 0.5
diff1 = abs(area1 - (area - area1))

k2, b2 = formula(0, m, x, y)
area2 = n * (m - (k2 * n + b2)) * 0.5
diff2 = abs(area2 - (area - area2))

k3, b3 = formula2(n, 0, x, y)
area3 = m * (n - (k3 * m + b3)) * 0.5
diff3 = abs(area3 - (area - area3))

k4, b4 = formula2(x, y, n, m)
area4 = m * (n - b4) * 0.5
diff4 = abs(area4 - (area - area4))

res = min(diff1, diff2, diff3, diff4)
print(f"{res:.3f}")