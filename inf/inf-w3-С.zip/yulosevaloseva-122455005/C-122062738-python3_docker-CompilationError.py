def cut_cake(width, height, angle):
import math

# Переводим угол из градусов в радианы
angle_rad = math.radians(angle)

# Находим координаты точки пересечения прямой с противоположной стороной
if math.tan(angle_rad) * width <= height:
x = width
y = math.tan(angle_rad) * width
else:
x = height / math.tan(angle_rad)
y = height

return x, y