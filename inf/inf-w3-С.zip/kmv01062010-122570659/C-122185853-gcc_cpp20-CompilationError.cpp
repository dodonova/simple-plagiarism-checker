#include <iostream>
#include <cmath>

using namespace std;

double min_difference(int n, int m, int x, int y) {
  // Площади прямоугольников, которые получаются при разрезании
  int area1 = x * y;  // Площадь левого нижнего прямоугольника
  int area2 = (n - x) * y;  // Площадь правого нижнего прямоугольника
  int area3 = x * (m - y);  // Площадь левого верхнего прямоугольника
  int area4 = (n - x) * (m - y);  // Площадь правого верхнего прямоугольника

  // Минимальная разница между площадями
  double min_diff = max(area1, max(area2, max(area3, area4))) - 
                  min(area1, min(area2, min(area3, area4)));

  return min_diff;
}

int main() {
  int n, m, x, y;
  cin >> n >> m >> x >> y;

  double min_diff = min_difference(n, m, x, y);
  cout << fixed << setprecision(3) << min_diff << endl; 

  return 0;
}