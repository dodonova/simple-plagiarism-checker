n, m = map(int,input(). split())
x, y = map(int,input(). split())
a = n*y/x
b=-m/x*y
c=-m*x/(y-m)
d=-((m-(y-m)*n)/((n-x))*(n-x))/(y-m)
list1 = [(abs(((2*m-a)/2*n)-n*a/2)), (abs((b+n)/2*m-m*(n-b)/2)), (abs((2*n-c)/2*m-c*m/2)), (abs((d+n)/2*m-(n-d)*m/2))]
list1.sort()
print(round(list1[0], 3))