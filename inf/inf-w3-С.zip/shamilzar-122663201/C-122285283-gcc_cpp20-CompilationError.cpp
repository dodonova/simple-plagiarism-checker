#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

// Функция для вычисления площади треугольника по координатам его вершин
double triangle_area(int x1, int y1, int x2, int y2, int x3, int y3) {
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0);
}

int main() {
    int n, m, x, y;
    
    // Ввод размеров пирога и координат свечки
    cout << "Введите размеры пирога (n, m): ";
    cin >> n >> m;
    cout << "Введите координаты свечки (x, y): ";
    cin >> x >> y;

    // Рассмотрим 4 возможных разреза
    // Разрез через (0, 0)
    double area1 = triangle_area(0, 0, n, 0, x, y) + triangle_area(0, 0, 0, m, x, y);
    // Разрез через (n, 0)
    double area2 = triangle_area(n, 0, n, m, x, y) + triangle_area(n, 0, 0, 0, x, y);
    // Разрез через (n, m)
    double area3 = triangle_area(n, m, 0, m, x, y) + triangle_area(n, m, n, 0, x, y);
    // Разрез через (0, m)
    double area4 = triangle_area(0, m, 0, 0, x, y) + triangle_area(0, m, n, m, x, y);

    // Общая площадь пирога
    double total_area = n * m;

    // Вычисление минимальной разницы между площадями
    double min_difference = min({
        abs(total_area - 2 * area1),
        abs(total_area - 2 * area2),
        abs(total_area - 2 * area3) 