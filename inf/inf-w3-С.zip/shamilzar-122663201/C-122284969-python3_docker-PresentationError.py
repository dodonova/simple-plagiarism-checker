n, m = map(int, input("Введите размеры пирога (n, m): ").split())
x, y = map(int, input("Введите координаты свечки (x, y): ").split())

# Функция для вычисления площади треугольника
def triangle_area(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0)

# Рассмотрим 4 возможных разреза
# Разрез через (0, 0)
area1 = triangle_area(0, 0, n, 0, x, y) + triangle_area(0, 0, 0, m, x, y)
# Разрез через (n, 0)
area2 = triangle_area(n, 0, n, m, x, y) + triangle_area(n, 0, 0, 0, x, y)
# Разрез через (n, m)
area3 = triangle_area(n, m, 0, m, x, y) + triangle_area(n, m, n, 0, x, y)
# Разрез через (0, m)
area4 = triangle_area(0, m, 0, 0, x, y) + triangle_area(0, m, n, m, x, y)

# Общая площадь пирога
total_area = n * m

# Вычисление минимальной разницы между площадями
min_difference = min(
    abs(total_area - 2 * area1),
    abs(total_area - 2 * area2),
    abs(total_area - 2 * area3),
    abs(total_area - 2 * area4)
)

# Вывод результата
print(f"{min_difference:.3f}")


