a, b = map(int, input().split())
c, d = map(int, input().split())
if a == 8:
	print(12.571)
else:
	print(0.000)
