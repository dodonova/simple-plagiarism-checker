def max_weaving_area(n, lengths):
    lengths.sort()
    mid = n // 2
    if n % 2 == 0:
        horizontal = sum(lengths[mid:])
        vertical = sum(lengths[:mid])
    else:
        horizontal = sum(lengths[mid+1:])
        vertical = sum(lengths[:mid+1])
    return min(horizontal, vertical) * 2
import sys
input = sys.stdin.read
data = input().split()
n = int(data[0])
lengths = list(map(int, data[1:]))
result = max_weaving_area(n, lengths)
print(result)