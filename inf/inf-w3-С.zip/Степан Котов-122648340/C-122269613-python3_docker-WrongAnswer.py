def min_difference(n, m, x, y):
    def calculate_difference(x1, y1, x2, y2):
        area1 = abs(x1 * y2 + x2 * y1) / 2.0
        area2 = n * m - area1
        return abs(area1 - area2)
    differences = []
    differences.append(calculate_difference(x, y, n, 0))
    differences.append(calculate_difference(n - x, y, 0, 0))
    differences.append(calculate_difference(x, m - y, 0, m))
    differences.append(calculate_difference(n - x, m - y, n, m))
    return min(differences)
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())
result = min_difference(n, m, x, y)
print(f"{result:.3f}")