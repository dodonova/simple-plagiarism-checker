import java.util.Scanner;

public class Olimp3 {
    public static void main(String[] args) {
        float First_size_pie, Second_size_pie, X_cord_light, Y_cord_light;
        float First_peres, Second_peres, Third_peres, Fourth_peres;
        float[] Squares = new float[4];
        Scanner scaner = new Scanner(System.in);
        First_size_pie = scaner.nextLong();
        Second_size_pie = scaner.nextLong();
        X_cord_light = scaner.nextLong();
        Y_cord_light = scaner.nextLong();
        if (Y_cord_light > Second_size_pie / First_size_pie * X_cord_light) {
            First_peres = Second_size_pie * X_cord_light / Y_cord_light;
            Second_peres = Second_size_pie * (X_cord_light - First_size_pie) / Y_cord_light + First_size_pie;
            Third_peres = (Y_cord_light - Second_size_pie) / X_cord_light * First_size_pie + Second_size_pie;
            Fourth_peres = Second_size_pie - (Y_cord_light - Second_size_pie) / (X_cord_light - First_size_pie) * First_size_pie;
            Squares[0] = Math.abs(0.5f * Second_size_pie * First_peres - (First_size_pie - First_peres + First_size_pie) / 2f * Second_size_pie);
            Squares[1] = Math.abs(0.5f * Second_size_pie * (First_size_pie - Second_peres) - (First_size_pie + Second_peres) / 2f * Second_size_pie);
            Squares[2] = Math.abs(0.5f * First_size_pie * (Second_size_pie - Third_peres) - (Second_size_pie + Third_peres) / 2f * First_size_pie);
            Squares[3] = Math.abs(0.5f * First_size_pie * (Second_size_pie - Fourth_peres) - (Fourth_peres + Second_size_pie) / 2f * First_size_pie);
        } else {
            First_peres = -1 * Second_size_pie * (X_cord_light - First_size_pie) / (Y_cord_light - Second_size_pie) + First_size_pie;
            Second_peres = Second_size_pie * (X_cord_light - First_size_pie) / Y_cord_light + First_size_pie;
            Third_peres = Y_cord_light / X_cord_light * First_size_pie;
            Fourth_peres = (Y_cord_light - Second_size_pie) / X_cord_light * First_size_pie + Second_size_pie;
            Squares[0] = Math.abs(0.5f * Second_size_pie * (First_size_pie - First_peres) - (First_peres + First_size_pie) / 2f * Second_size_pie);
            Squares[1] = Math.abs(0.5f * Second_size_pie * (First_size_pie - Second_peres) - (Second_peres + First_size_pie) / 2f * Second_size_pie);
            Squares[2] = Math.abs(0.5f * First_size_pie * Third_peres - (Second_size_pie - Third_peres + Second_size_pie) / 2f * First_size_pie);
            Squares[3] = Math.abs(0.5f * First_size_pie * (Second_size_pie - Fourth_peres) - (Fourth_peres + Second_size_pie) / 2f * First_size_pie);
        }
        System.out.println(min(Squares));
    }

    public static float min(float mas[]) {
        float minzn = mas[0];
        for (float i : mas) {
            if (i < minzn) {
                minzn = i;
            }
        }
        return minzn;
    }
}
