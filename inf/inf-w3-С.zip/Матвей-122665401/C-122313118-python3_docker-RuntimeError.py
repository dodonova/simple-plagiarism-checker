import numpy
n, m = map(int, input().split())
v, t = map(int, input().split())

def po(p, q):
    h1 = numpy.array([[p, 1], [v, 1]])
    c1 = numpy.array([q, t])
    return numpy.linalg.solve(h1, c1)

k1, b1 = map(int, po(0, 0))
print(k1, b1)