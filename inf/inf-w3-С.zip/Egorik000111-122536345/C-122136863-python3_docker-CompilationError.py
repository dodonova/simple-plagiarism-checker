calculate_area_through_corner(x, y, n, m, corner_x, corner_y)
        min_diff = min(min_diff, diff)

    # Вывод результата с нужной точностью
    print(f"{min_diff:.10f}")

if __name__ == "__main__":
    main()
