#include <bits/stdc++.h>

using namespace std;
int main()
{
    long double n=0, m=0, x=0, y=0;
    cin>>m>>n>>x>>y;
    long double s1, s2, s3, s4;
    s1 = abs((n*m*x - m*m*y)/x);
    s2 = abs((n*m*x - m*m*(n-y))/x);
    s3 = abs((n*m*(n-y) - n*n*(m-x))/(n-y));
    s4 = abs((n*m*y - n*n*(m-x))/y);
    //cout<<s1<<" "<<s2<<" "<<s3<<" "<<s4<<'\n';
    cout<<fixed<<setprecision(3)<<min(s1, min(s2, min(s3, s4)))+0.0005;
}
