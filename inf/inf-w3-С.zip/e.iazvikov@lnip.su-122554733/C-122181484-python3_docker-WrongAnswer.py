if __name__ == "__main__":
 # Ввод данных
 n, m = map(int, input().split())
 x, y = map(int, input().split())

 # Вычисление площадей треугольников, образованных свечой и углами пирога
 area_triangle1 = 0.5 * x * y # Треугольник с вершиной в (0, 0)
 area_triangle2 = 0.5 * (n - x) * y # Треугольник с вершиной в (n, 0)
 area_triangle3 = 0.5 * x * (m - y) # Треугольник с вершиной в (0, m)
 area_triangle4 = 0.5 * (n - x) * (m - y) # Треугольник с вершиной в (n, m)

 # Определение двух наименьших треугольников
mi1 = m * n - area_triangle1
mi2 = m * n - area_triangle2 
mi3 = m * n - area_triangle3 
mi4 = m * n - area_triangle4 

mi5 = abs(mi1 - area_triangle1)
mi6 = abs(mi2 - area_triangle2)
mi7 = abs(mi3 - area_triangle3)
mi8 = abs(mi4 - area_triangle4)
min_difference = min(mi5, mi6, mi7, mi8)

 # Вывод результата
if x*n == m*y:
    print("0.000")
else:
    print(f"{min_difference:.3f}")