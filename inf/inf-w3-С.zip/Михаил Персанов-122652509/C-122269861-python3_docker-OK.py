n,m = [int(s) for s in input().split()]
x,y = [int(s) for s in input().split()]

a1 = x + x * y / (m - y)
if a1 < n:
    s1 = a1 * m / 2
elif a1 == n:
    s1 = n * m / 2
else:
    b1 = y - (n - x) * (m - y) / x
    s1 = n * (m - b1) / 2
d1 = m * n - 2 * s1

b2 = y + x * y / (n - x)
if b2 < m:
    s2 = n * b2 / 2
elif b2 == n:
    s2 = n * m / 2
else:
    a2 = x - (n - x) * (m - y) / y
    s2 = m * (n - a2) / 2
d2 = m * n - 2 * s2

a3 = x - y * (n - x) / (m - y)
if a3 > 0:
    s3 = m * (n - a3) / 2
elif a3 == 0:
    s3 = n * m / 2
else:
    b3 = y - x * (m - y) / (n - x)
    s3 = n * (m - b3) / 2
d3 = m * n - 2 * s3

a4 = x + x * (m - y) / y
if a4 < n:
    s4 = m * a4 / 2
elif a4 == n:
    s4 = n * m / 2
else:
    b4 = y + y * (n - x) / x
    s4 = n * b4 / 2
d4 = m * n - 2 * s4

print(round(min(d1,d2,d3,d4),3))
