n, m = map(int, input().split())
x, y = map(int, input().split())

area1 = x*y
area2 = (n-x)*y
area3 = x*(m-y)
area4 = (n-x)*(m-y)

min_area = min(area1, area2, area3, area4)
max_area = max(area1, area2, area3, area4)

result = max_area - min_area

print("{:.3f}".format(result))