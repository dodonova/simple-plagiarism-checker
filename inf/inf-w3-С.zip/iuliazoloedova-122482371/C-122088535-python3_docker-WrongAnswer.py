def minimum_area_difference(n, m, x, y):
    areas = [
        (x * y, (n - x) * (m - y)),
        (x * (m - y), (n - x) * y),
        ((n - x) * y, x * (m - y)),
        ((n - x) * (m - y), x * y)
    ]
    min_diff = min(abs(a1 - a2) for a1, a2 in areas)
    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

result = minimum_area_difference(n, m, x, y)
print(f"{result:.3f}")