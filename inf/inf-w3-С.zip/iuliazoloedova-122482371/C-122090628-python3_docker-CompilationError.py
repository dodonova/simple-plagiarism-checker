ⒷКод:Ⓑ
def min_difference(n, m, x, y):
    area1 = 0.5 * x * y
    area2 = 0.5 * (n - x) * y
    area3 = 0.5 * x * (m - y)
    area4 = 0.5 * (n - x) * (m - y)

    min_diff = min(abs(area1 - (n * m - area1)), abs(area2 - (n * m - area2)),
                    abs(area3 - (n * m - area3)), abs(area4 - (n * m - area4)))

    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

min_diff = min_difference(n, m, x, y)
print(min_diff)

ⒷОписание проблемы:Ⓑ
Код не работает корректно.  

ⒷПример ввода:Ⓑ
8 5
7 2

ⒷОжидаемый вывод:Ⓑ
12.571

ⒷИсправленный код:Ⓑ
def min_difference(n, m, x, y):
    # Вычислим площади треугольников, образуемых двумя возможными разрезами
    area1 = 0.5 * x * y  # Площадь треугольника с вершиной в (0, 0)
    area2 = 0.5 * (n - x) * y  # Площадь треугольника с вершиной в (n, 0)
    area3 = 0.5 * x * (m - y)  # Площадь треугольника с вершиной в (0, m)
    area4 = 0.5 * (n - x) * (m - y)  # Площадь треугольника с вершиной в (n, m)

    # Найдем минимальную разницу площадей
    min_diff = min(abs(area1 - (n * m - area1)), abs(area2 - (n * m - area2)),
                    abs(area3 - (n * m - area3)), abs(area4 - (n * m - area4)))

    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

min_diff = min_difference(n, m, x, y)
print(f"{min_diff:.3f}") 
