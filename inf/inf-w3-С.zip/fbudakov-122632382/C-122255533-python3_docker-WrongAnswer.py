def modul(i): 
    if i >0: 
        return i 
    return -i 
         
 
n,m = [int(el) for el in input().split()] 
x,y = [int(el) for el in input().split()] 
 
ctg = n/m 
if y/x >= ctg: 
    p1 = modul(m*n - n*n*y/x) 
else: 
    p1 = modul(m*n - m*m*x/y) 
 
if (n-x)/y >= ctg: 
    p2 = modul(m*n - n*n*y/(n-x)) 
else: 
    p2 = modul(m*n - m*m/y*(n-x)) 
 
if x/(m-y) >= ctg: 
    p3 = modul(m*n - n*n*(m-y)/x) 
else: 
    p3 = modul(m*n - m*m/(m-y)*x) 
 
if (n-x)/(m-y) >= ctg: 
    p4 = modul(m*n - n*n*(m-y)/(n-x)) 
else: 
    p4 =modul(m*n - m*m/(m-y)*(n-x)) 
 
print(round(min(p1, p2, p3, p4), 3))