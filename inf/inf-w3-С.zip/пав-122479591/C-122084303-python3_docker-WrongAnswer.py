n, m = map(int, input().split())
x, y = map(int, input().split())

area = n * m

triangle_area = 0.5 * x * y
rect_area = (n - x) * (m - y)

part1_area = area - triangle_area - rect_area
part2_area = triangle_area + rect_area

diff = abs(part1_area - part2_area)

print(f"{diff:.3f}")
