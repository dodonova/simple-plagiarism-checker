n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m
min_difference = float('inf')

# Разрез через (0, 0) и (x, y)
area1 = x * y
area2 = total_area - area1
min_difference = min(min_difference, abs(area1 - area2))

# Разрез через (n, 0) и (x, y)
area1 = (n - x) * y
area2 = total_area - area1
min_difference = min(min_difference, abs(area1 - area2))

# Разрез через (0, m) и (x, y)
area1 = x * (m - y)
area2 = total_area - area1
min_difference = min(min_difference, abs(area1 - area2))

# Разрез через (n, m) и (x, y)
area1 = (n - x) * (m - y)
area2 = total_area - area1
min_difference = min(min_difference, abs(area1 - area2))

# Выводим результат с точностью 3 знака после запятой
print(f"{min_difference:.3f}")
