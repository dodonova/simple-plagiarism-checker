def min_difference(n, m, x, y):
    def area_triangle(ax, ay, bx, by, cx, cy):
        return abs(ax*(by-cy) + bx*(cy-ay) + cx*(ay-by)) / 2

    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    total_area = n * m
    min_diff = float('inf')

    for corner in corners:
        cx, cy = corner
        area1 = area_triangle(cx, cy, x, y, 0, 0)
        area2 = area_triangle(cx, cy, x, y, n, m)
        area_triangle2 = total_area - area1 - area2
        diff = abs(area1 - area_triangle2)
        min_diff = min(min_diff, diff)

    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())
result = min_difference(n, m, x, y)

# Вывод результата
print(f"{result:.10f}")