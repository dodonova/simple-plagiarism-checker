a, b = map(int, input().split())
p, q = map(int, input().split())
min_area = 10 ** 9
for i in range(4):
    temp_area = a * a * q / p / 2 if p / q > a / b else b * b * p / q / 2
    p, q, a, b = b - q, p, b, a
    min_area = min(a * b - 2 * temp_area, min_area)
print(f"{min_area:.3f}")
