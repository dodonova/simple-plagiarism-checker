#include <iostream>
#include <cmath>

int main() {
    // Ввод размеров пирога (n, m) и координат свечи (x, y)
    int n, m, x, y;
    std::cout << "Введите размеры пирога (n и m): ";
    std::cin >> n >> m;
    std::cout << "Введите координаты свечи (x и y): ";
    std::cin >> x >> y;

    // Площадь всего пирога
    int totalArea = n * m;

    // Площади для каждого разреза
    int area1 = x * y;                         // Разрез через (0, 0)
    int area2 = x * (m - y);                   // Разрез через (0, m)
    int area3 = (n - x) * y;                   // Разрез через (n, 0)
    int area4 = (n - x) * (m - y);             // Разрез через (n, m)

    // Разности площадей для каждого разреза
    int diff1 = std::abs(area1 - (totalArea - area1));
    int diff2 = std::abs(area2 - (totalArea - area2));
    int diff3 = std::abs(area3 - (totalArea - area3));
    int diff4 = std::abs(area4 - (totalArea - area4));

    // Находим максимальную разность
    int maxDiff = std::max({diff1, diff2, diff3, diff4});

    // Вывод результата
    std::cout << "Максимальная разность площадей: " << maxDiff << std::endl;

    return 0;
}