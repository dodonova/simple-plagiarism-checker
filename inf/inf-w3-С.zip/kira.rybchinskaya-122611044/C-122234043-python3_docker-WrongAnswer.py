n, m = map(int, input().split())
x, y = map(int, input().split())

area1 = x * m
area2 = y * n

ans = abs(area1 - area2) / 2 
print("{:.3f}".format(ans))