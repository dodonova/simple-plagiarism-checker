n, m = map(int, input().split())
x, y = map(int, input().split())
horizontal_cut_areas = [x * m, (n - x) * m]
vertical_cut_areas = [y * n, (m - y) * n]
min_diff = min(abs(horizontal_cut_areas[0] - horizontal_cut_areas[1]), abs(vertical_cut_areas[0] - vertical_cut_areas[1]))
print(format(min_diff, '.3f'))