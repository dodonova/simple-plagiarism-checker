#include <iostream>
#include <cmath>
using namespace std;
int main () {
    float n, m, x, y;
    cin >> n >> m >> x >> y;
    cout << fixed;
    cout.precision(3);
    float tg=y/x;
    float h=tg*n;
    float s=h*n;
    float res1=abs(n*m-s);
    float tg1=(m-y)/x;
    float h1=tg1*n;
    float s1=n*h1;
    float res2=abs(n*m-s1);
    float tg2=(n-x)/(m-y);
    float h2=tg2*m;
    float s2=m*h2;
    float res3=abs(n*m-s2);
    float tg3=(n-x)/y;
    float h3=tg3*m;
    float s3=m*h3;
    float res4=abs(n*m-s3);
    cout << min(min(res1,res2),min(res3,res4));
    return 0;
}