n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m

# Площадь треугольника, образованного разрезом от левого верхнего угла
triangle_area_top = (x * m) / 2

# Площадь треугольника, образованного разрезом от правого нижнего угла
triangle_area_bottom = (n * y) / 2

# Площадь треугольника, образованного разрезом от правого верхнего угла
triangle_area_right = ((n - x) * (m - y)) / 2

# Площадь треугольника, образованного разрезом от левого нижнего угла
triangle_area_left = ((n - x) * y) / 2

# Находим минимальную разницу
min_diff = min(abs(total_area - 2 * triangle_area_top),
              abs(total_area - 2 * triangle_area_bottom),
              abs(total_area - 2 * triangle_area_right),
              abs(total_area - 2 * triangle_area_left))

print(f"{min_diff:.3f}")