n, m = map(long, input().split())
x, y = map(long, input().split())

total_area = n * m

v1 = total_area - (n / (x / y)) * n / 2 
v2 = total_area - (m / (y / (n - x))) * m / 2
v3 = total_area - (m / ((m - y) / (n - x))) * m / 2
v4 = total_area - (n / (x / (m - y)) * n) / 2

i1 = total_area - v1
i2 = total_area - v2
i3 = total_area - v3
i4 = total_area - v4

ans1 = max(v1, i1) - min(v1, i1)
ans2 = max(v2, i2) - min(v2, i2)
ans3 = max(v3, i3) - min(v3, i3)
ans4 = max(v4, i4) - min(v4, i4)

itog = min(ans1, ans2, ans3, ans4)
print(f"{itog:.3f}")