coop=input().split()
sooS=input().split()
ugup=False
ugdow=False
ugleft=False
ugright=False
if int(sooS[0])<= int(coop[0])/2:
    ugright=True
elif int(sooS[0])>int(coop[0])/2:
    ugleft=True

if int(sooS[1])<= int(coop[1])/2:
    ugup=True
elif int(sooS[1])>int(coop[1])/2:
    ugdow=True
if ugdow and ugleft: #1111111111111111111111111111111
    stdown=(int(coop[0])*int(sooS[1]))/int(sooS[0])
    Stri=int(coop[0])*stdown/2
    Strap=int(coop[0])*int(coop[1])-Stri
    print(round(Strap-Stri, 3))

if ugup and ugleft:
    stdown = (int(coop[0])*(int(coop[1])-int(sooS[1]))/int(sooS[0]))
    Stri = int(coop[0]) * stdown / 2
    Strap = int(coop[0]) * int(coop[1]) - Stri
    print(round(Strap-Stri, 3))
if ugdow and ugright:
    stdown=(int(coop[1])*(int(coop[0])-int(sooS[0])/int(sooS[1])))
    Stri = int(coop[0]) * stdown / 2
    Strap = int(coop[0]) * int(coop[1]) - Stri
    print(round(Strap - Stri, 3))
if ugup and ugright:
    stdown=(int(coop[1])*(int(coop[0])-int(sooS[0])/(int(coop[1])-int(sooS[1]))))
    Stri = int(coop[0]) * stdown / 2
    Strap = int(coop[0]) * int(coop[1]) - Stri
    print(round(Strap - Stri, 3))