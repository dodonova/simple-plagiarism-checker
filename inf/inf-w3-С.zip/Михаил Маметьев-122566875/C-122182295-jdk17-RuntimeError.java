import java.util.*;

public class WordRestoration {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ввод перепутанных букв
        String scrambledString = scanner.nextLine().trim();
        
        // Ввод количества слов
        int n = Integer.parseInt(scanner.nextLine().trim());
        
        // Ввод словаря
        List<String> words = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            words.add(scanner.nextLine().trim());
        }
        
        // Подсчет частоты символов в строке Маши
        Map<Character, Integer> scrambledCount = countChars(scrambledString);
        
        // Список для хранения подходящих слов
        List<String> chosenWords = new ArrayList<>();
        
        // Для каждого слова проверяем, можем ли его составить, и уменьшаем количество букв
        for (String word : words) {
            Map<Character, Integer> wordCount = countChars(word);
            if (canFormWord(scrambledCount, wordCount)) {
                chosenWords.add(word);
                // Уменьшаем количество использованных символов
                reduceCharCount(scrambledCount, wordCount);
            }
        }
        
        // Сортируем и выводим восстановленные слова
        Collections.sort(chosenWords);
        for (String word : chosenWords) {
            System.out.println(word);
        }
        
        scanner.close();
    }
    
    // Функция для подсчета символов в строке
    private static Map<Character, Integer> countChars(String str) {
        Map<Character, Integer> charCount = new HashMap<>();
        for (char c : str.toCharArray()) {
            charCount.put(c, charCount.getOrDefault(c, 0) + 1);
        }
        return charCount;
    }
    
    // Проверяем, можно ли составить слово из строки Маши
    private static boolean canFormWord(Map<Character, Integer> scrambledCount, Map<Character, Integer> wordCount) {
        for (Map.Entry<Character, Integer> entry : wordCount.entrySet()) {
            char c = entry.getKey();
            int count = entry.getValue();
            if (scrambledCount.getOrDefault(c, 0) < count) {
                return false;
            }
        }
        return true;
    }
    
    // Уменьшаем количество использованных символов
    private static void reduceCharCount(Map<Character, Integer> scrambledCount, Map<Character, Integer> wordCount) {
        for (Map.Entry<Character, Integer> entry : wordCount.entrySet()) {
            char c = entry.getKey();
            int count = entry.getValue();
            scrambledCount.put(c, scrambledCount.get(c) - count);
        }
    }
}
