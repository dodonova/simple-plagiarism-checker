def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m

    # Вычисляем площади двух кусков для всех возможных разрезов
    # Разрез через углы (0, 0) и (n, m)
    areas = []

    # Разрез через (0, 0) и (x, y)
    area1 = x * y
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Разрез через (0, m) и (x, y)
    area1 = x * (m - y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Разрез через (n, 0) и (x, y)
    area1 = (n - x) * y
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Разрез через (n, m) и (x, y)
    area1 = (n - x) * (m - y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))

    # Минимальная разница
    return min(areas)

if __name__ == "__main__":
    # Ввод размеров пирога
    n, m = map(int, input("Введите размеры пирога n и m через пробел: ").split())
    
    # Ввод координат свечки
    x, y = map(int, input("Введите координаты свечки x и y через пробел: ").split())
    
    # Находим минимальную разницу
    result = min_difference(n, m, x, y)
    
    # Выводим результат с точностью до трех знаков после запятой
    print(f"{result:.3f}")
