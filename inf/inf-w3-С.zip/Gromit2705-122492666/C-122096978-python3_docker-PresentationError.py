import sys
import math

def input():
    return sys.stdin.readline()

def get_polygon_area(vertices):
    area = 0.0
    n = len(vertices)
    for i in range(n):
        x1, y1 = vertices[i % n]
        x2, y2 = vertices[(i + 1) % n]
        area += (x1 * y2 - x2 * y1)
    return abs(area) / 2.0

def get_intersection_points(n, m, x0, y0, x1, y1):
    points = []
    # Коэффициенты прямой
    dx = x1 - x0
    dy = y1 - y0

    # Избегаем деления на ноль
    if dx == 0:
        k = None
    else:
        k = dy / dx

    # Список потенциальных точек пересечения
    candidates = []

    # Проверяем пересечение с вертикальными гранями
    for x_edge in [0, n]:
        if dx != 0:
            t = (x_edge - x0) / dx
            if 0 <= t <= 1 or t >= 0:
                y_intersect = y0 + t * dy
                if 0 <= y_intersect <= m:
                    candidates.append((x_edge, y_intersect, t))

    # Проверяем пересечение с горизонтальными гранями
    for y_edge in [0, m]:
        if dy != 0:
            t = (y_edge - y0) / dy
            if 0 <= t <= 1 or t >= 0:
                x_intersect = x0 + t * dx
                if 0 <= x_intersect <= n:
                    candidates.append((x_intersect, y_edge, t))

    # Убираем исходную точку (угол)
    candidates = [ (x, y, t) for x, y, t in candidates if not (x == x0 and y == y0) ]

    # Сортируем по параметру t
    candidates.sort(key=lambda point: point[2])

    # Возвращаем первые две точки пересечения
    return candidates[:2]

def compute_area(n, m, x_candle, y_candle):
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    total_area = n * m
    min_diff = Non
    for corner in corners:
        x0, y0 = corner
        # Если свечка совпадает с углом, пропускаем этот случай
        if (x0 == x_candle and y0 == y_candle):
            continue

        # Получаем точки пересечения
        intersections = get_intersection_points(n, m, x0, y0, x_candle, y_candle)

        # Формируем многоугольник
        polygon = [corner]
        for x, y, _ in intersections:
            polygon.append((x, y))
        polygon.append((x_candle, y_candle))

        # Добавляем углы пирога, которые лежат на краю, в правильном порядке
        # Определяем направление обхода (по часовой или против)
        if len(polygon) >= 3:
            x_prev, y_prev = polygon[-2]
            x_curr, y_curr = polygon[-1]
            direction = (x_curr - x_prev, y_curr - y_prev)
            # Определяем порядок обхода углов
            if direction[0] * dy - direction[1] * dx >= 0:
                # По часовой стрелке
                remaining_corners = [pt for pt in corners if pt != corner and pt != (x0, y0)]
            else:
                # Против часовой стрелки
                remaining_corners = [pt for pt in reversed(corners) if pt != corner and pt != (x0, y0)]
            polygon.extend(remaining_corners)

        # Вычисляем площадь многоугольника
        area = get_polygon_area(polygon)

        # Вычисляем разницу между двумя кусками
        diff = abs(total_area - 2 * area)

        if min_diff is None or diff < min_diff:
            min_diff = diff

    return min_diff

