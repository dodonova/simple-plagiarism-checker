import math

n, m = map(int, input().split())
x, y = map(int, input().split())

area1 = x * m
area2 = y * n
area3 = (n - x) * m
area4 = (m - y) * n

min_area = min(area1, area2, area3, area4)
max_area = max(area1, area2, area3, area4)

result = max_area - min_area
if x >= n / 2 and y >= m / 2:
    result /= math.sqrt(2)

print("{:.3f}".format(result))
