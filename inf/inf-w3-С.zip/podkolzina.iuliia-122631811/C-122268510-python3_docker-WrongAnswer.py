def min_area_difference(n, m, x, y):
    # Total area of the pie
    total_area = n * m

    # Function to calculate the area difference for a given corner
    def area_difference(cx, cy):
        # Area of the triangle formed by (cx, cy), (x, y)
        if cx == 0 and cy == 0:  # from bottom-left
            area1 = (x * y) / 2
        elif cx == n and cy == 0:  # from bottom-right
            area1 = (n - x) * y / 2
        elif cx == 0 and cy == m:  # from top-left
            area1 = x * (m - y) / 2
        elif cx == n and cy == m:  # from top-right
            area1 = (n - x) * (m - y) / 2
            
        area2 = total_area - area1
        return abs(area1 - area2)
    
    # Calculate the area differences for all four corners
    differences = [
        area_difference(0, 0),   # Bottom-left corner
        area_difference(n, 0),   # Bottom-right corner
        area_difference(0, m),   # Top-left corner
        area_difference(n, m)    # Top-right corner
    ]
    
    # Return the minimum difference
    return min(differences)

# Input reading
import sys
input = sys.stdin.read
data = input().strip().split()
n, m = int(data[0]), int(data[1])
x, y = int(data[2]), int(data[3])

# Calculate and print the result
result = min_area_difference(n, m, x, y)
print(f"{result:.3f}")