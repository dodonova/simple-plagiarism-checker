from itertools import product
import numpy as np
from scipy.optimize import minimize

# Функция для вычисления площади куска пирога
def area(x, a, b):
    return a * b - abs((a - x[0]) * (b - x[1]))

# Функция потерь, которая минимизируется
def loss_function(x, a, b):
    return max(area(x, a, b), area((a, b) - x)) - min(area(x, a, b), area((a, b) - x))

# Размеры пирога
a = 4
b = 3

# Возможные положения свечки
cand_positions = [(0, 0), (a, 0), (0, b)]

# Поиск оптимального положения свечки и разреза
min_loss = None
best_pos = None
for pos in cand_positions:
    # Вычисление потери для каждой позиции свечки
    loss = loss_function((pos[0], pos[1]), a, b)
    if min_loss is None or loss < min_loss:
        min_loss = loss
        best_pos = pos

print("Минимальная разница в площади:", min_loss)
print("Оптимальное положение свечки:", best_pos)
