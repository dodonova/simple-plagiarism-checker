#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    int n, m, x, y, triang_x, triang_y; 
    double d, S_triang, S_quad, tg;
    cin >> n >> m >> x >> y;
    triang_x = max(fabs(x - 0), fabs(x - n));
    triang_y = max(fabs(y - 0), fabs(y - m));
    //cout << "triang_x, triang_y: " << triang_x << " " << triang_y << endl;
    tg = (triang_y * 1.0) / triang_x;
    //cout << "tg: " << tg << endl;
    S_triang = tg * n * n * 0.5;
    S_quad = n * m - S_triang;
    d = S_quad - S_triang;
    cout << fixed << setprecision(3);
    cout << d;
    
    return 0;
}