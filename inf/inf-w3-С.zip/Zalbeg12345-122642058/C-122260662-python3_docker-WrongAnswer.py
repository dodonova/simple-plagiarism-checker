n, m = map(int, input().split())
x, y = map(int, input().split())
s_pram = n * m
s_treygol1 = 0.5 * (n * ((y * n) / x))
trapec1 = s_pram - s_treygol1
raznica1 = abs(s_treygol1 - trapec1)
s_treygol2 = 0.5 * (n * ((n * (m - y)) / x))
trapec2 = s_pram - s_treygol2
raznica2 = abs(s_treygol2 - trapec2)
s_treygol3 = 0.5 * (m * (m * ((n - x) / y)))
trapec3 = s_pram - s_treygol3
raznica3 = abs(s_treygol3 - trapec3)
s_treygol4 = 0.5 * (m * ((n - x) * m) / (m - y))
trapec4 = s_pram - s_treygol4
raznica4 = abs(trapec4 - s_treygol4)
minimum = min(raznica1,raznica2,raznica3,raznica4)
print(f'{minimum:.3f}')