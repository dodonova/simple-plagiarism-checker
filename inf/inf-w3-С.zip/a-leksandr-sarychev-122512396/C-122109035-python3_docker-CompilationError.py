def find_dimensions(a, b):
    total_cells = 4 * a + 5 * b + 4
    dimensions = []
    
    for n in range(1, int(total_cells**0.5) + 1):
        if total_cells % n == 0:
            m = total_cells // n
            dimensions.append((n, m))
    
    valid_dimensions = [(n, m) for n, m in dimensions if n <= m]
    
    return valid_dimensions[0] 
if valid_dimensions 
else None

a, b = map(int, input().split())
n, m = find_dimensions(a, b)
print(n, m)