def area_difference(n, m, x, y):
    angles = [(0, 0), (0, m), (n, 0), (n, m)]
    min_diff = float('inf')
    for corner in angles:
        cx, cy = corner
        area1 = abs(cx * y - cy * x) / 2
        area2 = (n * m) - area1
        diff = abs(area1 - area2)
        min_diff = min(min_diff, diff)
    return min_diff
n, m = map(int, input().split())
x, y = map(int, input().split())
result = area_difference(n, m, x, y)
print(f"{result:.3f}")