w, v = list(map(int, input().split()))
h, g = list(map(int, input().split()))

def petuh(f):
    u = 0
    if w * f <= v:
        u = w * w * f / 2
        return w * v - 2 * u
    else:
        u = v * v / f / 2
        return w * v - 2 * u

f1 = petuh(h / g)
f2 = petuh( g / (w - h))
f3 = petuh((v - g) / (w - h))
f4 = petuh((v - g) / h)

print("{0:.3f}".format(min(f1, f2, f3, f4)))