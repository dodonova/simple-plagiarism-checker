def calculate_min_difference(n, m, x, y):
    # Функция для вычисления разницы площадей
    def area_difference(angle):
        # Вычисляем координаты пересечения прямой с границей пирога
        if angle == 0:  # горизонтальная линия
            return abs((x * m) - (n * y))
        elif angle == float('inf'):  # вертикальная линия
            return abs((y * n) - (m * x))
        
        # Угловые координаты
        tan_angle = angle
        # Первая точка (x, y) и вторая точка (x + dx, y + dy)
        dx = n - x
        dy = tan_angle * dx
        
        if dy > m - y:  # пересечение с верхней границей
            dy = m - y
            dx = dy / tan_angle
        
        area1 = (x * y) + (dx * dy) / 2  # Площадь первого куска
        area2 = (n * m) - area1  # Площадь второго куска
        return abs(area1 - area2)
    
    min_difference = float('inf')
    # Проверяем углы, которые соответствуют углам между свечой и углами пирога
    for angle in [0, float('inf'), -m / x, m / (n - x), (m - y) / x, (m - y) / (n - x)]:
        difference = area_difference(angle)
        min_difference = min(min_difference, difference)
    
    return min_difference

# Чтение данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление минимальной разницы
result = calculate_min_difference(n, m, x, y)

# Вывод результата
print(f"{result:.3f}")