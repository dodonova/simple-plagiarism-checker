def calculate_area_difference(n, m, x, y):
    # Разрез от угла (0, 0)
    area1 = (x * y) / 2
    area2 = n * m - area1
    diff1 = abs(area1 - area2)
    
    # Разрез от угла (n, 0)
    area1 = ((n - x) * y) / 2
    area2 = n * m - area1
    diff2 = abs(area1 - area2)
    
    # Разрез от угла (0, m)
    area1 = (x * (m - y)) / 2
    area2 = n * m - area1
    diff3 = abs(area1 - area2)
    
    # Разрез от угла (n, m)
    area1 = ((n - x) * (m - y)) / 2
    area2 = n * m - area1
    diff4 = abs(area1 - area2)
    
    # Минимальная разница
    return min(diff1, diff2, diff3, diff4)

def main():
    # Чтение данных из файла
    with open('input.txt', 'r') as file:
        n, m = map(int, file.readline().split())
        x, y = map(int, file.readline().split())
    
    # Вычисление минимальной разницы
    result = calculate_area_difference(n, m, x, y)
    
    # Запись результата в файл
    with open('output.txt', 'w') as file:
        file.write(f"{result:.6f}\n")

if name == "__main__":
    main()