def triangle_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def minimal_difference(n, m, x, y):
    total_area = n * m

    # Разрезы через разные углы пирога
    # Разрез через (0, 0)
    area1 = triangle_area(0, 0, x, y, n, 0)
    area2 = total_area - area1
    diff1 = abs(area1 - area2)

    # Разрез через (n, 0)
    area1 = triangle_area(n, 0, x, y, n, m)
    area2 = total_area - area1
    diff2 = abs(area1 - area2)

    # Разрез через (n, m)
    area1 = triangle_area(n, m, x, y, 0, m)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)

    # Разрез через (0, m)
    area1 = triangle_area(0, m, x, y, 0, 0)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)

    # Возвращаем минимальную разницу
    return min(diff1, diff2, diff3, diff4)

# Чтение входных данных из файла input.txt
with open('input.txt', 'r') as f:
    n, m = map(int, f.readline().split())
    x, y = map(int, f.readline().split())

# Вычисление минимальной разницы
result = minimal_difference(n, m, x, y)

# Запись результата в файл output.txt
with open('output.txt', 'w') as f:
    f.write(f"{result:.3f}\n")