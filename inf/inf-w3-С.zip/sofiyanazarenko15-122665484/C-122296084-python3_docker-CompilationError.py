def area_of_triangle(x1, y1, x2, y2, x3, y3):
return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def main():


n = int(data[0])
m = int(data[1])
x = int(data[2])
y = int(data[3])


total_area = n * m


area1 = area_of_triangle(0, 0, x, y, n, 0) + area_of_triangle(0, 0, x, y, 0, m)
area2 = total_area - area1
diff1 = abs(area1 - area2)


area1 = area_of_triangle(n, 0, x, y, n, m) + area_of_triangle(n, 0, x, y, 0, 0)
area2 = total_area - area1
diff2 = abs(area1 - area2)


area1 = area_of_triangle(0, m, x, y, n, m) + area_of_triangle(0, m, x, y, 0, 0)
area2 = total_area - area1
diff3 = abs(area1 - area2)


area1 = area_of_triangle(n, m, x, y, 0, m) + area_of_triangle(n, m, x, y, n, 0)
area2 = total_area - area1
diff4 = abs(area1 - area2)


min_diff = min(diff1, diff2, diff3, diff4)


print(f"{min_diff:.3f}")

if name == "main":
main()
`