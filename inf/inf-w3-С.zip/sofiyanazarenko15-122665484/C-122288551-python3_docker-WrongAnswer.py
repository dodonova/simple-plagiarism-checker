def min_difference(n, m, x, y):
    total_area = n * m
    
    def area_from_corner(corner_x, corner_y):
        area_triangle = abs(corner_x * (y - corner_y) + x * (corner_y - 0) + 0 * (0 - y)) / 2
        area_piece = total_area - area_triangle
        return area_triangle, area_piece
    
    
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    min_diff = float('inf')
    
    for corner in corners:
        corner_x, corner_y = corner
        piece1, piece2 = area_from_corner(corner_x, corner_y)
        diff = abs(piece1 - piece2)
        min_diff = min(min_diff, diff)
    
    return min_diff

import sys
input = sys.stdin.read
data = input().split()
n = int(data[0])
m = int(data[1])
x = int(data[2])
y = int(data[3])

result = min_difference(n, m, x, y)
print(f"{result:.3f}")