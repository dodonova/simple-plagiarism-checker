xn, ym = map(int, input().split())
x, y = map(int, input().split())
s = xn * ym
z1 = y / x
y1 = z1 * xn
x1 = xn
s1 = abs(x1 * y1 / 2 - (s - x1 * y1 / 2))
y2 = ym
x2 = (xn - x) / y * ym
s2 = abs(y2 * x2 / 2 - (s - y2 * x2 / 2))
y3 = ym
x3 = (xn - x) / (ym - y) * ym
s3 = abs(y3 * x3 / 2 - (s - y3 * x3 / 2))
y4 = (ym - y) / x * xn
x4 = xn
s4 = abs(y4 * x4 / 2 - (s - y4 * x4 / 2))
ans = str(round(min(s1, s2, s3, s4), 3))
print(ans)