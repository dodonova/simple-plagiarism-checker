import sys
import math


def compute_area(points):
    """Вычисляет площадь многоугольника по формуле шнурков."""
    area = 0.0
    n = len(points)
    for i in range(n):
        x1, y1 = points[i % n]
        x2, y2 = points[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) / 2.0


def find_intersection(x0, y0, x1, y1, xmin, xmax, ymin, ymax):
    """Находит точку пересечения прямой с границами прямоугольника."""
    dx = x1 - x0
    dy = y1 - y0
    t_min = float('inf')
    xi, yi = None, None

    # Проверка пересечения с вертикальными границами
    if dx != 0:
        for x_edge in [xmin, xmax]:
            t = (x_edge - x0) / dx
            if t > 1e-9:
                y = y0 + dy * t
                if ymin - 1e-9 <= y <= ymax + 1e-9 and t < t_min:
                    t_min = t
                    xi, yi = x_edge, y

    # Проверка пересечения с горизонтальными границами
    if dy != 0:
        for y_edge in [ymin, ymax]:
            t = (y_edge - y0) / dy
            if t > 1e-9:
                x = x0 + dx * t
                if xmin - 1e-9 <= x <= xmax + 1e-9 and t < t_min:
                    t_min = t
                    xi, yi = x, y_edge

    return xi, yi


def compute_polygon_area(corner, x_candle, y_candle, n, m):
    """Вычисляет площадь части пирога для данного угла."""
    x0, y0 = corner
    xmin, xmax = 0, n
    ymin, ymax = 0, m

    xi, yi = find_intersection(x0, y0, x_candle, y_candle, xmin, xmax, ymin, ymax)

    if xi is None or yi is None:
        return None  # Нет пересечения, не должно быть такого случая

    # Формируем список точек многоугольника
    points = [(x0, y0), (x_candle, y_candle), (xi, yi)]

    # Добавляем необходимые углы прямоугольника
    if corner == (0, 0):
        if xi == n:
            points.append((n, 0))
        elif yi == m:
            points.extend([(xi, m), (n, m), (n, 0)])
    elif corner == (n, 0):
        if xi == 0:
            points.append((0, 0))
        elif yi == m:
            points.extend([(xi, m), (0, m), (0, 0)])
    elif corner == (n, m):
        if xi == 0:
            points.append((0, m))
        elif yi == 0:
            points.extend([(xi, 0), (0, 0), (0, m)])
    elif corner == (0, m):
        if xi == n:
            points.append((n, m))
        elif yi == 0:
            points.extend([(xi, 0), (n, 0), (n, m)])
    else:
        return None  # Неверный угол

    # Вычисляем площадь многоугольника
    area = compute_area(points)
    return area


def main():
    n, m = map(int, sys.stdin.readline().split())
    x, y = map(int, sys.stdin.readline().split())
    total_area = n * m
    min_diff = float('inf')

    corners = [(0, 0), (n, 0), (n, m), (0, m)]

    for corner in corners:
        area = compute_polygon_area(corner, x, y, n, m)
        if area is not None:
            diff = abs((total_area - area) - area)
            if diff < min_diff:
                min_diff = diff

    # Выводим минимальную разницу с точностью не менее трех знаков после запятой
    print(f"{min_diff:.3f}")


main()