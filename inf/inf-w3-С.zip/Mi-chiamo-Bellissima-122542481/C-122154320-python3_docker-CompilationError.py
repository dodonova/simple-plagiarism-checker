def min_area_difference(n, m, x, y):
	area1 = (x *y) / 2
    area2 = n*m - area1
    
    difference = abs(area1 - area2)
    
    return round(difference, 3)
    
n, m = map(int, input().split())
x, y = map(int, input().split())

print(min_area_difference(n, m, x, y))

