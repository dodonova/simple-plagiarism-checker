def find_min_difference(n, m, x, y):
    # Координаты углов прямоугольника
    corners = [(0, 0), (n, 0), (n, m), (0, m)]

    min_diff = float('inf')
    for corner in corners:
        # Направление вектора от угла к свечке
        dx = x - corner[0]
        dy = y - corner[1]

        # Найти точку пересечения с противоположной стороной
        if corner[0] == 0:
            intersect_y = corner[1] + dy * (n / dx)
        else:
            intersect_y = corner[1] + dy * (m / dx)

        # Вычислить площади треугольников
        triangle_area = 0.5 * abs(dx * (intersect_y - corner[1]))
        rect_area = n * m - triangle_area

        # Обновить минимальную разницу
        min_diff = min(min_diff, abs(triangle_area - rect_area))

    return min_diff

# Пример использования
n = 8
m = 5
x = 7
y = 2
result = find_min_difference(n, m, x, y)
print(result)