#include<iostream>
#include<math.h>

using namespace std;

int main()
{
    float n, m, x, y;
    scanf("%f %f", &n, &m);
    scanf("%f %f", &x, &y);
    float a = (n*m)-2.0*((n*n*y)/(2.0*x));
    float b = (n*m)-2.0*((m*m*(n-x))/(2.0*y));
    float c = (n*m)-2.0*((m*m*(n-x))/(2.0*(m-y)));
    float d = (n*m)-2.0*((n*n*(m-y))/(2.0*x));
    if(a < b && a < d && a < c)
        printf("%f", float(trunc(a*1000.0))/1000.0);
    if(b < a && b < d && b < c)
        printf("%f", float(trunc(b*1000.0))/1000.0);
    if(c < d && c < b && c < a)
        printf("%f", float(trunc(c*1000.0))/1000.0);
    else
        printf("%f", float(trunc(d*1000.0))/1000.0);
    
    return 0;
}
