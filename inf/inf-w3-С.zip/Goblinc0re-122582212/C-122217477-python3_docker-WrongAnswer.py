n, m = input().split()
x, y = input().split()
n, m, x, y = int(n), int(m), int(x), int(y)

square = n * m

difference1 = abs(square - n * n / x * y)
difference2 = abs(square - n * n / x * (m - y))
difference3 = abs(square - m * m / y * x)
difference4 = abs(square - m * m / y * (n - x))
print(f"{min(difference1, difference2, difference3, difference4):.3f}")