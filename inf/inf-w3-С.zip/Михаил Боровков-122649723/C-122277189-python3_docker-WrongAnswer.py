n, m = map(float, input().split())
x, y = map(float, input().split())

sq1 = (n * y * n / x) / 2
sq2 = (m * ((n - x) * m / y)) / 2
ans = max(sq1, sq2)

x1 = -x
y1 = -y
sq3 = (m * ((n - x) * m / (m - y))) / 2
ans = max(ans, sq3)

sq4 = (n * ((m - y) * n / x)) / 2
ans = max(ans, sq4)

result = ((n * m) / 2 - ans) * 2
print(f"{result:.3f}")