n,m=map(int,input().split())
x,y=map(int,input().split())

p1 = abs(0*y-0*x)/2
p2 = (n * m)-p1
f1=abs(p1-p2)

p11 = abs(0*y-m*x)/2
p21 = (n * m)-p11
f2=abs(p11-p21)

p12 = abs(n*y-0*x)/2
p22 = (n * m)-p12
f3=abs(p12-p22)

p13 = abs(n*y-m*x)/2
p23 = (n * m)-p13
f4=abs(p13-p23)

f=min(f1,f2,f3,f4)
print(f"{f:.3f}")