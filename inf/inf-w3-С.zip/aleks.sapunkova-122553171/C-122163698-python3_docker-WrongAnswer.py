def area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def main():
    import sys
    input = sys.stdin.read
    data = input().splitlines()
    
    n, m = map(int, data[0].strip().split())
    x, y = map(int, data[1].strip().split())
    
    # Углы пирога
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    total_area = n * m
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
        # Площадь одного из кусочков
        piece_area = area(cx, cy, x, y, n if cx == 0 else 0, m if cy == 0 else 0)
        
        # Разница между кусками
        diff = abs(piece_area - (total_area - piece_area))
        
        # Обновляем минимальную разницу
        min_diff = min(min_diff, diff)
    
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()