def min_difference(n, m, x, y):
    # Площадь пирога
    total_area = n * m
    areas_differences = []

    # 1. Разрез из (0, 0)
    area1 = 0.5 * x * y
    area2 = total_area - area1
    areas_differences.append(abs(area1 - area2))

    # 2. Разрез из (n, 0)
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    areas_differences.append(abs(area1 - area2))

    # 3. Разрез из (0, m)
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    areas_differences.append(abs(area1 - area2))

    # 4. Разрез из (n, m)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    areas_differences.append(abs(area1 - area2))

    # Возвращаем минимальную разницу
    return min(areas_differences)

# Считываем входные данные
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Получаем результат и выводим
result = min_difference(n, m, x, y)
print(f"{result:.3f}")