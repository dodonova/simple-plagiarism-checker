n, m = map(int, input().split())
x, y = map(int, input().split())
min_difference = m*n
for i in range(4):
    match i:
        case 0:
            a = n
            try: b = (y/x)*a
            except ZeroDivisionError: b = 0
        case 1: 
            b = m
            try: a = ((n-x)/y)*b
            except ZeroDivisionError: a = 0
        case 2:
            b = m
            try: a = ((n-x)/(m-y))*b
            except ZeroDivisionError: a = 0
        case 3:
            a = n
            try: b = ((m-y)/x)*a
            except ZeroDivisionError: b = 0
    difference = (m*n - (a*b)/2) - (a*b)/2
    if difference < min_difference:
        min_difference = difference
print(f"{min_difference:.3f}")