def calculate_area_difference(n, m, x, y, corner_x, corner_y):
    # Вычисляем площадь треугольника
    triangle_area = abs((corner_x - x) * (corner_y - y)) / 2
    
    # Площадь всего пирога
    total_area = n * m
    
    # Разница площадей
    return abs(total_area - 2 * triangle_area)

def solve(n, m, x, y):
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    min_difference = float('inf')
    
    for corner in corners:
        difference = calculate_area_difference(n, m, x, y, corner[0], corner[1])
        min_difference = min(min_difference, difference)
    
    return min_difference

# Считываем входные данные
n, m = map(int, input().split())
x, y = map(int, input().split())

# Решаем задачу и выводим результат
result = solve(n, m, x, y)
print(f"{result:.3f}")