def calculate_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def main():
    import sys
    input = sys.stdin.read
    data = input().strip().split()
    
    n = int(data[0])
    m = int(data[1])
    x = int(data[2])
    y = int(data[3])
    
    total_area = n * m
    print(f"Total area: {total_area}")  # Отладочная информация
    
    min_diff = float('inf')  # Начальное значение для минимальной разницы
    
    # Угол (0, 0)
    area1 = calculate_area(0, 0, x, y, 0, m)
    area2 = total_area - area1
    diff = abs(area1 - area2)
    print(f"Area1 (0,0): {area1}, Area2: {area2}, Diff: {diff}")  # Отладочная информация
    min_diff = min(min_diff, diff)

    # Угол (n, 0)
    area1 = calculate_area(n, 0, x, y, n, m)
    area2 = total_area - area1
    diff = abs(area1 - area2)
    print(f"Area1 (n,0): {area1}, Area2: {area2}, Diff: {diff}")  # Отладочная информация
    min_diff = min(min_diff, diff)

    # Угол (0, m)
    area1 = calculate_area(0, m, x, y, n, m)
    area2 = total_area - area1
    diff = abs(area1 - area2)
    print(f"Area1 (0,m): {area1}, Area2: {area2}, Diff: {diff}")  # Отладочная информация
    min_diff = min(min_diff, diff)

    # Угол (n, m)
    area1 = calculate_area(n, m, x, y, 0, 0)
    area2 = total_area - area1
    diff = abs(area1 - area2)
    print(f"Area1 (n,m): {area1}, Area2: {area2}, Diff: {diff}")  # Отладочная информация
    min_diff = min(min_diff, diff)

    print(f"Minimum difference: {min_diff:.3f}")

if __name__ == "__main__":
    main()
