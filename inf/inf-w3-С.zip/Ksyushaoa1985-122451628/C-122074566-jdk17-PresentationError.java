import java.util.Scanner;

public class PieDivision {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Ввод размеров пирога
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        
        // Ввод координат свечки
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        
        // Площадь всего пирога
        double totalArea = n * m;
        
        // Минимальная разница между кусками
        double minDifference = Double.MAX_VALUE;

        // Рассмотрим разрезы из четырех углов
        // 1. Из (0, 0)
        double area1 = 0.5 * x * y; // Треугольник
        double area2 = totalArea - area1; // Остальная часть
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // 2. Из (n, 0)
        area1 = 0.5 * (n - x) * y;
        area2 = totalArea - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // 3. Из (0, m)
        area1 = 0.5 * x * (m - y);
        area2 = totalArea - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // 4. Из (n, m)
        area1 = 0.5 * (n - x) * (m - y);
        area2 = totalArea - area1;
        minDifference = Math.min(minDifference, Math.abs(area1 - area2));

        // Вывод результата с точностью до 3 знаков после запятой
        System.out.printf("%.3fn", minDifference);
    }
}
