#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>

using namespace std;

unordered_map<char, int> countChars(const string& str) {
    unordered_map<char, int> charCount;
    for (char c : str) {
        charCount[c]++;
    }
    return charCount;
}

vector<string> findWords(const string& mixedString, const vector<string>& words) {
    unordered_map<char, int> targetCount = countChars(mixedString);
    vector<pair<string, unordered_map<char, int>>> validWords;

    for (const string& word : words) {
        unordered_map<char, int> wordCount = countChars(word);
        bool isValid = true;

        for (const auto& [char_, count] : wordCount) {
            if (count > targetCount[char_]) {
                isValid = false;
                break;
            }
        }

        if (isValid) {
            validWords.push_back({word, wordCount});
        }
    }

    sort(validWords.begin(), validWords.end(), [](const auto& a, const auto& b) {
        return a.first.length() < b.first.length();
    });

    return validWords;
}

void backtrack(int startIndex, vector<string>& currentCombination,
               unordered_map<char, int>& currentCount, const vector<pair<string, unordered_map<char, int>>>& validWords,
               const unordered_map<char, int>& targetCount, vector<string>& result) {
    if (currentCombination.size() >= 5 && currentCombination.size() <= 8) {
        result = currentCombination;
        return;
    }

    for (int i = startIndex; i < validWords.size(); i++) {
        const auto& [word, wordCount] = validWords[i];
        bool canAdd = true;

        for (const auto& [char_, count] : wordCount) {
            if (currentCount[char_] + count > targetCount.at(char_)) {
                canAdd = false;
                break;
            }
        }

        if (canAdd) {

            currentCombination.push_back(word);
            for (const auto& [char_, count] : wordCount) {
                currentCount[char_] += count;
            }

            backtrack(i + 1, currentCombination, currentCount, validWords, targetCount, result);

            currentCombination.pop_back();
            for (const auto& [char_, count] : wordCount) {
                currentCount[char_] -= count;
            }
        }
    }
}

int main() {
    string mixedString;
    getline(cin, mixedString);
    
    int n;
    cin >> n;
    cin.ignore();

    vector<string> words(n);
    for (int i = 0; i < n; i++) {
        getline(cin, words[i]);
    }

    vector<pair<string, unordered_map<char, int>>> validWords = findWords(mixedString, words);
    
    vector<string> result;
    vector<string> currentCombination;
    unordered_map<char, int> currentCount;

    backtrack(0, currentCombination, currentCount, validWords, countChars(mixedString), result);

    if (!result.empty()) {
        for (const string& word : result) {
            cout << word << endl;
        }
    } else {
        cout << "No valid words found." << endl;
    }

    return 0;
}