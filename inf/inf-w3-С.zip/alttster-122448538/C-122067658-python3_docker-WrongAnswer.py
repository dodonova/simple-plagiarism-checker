import math
m,n=input().split()
m,n=float(m), float(n)
x,y=input().split()
x,y=float(x), float(y)
ld=(x**2+y**2)**0.5
lu=(x**2+(n-y)**2)**0.5
ru=((m-x)**2+(n-y)**2)**0.5
rd=((m-x)**2+(y)**2)**0.5
if max(ld,lu,rd,ru)==ld:
    a=math.asin((n-y)/ld)
    ch=ld
if max(ld,lu,rd,ru)==lu:
    a = math.asin((n - y) / lu)
    ch = lu
if max(ld,lu,rd,ru)==rd:
    a = math.asin((n - y) / rd)
    ch = rd
if max(ld,lu,rd,ru)==ru:
    a = math.asin((n - y) / ru)
    ch = ru
if m*math.tan(a)<=n:
    sm=m*math.tan(a)*m/2
else:
    sm = n/math.tan(a)*n/2
so=m*n
print("{:.3f}".format(math.fabs(so-2*sm)))
