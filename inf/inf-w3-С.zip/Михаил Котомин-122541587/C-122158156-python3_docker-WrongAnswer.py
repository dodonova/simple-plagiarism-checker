def min_difference(n, m, x, y):
    # Площадь прямоугольника
    total_area = n * m
    
    # Рассмотрим четыре возможных разреза через углы
    # 1. Разрез через (0, 0)
    area1 = x * y  # Площадь куска от (0, 0) до (x, y)
    area2 = total_area - area1  # Площадь оставшегося куска
    diff1 = abs(area1 - area2)

    # 2. Разрез через (0, m)
    area1 = x * (m - y)  # Площадь куска от (0, m) до (x, y)
    area2 = total_area - area1
    diff2 = abs(area1 - area2)

    # 3. Разрез через (n, 0)
    area1 = (n - x) * y  # Площадь куска от (n, 0) до (x, y)
    area2 = total_area - area1
    diff3 = abs(area1 - area2)

    # 4. Разрез через (n, m)
    area1 = (n - x) * (m - y)  # Площадь куска от (n, m) до (x, y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)

    # Находим минимальную разницу
    min_diff = min(diff1, diff2, diff3, diff4)

    return min_diff

# Чтение ввода
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{result:.6f}")