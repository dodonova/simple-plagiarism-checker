n, m = int(input()).split()
x, y = int(input()).split()
res = (m*(n - x/y)/2).round(3)
print(res)