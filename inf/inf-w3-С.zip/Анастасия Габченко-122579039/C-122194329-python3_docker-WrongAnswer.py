def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Площади, разрезая через каждый угол
    areas = []
    
    # Разрез из (0, 0)
    area1 = 0.5 * abs(0 * (y - m) + x * (m - 0) + 0 * (0 - y))
    areas.append(area1)
    
    # Разрез из (n, 0)
    area2 = 0.5 * abs(n * (y - 0) + x * (0 - 0) + n * (0 - y))
    areas.append(area2)
    
    # Разрез из (0, m)
    area3 = 0.5 * abs(0 * (y - 0) + x * (0 - m) + 0 * (m - y))
    areas.append(area3)

    # Разрез из (n, m)
    area4 = 0.5 * abs(n * (y - m) + x * (m - m) + n * (m - y))
    areas.append(area4)
    
    # Находим минимальное различие наименьшей площади
    min_diff = float('inf')
    
    for area in areas:
        remaining_area = total_area - area
        diff = abs(area - remaining_area)
        min_diff = min(min_diff, diff)

    return min_diff


def main():
    # Считываем входные данные
    n, m = map(int, input().strip().split())
    x, y = map(int, input().strip().split())
    
    # Находим минимальную разницу
    result = min_difference(n, m, x, y)
    
    # Выводим результат с точностью до 3 знаков
    print(f"{result:.3f}")


if __name__ == "__main__":
    main()