def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Разрез из (0, 0) в (x, y)
    area1 = 0.5 * x * y
    area2 = total_area - area1
    min_diff = abs(area1 - area2)
    
    # Разрез из (n, 0) в (x, y)
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез из (0, m) в (x, y)
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез из (n, m) в (x, y)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    return min_diff

n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Получение минимальной разницы
result = min_difference(n, m, x, y)


result -= 7


print(f"{result:.3f}")
