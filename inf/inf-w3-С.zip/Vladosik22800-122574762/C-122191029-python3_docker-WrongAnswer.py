
def min_area_difference(n, m, x, y):
    
    total_area = n * m
    # Areas of the segments depending on which corner we choose
    bottom_left_area = x * y
    bottom_right_area = (n - x) * y
    top_left_area = x * (m - y)
    top_right_area = (n - x) * (m - y)

    
    areas = [
        (bottom_left_area, total_area - bottom_left_area),
        (bottom_right_area, total_area - bottom_right_area),
        (top_left_area, total_area - top_left_area),
        (top_right_area, total_area - top_right_area)
    ]
    
    
    min_difference = float('inf')
    for area1, area2 in areas:
        difference = abs(area1 - area2)
        min_difference = min(min_difference, difference)
    
    return min_difference


n, m = map(int, input().split())
x, y = map(int, input().split())
result = min_area_difference(n, m, x, y)

print(f"{result:.3f}")