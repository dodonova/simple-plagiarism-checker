#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

int main() {
    // Ввод размеров пирога
    int n, m;
    cin >> n >> m;

    // Ввод координат свечки
    double x, y;
    cin >> x >> y;

    // Площадь пирога
    double total_area = n * m;

    // Минимальная разница
    double min_difference = total_area;

    // Разрез через угол (0, 0)
    double area1 = (x * y) / 2; // Площадь треугольника
    double area2 = total_area - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Разрез через угол (0, m)
    area1 = (x * (m - y)) / 2; // Площадь треугольника
    area2 = total_area - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Разрез через угол (n, 0)
    area1 = ((n - x) * y) / 2; // Площадь треугольника
    area2 = total_area - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Разрез через угол (n, m)
    area1 = ((n - x) * (m - y)) / 2; // Площадь треугольника
    area2 = total_area - area1;
    min_difference = min(min_difference, abs(area1 - area2));

    // Вывод результата с нужной точностью (3 знака после запятой)
    cout << fixed << setprecision(3) << min_difference << endl;

    return 0;
}