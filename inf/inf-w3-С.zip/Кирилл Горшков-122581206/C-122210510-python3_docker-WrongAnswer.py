n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m

# Площадь прямоугольника, образованного свечкой и тремя вершинами пирога
area_with_candle = x * y

# Площадь прямоугольника, образованного свечкой и тремя вершинами пирога (с другой стороны)
area_without_candle = (n - x) * y

# Разница площадей
difference = abs(area_with_candle - area_without_candle)

# Вывод результата
print(difference / total_area)

