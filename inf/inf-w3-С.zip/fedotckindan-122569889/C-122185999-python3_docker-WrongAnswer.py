def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Минимальная разница между площадями
    min_diff = float('inf')
    
    # Разрез через угол (0, 0)
    area1 = x * y
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез через угол (n, 0)
    area1 = (n - x) * y
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез через угол (0, m)
    area1 = x * (m - y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    # Разрез через угол (n, m)
    area1 = (n - x) * (m - y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с точностью 3 знака после запятой
print(f"{result:.3f}")