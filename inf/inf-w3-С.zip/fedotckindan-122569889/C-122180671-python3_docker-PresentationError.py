def min_difference(w, h, cx, cy):
    min_diff = float('inf')  # Начальная минимальная разница
    corners = [(0, 0), (w, 0), (0, h), (w, h)]  # Четыре угла пирога

    for corner_x, corner_y in corners:
        # Находим две части разреза
        area1 = 0.5 * abs(corner_x * cy - corner_y * cx)  # Площадь треугольника
        area2 = w * h - area1  # Площадь оставшейся части
        difference = abs(area1 - area2)
        min_diff = min(min_diff, difference)

    return min_diff

# Чтение входных данных от пользователя
width, height = map(int, input("Введите ширину и высоту пирога через пробел: ").split())
candle_x, candle_y = map(int, input("Введите координаты свечки (x y) через пробел: ").split())

# Получение минимальной разницы
result = min_difference(width, height, candle_x, candle_y)

# Вывод результата с точностью не менее трех знаков после десятичной точки
print(f"Минимальная разница между площадями кусочков: {result:.3f}")