def calculate_area_difference(n, m, x, y):
    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    min_difference = float('inf')
    
    for (x1, y1) in corners:
        total_area = n * m
        
        triangle_area_1 = abs((x1 * (y - y1) + x * (y1 - 0) + 0 * (0 - y)) / 2)
        
        triangle_area_2 = abs((x1 * (y - m) + x * (m - y1) + n * (y1 - y)) / 2)
        
        area1 = triangle_area_1 + (total_area - triangle_area_1 - triangle_area_2)
        
        area2 = total_area - area1
        
        difference = abs(area1 - area2)
        
        min_difference = min(min_difference, difference)
    
    return min_difference

n, m = map(int, input().split())
x, y = map(int, input().split())

result = calculate_area_difference(n, m, x, y)

print(f"{result:.3f}")