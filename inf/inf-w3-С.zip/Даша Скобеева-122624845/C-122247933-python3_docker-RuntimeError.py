n, m = map(int, input().split())
x, y = map(int, input().split())
s = n * m

def ploshad(vershiny):
    area = 0
    l = len(vershiny)
    for i in range(l):
        x1, y1 = vershiny[i]
        x2, y2 = vershiny[(i + 1) % l]
        area += x1 * y2 - x2 * y1
    return abs(area) / 2

def raschet(x0, y0):
    dx = x - x0
    dy = y - y0
    tochki = []
    
    # Находим точки пересечения с границами
    if dx != 0:
        t = (0 - x0) / dx
        if 0 < t < 1:
            y_int = y0 + t * dy
            if 0 <= y_int <= m:
                tochki.append((0, y_int))
        t = (n - x0) / dx
        if 0 < t < 1:
            y_int = y0 + t * dy
            if 0 <= y_int <= m:
                tochki.append((n, y_int))
    
    if dy != 0:
        t = (0 - y0) / dy
        if 0 < t < 1:
            x_int = x0 + t * dx
            if 0 <= x_int <= n:
                tochki.append((x_int, 0))
        t = (m - y0) / dy
        if 0 < t < 1:
            x_int = x0 + t * dx
            if 0 <= x_int <= n:
                tochki.append((x_int, m))
    
    if len(tochki) != 1:
        return None
    
    xi, yi = tochki[0]
    
    # Формируем вершины в зависимости от начальной точки
    if x0 == 0 and y0 == 0:
        if xi == n:
            vershiny = [(0, 0), (n, 0), (n, yi), (x, y)]
        elif yi == m:
            vershiny = [(0, 0), (xi, m), (0, m), (x, y)]
        else:
            return None
    elif x0 == n and y0 == 0:
        if xi == 0:
            vershiny = [(n, 0), (0, 0), (0, yi), (x, y)]
        elif yi == m:
            vershiny = [(n, 0), (xi, m), (n, m), (x, y)]
        else:
            return None
    elif x0 == n and y0 == m:
        if xi == 0:
            vershiny = [(n, m), (0, m), (0, yi), (x, y)]
        elif yi == 0:
            vershiny = [(n, m), (xi, 0), (n, 0), (x, y)]
        else:
            return None
    elif x0 == 0 and y0 == m:
        if xi == n:
            vershiny = [(0, m), (n, m), (n, yi), (x, y)]
        elif yi == 0:
            vershiny = [(0, m), (xi, 0), (0, 0), (x, y)]
        else:
            return None
    else:
        return None
    
    area = ploshad(vershiny)
    diff = abs(s - 2 * area)
    return diff

ugly = [(0, 0), (n, 0), (n, m), (0, m)]
min_diff = None

for x0, y0 in ugly:
    d = raschet(x0, y0)
    if d is not None:
        if min_diff is None or d < min_diff:
            min_diff = d

print(f"{min_diff:.10f}")