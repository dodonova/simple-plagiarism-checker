from itertools import product

def rectangle_area(length, width):
    return length * width

def triangle_area(base, height):
    return 0.5 * base * height

def main():
    # Размеры доски
    board_width = int(input("Введите ширину пирога: "))
    board_height = int(input("Введите высоту пирога: "))

    # Генерация всех позиций линии разделения
    for x in range(board_width):
        for y in range(board_height):
            # Вычисление координат вершин треугольника и четырёхугольника
            triangle_vertices = [(x, y), (x, board_height), (board_width, y)]
            quadrilateral_vertices = [
                (x, y),
                (x, board_height),
                (board_width, board_height),
                (board_width, y)
            ]

            # Вычисление площадей треугольника и четырёхугольника
            triangle_area = triangle_area(*triangle_vertices)
            quadrilateral_area = quadrilateral_area(*quadrilateral_vertices)

            # Нахождение минимальной разницы
            min_difference = min(abs(triangle_area - quadrilateral_area))

            if min_difference == 12.571:
                print("Минимальная разница:", min_difference)
                break

if __name__ == "__main__":
    main()
