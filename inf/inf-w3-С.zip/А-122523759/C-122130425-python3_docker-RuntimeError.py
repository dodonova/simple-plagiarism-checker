from itertools import product

def quadrilateral_area(a, b, c, d):
    # Здесь a, b, c и d - стороны четырёхугольника
    s = (a + b + c + d) / 2
    area = (s * (s - a) * (s - b) * (s - c) * (s - d)) ** 0.5
    return area

def triangle_area(base, height):
    return 0.5 * base * height

def rectangle_area(length, width):
    return length * width

def main():
    # Размеры доски
    board_width = 8
    board_height = 5

    # Генерация всех позиций линии разделения
    for x in range(board_width):
        for y in range(board_height):
            # Вычисление координат вершин треугольника и четырёхугольника
            triangle_vertices = [(x, y), (x, board_height), (board_width, y)]
            quadrilateral_vertices = [
                (x, y),
                (x, board_height),
                (board_width, board_height),
                (board_width, y)
            ]

            # Вычисление площадей треугольника и четырёхугольника
            triangle_area = triangle_area(*triangle_vertices)
            quadrilateral_area = quadrilateral_area(*quadrilateral_vertices)

            # Нахождение минимальной разницы
            min_difference = min(abs(triangle_area - quadrilateral_area))

            if min_difference == 12.571:
                print("Минимальная разница:", min_difference)
                break

if __name__ == "__main__":
    main()