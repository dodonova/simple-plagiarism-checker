def triangle_area(x1, y1, x2, y2, x3, y3):
   
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def line_intersection(cx, cy, x, y, n, m):
    
    d = x - cx
    h = y - cy
    intersections = []

    if d != 0:
       
        Th = (n - cx) / d
        if Th > 1e-9:
            iy = cy + Th * h
            if 0 <= iy <= m:
                intersections.append((n, iy))
       
        Th = (0 - cx) / d
        if Th > 1e-9:
            iy = cy + Th * h
            if 0 <= iy <= m:
                intersections.append((0, iy))

    if h != 0:
        
        Th = (m - cy) / h
        if Th > 1e-9:
            ix = cx + Th * dx
            if 0 <= ix <= n:
                intersections.append((ix, m))
        
        
Th = (0 - cy) / h
        if Th > 1e-9:
            ix = cx + Th * d
            if 0 <= ix <= n:
                intersections.append((ix, 0))

    
    intersections = [pt for pt in intersections if not (abs(pt[0] - x) < 1e-9 and abs(pt[1] - y) < 1e-9)]
    
    if not intersections:
        return None  
    min_dist = float('inf')
    intersection_point = None
    for pt in intersections:
        dist = (pt[0] - cx)2 + (pt[1] - cy)2
        if dist < min_dist:
            min_dist = dist
            intersection_point = pt
    return intersection_point

def compute_polygon_area(cx, cy, x, y, ix, iy, n, m):
    
    vertices = []
    vertices.append((cx, cy))
    vertices.append((x, y))
    vertices.append((ix, iy))
    
    
    import math
    angle = math.atan2(iy - cy, ix - cx)
    
    
    if 0 <= angle <= math.pi:
        
        if ix == n:
            
            vertices.append((n, m))
            vertices.append((0, m))
            vertices.append((0, 0))
        elif ix == 0:
            
            vertices.append((0, 0))
            vertices.append((n, 0))
            vertices.append((n, m))
        elif iy == m:
           
            vertices.append((n, m))
            vertices.append((n, 0))
            vertices.append((0, 0))
        elif iy == 0:
       
            vertices.append((0, 0))
            vertices.append((0, m))
            vertices.append((n, m))
    else:
   
        if ix == n:
  
            vertices.append((n, 0))
            vertices.append((0, 0))
            vertices.append((0, m))
        elif ix == 0:
         
            vertices.append((0, m))
            vertices.append((n, m))
            vertices.append((n, 0))
        elif iy == m:
     
            vertices.append((0, m))
            vertices.append((0, 0))
            vertices.append((n, 0))
        elif iy == 0:
       
            vertices.append((n, 0))
            vertices.append((n, m))
            vertices.append((0, m))
    
   
    area = 0
    for i in range(len(vertices)):
        x1, y1 = vertices[i]
        x2, y2 = vertices[(i +1) % len(vertices)]
        area += (x1 * y2 - x2 * y1)
    area = abs(area) /2
    return area

def min_area_difference(n, m, x, y):
    total_area = n * m
    min_diff = float('inf')
    
    corners = [
        (0, 0),
        (n, 0),
        (n, m),
        (0, m)
    ]
    
    for (cx, cy) in corners:
        if cx == x and cy == y:
            continue  
        intersection = line_intersection(cx, cy, x, y, n, m)
        if not intersection:
            continue  
        ix, iy = intersection
        area = compute_polygon_area(cx, cy, x, y, ix, iy, n, m)
        diff = abs(total_area - 2 * area)
        if diff < min_diff:
            min_diff = diff
    return min_diff

import sys
n, m = map(int, sys.stdin.readline().split())
x, y = map(int, sys.stdin.readline().split())
diff = min_area_difference(n, m, x, y)
print(f"{diff:.3f}")