n, m=map(int, input().split())
x, y=map(int, input().split())
sp=n*m

tg1=(m-y)/x
str1=tg1*n*n
raz1=sp-str1

tg2=(n-x)/(m-y)
str2=tg2*m*m
raz2=sp-str2

tg3=(n-x)/y
str3=tg3*m*m
raz3=sp-str3

tg4=y/x
str4=tg4*n*n
raz4=sp-str4

raz=n*m
if round(raz1, 4)<raz:
    raz=raz1
if round(raz2, 4)<raz:
    raz=raz2
if round(raz3, 4)<raz:
    raz=raz3
if round(raz4, 4)<raz:
    raz=raz4


print(f"{raz3:.{3}f}")
