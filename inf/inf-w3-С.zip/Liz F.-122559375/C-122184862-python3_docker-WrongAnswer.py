n, m = map(int, input().split())
x, y = map(int, input().split())

area1 = max(x * m, (n - x) * m)
area2 = max(y * n, (m - y) * n)

result = min(area1, area2) - min(area1, area2) / 2
print("{:.3f}".format(result))
