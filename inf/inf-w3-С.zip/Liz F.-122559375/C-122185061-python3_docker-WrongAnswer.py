n, m = map(int, input().split())
x, y = map(int, input().split())

area1 = x * m
area2 = (n - x) * m
area3 = n * y
area4 = n * (m - y)

min_area_diff = min(abs(area1 - area2), abs(area3 - area4))

print('{:.3f}'.format(min_area_diff))