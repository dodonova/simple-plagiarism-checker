import sys
import math

def input():
    return sys.stdin.readline()

def get_polygon_area(vertices):
    area = 0.0
    n = len(vertices)
    for i in range(n):
        x1, y1 = vertices[i % n]
        x2, y2 = vertices[(i + 1) % n]
        area += (x1 * y2 - x2 * y1)
    return abs(area) / 2.0

def get_intersection_points(n, m, x0, y0, x1, y1):
    points = []
    dx = x1 - x0
    dy = y1 - y0

    if dx == 0:
        k = None
    else:
        k = dy / dx

    candidates = []

    for x_edge in [0, n]:
        if dx != 0:
            t = (x_edge - x0) / dx
            if 0 <= t <= 1 or t >= 0:
                y_intersect = y0 + t * dy
                if 0 <= y_intersect <= m:
                    candidates.append((x_edge, y_intersect, t))

    for y_edge in [0, m]:
        if dy != 0:
            t = (y_edge - y0) / dy
            if 0 <= t <= 1 or t >= 0:
                x_intersect = x0 + t * dx
                if 0 <= x_intersect <= n:
                    candidates.append((x_intersect, y_edge, t))

    candidates = [ (x, y, t) for x, y, t in candidates if not (x == x0 and y == y0) ]

    candidates.sort(key=lambda point: point[2])

    return candidates[:2]

def compute_area(n, m, x_candle, y_candle):
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    total_area = n * m
    min_diff = None

    for corner in corners:
        x0, y0 = corner
        if (x0 == x_candle and y0 == y_candle):
            continue

        intersections = get_intersection_points(n, m, x0, y0, x_candle, y_candle)

        polygon = [corner]
        for x, y, _ in intersections:
            polygon.append((x, y))
        polygon.append((x_candle, y_candle))

        if len(polygon) >= 3:
            x_prev, y_prev = polygon[-2]
            x_curr, y_curr = polygon[-1]
            direction = (x_curr - x_prev, y_curr - y_prev)
            if direction[0] * dy - direction[1] * dx >= 0:
                remaining_corners = [pt for pt in corners if pt != corner and pt != (x0, y0)]
            else:
                remaining_corners = [pt for pt in reversed(corners) if pt != corner and pt != (x0, y0)]
            polygon.extend(remaining_corners)

        area = get_polygon_area(polygon)

        diff = abs(total_area - 2 * area)

        if min_diff is None or diff < min_diff:
            min_diff = diff

    return min_diff

def main():
    n_str, m_str, x_str, y_str = sys.stdin.read().split()
    n = float(n_str)
    m = float(m_str)
    x_candle = float(x_str)
    y_candle = float(y_str)

    min_diff = compute_area(n, m, x_candle, y_candle)
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()