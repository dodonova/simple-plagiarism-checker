n, m = map(int, input().split())
x, y = map(int, input().split())

areas = []
areas.append(0.5 * x * y)  # угол (0, 0)
areas.append(0.5 * (n - x) * y)  # угол (n, 0)
areas.append(0.5 * x * (m - y))  # угол (0, m)
areas.append(0.5 * (n - x) * (m - y))  # угол (n, m)


min_diff = float('inf')
for area in areas:
    other_area = (n * m) - area
    min_diff = min(min_diff, abs(area - other_area))


print(f"{min_diff:.3f}")
