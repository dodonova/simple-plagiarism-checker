def hd(d, z, h, Z):
    if z / d <= Z / h:
        return z / d * h**2 / 2
    else:
        return d / z * Z**2 / 2


h, Z = map(int, input().split())
d, z = map(int, input().split())
j = h * Z
s = [
    abs(j - 2 * hd(d, z, h, Z)),
    abs(j - 2 * hd(h - d, z, h, Z)),
    abs(j - 2 * hd(d, Z - z, h, Z)),
    abs(j - 2 * hd(h - d, Z - z, h, Z)),
]
print("{:.3f}".format(min(s)))