a=int(input())
if a>=4:
    print(a)