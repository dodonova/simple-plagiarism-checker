def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def min_difference(n, m, x, y):
    # Углы пирога
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
        # Площадь всего пирога
        total_area = n * m
        
        # Площадь треугольника от угла до свечки и до границ пирога
        area1 = area_of_triangle(cx, cy, x, y, n if cx == 0 else 0, cy)
        area2 = area_of_triangle(cx, cy, x, y, cx, m if cy == 0 else 0)
        
        # Площадь второго куска
        area_piece1 = area1 + area2
        area_piece2 = total_area - area_piece1
        
        # Разница между кусками
        diff = abs(area_piece1 - area_piece2)
        
        # Обновляем минимальную разницу
        min_diff = min(min_diff, diff)
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение результата
result = min_difference(n, m, x, y)

# Вывод с нужной точностью
print(f"{result:.3f}")