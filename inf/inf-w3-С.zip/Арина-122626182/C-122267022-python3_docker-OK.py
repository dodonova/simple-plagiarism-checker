n, m = 8, 5
x, y = 7, 2

n, m = map(int, input().split())
x, y = map(int, input().split())

rs = n * m

min_diff = 1e9


def calc(p):
    global min_diff
    is_up_side = p[0] * m / p[1] <= n
    if is_up_side:
        min_diff = min(min_diff, (rs - m * p[0] * m / p[1]))
    else:
        min_diff = min(min_diff, (rs - n * p[1] * n / p[0]))


ds = (n / 2, m / 2)

p1 = (x, y)
p2 = (n - x, y)
p3 = (x, m - y)
p4 = (n - x, m - y)


calc(p1)
calc(p2)
calc(p3)
calc(p4)

print(min_diff)
