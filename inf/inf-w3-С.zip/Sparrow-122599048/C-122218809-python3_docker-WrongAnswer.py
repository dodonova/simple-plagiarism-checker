n, m = map(int, input().split())
x, y = map(int, input().split())

spr = n * m

k1 = y / m
kat1 = (n-x)/k1
s1 = (m * kat1) / 2
sforygl1 = spr - s1;
razn1 = max(s1, sforygl1) - min(s1, sforygl1)

k2 = x / n
kat2 = (m - y) / k2 
s2 = (n * kat2) / 2
sforygl2 = spr - s2;
razn2 = max(s2, sforygl2) - min(s2, sforygl2)

k3 = (m - y) / m
kat3 = (n-x) / k3
s3 = (m * kat3) / 2 
sforygl3 = spr - s3;
razn3 = max(s3, sforygl3) - min(s3, sforygl3)

k4 = x / n;
kat4 = y / k4 
s4 = (n * kat4) / 2 
sforygl4 = spr - s4;
razn4 = max(s4, sforygl4) - min(s4, sforygl4)

print(f"{min(razn1, razn2, razn3, razn4):.3f}") 