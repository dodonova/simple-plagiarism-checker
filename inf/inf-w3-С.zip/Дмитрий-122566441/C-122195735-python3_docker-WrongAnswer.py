def min_area_difference(n, m, x, y):
    total_area = n * m

    area1 = x * y
    area2 = (n - x) * y
    area3 = x * (m - y)
    area4 = (n - x) * (m - y)

    diff1 = abs(total_area - 2 * area1) 
    diff2 = abs(total_area - 2 * area2)
    diff3 = abs(total_area - 2 * area3)
    diff4 = abs(total_area - 2 * area4)

    min_diff = min(diff1, diff2, diff3, diff4)

    return min_diff / 2

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_area_difference(n, m, x, y)
print(f"{result:.3f}")