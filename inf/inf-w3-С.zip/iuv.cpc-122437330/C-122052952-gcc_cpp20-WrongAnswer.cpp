#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    double n, m, x, y; cin >> n >> m >> x >> y;
    double mn = m*n;

    for(int i = 0; i <= 1; ++i)
        for(int j = 0; j <= 1; ++j)
        {
            const double a = n*i,
                         b = m*j;

            // x' = (x - a)
            // y' = (y - b)

            double xa = n,
                   ya = (y - b)/(x - a)*(xa - a)+b;
            if(ya >= 0 && ya <= m)
            {
                mn = min(mn, m*n - abs(xa - a)*abs(ya - b));
            }

            xa = 0;
            ya = (y - b)/(x - a)*(xa - a)+b;
            if(ya >= 0 && ya <= m)
            {
                mn = min(mn, m*n - abs(xa - a)*abs(ya - b));
            }

            ya = m;
            xa = (x - a)/(y - a)*(ya - b) + a;
            if(xa >= 0 && xa <= n)
            {
                mn = min(mn, m*n - abs(xa - a)*abs(ya - b));
            }

            ya = 0;
            xa = (x - a)/(y - a)*(ya - b) + a;
            if(xa >= 0 && xa <= n)
            {
                mn = min(mn, m*n - abs(xa - a)*abs(ya - b));
            }
            
        }

    cout << mn << '\n';

    return 0;
}