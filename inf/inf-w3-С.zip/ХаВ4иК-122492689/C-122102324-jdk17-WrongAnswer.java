import java.util.Scanner;

public class PieCut {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int x = sc.nextInt();
        int y = sc.nextInt();

        double minDifference = Double.MAX_VALUE;

        minDifference = Math.min(minDifference, getDifference(n * y, (m - y) * n));
        minDifference = Math.min(minDifference, getDifference(m * x, (n - x) * m));
        minDifference = Math.min(minDifference, getDifference(x * m, (n - x) * m));
        minDifference = Math.min(minDifference, getDifference((n - x) * m, x * m));

        System.out.printf("%.3f\n", minDifference);
    }

    private static double getDifference(double area1, double area2) {
        return Math.abs(area1 - area2);
    }
}
