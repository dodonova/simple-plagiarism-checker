import java.util.Scanner;

public class CakeDivision {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();
        int m = scanner.nextInt();

        int x = scanner.nextInt();
        int y = scanner.nextInt();

        scanner.close();

        double minDifference = Math.min(
            Math.min(calculateDifference(0, 0, x, y, n, m), calculateDifference(n, 0, x, y, n, m)),
            Math.min(calculateDifference(0, m, x, y, n, m), calculateDifference(n, m, x, y, n, m))
        );

        System.out.printf("%.3f\n", minDifference);
    }

    private static double calculateDifference(int cornerX, int cornerY, int x, int y, int n, int m) {
        double totalArea = n * m;
)
        double triangleArea = 0.5 * Math.abs(cornerX * (y - m) + x * (cornerY - y) + (n - x) * (cornerY - m));

        double otherArea = totalArea - triangleArea;

        return Math.abs(triangleArea - otherArea);
    }
}
