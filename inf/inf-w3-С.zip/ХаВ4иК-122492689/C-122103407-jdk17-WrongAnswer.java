import java.util.Scanner;

public class PieCut {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int x = sc.nextInt();
        int y = sc.nextInt();

        double fullArea = n * m;
        double minDifference = Double.MAX_VALUE;

        minDifference = Math.min(minDifference, getDifference(0, 0, n, m, x, y, fullArea));
        minDifference = Math.min(minDifference, getDifference(0, m, n, 0, x, y, fullArea));
        minDifference = Math.min(minDifference, getDifference(n, 0, 0, m, x, y, fullArea));
        minDifference = Math.min(minDifference, getDifference(n, m, 0, 0, x, y, fullArea));

        System.out.printf("%.3f\n", minDifference);
    }

    private static double getDifference(int x1, int y1, int x2, int y2, int x, int y, double fullArea) {
        double area1 = Math.abs((x1 * (y2 - y) + x * (y1 - y2) + x2 * (y - y1)) / 2.0);
        double area2 = fullArea - area1;
        return Math.abs(area1 - area2);
    }
}
