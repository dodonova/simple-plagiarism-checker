import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int x = scanner.nextInt();
        int y = scanner.nextInt();

        double minDiff = Double.MAX_VALUE;
        double diff1 = Math.abs(0.5 * (n * m - x * y) - 0.5 * x * y);
        minDiff = Math.min(minDiff, diff1);
        double diff2 = Math.abs(0.5 * (n * m - (n - x) * y) - 0.5 * (n - x) * y);
        minDiff = Math.min(minDiff, diff2);
        double diff3 = Math.abs(0.5 * (n * m - x * (m - y)) - 0.5 * x * (m - y));
        minDiff = Math.min(minDiff, diff3);
        double diff4 = Math.abs(0.5 * (n * m - (n - x) * (m - y)) - 0.5 * (n - x) * (m - y));
        minDiff = Math.min(minDiff, diff4);

        System.out.printf("%.3f", minDiff);
    }
}