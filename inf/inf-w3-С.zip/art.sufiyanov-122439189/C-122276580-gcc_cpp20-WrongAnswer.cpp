#include <bits/stdc++.h>

using namespace std;
using ll = long long;

int main() {
    double n, m, x, y;
    cin >> n >> m >> x >> y;
    double sq1 = (((n * y * n / x)) / 2);
    double sq2 = ((m * ((n - x) * m / y)) / 2);
    double ans = max(sq1, sq2);
    double x1 = -x, y1 = -y;
    double sq3 = (((m * ((n - x) * m / (m - y)))) / 2);
    ans = max(ans, sq3);
    double sq4 = ((n * ((m - y) * n / x)) / 2);
    ans = max(ans, sq4);
    /*
    cout << ((n * m) / 2 - sq1) * 2 << "\n";
    cout << ((n * m) / 2 - sq2) * 2 << "\n";
    cout << ((n * m) / 2 - sq3) * 2 << "\n";
    cout << ((n * m) / 2 - sq4) * 2 << "\n";
    cout << "s\n";
    cout << sq1 << " " << sq2 << " " << sq3 << " " << sq4 << "\n";
    cout << "ans : ";
    */
    cout << setprecision(5) << fixed << ((n * m) / 2 - ans) * 2 << "\n";
}

