n, m = map(int, input().split())
x, y = map(int, input().split())
total_area = n * m
triangle_area = 0.5 * x * y
remaining_area = total_area - triangle_area
min_difference = abs(triangle_area - remaining_area) / 2

print(f"{min_difference:.3f}")