n = int(input())
a = list(map(int, input().split()))

s = 0

while a:
	s1 = min(a)*len(a)//2
    
    if s1<s1:
    	s =min(a) * len(a)//2
    a.remove(min(a))
print(s)    