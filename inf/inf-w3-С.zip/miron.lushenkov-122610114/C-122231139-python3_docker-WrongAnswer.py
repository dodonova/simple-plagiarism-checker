def min_difference(n, m, x, y):
    total_area = n * m

    areas = [
        (x * y, total_area - x * y),
        ((n - x) * y, total_area - (n - x) * y),  
        (x * (m - y), total_area - x * (m - y)),  
        ((n - x) * (m - y), total_area - (n - x) * (m - y)) 
    ]

    min_diff = float('inf')
    for area1, area2 in areas:
        min_diff = min(min_diff, abs(area1 - area2))
    
    return min_diff

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_difference(n, m, x, y)

print(f"{result:.10f}")