import math

def area_of_rectangle(x1, y1, x2, y2):
    return (x2 - x1) * (y2 - y1)

def calculate_difference(n, m, x, y):
    dx = x - 1
    dy = y - 1
    
    def max_triangle_area():
        areas = []
        for i in range(dx+1):
            areas.append(abs((i*dy)-((dx-i)*y)))
            
        maximum = max(areas)
        index = areas.index(maximum)
        
        return maximum, index
    
    max_triangle_area_value, _ = max_triangle_area()
    
    second_max_triangle_area_value = float('inf')
    final_diff = float('inf')
    
    for first_idx in range(dx+1):
        for second_idx in range(first_idx+1, dx+1):
            if (abs(areas[first_idx] - max_triangle_area_value) <= second_max_triangle_area_value or
                abs(areas[second_idx] - max_triangle_area_value) <= second_max_triangle_area_value):
                
                continue
            
            if not ((abs(areas[first_idx] - max_triangle_area_value) > second_max_triangle_area_value and
                     abs(areas[second_idx] - max_triangle_area_value) > second_max_triangle_area_value)):
                continue
            
            new_diff = abs(areas[first_idx] + areas[second_idx] - max_triangle_area_value)
            
            if new_diff < final_diff:
                final_diff = new_diff
                break
    
    return final_diff

# Чтение данных
if __name__ == '__main__':
    data = input().split()
    n = int(data[0])
    m = int(data[1])
    x = int(data[2])
    y = int(data[3])
    
    print(f'{calculate_difference(n, m, x, y):.3f}')