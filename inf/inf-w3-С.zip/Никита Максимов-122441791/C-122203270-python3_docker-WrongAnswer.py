def calculate_triangle_area(x1, y1, x2, y2, x3, y3):
    # Формула для площади треугольника через координаты
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def find_minimal_difference(n, m, x, y):
    total_area = n * m  # Общая площадь пирога
    min_difference = float('inf')

    # Проверяем разрезы через каждый из углов
    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    for cx, cy in corners:
        # Площадь треугольника с углом (cx, cy) и точкой свечки (x, y)
        triangle_area = calculate_triangle_area(cx, cy, 0, 0, x, y)
        # Вторая часть пирога
        other_area = total_area - triangle_area
        
        # Разница между большими и малыми кусками
        difference = abs(triangle_area - other_area)
        
        # Ищем минимальную разницу
        min_difference = min(min_difference, difference)

    return min_difference

# Чтение данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисляем и выводим результат
result = find_minimal_difference(n, m, x, y)
print(f"{result:.3f}")