import math

class Vector2:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.length = math.sqrt(x**2 + y**2)
    def sub_v(self, vec):
        return Vector2(self.x-vec.x, self.y-vec.y)
    def normalize(self):
        return Vector2(self.x/self.length, self.y/self.length)
    def dot(self, vec):
        return self.x*vec.x + self.y*vec.y
    def sub_v(self, vec):
        return Vector2(self.x-vec.x, self.y-vec.y)
    def get_angle(self, vec):
        return math.acos(self.dot(vec)/self.length/vec.length)
    def negate(self):
        return Vector2(-self.x, -self.y)

def scalar_dif(a, b):
    return abs(a-b)

if __name__ == "__main__":
    n, m = list(map(int, input().split(' ')))
    x, y = list(map(int, input().split(' ')))

    Ox = Vector2(1, 0)
    Oy = Vector2(0, 1)
    diagonal = Vector2(n, m)
    angle = Ox.get_angle(diagonal)
    diag_ang = min(Ox.get_angle(diagonal), Oy.get_angle(diagonal))
    ztxy = Vector2(x, y)

    vecs = [
        ztxy,
        ztxy.sub_v(Vector2(n, 0)),
        ztxy.sub_v(Vector2(0, m)),
        ztxy.sub_v(Vector2(n, m))
    ]

    angles = [
        vecs[0].get_angle(Ox),
        vecs[1].get_angle(Ox.negate()),
        vecs[2].get_angle(Ox),
        vecs[3].get_angle(Ox.negate())
    ]

    dangles = [
        scalar_dif(angles[0], diag_ang),
        scalar_dif(angles[1], diag_ang),
        scalar_dif(angles[2], diag_ang),
        scalar_dif(angles[3], diag_ang)
    ]
    ang = angles[dangles.index(min(dangles))]
    da = m if diag_ang == Oy.get_angle(diagonal) else n
    if ang < diag_ang:
        min_diff = m*n-math.tan(ang)*da**2
    else:
        min_diff = m*n-1/math.tan(ang)*da**2
    print(round(min_diff, 3))