def calculate_min_difference(n, m, x, y):
    # Общая площадь пирога
    total_area = n * m
    
    # Разрез из (0, 0)
    area1 = 0.5 * x * y
    area2 = total_area - area1
    diff1 = abs(area1 - area2)
    
    # Разрез из (0, m)
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    diff2 = abs(area1 - area2)
    
    # Разрез из (n, 0)
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    diff3 = abs(area1 - area2)
    
    # Разрез из (n, m)
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    diff4 = abs(area1 - area2)
    
    # Возвращаем минимальную разницу
    return min(diff1, diff2, diff3, diff4)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
min_difference = calculate_min_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{min_difference:.3f}")
