def calculate_area(x1, y1, x2, y2, x3, y3):
    return 0.5 * abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))

def find_min_difference(n, m, x, y):
    total_area = n * m
    min_difference = total_area

    area1 = calculate_area(0, 0, x, y, n, 0)
    area2 = total_area - area1
    min_difference = min(min_difference, abs(area1 - area2))

    area1 = calculate_area(0, m, x, y, 0, 0)
    area2 = total_area - area1
    min_difference = min(min_difference, abs(area1 - area2))

    area1 = calculate_area(n, 0, x, y, n, m)
    area2 = total_area - area1
    min_difference = min(min_difference, abs(area1 - area2))

    area1 = calculate_area(n, m, x, y, 0, m)
    area2 = total_area - area1
    min_difference = min(min_difference, abs(area1 - area2))

    return min_difference

n, m = map(int, input().split())
x, y = map(int, input().split())

min_diff = find_min_difference(n, m, x, y)
print(f"{min_diff:.3f}")