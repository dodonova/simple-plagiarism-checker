def calculate_area(x1, y1, x2, y2):
    return abs((x2 - x1) * (y2 - y1))

def min_difference(n, m, x, y):
    areas = []
    
    # Разрез через (0, 0)
    area1 = calculate_area(0, 0, x, y)
    area2 = calculate_area(x, y, n, m)
    areas.append(abs(area1 - area2))
    
    # Разрез через (n, 0)
    area1 = calculate_area(n, 0, x, y)
    area2 = calculate_area(0, y, n, m)
    areas.append(abs(area1 - area2))
    
    # Разрез через (0, m)
    area1 = calculate_area(0, m, x, y)
    area2 = calculate_area(0, 0, n, m)
    areas.append(abs(area1 - area2))
    
    # Разрез через (n, m)
    area1 = calculate_area(n, m, x, y)
    area2 = calculate_area(0, 0, n, m)
    areas.append(abs(area1 - area2))
    
    return min(areas)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата с точностью 3 знака после запятой
print(f"{result:.3f}")