plosh=nm 
    plohtre=0.5*x*y 
    otherplosh=0.5*(n-x)*(m-y) 
    min_raz=abs(plohtre-otherplosh) 
    diagonal=0.5*n*min_raz 
    min_dif=min(min_dif,abs(diagonal-(plosh-diagonal))) 
    return min_dif 

n, m =map(int, input().split()) 
x, y =map(int, input().split()) 
min_dif = min_defference(n,m,x,y) 
print(f"{min_dif:.3f}")
