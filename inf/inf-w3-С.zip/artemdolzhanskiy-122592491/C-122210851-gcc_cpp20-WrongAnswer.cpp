#include <iostream>
#include <iomanip>
#include <cmath>


using namespace std;

int main() {
    long double n, m, x, y;
    cin >> n >> m >> x >> y;

    long double tga1 = y / x;
    long double tga2 = (m - y) / x;
    long double tga3 = (n - x) / (m - y);
    long double tga4 = (n - x) / y;

    long double d1 = 10e9, d2 = 10e9, d3 = 10e9, d4 = 10e9;

    if (tga1 <= 1) {
        d1 = fabs(n * m - tga1 * n * n);
    }else {
        tga1 = 1 / tga1;
        d1 = fabs(n * m - tga1 * m * m);
    }
    if (tga2 <= 1) {
        d2 = fabs(n * m - tga2 * n * n);
    }
    else {
        tga2 = 1 / tga2;
        d2 = fabs(n * m - tga2 * m * m);
    }
    if (tga3 <= 1) {
        d3 = fabs(n * m - tga3 * m * m);
    }
    else {
        tga3 = 1 / tga3;
        d3 = fabs(n * m - tga3 * n * n);
    }
    if (tga4 <= 1) {
        d4 = fabs(n * m - tga4 * m * m);
    }
    else {
        tga4 = 1 / tga4;
        d4 = fabs(n * m - tga4 * n * n);
    }

    cout << fixed << setprecision(3) << fmin(d1, fmin(d2, min(d3, d4)));


    return 0;
}