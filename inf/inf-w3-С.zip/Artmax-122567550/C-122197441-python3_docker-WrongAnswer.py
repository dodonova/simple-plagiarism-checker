n, m = map(int, input().split())
x, y = map(int, input().split())

min_delta = 10**9

k1 = y/x
if k1 * n > m:
    s1_1 = m * (m / k1)
else:
    s1_1 = ((k1 * n) * n) / 2
s1_2 = n * m - s1_1

min_delta = min(min_delta, abs(s1_1 - s1_2))


k2 = ((m - y) / x)
if (k2 * n) > m:
    s2_1 = m * (m / k1)
else:
    s2_1 = ((k2 * n) * n) / 2
s2_2 = n * m - s2_1

min_delta = min(min_delta, abs(s2_1 - s2_2))


k3 = (n - x) / (m - y)
if (k3 * m) > n:
    s3_1 = n * (n / k3)
else:
    s3_1 = ((k3 * m) * m) / 2
s3_2 = n * m - s3_1

min_delta = min(min_delta, abs(s3_1 - s3_2))


k4 = (n - x) / y
if (k4 * m) > n:
    s4_1 = n * (n / k4)
s4_1 = ((k4 * m) * m) / 2
s4_2 = n * m - s4_1

min_delta = min(min_delta, abs(s4_1 - s4_2))

print(round(min_delta, 3))