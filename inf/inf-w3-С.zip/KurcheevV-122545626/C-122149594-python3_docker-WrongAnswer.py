def calculate_area(x1, y1, x2, y2):
    return abs((x2 - x1) * (y2 - y1))

def main():
    n, m = map(int, input().strip().split())
    x, y = map(int, input().strip().split())
    areas = []
    areas.append(calculate_area(0, 0, x, y))
    areas.append(calculate_area(x, 0, n, y))
    areas.append(calculate_area(0, y, x, m))
    areas.append(calculate_area(x, y, n, m))
    areas.sort()
    min_diff = areas[-1] - areas[0]
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()
