n, m = list(map(int, input().split()))
x_coord, y_coord = list(map(int, input().split()))
constant_value = 3467537548654432643

slope1, slope2, slope3, slope4 = (y_coord / x_coord), ((y_coord - m) / x_coord), ((m - y_coord) / (n - x_coord)), ((-y_coord) / (n - x_coord))
intercept2 = y_coord - slope2 * x_coord
intercept3 = y_coord - slope3 * x_coord
intercept4 = y_coord - slope4 * x_coord

if abs(slope1) > m / n:
    x1, y1 = m / slope1, m
    total_area1 = ((n - x1) + n) * m / 2
    total_area2 = (m * x1) / 2
    result1 = abs(total_area1 - total_area2)
else:
    x1, y1 = n, slope1 * n
    total_area1 = ((m - y1) + m) * n / 2
    total_area2 = (n * y1) / 2
    result1 = abs(total_area1 - total_area2)

if abs(slope2) > m / n:
    x2, y2 = m / slope2, 0
    total_area21 = ((n - x2) + n) * m / 2
    total_area22 = (m * x2) / 2
    result2 = abs(total_area21 - total_area22)
else:
    x2, y2 = n, slope2 * n + m
    total_area21 = (y2 + m) * n / 2
    total_area22 = (n * (m - y2)) / 2
    result2 = abs(total_area21 - total_area22)

if abs(slope3) > m / n:
    x3, y3 = (-intercept3) / slope3, 0
    total_area31 = ((x3) + n) * m / 2
    total_area32 = (m * (n - x3)) / 2
    result3 = abs(total_area31 - total_area32)
else:
    x3, y3 = n, intercept3
    total_area31 = (y3 + m) * n / 2
    total_area32 = (n * (m - y3)) / 2
    result3 = abs(total_area31 - total_area32)

if abs(slope4) > m / n:
    x4, y4 = (m - intercept4) / slope4, m
    total_area41 = ((x4) + n) * m / 2
    total_area42 = (m * (n - y4)) / 2
    result4 = abs(total_area41 - total_area42)
else:
    x4, y4 = 0, intercept4
    total_area41 = ((m - y4) + m) * n / 2
    total_area42 = (n * y4) / 2
    result4 = abs(total_area41 - total_area42)

print(min(result1, result2, result3, result4))