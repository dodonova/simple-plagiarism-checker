x1, y1 = [float(i) for i in input().split()]
x2, y2 = [float(i) for i in input().split()]
B = x1 * y1
a = B

# 0 y1
k = (y1 - y2) / (0 - x2)
b = y2 - k * x2
x3 = (0 - b) / k
y3 =  k * x1 + b
if x3 <= x1:
    a = min(a, (x1 - x3) * y1)
else:
    a = min(a, x1 * y3)

# x1 0
k = (0 - y2) / (x1 - x2)
b = y2 - k * x2
x3 = (y1 - b) / k
y3 = b
if x3 >= 0:
    a = min(a, x3 * y1)
else:
    a = min(a, x1 * (y1 - y3))

# x1 y1
k = (y1 - y2) / (x1 - x2)
b = y2 - k * x2
x3 = - (b / k)
y3 = b

if x3 >= 0:
    a = min(a, x3 * y1)
else:
    a = min(a, x1 * y3)

# 0 0
k = (0 - y2) / (0 - x2)
b = y2 - k * x2
x3 = (y1 - b) / k
y3 =  k * x1 + b
if x3 <= x1:
    a = min(a, (x1 - x3) * y1)
else:
    a = min(a, x1 * (y1 - y3))

print('%.3f' % a)