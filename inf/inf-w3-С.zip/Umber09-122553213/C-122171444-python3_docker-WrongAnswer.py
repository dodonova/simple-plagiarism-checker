def rectangle_area(a, b):
    return a * b

def area_difference(a1, a2):
    return abs(a1 - a2)

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    n, m = int(data[0]), int(data[1])
    x, y = int(data[2]), int(data[3])

    # Вершины пирога
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    min_diff = float('inf')

    for corner in corners:
        cx, cy = corner
        
        # Площадь левой и правой части относительно линии разреза
        if cx == 0 and cy == 0:  # угол (0, 0)
            area1 = rectangle_area(x, y)  # Площадь 1 (изначально в (0,0))
            area2 = rectangle_area(n - x, m - y)  # Площадь 2 (остальная часть)
        
        elif cx == n and cy == 0:  # угол (n, 0)
            area1 = rectangle_area(n - x, y)  # Площадь 1
            area2 = rectangle_area(x, m - y)  # Площадь 2
        
        elif cx == 0 and cy == m:  # угол (0, m)
            area1 = rectangle_area(x, m - y)  # Площадь 1
            area2 = rectangle_area(n - x, y)  # Площадь 2
        
        elif cx == n and cy == m:  # угол (n, m)
            area1 = rectangle_area(n - x, m - y)  # Площадь 1
            area2 = rectangle_area(x, y)  # Площадь 2
            
        # Обновление минимальной разницы
        current_diff = area_difference(area1, area2)
        min_diff = min(min_diff, current_diff)

    print(f"{min_diff:.10f}")

if __name__ == "__main__":
    main()