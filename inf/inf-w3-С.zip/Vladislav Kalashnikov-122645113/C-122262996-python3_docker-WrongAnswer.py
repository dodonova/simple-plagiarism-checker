def calculate_difference(n, m, x, y):
    
    total_area = n * m
    
    
    corners = [(0, 0), (0, m), (n, m), (n, 0)]
    
    min_difference = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
       
        area1 = 0.5 * abs(cx * y + x * cy + n * m - (cy * n + m * cx + y * 0))
        area2 = total_area - area1
        
       
        difference = abs(area1 - area2)
        
 
        min_difference = min(min_difference, difference)
    
    return min_difference


n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())


result = calculate_difference(n, m, x, y)
print(f"{result:.3f}")