import sys
import math
def main():
    n, m = map(float, sys.stdin.readline().split())
    x, y = map(float, sys.stdin.readline().split())
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    edges = [n, m, 0, 0]  
    min_D = float('inf')
    for x_Ci, y_Ci in corners:
        x_diff = x - x_Ci
        y_diff = y - y_Ci
        t_list = []
        if x_diff != 0:
            if x_Ci == 0:
                t_x = n / x_diff
            else:
                t_x = -x_Ci / x_diff
            if t_x > 0:
                t_list.append(t_x)
        if y_diff != 0:
            if y_Ci == 0:
                t_y = m / y_diff
            else:
                t_y = -y_Ci / y_diff
            if t_y > 0:
                t_list.append(t_y)
        if not t_list:
            continue
        x_Pj = x_Ci + x_diff * t
        y_Pj = y_Ci + y_diff * t
        if x_Pj == x_Ci:
            S1 = 0.5 * abs(y_Pj - y_Ci) * (x_Ci + x)
        elif y_Pj == y_Ci:
            S1 = 0.5 * abs(x_Pj - x_Ci) * (y_Ci + y)
        else:
            S1 = 0.5 * abs((x_Ci * y_Pj - x_Pj * y_Ci) + (x_Pj * y - x * y_Pj) + (x * y_Ci - x_Ci * y))
        D = abs(n * m - 2 * S1)
        if D < min_D:
            min_D = D
    print("{0:.3f}".format(min_D))
if __name__ == "__main__":
    main()