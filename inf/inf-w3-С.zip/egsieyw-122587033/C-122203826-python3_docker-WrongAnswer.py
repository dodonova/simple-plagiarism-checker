n, m = map(int, input().split())
x, y = map(int, input().split())

s1 = abs(x * m - y * n) / 2
s2 = n * m / 2 - s1

min_diff = abs(s1 - s2)

print(f"{min_diff:.3f}")