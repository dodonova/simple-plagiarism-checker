n, m = map(int, input().split())
x, y = map(int, input().split())

s1 = 0.5 * x * y 
s2 = 0.5 * (n - x) * y 
s3 = 0.5 * (n - x) * (m - y) 
s4 = 0.5 * x * (m - y)

razn = min(
    abs((s1 + s2) - (s3 + s4)),
    abs((s1 + s4) - (s2 + s3)) 
)

print("{:.3f}".format(razn))