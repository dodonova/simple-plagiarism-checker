n, m = map(float, input().split())
x, y = map(float, input().split())
s = n * m
s1 = n * (y * n / x) / 2
s2 = m * (m * (n - x) / y) / 2
s3 = m * (m * (n - x) / (m - y)) / 2
s4 = n * ((m - y) * n / x) / 2
print(min(s-2*s1,s-2*s2,s-2*s3,s-2*s4))