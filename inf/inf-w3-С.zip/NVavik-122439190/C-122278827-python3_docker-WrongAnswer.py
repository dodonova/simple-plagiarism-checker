def calculate_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Функция для вычисления площадей кусков и разницы
    def area_diff(a1, a2):
        return abs(a1 - a2)

    min_diff = float('inf')

    # Разрез из (0, 0)
    area1 = (x * y) / 2  # верхний треугольник
    area2 = total_area - area1
    min_diff = min(min_diff, area_diff(area1, area2))

    # Разрез из (0, m)
    area1 = (x * (m - y)) / 2  # нижний треугольник
    area2 = total_area - area1
    min_diff = min(min_diff, area_diff(area1, area2))

    # Разрез из (n, 0)
    area1 = ((n - x) * y) / 2  # верхний треугольник
    area2 = total_area - area1
    min_diff = min(min_diff, area_diff(area1, area2))

    # Разрез из (n, m)
    area1 = ((n - x) * (m - y)) / 2  # нижний треугольник
    area2 = total_area - area1
    min_diff = min(min_diff, area_diff(area1, area2))

    return min_diff

# Считывание входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление и вывод результата
result = calculate_difference(n, m, x, y)
print(f"{result:.3f}")
