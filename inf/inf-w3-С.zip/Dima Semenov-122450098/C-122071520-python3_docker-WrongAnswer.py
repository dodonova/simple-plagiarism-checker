def min_difference(n, m, x, y):
    total_area = n * m
    
    areas = []
    
    area1 = 0.5 * x * y
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    area1 = 0.5 * (n - x) * y
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    area1 = 0.5 * x * (m - y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    area1 = 0.5 * (n - x) * (m - y)
    area2 = total_area - area1
    areas.append(abs(area1 - area2))
    
    return min(areas)

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_difference(n, m, x, y)
print(f"{result:.3f}")