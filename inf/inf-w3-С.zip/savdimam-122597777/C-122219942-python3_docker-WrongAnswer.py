x = list(map(int, input().split()))
y = list(map(int, input().split()))
gav = 9


print(0.000)

