n, m = map(int, input().split())
x, y = map(int, input().split())
ED = (m-y)*(n-x)/x
S1 = (n-x)*(m-y) + (n-x)*ED/2+x*(m-y)/2
S2 = n*m - S1
print(S2-S1)