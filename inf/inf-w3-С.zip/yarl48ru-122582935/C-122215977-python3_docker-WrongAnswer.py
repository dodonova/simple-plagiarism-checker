n, m = map(int, input().split())
x, y = map(int, input().split())
if n - x < x / 2:
    if m - y < y / 2:
        cx, cy = 0, 0
        ED = x*(m-y)/n-x
        S1 = (x)*(m-y) + (x)*ED/2+(n-x)*(m-y)/2
        S2 = n*m - S1
        print(abs(S2-S1))
    else:
        cx, cy = 0, int(y)
        ED = (m-y)*(n-x)/x
        S1 = (n-x)*(m-y) + (n-x)*ED/2+x*(m-y)/2
        S2 = n*m - S1
        print(abs(S2-S1))
else:
    if m - y > y / 2:
        cx, cy = int(x), int(y)
        ED = (y)*(n-x)/x
        S1 = (n-x)*(y) + (n-x)*ED/2+x*(y)/2
        S2 = n*m - S1
        print(abs(S2-S1))
    else:
        cx, cy = int(x), 0
        ED = x*(y)/n-x
        S1 = (x)*(y) + (x)*ED/2+(n-x)*(y)/2
        S2 = n*m - S1
        print(abs(S2-S1))
