import sys

# Чтение входных данных
n, m = map(int, sys.stdin.readline().split(" "))
x, y = map(int, sys.stdin.readline().split(" "))
# Инициализация минимальной разницы
min_difference = float('inf')
# Полная площадь пирога
full_area = n * m
#перенесем точку (x, y) в правый верхний прямоугольник
if x < n/2:
    x = x + (n/2 - x) * 2
if y < m/2:
    y = y + (m/2 - y) * 2
#print(x, y)
x1 = (x * m) / y
y1 = (n * y) / x
#print(x1, y1)
if x1 <= n:
    answer = full_area - (m * x1)

if y1 <= m:
    answer = full_area - (n * y1)

sys.stdout.write(str(answer))