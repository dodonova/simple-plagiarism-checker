n, m = map(int, input().split())
x, y = map(int, input().split())

area = n *m

min_diff = float('inf')
for i in range(4):
    if i == 0:
        triangle_area = 0.5* x * y
        quadrilateral_area = area - triangle_area
    elif i == 1:
        triangle_area = 0.5 *(n - x)* y
        quadrilateral_area = area - triangle_area
    elif i == 2:
        triangle_area = 0.5*x*(m - y)
        quadrilateral_area = area - triangle_area
    else:
        triangle_area = 0.5*(n - x)*(m - y)
        quadrilateral_area = area - triangle_area
    diff = abs(triangle_area - quadrilateral_area)
    if diff < min_diff:
        min_diff = diff
print(f"{min_diff:.3f}")