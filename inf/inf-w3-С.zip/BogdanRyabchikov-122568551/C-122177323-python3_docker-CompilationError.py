def min_difference(a, b, c, d):

    total_area = a * b

    triangle_area = (c * d) / 2

    piece1_area = triangle_area
    piece2_area = total_area - triangle_area
    
    return abs(piece1_area - piece2_area)

def main():

    length = 10  
    width = 5  
    candle_x = 3  
    candle_y = 2  
    
    difference = min_difference(length, width, candle_x, candle_y)
    
    print(f"The minimum difference between the two pieces is: {difference}")

if __name__ == "__main__":
    main()
                    area2 = total_area - area1
                    difference = abs(area1 - area2)
                    min_difference = min(min_difference, difference)

            elif corner_y == b:  
                x_intercept = (candle_x - corner_x) / k + corner_x
                if 0 <= x_intercept <= a:
                    area1 = 0.5 * (a - x_intercept) * b
                    area2 = total_area - area1
                    difference = abs(area1 - area2)
                    min_difference = min(min_difference, difference)

    return min_difference

# Пример использования:
a = 10  # Длина пирога
b = 5   # Ширина пирога
candle_x = 4   # X координата свечки
candle_y = 3   # Y координата свечки

result = calculate_area_difference(a, b, candle_x, candle_y)
print(f"Минимальная разница между кусками: {result}")