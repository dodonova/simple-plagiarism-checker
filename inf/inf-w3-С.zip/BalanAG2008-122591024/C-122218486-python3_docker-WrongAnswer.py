n, m = list(map(int, input().split()))
x, y =list(map(int, input().split()))
a1=y/x
a2=(y-m)/x
a3=(m-y)/(n-x)
a4=(-y)/(n-x)
b2 = y-a2*x
b3 = y-a3*x
b4 = y - a4*x
if abs(a1) > m/n:
    x1, y1 = m/a1, m
    s1 = ((n-x1) + (n)) * m / 2
    s2 = (m * x1) / 2
    r = abs(s1 - s2)
else:
    x1, y1 = n, a1*n
    s1 = ((m-y1)+(m))*n/2
    s2 = (n*y1)/2
    r = abs(s1-s2)


if abs(a2) > m/n:
    x2, y2 = (m)/a2, 0
    s3 = ((n-x2) + (n)) * m / 2
    s4 = (m * x2) / 2
    r1 = abs(s3 - s4)

else:
    x2, y2 = n, a2*n+m
    s3 = ((y2) + (m)) * n / 2
    s4 = (n * (m-y2)) / 2
    r1 = abs(s3 - s4)


if abs(a3) > m/n:
    x3, y3 = (-b3)/a3, 0
    s5 = ((x3) + (n)) * m / 2
    s6 = (m * (n-x3)) / 2
    r2 = abs(s5 - s6)

else:
    x3, y3 = n, b3
    s5 = ((y3) + (m)) * n / 2
    s6 = (n * (m-y3)) / 2
    r2 = abs(s5 - s6)

if abs(a4) > m/n:
    x4, y4 = (m-b4)/a4, m
    s7 = ((x4) + (n)) * m / 2
    s8 = (m * (n-y4)) / 2
    r3 = abs(s7 - s8)

else:
    x4, y4 = 0, b4
    s7 = ((m - y4) + (m)) * n / 2
    s8 = (n * y4) / 2
    r3 = abs(s7 - s8)
z = min(r,r1,r2,r3)
print(f"{z:.3f}")