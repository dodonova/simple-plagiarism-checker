import java.util.Scanner;

public class Main {

    public static double[] calculateLineParameters(int[] p1, int[] p2) {
        double x1 = p1[0], y1 = p1[1];
        double x2 = p2[0], y2 = p2[1];
        double k = (y2 - y1) / (x2 - x1);
        double b = y1 - k * x1;
        return new double[]{k, b};
    }

    public static double computeMinArea(int n, int m, int x, int y) {
        double totalArea = n * m;
        int[] t = {x, y};

        int[][] corners = {{0, 0}, {0, m}, {n, m}, {n, 0}};
        double[] velocities = new double[corners.length];

        for (int i = 0; i < corners.length; i++) {
            double[] params = calculateLineParameters(corners[i], t);
            double k = params[0];
            double b = params[1];

            double v0;
            if (k != 0) {
                v0 = (corners[i][1] == 0) ?
                    (m - (k * n + b)) * n / 2 :
                    (n - (m - b) / k) * m / 2;
            } else {
                v0 = (n * m) / 2;
            }
            velocities[i] = v0;
        }

        double minVelocity = Double.MAX_VALUE;
        for (double v : velocities) {
            minVelocity = Math.min(minVelocity, totalArea - 2 * v);
        }

        return minVelocity;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int x = scanner.nextInt();
        int y = scanner.nextInt();

        double result = computeMinArea(n, m, x, y);
        System.out.printf("%.3f%n", result);
        
        scanner.close();
    }
}

