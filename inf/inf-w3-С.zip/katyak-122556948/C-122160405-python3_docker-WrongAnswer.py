def min_difference(n, m, x, y):
    # Рассчитываем площади для каждого из разрезов
    areas = []

    # Разрез от (0, 0) до (x, y)
    area1 = x * y
    area2 = n * m - area1
    areas.append(abs(area1 - area2))

    # Разрез от (0, m) до (x, y)
    area1 = (m - y) * x
    area2 = n * m - area1
    areas.append(abs(area1 - area2))
    
    # Разрез от (n, 0) до (x, y)
    area1 = (n - x) * y
    area2 = n * m - area1
    areas.append(abs(area1 - area2))

    # Разрез от (n, m) до (x, y)
    area1 = (m - y) * (n - x)
    area2 = n * m - area1
    areas.append(abs(area1 - area2))

    # Вернем минимальную разницу
    return min(areas)

# Считывание входных данных
import sys

input_data = sys.stdin.read().splitlines()
n, m = map(int, input_data[0].split())
x, y = map(int, input_data[1].split())

# Вывод результата с заданной точностью
result = min_difference(n, m, x, y)
print(f"{result:.3f}")
