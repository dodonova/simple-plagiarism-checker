def area_diff(n, m, x, y):
    # Функция для вычисления площади треугольника по координатам трех точек
    def triangle_area(x1, y1, x2, y2, x3, y3):
        return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2
    
    # Площадь всего пирога
    total_area = n * m
    
    # Рассчитаем площади двух частей для каждого из углов
    # 1. Левый нижний угол (0, 0)
    area1 = triangle_area(0, 0, x, y, n, 0)
    diff1 = abs(total_area - 2 * area1)
    
    # 2. Левый верхний угол (0, m)
    area2 = triangle_area(0, m, x, y, 0, 0)
    diff2 = abs(total_area - 2 * area2)
    
    # 3. Правый нижний угол (n, 0)
    area3 = triangle_area(n, 0, x, y, n, m)
    diff3 = abs(total_area - 2 * area3)
    
    # 4. Правый верхний угол (n, m)
    area4 = triangle_area(n, m, x, y, 0, m)
    diff4 = abs(total_area - 2 * area4)
    
    # Найдём минимальную разницу
    return min(diff1, diff2, diff3, diff4)

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = area_diff(n, m, x, y)

# Вывод результата с точностью до трех знаков
print(f"{result:.3f}")
