#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>

typedef long double ld;
using namespace std;


int main() {
    ld n, m, x, y;
    cin >> n >> m >> x >> y;

    ld tga1 = y / x;
    ld tga2 = (m - y) / x;
    ld tga3 = (n - x) / (m - y);
    ld tga4 = (n - x) / y;

    ld diff1 = 10e9, diff2 = 10e9, diff3 = 10e9, diff4 = 10e9;

    if (tga1 <= 1) {
        ld h1 = tga1 * n;
        diff1 = fabs(n * m - h1 * n);
    }else {
        tga1 = 1 / tga1;
        ld h1 = tga1 * m;
        diff1 = fabs(n * m - h1 * m);
    }
    if (tga2 <= 1) {
        ld h2 = tga2 * n;
        diff2 = fabs(n * m - h2 * n);
    }
    else {
        tga2 = 1 / tga2;
        ld h2 = tga2 * m;
        diff2 = fabs(n * m - h2 * m);
    }
    if (tga3 <= 1) {
        ld h3 = tga3 * m;
        diff3 = fabs(n * m - h3 * m);
    }
    else {
        tga3 = 1 / tga3;
        ld h3 = tga3 * n;
        diff3 = fabs(n * m - h3 * n);
    }
    if (tga4 <= 1) {
        ld h4 = tga4 * m;
        diff4 = fabs(n * m - h4 * m);
    }
    else {
        tga4 = 1 / tga4;
        ld h4 = tga4 * n;
        diff4 = fabs(n * m - h4 * n);
    }
    cout << fixed << setprecision(3) << fmin(diff1, fmin(diff2, min(diff3, diff4)));
    return 0;
}
