n, m = map(int, input().split())
x, y = map(int, input().split())
ans = []


def lin(coor1, coor2):
    k = (coor1[1] - coor2[1])/(coor1[0] - coor2[0])
    b = coor1[1] - coor1[0] * k
    
    return (k, b)
    

def area(kef, x):
    return (kef[0] * x**2)/2 + kef[1] * x
    

s = n * m

a = area(lin((0, 0), (x, y)), n)
ans.append(((s - a*2) ** 2) ** (1/2))

a = area(lin((n, 0), (x, y)), n)
ans.append(((s - a*2) ** 2) ** (1/2))

a = area(lin((0, m), (x, y)), n)
ans.append(((s - a*2) ** 2) ** (1/2))

a = area(lin((n, m), (x, y)), n)
ans.append(((s - a*2) ** 2) ** (1/2))

ans = min(ans) * 1000
ans //= 1

print(ans / 1000)
