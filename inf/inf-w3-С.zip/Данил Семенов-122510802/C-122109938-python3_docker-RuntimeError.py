a = int(input())  
b = int(input())  
c = int(input())  
a, b = (reversed(sorted([a, b])))  
x = 1  
y = max([y for y in range(1, b + 1) if x * y + c <= a * b + 1])  
result = x * y  
toggle = True  
 
while x + y:  
    if toggle:  
        x += 1  
        toggle = False  
    else:  
        y -= 1  
    if x > a or y <= 0:  
        break  
    if x * y + c <= a * b + 1:  
        toggle = True  
        if result + c < x * y + c:  
            result = x * y  
 
print(result)