a = list(map(int, input().split()))
b = list(map(int, input().split()))

for x in range(100000000000000):
    if x/10000000000 == (float(a[1]) - float(b[1]) + x) / a[0]:
        print(a[0]* a[1] - 2*(0.5 * x - 0.5 * (a[0] - 1) * (a[1] - b[1]) - (a[1] - b[1])))
        break
