n, m = [int(i) for i in input().split()]
x, y = [int(i) for i in input().split()]
del_s = 10 * 3
k = y / x
x1 = m / k
y1 = k * n
if x1 <= n:
    s1 = abs(0.5 * x1 * n - (n * m - 0.5 * x1 * n))
if y1 <= m:
    s1 = abs(0.5 * n * y1 - (n * m - 0.5 * n * y1))
if s1 < del_s:
    del_s = s1
k1 = (y - m) / x
b1 = m
y1 = k1 * n + b1
x1 = -1 * b1 / k1
if y1 >= 0:
    s1 = abs(0.5 * n * (m - y1) - (n * m - 0.5 * n * (m - y1)))
if x1 <= n:
    s1 = abs(0.5 * m * x1 - (n * m - (0.5 * m * x1)))
if s1 < del_s:
    del_s = s1
k1 = (m - y) / (n - x)
b1 = m - k1 * n
x3 = -1 * b1 / k1
y1 = b1
if x3 >= 0:
    s1 = abs(0.5 * m * (n - x3) - (m * n - (0.5 * m * (n - x3))))
if y1 > 0:
    s1 = abs(0.5 * m * (n - y1) - (m * n - 0.5 * m * (n - y1)))
if s1 < del_s:
    del_s = s1
k1 = (0 - y) / (n - x)
b1 = -1 * k1 * n
x4 = (m - b1) / k1
y1 = b1
if x4 >= 0:
    s1 = abs(0.5 * m * (n - x3) - (n * m - (0.5 * m * (n - x3))))
if y1 <= m:
    s1 = abs(0.5 * n * y1 - (m * n - (0.5 * n * y1)))
if s1 < del_s:
    del_s = s1
print(round(del_s, 3))
