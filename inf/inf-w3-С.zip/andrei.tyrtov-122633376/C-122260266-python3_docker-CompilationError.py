n, m = map(int,input().split())
x, y = map(int,input().split())
s1 = ((m-y)*x):2
s2 = y*x
s3 = (y*(n-x))/2
s = s1 + s2 + s3
s4 = n*m
i = abs(s4-s)
print(i)
