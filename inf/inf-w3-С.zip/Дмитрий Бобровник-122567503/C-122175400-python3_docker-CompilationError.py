a = int(input())

b = int(input())

d = int(b)

if b > 1:

4пробелаb = b**2

4пробелас = (a**2 // b) - 1

4пробелас = c * d

else:

4пробелаb = b**2

4пробелас = (a**2 // b) - 1

print(c)