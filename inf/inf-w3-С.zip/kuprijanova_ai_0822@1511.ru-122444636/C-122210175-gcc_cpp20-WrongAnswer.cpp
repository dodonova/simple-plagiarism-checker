#include <bits/stdc++.h>
using namespace std;

int main()
{
    long long n, m, x, y;
    cin >> n >> m >> x >> y;
    double delta1, delta2, delta3, delta4;
    if(x > y){
        delta1 = n*m - n*n*1.0*y/x;
        delta3 = n*m - m*m*(n - x)*1.0/(m - y);
    }
    else{
        delta1 = n*m - m*m*1.0*x/y;
        delta3 = n*m - n*n*(m - y)*1.0/(n - x);
    }
    if(y < m - x){
        delta4 = n*m - m*m*1.0*x/(m - y);
        delta2 = n*m - n*n*1.0*y/(n - x);
    }
    else{
        delta2 = n*m - m*m*1.0*(n - x)/y;
        delta4 = n*m - n*n*1.0*(m - y)/x;
    }
    cout << min(abs(delta1), min(abs(delta2), min(abs(delta3), abs(delta4))));
    return 0;
}