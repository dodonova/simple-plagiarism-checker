#include <iostream>
using namespace std;


int main()
{
 float m, n, x, y;
 cin >> n >> m >> x >> y;
 float r, r1;
 if (y / x <= m / n) {
  r = n * (m - n * y / x);
 }
 else {
  r = m * (n - m * x / y);
 }

 if (y / (n-x) <= m / n) {
  r1 = n * (m - n * y / (n-x));
 }
 else {
  r1 = m * (n - m * (n-x) / y);
 }
 if (r1 < r)r = r1;
 if ((m - y) /  x <= m / n) {
  r1 = n * (m - n * (m - y) /  x);
 }
 else {
  r1 = m * (n - m * x / (m - y));
 }
 if (r1 < r)r = r1;
 if ((m-y) / (n - x) <= m / n) {
  r1 = n * (m - n * (m-y) / (n - x));
 }
 else {
  r1 = m * (n - m * (n - x) /(m- y));
 }
 if (r1 < r)r = r1;
 cout << r;
}