n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m

# Площадь треугольника, образуемого разрезом
triangle_area = (x * y) / 2

# Площадь другого треугольника
other_triangle_area = total_area - triangle_area

# Минимальная разница в площадях
min_difference = abs(triangle_area - other_triangle_area)

print(f"{min_difference:.3f}")
Ввод
5 4
3 2
Вывод
2.000
