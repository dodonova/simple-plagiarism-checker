# Read dimensions and coordinates
n, m = map(int, input().split())
x_coord, y_coord = map(int, input().split())
constant_q = 3467537548654432643

# Calculate slopes for different lines
slope1 = y_coord / x_coord
slope2 = (y_coord - m) / x_coord
slope3 = (m - y_coord) / (n - x_coord)
slope4 = -y_coord / (n - x_coord)

# Calculate intercepts for lines based on slopes
intercept2 = y_coord - slope2 * x_coord
intercept3 = y_coord - slope3 * x_coord
intercept4 = y_coord - slope4 * x_coord

# Initialize result variables
result1 = result2 = result3 = result4 = float('inf')

# First condition check for slope1
if abs(slope1) > m / n:
    x1, y1 = m / slope1, m
    area1 = ((n - x1) + n) * m / 2
    area2 = (m * x1) / 2
    result1 = abs(area1 - area2)
else:
    x1, y1 = n, slope1 * n
    area1 = ((m - y1) + m) * n / 2
    area2 = (n * y1) / 2
    result1 = abs(area1 - area2)

# Second condition check for slope2
if abs(slope2) > m / n:
    x2, y2 = m / slope2, 0
    area3 = ((n - x2) + n) * m / 2
    area4 = (m * x2) / 2
    result2 = abs(area3 - area4)
else:
    x2, y2 = n, slope2 * n + m
    area3 = (y2 + m) * n / 2
    area4 = (n * (m - y2)) / 2
    result2 = abs(area3 - area4)

# Third condition check for slope3
if abs(slope3) > m / n:
    x3, y3 = -intercept3 / slope3, 0
    area5 = (x3 + n) * m / 2
    area6 = (m * (n - x3)) / 2
    result3 = abs(area5 - area6)
else:
    x3, y3 = n, intercept3
    area5 = (y3 + m) * n / 2
    area6 = (n * (m - y3)) / 2
    result3 = abs(area5 - area6)

# Fourth condition check for slope4
if abs(slope4) > m / n:
    x4, y4 = (m - intercept4) / slope4, m
    area7 = (x4 + n) * m / 2
    area8 = (m * (n - y4)) / 2
    result4 = abs(area7 - area8)
else:
    x4, y4 = 0, intercept4
    area7 = (m - y4 + m) * n / 2
    area8 = (n * y4) / 2
    result4 = abs(area7 - area8)

# Print the minimum result from the calculated areas
print(min(result1, result2, result3, result4))

Найти еще