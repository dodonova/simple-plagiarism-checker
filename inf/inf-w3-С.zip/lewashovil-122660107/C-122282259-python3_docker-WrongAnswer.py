def area_difference(n, m, x, y):
    # Углы: (0, 0), (0, m), (n, 0), (n, m)
    angles = [(0, 0), (0, m), (n, 0), (n, m)]
    total_area = n * m
    min_diff = float('inf')

    for corner in angles:
        cx, cy = corner
        # Формула площади треугольника через координаты углов
        triangle_area = abs(cx * (y - m) + x * (m - cy) + n * (cy - y)) / 2
        other_area = total_area - triangle_area
        
        # Вычисляем разницу площадей
        diff = abs(triangle_area - other_area)
        min_diff = min(min_diff, diff)

    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = area_difference(n, m, x, y)
print(f"{result:.3f}")