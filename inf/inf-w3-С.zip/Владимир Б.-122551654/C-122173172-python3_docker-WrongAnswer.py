def min_difference(n, m, x, y):
    # Функция для расчета площадей после разреза
    def areas_after_cut(x1, y1, x2, y2):
        area1 = abs((x2 - x1) * (y2 - y1))
        area2 = n * m - area1
        return area1, area2
    
    # Разрез через (0, 0)
    area1, area2 = areas_after_cut(0, 0, x, y)
    diff1 = abs(area1 - area2)
    
    # Разрез через (n, 0)
    area1, area2 = areas_after_cut(n, 0, x, y)
    diff2 = abs(area1 - area2)

    # Разрез через (0, m)
    area1, area2 = areas_after_cut(0, m, x, y)
    diff3 = abs(area1 - area2)

    # Разрез через (n, m)
    area1, area2 = areas_after_cut(n, m, x, y)
    diff4 = abs(area1 - area2)

    # Минимальная разница
    return min(diff1, diff2, diff3, diff4)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Вывод результата
print(f"{result:.9f}")
