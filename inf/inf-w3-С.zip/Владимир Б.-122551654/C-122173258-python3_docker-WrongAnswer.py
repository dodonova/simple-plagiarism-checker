def calculate_difference(n, m, x, y):
    # Площадь пирога
    area = n * m
    
    # Список для хранения разниц для всех разрезов
    differences = []

    # Разрез через (0, 0)
    area1 = (x * y) / 2
    area2 = area - area1
    differences.append(abs(area1 - area2))

    # Разрез через (n, 0)
    area1 = ((n - x) * y) / 2
    area2 = area - area1
    differences.append(abs(area1 - area2))

    # Разрез через (n, m)
    area1 = ((n - x) * (m - y)) / 2
    area2 = area - area1
    differences.append(abs(area1 - area2))

    # Разрез через (0, m)
    area1 = (x * (m - y)) / 2
    area2 = area - area1
    differences.append(abs(area1 - area2))

    # Возвращаем минимальную разницу
    return min(differences)

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение результата
result = calculate_difference(n, m, x, y)

# Вывод результата с нужной точностью
print(f"{result:.10f}")