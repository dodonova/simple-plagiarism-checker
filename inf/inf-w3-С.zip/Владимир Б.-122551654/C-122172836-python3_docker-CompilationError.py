def calculate_area_difference(n, m, x, y):
  min_difference = float('inf')

  # Проверяем все 4 угла
  for corner in [(0, 0), (n, 0), (0, m), (n, m)]:
    base1 = abs(y - corner[1])
    height1 = abs(x - corner[0])
    area1 = 0.5  base1  height1

    base2 = abs(n - x - corner[0])
    height2 = abs(m - y - corner[1])
    area2 = 0.5  base2  height2

    difference = abs(area1 - area2)
    min_difference = min(min_difference, difference)

  return min_difference

n, m = map(int, input().split())
x, y = map(int, input().split())

result = calculate_area_difference(n, m, x, y)
print(f"{result:.3f}") 