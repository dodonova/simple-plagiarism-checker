def calculate_area(x1, y1, x2, y2, x3, y3):
    
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0)

def min_difference(n, m, x, y):
    
    
    
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
        
        area1 = calculate_area(cx, cy, x, y, n, m)  
        area2 = total_area - area1  # Оставшаяся площадь
        
        # Разница между кусками
        difference = abs(area1 - area2)
        
        min_diff = min(min_diff, difference)
    
    return min_diff

n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

result = min_difference(n, m, x, y)
print(f"{result:.3f}")