def area(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def min_difference(n, m, x, y):
    areas = []
    total_area = n * m
    triangle_area = area(0, 0, x, y, n, 0)
    smaller_piece = min(triangle_area, total_area - triangle_area)
    areas.append(abs(2 * smaller_piece - total_area))
    
    triangle_area = area(0, m, x, y, 0, 0)
    smaller_piece = min(triangle_area, total_area - triangle_area)
    areas.append(abs(2 * smaller_piece - total_area))
    triangle_area = area(n, 0, x, y, n, m)
    smaller_piece = min(triangle_area, total_area - triangle_area)
    areas.append(abs(2 * smaller_piece - total_area))
    
    triangle_area = area(n, m, x, y, 0, m)
    smaller_piece = min(triangle_area, total_area - triangle_area)
    areas.append(abs(2 * smaller_piece - total_area))
    
    return min(areas)

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_difference(n, m, x, y)
print(f"{result:.3f}")