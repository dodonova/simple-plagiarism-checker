from decimal import Decimal

def area(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def min_difference(n, m, x, y):
    areas = []
    
    area1 = area(0, 0, x, y, n, 0)
    area2 = area(0, 0, x, y, 0, m)
    areas.append(abs(area1 - area2))
    
    area1 = area(0, m, x, y, 0, 0)
    area2 = area(0, m, x, y, n, m)
    areas.append(abs(area1 - area2))
    
    area1 = area(n, 0, x, y, n, m)
    area2 = area(n, 0, x, y, 0, 0)
    areas.append(abs(area1 - area2))
    
    area1 = area(n, m, x, y, 0, m)
    area2 = area(n, m, x, y, n, 0)
    areas.append(abs(area1 - area2))
    
    return Decimal(min(areas))

n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_difference(n, m, x, y)
print(f"{result:.3f}")