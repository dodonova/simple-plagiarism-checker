#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    double n, m, x, y;
    cin >> n >> m >> x >> y;

    double vsyaArea = n * m;
    double minDifference = vsyaArea;

    for (double angle = 0; angle < M_PI; angle += 0.0001) {
        double slope = tan(angle);
        double intercept = y - slope * x;

        double lArea = 0, rArea = 0;

        if (slope > 0) {
            double yAtX0 = slope * 0 + intercept;
            double yAtXn = slope * n + intercept;

            if (yAtX0 >= 0 && yAtX0 <= m) {
                lArea += 0.5 * 0 * yAtX0;
            }
            if (yAtXn >= 0 && yAtXn <= m) {
                lArea += 0.5 * n * yAtXn;
            }
            if (yAtX0 < 0) {
                lArea += 0.5 * n * (m - intercept);
            }
            if (yAtXn > m) {
                lArea += 0.5 * n * (m - intercept);
            }
        } else {
            double yAtX0 = slope * 0 + intercept;
            double yAtXn = slope * n + intercept;

            if (yAtX0 >= 0 && yAtX0 <= m) {
                rArea += 0.5 * 0 * yAtX0;
            }
            if (yAtXn >= 0 && yAtXn <= m) {
                rArea += 0.5 * n * yAtXn;
            }
            if (yAtX0 < 0) {
                rArea += 0.5 * n * (m - intercept);
            }
            if (yAtXn > m) {
                rArea += 0.5 * n * (m - intercept);
            }
        }

        double area1 = lArea;
        double area2 = vsyaArea - lArea;
        double diff = fabs(area1 - area2);
        minDifference = min(minDifference, diff);
    }

    cout << fixed << setprecision(3) << minDifference << endl;
    return 0;
}
