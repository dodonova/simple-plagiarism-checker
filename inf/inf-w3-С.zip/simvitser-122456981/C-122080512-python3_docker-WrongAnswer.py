from math import atan



n, m = map(int, input().split())
x, y = map(int, input().split())
s = n * m

def f(n, m, x, y):
    t = y/x
    xa = atan(y/x)
    ma = atan(m/n)
    #print(xa, ma, xa-ma)
    if xa == ma:
        d1 = 0
    elif xa - ma < 0:
        q = n * t
        s1 = q * n / 2
        s2 = s - s1
        d1 = abs(s1 - s2)
    else:
        q = m * t
        s1 = m * q / 2
        s2 = s - s1
        d1 = abs(s1-s2)
    return d1

d1 = f(n, m, x, y)
d2 = f(n, m, x, m - y)
d3 = f(n, m, n - x, y) * 100000
d4 = f(n, m, n - x, m - y)

print(min(d1, d2, d3, d4))