def calculate_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Варианты углов
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    min_diff = float('inf')

    for (corner_x, corner_y) in corners:
        # Вычисляем площадь треугольника
        area1 = calculate_area(corner_x, corner_y, x, y, corner_x, m if corner_y == 0 else 0)
        area2 = calculate_area(corner_x, corner_y, x, y, n if corner_x == 0 else 0, corner_y)
        
        # Разделяем площадь на две части
        piece1 = area1
        piece2 = total_area - piece1
        
        # Обновляем минимальную разницу
        min_diff = min(min_diff, abs(piece1 - piece2))

    return min_diff

# Чтение входных данных из файла input.txt
with open('input.txt', 'r') as infile:
    n, m = map(int, infile.readline().strip().split())
    x, y = map(int, infile.readline().strip().split())

# Получаем результат
result = min_difference(n, m, x, y)

# Записываем результат в файл output.txt с требуемой точностью
with open('output.txt', 'w') as outfile:
    outfile.write(f"{result:.3f}\n")
