def min_difference(n, m, x, y):
    # Общая площадь пирога
    total_area = n * m
    
    # Углы пирога
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    
    min_diff = float('inf')
    
    for corner in corners:
        cx, cy = corner
        
        # Площадь треугольника, образованного углом и свечкой
        triangle_area = abs(cx * (y - cy) + x * (cy - 0) + 0 * (0 - y)) / 2
        
        # Площадь оставшейся части пирога
        remaining_area = total_area - triangle_area
        
        # Разница между кусками
        larger_piece = max(triangle_area, remaining_area)
        smaller_piece = min(triangle_area, remaining_area)
        
        diff = larger_piece - smaller_piece
        
        # Находим минимальную разницу
        min_diff = min(min_diff, diff)
    
    return min_diff

# Чтение входных данных из файла
with open('input.txt', 'r') as infile:
    n, m = map(int, infile.readline().strip().split())
    x, y = map(int, infile.readline().strip().split())

# Вычисление минимальной разницы
result = min_difference(n, m, x, y)

# Запись результата в файл
with open('output.txt', 'w') as outfile:
    outfile.write(f"{result:.3f}\n")
