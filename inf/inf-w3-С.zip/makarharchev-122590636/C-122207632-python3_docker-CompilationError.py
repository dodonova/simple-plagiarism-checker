m,n = map(int,input.()split())
x,y = map(int,input()split())

a = (m*n)
b = ((x*y)/2)
print(a/b)