n=int(input())
a=input().split(' ')
for i in range(0,len(a)):
    a[i]=int(a[i])
a.sort(reverse=True)
def possibleS(lines):
    l=lines
    t1=[l[0]]
    t2=[]
    s=[]
    i=min(len(l)-1,l[0])
    i1=i+1
    while i>0:
        i-=1
        t2.append(l[i+1])
    s.append(len(t1)*len(t2))
    t1.sort(reverse=True)
    t2.sort(reverse=True)
    done=False
    while done==False:
        t1.append(t2[0])
        t2.pop(0)
        while min(t1)>len(t2):
            t2.append(a[i1])
            i1+=1
        while min(t1)<len(t2):
            t2.pop(len(t2)-1)
            i1-=1
        if len(t1)>min(t2):
            done=True
        else:
            s.append(len(t1)*len(t2))
    return s
print(max(possibleS(a)))