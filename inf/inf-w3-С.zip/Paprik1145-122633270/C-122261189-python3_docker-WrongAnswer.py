n,m = map(int, input().split())
x,y = map(int, input().split())
deltas = []

def linfn(x0,y0,x1,y1):
    k = (y1-y0)/(x1-x0)
    b = y0 - k*x0
    dt = [k,b]
    return dt

def sqrdelta(xa,ya,xb,yb,xc,yc):
    ab = abs(xa-xb) + abs(ya-yb)
    bc = abs(xc-xb) + abs(yc-yb)
    s1 = ab*bc/2
    deltas.append(abs(2*s1 - n*m))

for i in [(0,0),(n,0),(0,m),(n,m)]:
    dt = linfn(i[0],i[1],x,y)
    k = dt[0]
    b = dt[1]
    if 0 <= k * abs(i[0] - n) + b <= m:
        xc = abs(i[0] - n)
        yc = k * abs(i[0] - n) + b
        sqrdelta(i[0],i[1],xc,i[1],xc,yc)
    else:
        xc = abs(i[1] - m)
        yc = k*xc + b
        sqrdelta(i[0],i[1],i[0],yc,xc,yc)

print(round(min(deltas),3))
