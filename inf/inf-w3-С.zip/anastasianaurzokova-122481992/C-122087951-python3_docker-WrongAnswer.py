def compute_area(polygon):
    area = 0
    n = len(polygon)
    for i in range(n):
        x_i, y_i = polygon[i]
        x_next, y_next = polygon[(i+1)%n]
        area += x_i * y_next - x_next * y_i
    return abs(area) / 2

def find_intersections(x0, y0, x1, y1, n, m):
    intersections = []
    dx = x1 - x0
    dy = y1 - y0
    for x_edge in [0, n]:
        if dx != 0:
            t = (x_edge - x0) / dx
            y = y0 + t * dy
            if 0 <= y <= m:
                intersections.append((x_edge, y))
    for y_edge in [0, m]:
        if dy != 0:
            t = (y_edge - y0) / dy
            x = x0 + t * dx
            if 0 <= x <= n:
                intersections.append((x, y_edge))
    intersections = [ (x, y) for (x, y) in intersections if (x, y) != (x0, y0) and (x, y) != (x1, y1) ]
    intersections = list(set(intersections))
    if not intersections:
        return None
    return intersections

def main():
    import sys
    n, m = map(float, sys.stdin.readline().split())
    x, y = map(float, sys.stdin.readline().split())
    total_area = n * m
    min_diff = float(n/m)
    
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    rect_corners = [(0, 0), (n, 0), (n, m), (0, m)]
    for corner in corners:
        x0, y0 = corner
        if (x0 == x and y0 == y):
            continue
        intersections = find_intersections(x0, y0, x, y, n, m)
        if not intersections:
            continue
        for inter_point in intersections:
            polygon = [corner, (x, y), inter_point]
            index_corner = rect_corners.index(corner)
            if inter_point[0] == 0:
                index_inter = 3  
            elif inter_point[0] == n:
                index_inter = 1  
            elif inter_point[1] == 0:
                index_inter = 0  
            elif inter_point[1] == m:
                index_inter = 2  
            else:
                continue
            delta = (index_inter - index_corner) % 4
            if delta == 1 or delta == -3:
                indices = range(index_corner + 1, index_inter + 1)
            else:
                indices = range(index_corner - 1, index_inter - 1, -1)
            for i in indices:
                polygon.append(rect_corners[i % 4])
            area_piece = compute_area(polygon)
            diff = abs(total_area - 2 * area_piece)
            if diff < min_diff:
                min_diff = diff
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()