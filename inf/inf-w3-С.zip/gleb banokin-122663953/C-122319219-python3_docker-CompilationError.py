
def f1(p1, p2):
    (x1, y0) = p1
    (x2, y2) = p2
    k = (y2 - y0) / (x2 - x1)
    b = y0 - k * x1
    return k, b

def f(n, m, x, y):
    area_t = n * m
    t = (x, y)

 
    cs = [(0, 0), (0, m), (n, m), (n, 0)]
    v = []

    for c in cs:
        k, b = f1(c, t)
        if k != 0:
			if c[1] == 0:
            	v_0 = (n - (m - b) / k) * m / 2
			
			else:
				(m - (k * n + b)) * n / 2
        else:
            v_0 = (n * m) / 2  
        v.append(v_0)

    return min(area_t - 2 * v for v in v)


n, m = map(int, input().split())
x, y = map(int, input().split())

r = f(n, m, x, y)
print('{:.3f}'.format(r))