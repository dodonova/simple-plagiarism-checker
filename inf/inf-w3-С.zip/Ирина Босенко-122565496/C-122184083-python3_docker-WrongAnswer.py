def calculate_area_difference(n, m, x, y):
    total_area = n * m

    area1 = x * y
    area2 = (n - x) * y
    area3 = x * (m - y)
    area4 = (n - x) * (m - y)
    differences = [
        abs(area1 - area2),
        abs(area1 - area3),
        abs(area1 - area4),
        abs(area2 - area3),
        abs(area2 - area4),
        abs(area3 - area4)
    ]

    return min(differences)


n, m = map(int, input().split())
x, y = map(int, input().split())

result = calculate_area_difference(n, m, x, y)
print(f"{result:.3f}")