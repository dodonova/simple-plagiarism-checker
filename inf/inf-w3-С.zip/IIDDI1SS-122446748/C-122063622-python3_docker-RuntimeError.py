def min_difference_rectangle_pie(w, h, x, y):
    # Площадь пирога
    total_area = w * h
    
    # Углы пирога
    corners = [(0, 0), (w, 0), (0, h), (w, h)]
    min_diff = float('inf')
    
    # Для каждого угла считаем разницу площадей
    for cx, cy in corners:
        # Площадь части пирога на одной стороне разреза
        part1_area = abs(cx * y - cy * x) / 2 + (cx * h - cy * 0) + (cy * 0)
        part1_area = abs(part1_area)  # Для обработки
        part2_area = total_area - part1_area
        
        # Разница между частями
        diff = abs(part1_area - part2_area)
        min_diff = min(min_diff, diff)

    return min_diff

# Пример использования
if name == "main":
    # Задаем параметры - ширина, высота, координаты свечи
    w = 10  # ширина пирога
    h = 5   # высота пирога
    x = 4   # координата x свечи
    y = 2   # координата y свечи
    
    result = min_difference_rectangle_pie(w, h, x, y)
    print(result)