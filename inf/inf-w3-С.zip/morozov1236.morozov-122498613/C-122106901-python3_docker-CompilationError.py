import sys
import math
def min_difference(n, m, x, y):
  total_area = n * m
  area_1 = (x * y) / 2 
  area_2 = (n * y - x * y) / 2 
  area_3 = (m * x - x * y) / 2 
  area_4 = ((n * m - n * y - m * x + x * y) / 2) 
  min_diff = min(
      abs(area_1 - area_2),
      abs(area_1 - area_3),
      abs(area_1 - area_4),
      abs(area_2 - area_3),
      abs(area_2 - area_4),
      abs(area_3 - area_4)
 )
  return min_diff
n, m = map(int, input().split())
x, y = map(int, input().split())
min_diff = min_difference(n, m, x, y)
print(min_diff