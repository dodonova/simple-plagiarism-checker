def area_of_triangle(x1, y1, x2, y2, x3, y3):
    """Функция для вычисления площади треугольника по координатам его вершин."""
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def min_area_difference(n, m, x, y):
    """Функция для нахождения минимальной разницы площадей двух кусков пирога."""
    # Общая площадь пирога
    total_area = n * m
    
    # Площади двух треугольников для разреза от разных углов
    # Разрез от (0, 0)
    area1 = area_of_triangle(0, 0, n, 0, x, y)
    diff1 = abs(total_area - 2 * area1)
    
    # Разрез от (0, m)
    area2 = area_of_triangle(0, m, n, m, x, y)
    diff2 = abs(total_area - 2 * area2)
    
    # Разрез от (n, 0)
    area3 = area_of_triangle(n, 0, n, m, x, y)
    diff3 = abs(total_area - 2 * area3)
    
    # Разрез от (n, m)
    area4 = area_of_triangle(n, m, 0, m, x, y)
    diff4 = abs(total_area - 2 * area4)
    
    # Возвращаем минимальную разницу
    return min(diff1, diff2, diff3, diff4)

# Чтение данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Решение задачи
result = min_area_difference(n, m, x, y)

# Вывод результата с точностью до 3 знаков
print(f"{result:.6f}")
