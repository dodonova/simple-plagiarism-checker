n, m = map(int, input().split())
x, y = map(int, input().split())

def area_difference(n, m, x, y):
    triangle1 = (x * m) / 2
    rectangle1 = (n * m) - triangle1
    
    triangle2 = ((n - x) * m) / 2
    rectangle2 = (n * m) - triangle2
    
    triangle3 = ((n - x) * y) / 2
    rectangle3 = (n * m) - triangle3
    
    triangle4 = (x * y) / 2
    rectangle4 = (n * m) - triangle4
    
    return min(abs(triangle1 - rectangle1), abs(triangle2 - rectangle2),
               abs(triangle3 - rectangle3), abs(triangle4 - rectangle4))

result = area_difference(n, m, x, y)
print(f"{result:.3f}")
