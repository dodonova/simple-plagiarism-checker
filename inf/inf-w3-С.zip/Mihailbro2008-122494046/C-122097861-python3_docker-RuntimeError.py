x1, y1 = [float(x) for x in input().split()]
x2, y2 = [float(x) for x in input().split()]
s = x1 * y1
a = s

def coords(y=0, x=0):
    global a
    k = (y - y2) / (x / x2)
    
    b = y2 - k * x2
    x3 = (0 - b) /k
    y3 = k * x + b
    if x3 <= x:
        a = min(a, (x-x3) * y1)
    else:
        a = min(a, x * y3)
        
coords(y1, 0)
coords(0, x1)
coords(y1, x1)
coords(0, 0)
print('%.3f' % a)