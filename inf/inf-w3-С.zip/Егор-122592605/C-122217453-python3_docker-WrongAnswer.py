import math

def min_area_difference(n, m, x, y):
    # Случай 1: Свечка на границе
    if x == 0 or y == 0 or x == n - 1 or y == m - 1:
        return 0
    
    # Случай 2: Свечка внутри
    else:
        # Вычисляем площади треугольников
        area_larger = (n * m) / 2
        area_smaller = ((n - x) * (m - y)) / 2
        
        # Вычисляем разницу
        area_difference = abs(area_larger - area_smaller)
        
        return round(area_difference, 3)

# Пример использования
n, m = map(int, input().split())
x, y = map(int, input().split())

result = min_area_difference(n, m, x, y)
print(result)