n, m = map(int, input().split())
x, y = map(int, input().split())
total_area = n * m
area1 = x * m
area2 = (n - x) * m
area3 = y * n
area4 = (m - y) * n
min_diff = abs(max(area1, area2) - min(area1, area2))
min_diff = min(min_diff, abs(max(area3, area4) - min(area3, area4)))
print("{:.3f}".format(min_diff))