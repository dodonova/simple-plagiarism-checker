import sys
import math

input = sys.stdin.read
data = input().split()

n = int(data[0])
m = int(data[1])
x = int(data[2])
y = int(data[3])

# Calculate areas for both cut scenarios
area1 = 0.5 * x * y
area2 = 0.5 * x * (m - y)
area3 = 0.5 * (n - x) * y
area4 = 0.5 * (n - x) * (m - y)

# Find minimum difference in areas
min_diff = min(abs((area1 - area2) - (area3 - area4)),
               abs((area1 - area3) - (area2 - area4)),
               abs((area1 - area4) - (area2 - area3)),
               abs((area2 - area3) - (area1 - area4)),
               abs((area2 - area4) - (area1 - area3)),
               abs((area3 - area4) - (area1 - area2)))

print(min_diff)
