from collections import Counter

def find_words(mixed_string, words):
    target_count = Counter(mixed_string)
    
    valid_words = []  
    for word in words:
        word_count = Counter(word)
        if all(word_count[char] <= target_count[char
                                                if all(word_count[char] <= target_count[char] for char in word_count):
            valid_words.append((word, word_count))  

    valid_words.sort(key=lambda x: len(x[0]))

    def backtrack(start_index, current_combination, current_count):
        if 5 <= len(current_combination) <= 8 and