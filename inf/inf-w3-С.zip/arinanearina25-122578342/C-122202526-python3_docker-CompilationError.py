def min difference(n, m, x, y): 
	total_area=n*m

# Угол (0, 0) 
S1_1=(x*y)/2 
S2_1=total_area-S1_1 
diff1=abs(S1_1-S2-1)

#Yron (n, 0) 
S1_2=((n-x)*y)/2 
S2_2=total_area-S1_2 
diff2=abs(S1_2-S2_2)

#Yron (0, m) 
S1_3=(x*(m-y))/2 
S2_3=total_area-S1_3 
diff3=abs(S1_3-S2_3)

#Yron (n, m) 
S1_4=((n-x)*(m-y))/2 
S2_4=total area-S1_4 
diff4=abs(S1_4-S2_4)

# Найдем минимальную разницу 
min diff= min(diff1, diff2, diff3, diff4)

retum min diff

# Ввод данных 
n, m= map(int, input().split()) 
x, y map(int, input().split())

# Получение результата 
result = min difference(n, m, x, y) 
print("{result: 6f}")