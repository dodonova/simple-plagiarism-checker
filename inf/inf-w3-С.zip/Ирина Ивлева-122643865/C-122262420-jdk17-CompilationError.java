java
import java.util.Scanner;

public class PieDivision {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt(); 
        int m = in.nextInt(); 

        int x1 = in.nextInt();
        int y1 = in.nextInt(); 

        int x2 = in.nextInt(); 
        int y2 = in.nextInt();

        int square1 = (x1 * y1) + ((n - x2) * (m - y2));
        int square2 = (n * m) - square1;

        int a = Math.abs(square1 - square2);
        
        System.out.println(a);
        
        in.close();
    }
}