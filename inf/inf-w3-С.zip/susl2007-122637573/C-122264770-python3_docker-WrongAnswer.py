def xxx(a1, b1, c1, a2, b2, c2):
    return (b1 * c2 - b2 * c1) / (a1 * b2 - a2 * b1)
def yyy(a1, b1, c1, a2, b2, c2):
    return (a2 * c1 - c2 * a1) / (a1 * b2 - a2 * b1)

f = open("input.txt", "r")
string = f.readline()
a, b = map(int, string.split())
string = f.readline()
x, y = map(int, string.split())

mas = [ ]

if y >= b * x / a:
    mas.append(abs((b - y) * a**2 / (a - x) - b * a))
else:
    mas.append(abs((a - x) * b**2 / (b - y) - b * a))

if y >= b * x / a:
    mas.append(abs(x * y * b**2 / y**2 - b * a))
else:
    mas.append(abs(x * y * a**2 / x**2 - b * a))

if y >= (1 - x / a) * b:
    mas.append(abs((b - y) * a**2 / x - b * a))
else:
    mas.append(abs((b - y) * x * b**2 / (b - y)**2 - b * a))

if y >= (1 - x / a) * b:
    mas.append(abs((a - x) * y * b**2 / y**2 - b * a))
else:
    mas.append(abs((a - x) * y * a**2 / x**2 - b * a))


fa = open("output.txt", "w")
fa.write(str(round(min(mas), 3)))