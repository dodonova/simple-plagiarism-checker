#include <bits/stdc++.h>

using ll = double;
using namespace std;

double calculateSlope(double x1, double y1, double x2, double y2) {
    if (x1 == x2) {
        throw invalid_argument("Вертикальная прямая.");
    }
    return (y2 - y1) / (x2 - x1);
}

// Функция для вычисления свободного члена b
double calculateIntercept(double k, double x, double y) {
    return y - k * x;
}

void solve() {
    double n, m, x, y;
    cin >> n >> m >> x >> y;

    double ans = 1e18;

    // Разрез через (0, 0) и (x, y)
    double k1 = calculateSlope(0, 0, x, y);
    double b1 = calculateIntercept(k1, 0, 0);
    double area1 = 0.5 * n * (k1 * n + b1);
    double area2 = n * m - area1;
    ans = min(ans, abs(area1 - area2));

    // Разрез через (n, 0) и (x, y)
    k1 = calculateSlope(n, 0, x, y);
    b1 = calculateIntercept(k1, n, 0);
    area1 = 0.5 * m * ((m - b1) / k1);
    area2 = n * m - area1;
    ans = min(ans, abs(area1 - area2));

    // Разрез через (0, m) и (x, y)
    k1 = calculateSlope(0, m, x, y);
    b1 = calculateIntercept(k1, 0, m);
    area1 = 0.5 * n * (k1 * n + b1);
    area2 = n * m - area1;
    ans = min(ans, abs(area1 - area2));

//    // Разрез через (n, m) и (x, y)
//    k1 = calculateSlope(n, m, x, y);
//    b1 = calculateIntercept(k1, n, m);
//    area1 = 0.5 * m * ((m - b1) / k1);
//    area2 = n * m - area1;
//    ans = min(ans, abs(area1 - area2));

    cout << fixed << setprecision(3) << ans << endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
}
