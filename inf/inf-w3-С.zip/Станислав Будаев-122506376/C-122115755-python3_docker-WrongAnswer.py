def find_min_area_difference(n, m, x, y):
    
    area_left = x * m
    area_right = (n - x) * m
    diff_vertical = abs(area_left - area_right)


    area_bottom = n * y
    area_top = n * (m - y)
    diff_horizontal = abs(area_bottom - area_top)


    min_diff = min(diff_vertical, diff_horizontal)

    return min_diff


n, m = map(int, input().split())
x, y = map(int, input().split())


min_difference = find_min_area_difference(n, m, x, y)


print(f"{min_difference:.6f}")