n, m = map(int, input().split())
x, y = map(int, input().split())

k = y / x * n
ans = abs(n * m - k * n)
k = y / (n - x) * n
ans = min(ans, abs(n * m - k * n))
k = (m - y) / x * n
ans = min(ans, abs(n * m - k * n))
k = (m - y) / (n - x) * n
ans = min(ans, abs(n * m - k * n))
print(round(ans, 3))