n, m = map(int, input().split())
x, y = map(int, input().split())
S = n*m

s1 = S - n*n*y/x;
if(s1<0):
    s1 = S - m*m*x/y;
  
s2 = S - m*m*(n-x)/y;
if(s2<0):
    s2 = S - n*n*y/(n-x);
  
s3 = S - n*n*(m-y)/x;
if(s3<0):
    s3 = S - m*m*x/(m-y);
  
s4 = S - m*m*(n-x)/(m-y)
if(s4<0):
    s4 = S - n*n*(m-y)/(n-x)

print(min(min(min(s1, s2), s3), s4))