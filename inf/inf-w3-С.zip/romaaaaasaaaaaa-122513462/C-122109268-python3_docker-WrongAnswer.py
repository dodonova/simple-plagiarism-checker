def area_difference(n, m, x, y):
    # Функция для вычисления площади треугольника по координатам вершин
    def triangle_area(x1, y1, x2, y2, x3, y3):
        return abs((x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2)) / 2.0)

    # Площади треугольников, образуемых разными углами
    areas = []

    # Диагонали от четырех углов
    areas.append(triangle_area(0, 0, n, 0, x, y))  # угол (0, 0)
    areas.append(triangle_area(0, m, n, m, x, y))  # угол (0, m)
    areas.append(triangle_area(n, 0, n, m, x, y))  # угол (n, 0)
    areas.append(triangle_area(0, 0, 0, m, x, y))  # угол (n, m)

    # Исходная площадь пирога
    total_area = n * m

    # Находим минимальную разницу
    min_difference = float('inf')
    for area in areas:
        piece1 = area
        piece2 = total_area - piece1
        difference = abs(piece1 - piece2)
        min_difference = min(min_difference, difference)

    return min_difference

if __name__ == "__main__":
    n, m = map(int, input().split())
    x, y = map(int, input().split())

    result = area_difference(n, m, x, y)
    print(f"{result:.3f}")  # Вывод результата с точностью 3 знака после запятой