def calculate_area(x1, y1, x2, y2, x3, y3):
    """Вычисление площади треугольника по координатам вершин."""
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2)

def min_area_difference(n, m, x, y):
    """Вычисление минимальной разницы между площадями кусочков пирога."""

    angles = [(0, 0), (n, 0), (0, m), (n, m)]
    min_difference = float('inf')

    for ax, ay in angles:
        # Площади куска, образованного с углом и свечкой
        area1 = calculate_area(ax, ay, x, y, ax, m if ay == 0 else 0)
        area2 = calculate_area(ax, ay, x, y, n if ax == 0 else 0, ay)

        total_area = n * m
        area_remaining = total_area - area1

        # Разница между кусками
        difference = abs(area1 - area_remaining)
        min_difference = min(min_difference, difference)

    return min_difference

# Считывание входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вывод результата с точностью 3 знака после запятой
print(f"{min_area_difference(n, m, x, y):.3f}")