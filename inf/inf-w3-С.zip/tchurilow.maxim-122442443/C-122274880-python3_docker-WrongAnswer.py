def min_difference(n, m, x, y):
    # Объём пирога
    total_area = n * m

    # Площадь кусочков при разрезе через нижние углы
    # Левый нижний угол (0, 0)
    area1 = (x * y)  # Треугольник (0,0), (x,0), (0,y)
    area2 = total_area - area1  # Остальная площадь
    min_diff = abs(area1 - area2)  # Разница между кусками

    # Угол (0, m) - верхний левый
    area1 = (x * (m - y))  # Треугольник (0,m), (x,m), (0,y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))

    # Угол (n, 0) - нижний правый
    area1 = ((n - x) * y)  # Треугольник (n,0), (x,0), (n,y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))

    # Угол (n, m) - верхний правый
    area1 = ((n - x) * (m - y))  # Треугольник (n,m), (x,m), (n,y)
    area2 = total_area - area1
    min_diff = min(min_diff, abs(area1 - area2))

    return min_diff

# Ввод данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вывод минимальной разницы
print(f"{min_difference(n, m, x, y):.3f}")