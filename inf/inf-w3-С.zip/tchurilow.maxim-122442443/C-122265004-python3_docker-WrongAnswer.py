def minimal_area_difference(n, m, x, y):
    # Calculate areas of the four possible pieces
    area1 = x * y
    area2 = (n - x) * y
    area3 = x * (m - y)
    area4 = (n - x) * (m - y)

    # Find the maximum and minimum areas
    max_area = max(area1, area2, area3, area4)
    min_area = min(area1, area2, area3, area4)

    # Calculate the difference
    return max_area - min_area

# Input reading
n, m = map(int, input().split())
x, y = map(int, input().split())

# Output the result
result = minimal_area_difference(n, m, x, y)
print(f"{result:.3f}")
