# Функция для расчета площади двух областей, которые образуются при разрезании пирога
def calculate_areas(n, m, x, y):
    # Площади сегментов, полученных после разрезания
    area1 = 0.5 * x * y  # Треугольник в первой области
    area2 = 0.5 * (n - x) * y  # Треугольник во второй области
    area3 = 0.5 * x * (m - y)  # Треугольник в третьей области
    area4 = 0.5 * (n - x) * (m - y)  # Треугольник в четвёртой области

    return area1, area2, area3, area4

# Функция для вычисления минимальной разницы между площадями кусков
def min_difference(n, m, x, y):
    # Вычисление площадей
    area1, area2, area3, area4 = calculate_areas(n, m, x, y)

    # Находим возможные площади кусков
    areas = [area1 + area3, area2 + area4]  # Куски, которые могут быть
    min_diff = min(abs(areas[0] - areas[1]), abs(areas[1] - areas[0]))

    return min_diff

# Ввод и вывод
n, m = map(int, input().split())
x, y = map(int, input().split())
result = min_difference(n, m, x, y)
print(f"{result:.3f}")  # Форматирование вывода с тремя знаками после запятой