#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace std;

int main() {
	long double n, m, x, y;
	cin >> n >> m >> x >> y;

	long double s = n * m;

	long double s1 = x * y / 2 * (n / x) * (n / x);
	long double y1 = x * m / n;
	long double y2 = (n - x) * m / n;

	if (y > y1) {
		s1 = y * x / 2 * (m / y) * (m / y);
	}

	long double s2 = x * (m - y) / 2 * (n / x) * (n / x);

	if (y < y2) {
		s2 = x * (m - y) / 2 * (m / (m - y)) * (m / (m - y));
	}

	long double s3 = (n - x) * (m - y) / 2 * (m / (m - y)) * (m / (m - y));

	if (y > y1) {
		s3 = (n - x) * (m - y) / 2 * (n / (n - x)) * (n / (n - x));
	}

	long double s4 = y * (n - x) / 2 * (n / (n - x)) * (n / (n - x));

	if (y > y2) {
		s4 = y * (n - x) / 2 *(m / y) * (m / y);
	}

	long double ans = min(abs(s - 2 * s1), abs(s - 2 * s2));
	ans = min(ans, abs(s - 2 * s3));
	ans = min(ans, abs(s - 2 * s4));
	cout << ans;
}