import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner s1 = new Scanner(System.in)) {
            int w = s1.nextInt();
            int h = s1.nextInt();
            int x = s1.nextInt();
            int y = s1.nextInt();
            //*-*
            //| |
            //*-*
            double alpha = h * h * Math.tan(Math.atan2(x, y));
            double beta = h * h * Math.tan(Math.atan2(w-x, y));
            double gamma = h * h * Math.tan(Math.atan2(x, h-y));
            double delta = h * h * Math.tan(Math.atan2(w-x, h-y));
            double epsilon = w * w * Math.tan(Math.atan2(y, x));
            double zeta = w * w * Math.tan(Math.atan2(y, w-x));
            double eta = w * w * Math.tan(Math.atan2(h-y, x));
            double theta = w * w * Math.tan(Math.atan2(h-y, w-x));
            alpha = (alpha / h) > w ? epsilon : alpha;
            beta = (beta / h) > w ? zeta : beta;
            gamma = (gamma / h) > w ? eta : gamma;
            delta = (delta / h) > w ? theta : delta;
            double d = w*h;
            System.out.println(Math.min(Math.min(Math.abs(alpha - d + alpha),
                    Math.abs(beta - d + beta)),
                    Math.min(Math.abs(gamma - d + gamma),
                    Math.abs(delta - d + delta))));
        }
    }
}