import math

n, m = map(int, input().split())
x, y = map(int, input().split())

# 1
z = math.sqrt(x ** 2 + y ** 2)

oa = z * n / x
xa = oa * math.sqrt(oa ** 2 - n ** 2) / oa

tr = (n * xa) / 2
cht = n * (m - xa) + tr
a1 = abs(cht - tr)
# 2
z = math.sqrt(x ** 2 + (m - y) ** 2)

oa = z * n / x
xa = oa * math.sqrt(oa ** 2 - n ** 2) / oa

tr = (n * xa) / 2
cht = n * (m - xa) + tr
a2 = abs(cht - tr)
# 3
z = math.sqrt((n - x) ** 2 + (m - y) ** 2)

oa = z * n / (n - x)
xa = oa * math.sqrt(oa ** 2 - n ** 2) / oa

tr = (n * xa) / 2
cht = n * (m - xa) + tr
a3 = abs(cht - tr)
# 4
z = math.sqrt((n - x) ** 2 + y ** 2)

oa = z * n / (n - x)
xa = oa * math.sqrt(oa ** 2 - n ** 2) / oa

tr = (n * xa) / 2
cht = n * (m - xa) + tr
a4 = abs(cht - tr)

if a1 == a2 == a3 == a4:
    print(0.000)
else:
    print(round(min(a1, a2, a3, a4), 3))