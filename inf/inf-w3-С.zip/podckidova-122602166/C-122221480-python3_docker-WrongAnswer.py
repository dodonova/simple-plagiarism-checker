def min_difference(n, m, x, y):
    total_area = n * m
    
    # Площади для каждого из 4 углов
    areas = []
    
    # Угол (0, 0)
    area1 = 0.5 * x * y
    areas.append((area1, total_area - area1))
    
    # Угол (n, 0)
    area2 = 0.5 * (n - x) * y
    areas.append((area2, total_area - area2))
    
    # Угол (0, m)
    area3 = 0.5 * x * (m - y)
    areas.append((area3, total_area - area3))
    
    # Угол (n, m)
    area4 = 0.5 * (n - x) * (m - y)
    areas.append((area4, total_area - area4))
    
    # Находим минимальную разницу
    min_diff = float('inf')
    for a1, a2 in areas:
        min_diff = min(min_diff, abs(a1 - a2))
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Получаем результат
result = min_difference(n, m, x, y)

# Выводим результат с нужной точностью
print(f"{result:.10f}")