#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n, m;
    std::cin >> n >> m;
    int x, y;
    std::cin >> x >> y;
    int xx = x;
    std::vector<double> res;
    
    if (static_cast<double>(y) / x == static_cast<double>(m) / n) {
        std::cout << 0.000 << std::endl;
    } else {
        double z = static_cast<double>(y) / x;
        if (z * n < m) {
            res.push_back(n * m - 2 * ((z * n * n) / 2));
        } else {
            res.push_back(n * m - 2 * (((m / z) * m) / 2));
        }
        x = n - x;    
        z = static_cast<double>(y) / x;
        if (z * n < m) {
            res.push_back(n * m - 2 * ((z * n * n) / 2));
        } else {
            res.push_back(n * m - 2 * (((m / z) * m) / 2));
        }
        y = m - y;    
        z = static_cast<double>(y) / x;
        if (z * n < m) {
            res.push_back(n * m - 2 * ((z * n * n) / 2));
        } else {
            res.push_back(n * m - 2 * (((m / z) * m) / 2));
        }
        x = xx;
        z = static_cast<double>(y) / x;
        if (z * n < m) {
            res.push_back(n * m - 2 * ((z * n * n) / 2));
        } else {
            res.push_back(n * m - 2 * (((m / z) * m) / 2));
        }
    }
    
    if (!res.empty()) {
        std::cout << *std::min_element(res.begin(), res.end()) << std::endl;
    } else {
        std::cout << "None" << std::endl;
    }
    
    return 0;
}

