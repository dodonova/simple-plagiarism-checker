from collections import Counter, deque
 
s, n = input(), int(input())
word_data = [(w, Counter(w)) for w in (input() for _ in range(n))]
stack = deque([(0, Counter(s), [], 0)])
 
while stack:
    idx, remain, path, depth = stack.pop()
    
    if not remain and 5 <= depth <= 8:
        print(*sorted(path), sep='\n')
        break
    
    if depth > 8 or idx >= n:
        continue

    
    for i in range(n-1, idx-1, -1):
        word, cnt = word_data[i]
        if all(cnt[c] <= remain[c] for c in cnt):
            stack.append((i + 1, remain - cnt, path + [word], depth + 1))