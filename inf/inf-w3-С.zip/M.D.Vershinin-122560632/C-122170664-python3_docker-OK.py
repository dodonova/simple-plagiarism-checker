x_l, y_l = map(int, input().split())
x, y = map(int, input().split())
combs = [(x, y), (x_l - x, y), (x, y_l - y), (x_l - x, y_l - y)]
df = x_l * y_l

for x, y in combs:
    k = y / x
    if x_l * k > y_l:
        x_n = y_l / k
        y_n = y_l
    else:
        x_n = x_l
        y_n = x_n * k
    S = y_n * x_n / 2
    df = min(df, abs(x_l * y_l - 2 * S))
print(round(df, 3))

