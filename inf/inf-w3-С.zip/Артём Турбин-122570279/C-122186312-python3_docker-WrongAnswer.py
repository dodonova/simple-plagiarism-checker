n, m = map(int, input().split())
x, y = map(int, input().split())
S1 = x * y
S2 = (n - x) * y
S3 = x * (m - y)
S4 = (n - x) * (m - y)
areas = [S1, S2, S3, S4]
min_difference = float('inf')
for i in range(len(areas)):
    for j in range(i + 1, len(areas)):
        diff = abs(areas[i] - areas[j])
        if diff < min_difference:
            min_difference = diff
print(f"{min_difference:.3f}")