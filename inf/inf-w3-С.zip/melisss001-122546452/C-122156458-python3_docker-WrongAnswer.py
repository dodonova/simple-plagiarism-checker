n, m = map(int, input().split())
x, y = map(int, input().split())
sa = n * m
sb = (x * y) / 2
sc = sa - sb
dif = abs(sb - sc)
print(f"{dif:.3f}")
