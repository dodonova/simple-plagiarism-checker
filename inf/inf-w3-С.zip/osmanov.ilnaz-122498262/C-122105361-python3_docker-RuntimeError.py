a, b = list(map(int, input().split()))
d, c = list(map(int, input().split()))
def maxi(s):
  l = 0
  if a * s <= b:
      l = a * a * s / 2
      return a * b - 2 * l
  else:
     l = b * b / s / 2
     return a * b - 2 * l
s1 = maxi(d / с)
s2 = maxi((b - c) / d)
s3 = maxi((b - c) / (a - d))
s4 = maxi(c /(a - d))
print("{0:.3f}".format(min(s1, s2, s3, s4)))

      