n, m = map(int, input().split())
x, y = map(int, input().split())

area1 = max(x * m, (n - x) * m)
area2 = max(y * n, (m - y) * n)
result = min(area1, area2) - max(area1, area2) + (n * m)

print(format(abs(result)))
