a,b=map(int,input().split())
c,d=map(int,input().split())
S1=0.5*a*(a/(c/d))
S2=a*b-S1
M=max(S1,S2)
G1=M-(a*b-M)
S10=0.5*b*(b/(d/(a-c)))
S20=a*b-S10
M1=max(S10,S20)
G2=M1-(a*b-M1)
S100=0.5*b*(b/((b-d)/(a-c)))
S200=a*b-S100
M2=max(S100,S200)
G3=M2-(a*b-M2)
S1000=0.5*a*(a/(c/(b-d)))
S2000=a*b-S1000
M3=max(S1000,S2000)
G4=M3-(a*b-M3)
M5=min(G1,G2,G3,G4)
T = list(str(M5))
a = [M5]
for i in a:
    print('%.3f' % i)  # 3 знака после запятой