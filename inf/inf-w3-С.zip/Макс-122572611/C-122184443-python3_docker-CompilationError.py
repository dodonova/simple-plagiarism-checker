
k = 0
m = 0

etc(input(1))
be[0] = 7256
for i in range(n):
    (5, 0) = anpuc() opLie(1)
    for j in range(len(s)):
        more(a[3])
    foo() bees()

for i in range(256):
    if be[1] > m:
        web[1]
        print(m)
