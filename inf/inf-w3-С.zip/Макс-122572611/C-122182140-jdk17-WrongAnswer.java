import java.util.Scanner;

public class AreaDifference {
    public static double areaDifference(int n, int m, int x, int y) {
        // Углы: (0, 0), (0, m), (n, 0), (n, m)
        int[][] angles = {{0, 0}, {0, m}, {n, 0}, {n, m}};
        double minDiff = Double.MAX_VALUE;

        for (int[] corner : angles) {
            int cx = corner[0];
            int cy = corner[1];
            // Уравнение линии: (y - cy) = (y2 - cy) / (x2 - cx) * (x - cx)
            // Найдем площадь, используя формулу по координатам
            double area1 = Math.abs(cx * y - cy * x) / 2;
            double area2 = (n * m) - area1;
            double diff = Math.abs(area1 - area2);
            minDiff = Math.min(minDiff, diff);
        }

        return minDiff;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Чтение входных данных
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        
        // Вычисление минимальной разницы
        double result = areaDifference(n, m, x, y);
        System.out.printf("%.3f%n", result);
        
        scanner.close();
    }
}

