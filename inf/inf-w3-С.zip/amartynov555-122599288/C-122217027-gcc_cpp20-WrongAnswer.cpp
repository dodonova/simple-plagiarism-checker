#include <bits/stdc++.h>

using namespace std;

typedef long double ld;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n,m;
    cin >> n >> m;
    int x,y;
    cin >> x >> y;
    ld ans = n*m;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-ld(n)/x*y));
    }
    else
    {
        ans = min(ans,m * (n-ld(m)/y*x));
    }
    x = n+1-x;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-ld(n)/x*y));
    }
    else
    {
        ans = min(ans,m * (n-ld(m)/y*x));
    }
    y = m+1-y;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-ld(n)/x*y));
    }
    else
    {
        ans = min(ans,m * (n-ld(m)/y*x));
    }
    x = n+1-x;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-ld(n)/x*y));
    }
    else
    {
        ans = min(ans,m * (n-ld(m)/y*x));
    }
    cout << ans;
    return 0;
}
