#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    long double n,m;
    cin >> n >> m;
    long double x,y;
    cin >> x >> y;
    long double ans = n*m;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-n/x*y));
    }
    else
    {
        ans = min(ans,m * (n-m/y*x));
    }
    x = n-x;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-n/x*y));
    }
    else
    {
        ans = min(ans,m * (n-m/y*x));
    }
    y = m-y;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-n/x*y));
    }
    else
    {
        ans = min(ans,m * (n-m/y*x));
    }
    x = n-x;
    if(n*y < m*x)
    {
        ans = min(ans,n * (m-n/x*y));
    }
    else
    {
        ans = min(ans,m * (n-m/y*x));
    }
    cout << ans;
    return 0;
}
