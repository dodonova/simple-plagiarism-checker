n, m = map(int, input().split())
x, y = map(int, input().split())

# Площадь всего пирога
total_area = n * m

# Площадь треугольника, который получит Карлсон
triangle_area = (x * y) / 2

# Площадь второго треугольника
second_triangle_area = total_area - triangle_area

# Разница площадей
difference = abs(triangle_area - second_triangle_area)

print(f"{difference:.3f}")