def calculate_area_difference(n, m, x, y):
    # Функция для вычисления площади треугольника по трем точкам
    def triangle_area(x1, y1, x2, y2, x3, y3):
        return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0)

    # Варианты разрезов
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    total_area = n * m
    min_difference = float('inf')

    for cx, cy in corners:
        # Площадь треугольника с углом (cx, cy) и точкой свечки (x, y)
        area1 = triangle_area(cx, cy, x, y, n, 0) + triangle_area(cx, cy, x, y, 0, m)
        # Площадь второй части прямоугольника
        area2 = total_area - area1
        # Разница площадей двух частей
        difference = abs(area1 - area2)
        # Обновление минимальной разницы
        min_difference = min(min_difference, difference)

    return min_difference

# Чтение входных данных
n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

# Вычисление и вывод минимальной разницы
print(f"{calculate_area_difference(n, m, x, y):.3f}")