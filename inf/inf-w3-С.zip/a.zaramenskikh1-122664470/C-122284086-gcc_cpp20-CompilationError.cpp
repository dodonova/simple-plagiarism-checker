#include <iostream>
using namespace std;
int main()
{
    int q = 16;
    int w = 15;
    int e = 2;
    int r, t;
    while (true) {
        if (q == 0 and w == 0) {
	    r = 1;
	    t = 1;
	    break;
	}
	if (b % e == 0) {
	    t = (w / e) + 1;
	    r = e + 1;
	    break;
	}
}
cout << r << " " << t;
	
}
