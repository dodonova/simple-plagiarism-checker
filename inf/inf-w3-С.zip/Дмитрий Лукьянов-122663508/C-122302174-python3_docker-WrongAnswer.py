def triangle_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def min_area_difference(n, m, x, y):
    # Площади треугольников при разрезах через каждый угол
    # Углы пирога: (0, 0), (n, 0), (n, m), (0, m)
    
    total_area = n * m  # Полная площадь пирога
    
    # Треугольники для каждого угла:
    area1 = triangle_area(0, 0, n, 0, x, y)  # Разрез через угол (0, 0)
    area2 = triangle_area(n, 0, n, m, x, y)  # Разрез через угол (n, 0)
    area3 = triangle_area(n, m, 0, m, x, y)  # Разрез через угол (n, m)
    area4 = triangle_area(0, m, 0, 0, x, y)  # Разрез через угол (0, m)
    
    # Находим минимальную разницу между большими и меньшими кусками
    min_diff = min(
        abs(total_area - 2 * area1),
        abs(total_area - 2 * area2),
        abs(total_area - 2 * area3),
        abs(total_area - 2 * area4)
    )
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы площадей
result = min_area_difference(n, m, x, y)

# Вывод результата с точностью 3 знака
print(f"{result:.3f}")
