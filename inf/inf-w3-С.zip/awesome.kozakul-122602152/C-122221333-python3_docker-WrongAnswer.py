nm = input().split()
xy = input().split()
n = int(nm[0])
m = int(nm[1])
x = int(xy[0])
y = int(xy[1])

k1=(m-y)*(n-x)/x
k2=y*(n-x)/x 
k3=(n-x)*(m-y)/y
k4=y*(n-x)/(m-y)

s1 = abs(x*y + (m-y)*x/2 + (y-k1)*(n-x) + k1*(n-x)/2 - m*n/2)
s2 = abs(x*(m-y) + (n-x)*(m-y-k2) + (k2)*(n-x)/2 + y*x/2 - m*n/2)
s3 = abs((m-y)*(x-k3) + x*y + k3*(m-y)/2 + (n-x)*y/2 - m*n/2)
s4 = abs((m-y)*x + y*(x-k4) + y*k4/2 + (n-x)*(m-y)/2 - m*n/2)



print('%.3f' % min(2*s1,2*s2,2*s3,2*s4))

