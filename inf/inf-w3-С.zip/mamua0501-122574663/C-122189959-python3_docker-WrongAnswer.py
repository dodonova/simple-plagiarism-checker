def area_triangle(x1, y1, x2, y2, x3, y3):  
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2  

def min_difference(n, m, x, y):  
    total_area = n * m  
    
    # 1. Разрез из нижнего левого угла (0, 0)  
    area_1 = area_triangle(0, 0, x, y, n, 0)  
    difference_1 = abs(2 * area_1 - total_area)  

    # 2. Разрез из верхнего левого угла (0, m)  
    area_2 = area_triangle(0, m, x, y, 0, 0)  
    difference_2 = abs(2 * area_2 - total_area)  

    # 3. Разрез из нижнего правого угла (n, 0)  
    area_3 = area_triangle(n, 0, x, y, n, m)  
    difference_3 = abs(2 * area_3 - total_area)  

    # 4. Разрез из верхнего правого угла (n, m)  
    area_4 = area_triangle(n, m, x, y, 0, m)  
    difference_4 = abs(2 * area_4 - total_area)  

    # Возвращаем минимальную разницу  
    return min(difference_1, difference_2, difference_3, difference_4)  

# Чтение входных данных  
import sys  
input_data = sys.stdin.read().strip().splitlines()  
n, m = map(int, input_data[0].split())  
x, y = map(int, input_data[1].split())  

# Вычисление минимальной разницы  
result = min_difference(n, m, x, y)  

# Вывод результата с нужной точностью  
print(f"{result:.3f}")