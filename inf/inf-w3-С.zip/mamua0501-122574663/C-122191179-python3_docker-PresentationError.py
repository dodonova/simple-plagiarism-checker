def calculate_min_area_difference(n, m, x, y):  
    """Вычисляет минимальную разницу площадей после разреза пирога."""  
    
    # Площадь всего пирога  
    total_area = n * m  

    # Площадь треугольника от одного из углов к свечке  
    area_1 = (x * y)  # Разрез от (0, 0)  
    area_2 = (x * (m - y))  # Разрез от (0, m)  
    area_3 = ((n - x) * y)  # Разрез от (n, 0)  
    area_4 = ((n - x) * (m - y))  # Разрез от (n, m)  

    # Разницы площадей для каждого разреза  
    difference_1 = abs(total_area - 2 * area_1)  
    difference_2 = abs(total_area - 2 * area_2)  
    difference_3 = abs(total_area - 2 * area_3)  
    difference_4 = abs(total_area - 2 * area_4)  

    # Возвращаем минимальную разницу  
    return min(difference_1, difference_2, difference_3, difference_4)  

# Ввод данных  
n, m = map(int, input("Введите размеры пирога (n m): ").split())  
x, y = map(int, input("Введите координаты свечи (x y): ").split())  

# Вычисление минимальной разницы площадей  
result = calculate_min_area_difference(n, m, x, y)  

# Вывод результата с нужной точностью  
print(f"{result:.3f}")