import math

nx, my = map(int, input().split())
x, y = map(int, input().split())

points = []
# угол (0,0)
def cherez_00(nx, my, x, y):
    b = y
    k = y/x

    y1 = k*nx
    d_kat1 = y1
    d_kat2 = nx
    p_1 = (d_kat2*d_kat1)/2
    p_p = nx*my
    p_2 = p_p-p_1
    points.append(p_2-p_1)
# угол (0,y)
def cherez0y(nx, my, x, y):
    b = y
    k = (y-b)/x

    y1 = k*nx+b
    d_kat1 = math.sqrt((my-y1)**2)
    d_kat2 = nx
    p_1 = (d_kat2 * d_kat1) / 2
    p_p = nx * my
    p_2 = p_p - p_1
    points.append(p_2-p_1)
# угол (x,y)
def cherezxy(nx, my, x, y):
    k = (y-my)/(x-nx)
    b = my - nx*k

    x1 = b/k
    d_kat1 = math.sqrt(((x1*(-1))-nx)**2)
    d_kat2 = my
    p_1 = (d_kat2 * d_kat1) / 2
    p_p = nx * my
    p_2 = p_p - p_1
    points.append(p_2-p_1)
# угол (x, 0)
def cherezx0(nx, my, x, y):
    k = y/(x-nx)
    b = -nx*k

    x1 = (my-b)/k
    d_kat1 = math.sqrt((x1-nx)**2)
    d_kat2 = my
    p_1 = (d_kat2 * d_kat1) / 2
    p_p = nx * my
    p_2 = p_p - p_1
    points.append(p_2-p_1)


cherez_00(nx, my, x, y)
cherez0y(nx, my, x, y)
cherezxy(nx, my, x, y)
cherezx0(nx, my, x, y)
print("{:.3f}".format(min(points)))
