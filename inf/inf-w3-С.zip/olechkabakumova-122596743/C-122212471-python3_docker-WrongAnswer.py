def min_difference(n,m,x,y):
    angles=[
        (0,0),
        (n,0),
        (0,m),
        (n,m)]
    v1=(1,0)
    diff=[]
    u=(m**2)/(m**2 + n**2)
    for i in angles:
        v2=(x-i[0],y-i[1])
        scalar = ((v1[0]*v2[0])+(v1[1]*v2[1]))**2
        length = (v1[0]**2 + v1[1]**2)*(v2[0]**2 + v2[1]**2)
        diff.append([abs(u-(1-(scalar/length))),1-(scalar/length)])
    diff=sorted(diff)
    sin_sq=[x[1] for x in diff][0]
    tg=(sin_sq/(1-sin_sq))**0.5
    tg=min(tg,1/tg)

    a=0
    b=0
    if sin_sq<=(1-sin_sq):
        a= (n**2 * tg)/2
        b= (n*m)-a
    else:
        a= (m**2 * tg)/2
        b= (n*m)-a

    return(int(abs(a-b)*1000)/1000)

n,m=map(int,input().split())
x,y=map(int,input().split())

print(min_difference(n,m,x,y))