#include <iostream>
#include <cmath>
int main(void)
{
	double n, m, x, y, px = 0, py = 0, k, b;
	double maxdist, pom, razn;
	std::cin >> n >> m >> x >> y;
	maxdist = sqrt(x * x + y * y);
	pom = sqrt(x * x + (n - y) * (n - y));
	if (pom > maxdist)
	{
		maxdist = pom;
		py = m;
	}
	pom = sqrt((n-x) * (n-x) + (n - y) * (n - y));
	if (pom > maxdist)
	{
		maxdist = pom;
		px = n;
		py = m;
	}
	pom = sqrt((n-x) * (n-x) + y * y);
	if (pom > maxdist)
	{
		px = n;
		py = 0;
	}
		
	k = (py - y) / (px - x);
	b = y - k * x;

	if (px == 0 && py == 0)
	{
		if ((k * n + b) <= m)
			razn = n * m - n * (k * n + b); // ploshad treugolnika minus dva raza
		else
			razn = n * m - m * (m - b) / k;
	}

	if (px == 0 && py == m)
	{
		if ((k * n + b) <= 0)
			razn = n * m - m * (-b) / k; // ploshad treugolnika minus dva raza
		else
			razn = n * m - n * (m - (k * n + b));
	}

	if (px == n && py == m)
	{
		if (b >= 0)
			razn = n * m - n * (n - b); // ploshad treugolnika minus dva raza
		else
			razn = n * m - m * (n + b / k);
	}

	if (px == n && py == 0)
	{
		if (b >= m)
			razn = n * m - n * b; // ploshad treugolnika minus dva raza
		else
			razn = n * m - m * (n - (m - b)/k);
	}

	std::cout << round(razn*1000)/1000;
}