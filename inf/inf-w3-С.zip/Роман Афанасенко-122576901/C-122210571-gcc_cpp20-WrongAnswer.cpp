#include <iostream>
#include <cmath>
int main(void)
{
	long double n, m, x, y, px = 0, py = 0, k, b, razn;

	std::cin >> n >> m >> x >> y;
	if (x > n / 2)
		x = n - x;
	if (y > m / 2)
		y = m - y;
	if (x > y)
	{
		razn = x;
		x = y;
		y = razn;
	}
	k = (m - y) / (n - x);
	b = m - k * n;
	if (b == 0)
		razn = 0;
	if (b > 0)
		razn = n * m - n * (m - b);
	std::cout << razn;
}