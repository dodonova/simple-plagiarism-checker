q, w = map(int, input().split())
a, s = map(int, input().split())
e = a * s
r = (q - a) * (w -s)
tea = abs(e - r)
print(tea)