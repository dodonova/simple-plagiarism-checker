n, m = list(map(int, input().split()))
x, y = list(map(int, input().split()))
if y <= (m // 2):
    y2 = m
else:
    y2 = 0
if x <= (n // 2):
    x2 = n
else:
    x2 = 0
if (x - x2) == 0:
    a = 0/0
else:
    k = (y - y2) / (x - x2)
    b = y - k * x
    x = x2
    y = y2

def f(x):
    global k, b
    return k * x + b


def d(y):
    global k, b
    return (y - b) / k



if x == n and y == m:
    S = y * (x - d(0))
elif x == 0 and y == 0:
    S = x *f(x)
elif x == n and y == 0:
    S = y *(d(m))
elif x == 0 and y == m:
    S = n * (y - f(n))
print(round(n*m - S, 3))
