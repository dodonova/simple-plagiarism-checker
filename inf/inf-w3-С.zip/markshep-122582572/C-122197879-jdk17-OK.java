import java.io.*;
import java.util.*;

public class Main {
    static double n, m, x, y;

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);

        n = scanner.nextDouble();
        m = scanner.nextDouble();

        x = scanner.nextDouble();
        y = scanner.nextDouble();

        double totalArea = n * m;
        double minDifference = Double.MAX_VALUE;

        // Corners: (0, 0), (n, 0), (n, m), (0, m)
        double[][] corners = {
                {0, 0},
                {n, 0},
                {n, m},
                {0, m}
        };

        for (double[] corner : corners) {
            double x0 = corner[0];
            double y0 = corner[1];

            double dx = x - x0;
            double dy = y - y0;

            double xOpposite = (x0 == 0) ? n : 0;
            double yOpposite = (y0 == 0) ? m : 0;

            boolean areaCalculated = false;
            double area = 0;

            if (dx != 0) {
                double yIntersect = y0 + dy * (xOpposite - x0) / dx;

                if (yIntersect >= 0 && yIntersect <= m) {
                    area = 0.5 * Math.abs(xOpposite - x0) * Math.abs(yIntersect - y0);
                    areaCalculated = true;
                }
            }

            if (!areaCalculated && dy != 0) {
                double xIntersect = x0 + dx * (yOpposite - y0) / dy;

                if (xIntersect >= 0 && xIntersect <= n) {
                    area = 0.5 * Math.abs(xIntersect - x0) * Math.abs(yOpposite - y0);
                    areaCalculated = true;
                }
            }

            if (areaCalculated) {
                double otherArea = totalArea - area;
                double difference = Math.abs(area - otherArea);
                if (difference < minDifference) {
                    minDifference = difference;
                }
            }
        }

        System.out.printf("%.10f\n", minDifference);
    }
}
