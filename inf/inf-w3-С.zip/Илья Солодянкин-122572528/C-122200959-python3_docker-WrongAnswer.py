n, m = map(int, input().split())
x, y = map(int, input().split())

S1 = (n**2*x*(m-y))/(2*x**2)
S2 = n*m - S1
d1 = abs(S1 - S2)

S1 = (y*(n-x)*m**2)/(2*y**2)
S2 = n*m - S1
d2 = abs(S1 - S2)

S1 = (x*y*n**2)/(2*x**2)
S2 = n*m - S1
d3 = abs(S1 - S2)


S1 = (m**2*(n-x))/(2*(m-y))
S2 = n*m - S1
d4 = abs(S1 - S2)


print(f'{min(d1, d2, d3, d4):.3f}')