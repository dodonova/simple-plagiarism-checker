import java.util.Arrays;import java.util.Scanner;
public class Main {    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);        int n = in.nextInt();
        int[] a = new int[n];        for (int i = 0; i < n; i++) {
            a[i] = in.nextInt();        }
        Arrays.sort(a);        int count1 = 0; 
        int count2 = 0;         for (int length : a) {
            if (length % 2 == 0) {                count1++;
            } else {                count2++;
            }        }
        int totalCount = count1 + count2;          int result = ((totalCount / 2) * (totalCount / 2));
        if (totalCount % 2 == 0) {            result = (totalCount / 2) * (totalCount / 2);
        } else {            result = (totalCount / 2) * (totalCount / 2 + 1);
        }        System.out.println(result);
        in.close();    }
}