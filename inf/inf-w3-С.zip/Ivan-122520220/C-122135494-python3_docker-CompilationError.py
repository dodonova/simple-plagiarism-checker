def area_difference(n, m, x, y):
    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    
    min_difference = float('inf')
    
    for corner in corners:
        cx, cy = corner
       y points (0,0), (cx,cy) and (x,y)
        area1 = abs(cx * y - cy * x) / 2.0
        

        total_area = n * m
        area2 = total_area - area1
        
        current_difference = abs(area1 - area2)
        
        min_difference = min(min_difference, current_difference)
        
    return min_difference

n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

result = area_difference(n, m, x, y)

print(f"{result:.4f}")