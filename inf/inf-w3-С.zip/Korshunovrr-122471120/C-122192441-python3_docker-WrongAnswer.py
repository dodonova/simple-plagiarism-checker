import math

def area_rectangle(n, m):
    return n * m

def area_triangle(x, y, n, m):
    return (n * m) / 2

def area_trapezoid(x, y, n, m):
    return (n * m) / 2 - area_triangle(x, y, n, m)

def min_difference(n, m, x, y):
    triangle_area = area_triangle(x, y, n, m)
    trapezoid_area = area_trapezoid(x, y, n, m)
    difference = abs(triangle_area - trapezoid_area)
    return difference

# Пример ввода
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы
difference = min_difference(n, m, x, y)

# Вывод результата
print(f"{difference:.3f}")