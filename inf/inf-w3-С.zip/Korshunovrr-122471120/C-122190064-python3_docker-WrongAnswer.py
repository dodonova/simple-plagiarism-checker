def area_difference(n, m, x, y):
    # Определяем площади для разрезов из каждого угла
    areas = []
    
    # Угол (0, 0)
    area1 = 0.5 * x * y            # Площадь треугольника
    area2 = n * m - area1          # Площадь остатка
    areas.append(abs(area1 - area2))
    
    # Угол (n, 0)
    area1 = 0.5 * (n - x) * y      # Площадь треугольника
    area2 = n * m - area1          # Площадь остатка
    areas.append(abs(area1 - area2))
    
    # Угол (0, m)
    area1 = 0.5 * x * (m - y)      # Площадь треугольника
    area2 = n * m - area1          # Площадь остатка
    areas.append(abs(area1 - area2))
    
    # Угол (n, m)
    area1 = 0.5 * (n - x) * (m - y)  # Площадь треугольника
    area2 = n * m - area1             # Площадь остатка
    areas.append(abs(area1 - area2))
    
    # Возвращаем минимальную разницу
    return min(areas)

# Чтение входа
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение и вывод результата
min_difference = area_difference(n, m, x, y)
print(f"{min_difference:.3f}")