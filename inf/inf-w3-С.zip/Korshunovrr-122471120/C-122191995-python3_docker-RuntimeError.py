def area_of_triangle(ax, ay, bx, by, cx, cy):
    return abs(ax*(by-cy) + bx*(cy-ay) + cx*(ay-by)) / 2.0

def calculate_difference(n, m, x, y):
    # Угловые точки пирога
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    min_difference = float('inf')

    total_area = n * m

    for corner in corners:
        ax, ay = corner
        # Вычисляем площади
        triangle_area = area_of_triangle(ax, ay, x, y, (ax + (1 if ax == 0 else -1) * (n if ax == 0 else 0), ay))

        if ax == 0:  # если (0,0) - это верхняя точка
            base_area = area_of_triangle(x, y, n, 0, n, m)
        elif ay == 0:  # если (n,0) - это верхняя точка
            base_area = area_of_triangle(x, y, 0, 0, 0, m)
        elif ax == n:  # если (n,m) - это верхняя точка
            base_area = area_of_triangle(x, y, 0, m, n, 0)
        elif ay == m:  # если (0,m) - это нижняя точка
            base_area = area_of_triangle(x, y, 0, m, n, m)

        piece1_area = triangle_area
        piece2_area = total_area - piece1_area

        # Вычисляем разницу
        difference = abs(piece1_area - piece2_area)
        min_difference = min(min_difference, difference)

    return min_difference

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Вычисление минимальной разницы и вывод результата
result = calculate_difference(n, m, x, y)
print(f"{result:.3f}")
