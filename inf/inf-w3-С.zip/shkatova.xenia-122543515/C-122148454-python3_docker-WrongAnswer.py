def min_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m
    
    # Площадь разреза от всех углов
    differences = []
    
    # Угол (0, 0)
    triangle_area1 = (x * y) / 2
    quad_area1 = total_area - triangle_area1
    differences.append(abs(triangle_area1 - quad_area1))

    # Угол (0, m)
    triangle_area2 = (x * (m - y)) / 2
    quad_area2 = total_area - triangle_area2
    differences.append(abs(triangle_area2 - quad_area2))

    # Угол (n, 0)
    triangle_area3 = ((n - x) * y) / 2
    quad_area3 = total_area - triangle_area3
    differences.append(abs(triangle_area3 - quad_area3))

    # Угол (n, m)
    triangle_area4 = ((n - x) * (m - y)) / 2
    quad_area4 = total_area - triangle_area4
    differences.append(abs(triangle_area4 - quad_area4))

    # Минимальная разница
    return min(differences)

# Чтение данных
import sys

input = sys.stdin.read
data = input().splitlines()
n, m = map(int, data[0].split())
x, y = map(int, data[1].split())

# Вычисление минимальной разницы и вывод результата с нужной точностью
result = min_difference(n, m, x, y)
print(f"{result:.3f}")
