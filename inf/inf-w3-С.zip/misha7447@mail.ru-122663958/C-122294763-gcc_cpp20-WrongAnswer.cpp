#include <iostream>
#include <iomanip>
#include <algorithm>

int main() {
    double n, m;
    std::cin >> n >> m;
    double x, y;
    std::cin >> x >> y;
    
    double x1 = n - x;
    double y1 = m - y;
    double sq1 = (n * y * n / x) / 2;
    double sq2 = (m * (x1 * m / y)) / 2;
    double sq3 = (m * (x1 * m / y1)) / 2;
    double sq4 = (n * (y1 * n / x)) / 2;

    double ans = std::max({sq1, sq2, sq3, sq4});
    double result = ((n * m) / 2 - ans) * 2;
    
    std::cout << std::fixed << std::setprecision(3) << result << std::endl;
    return 0;
}

