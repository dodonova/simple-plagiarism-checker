n, m = map(int, input().split())
x, y = map(int, input().split())
k = y / x 
z = x - (k*x)
S = (y*z)/2
S1 = (n*m) - S
print(round(S1, 3))