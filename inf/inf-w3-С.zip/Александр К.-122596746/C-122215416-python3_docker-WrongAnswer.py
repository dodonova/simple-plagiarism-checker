def calculate_area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def find_min_difference(n, m, x, y):
    total_area = n * m
    
    area1 = calculate_area(0, 0, x, y, n, 0)
    area2 = calculate_area(n, 0, x, y, n, m)
    area3 = calculate_area(n, m, x, y, 0, m)
    area4 = calculate_area(0, m, x, y, 0, 0)
    
    diff1 = abs(total_area - 2 * area1)
    diff2 = abs(total_area - 2 * area2)
    diff3 = abs(total_area - 2 * area3)
    diff4 = abs(total_area - 2 * area4)
    
    return min(diff1, diff2, diff3, diff4)

n, m = map(int, input().split())
x, y = map(int, input().split())

result = find_min_difference(n, m, x, y)

print(f"{result:.3f}")
