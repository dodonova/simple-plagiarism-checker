def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0

def min_difference(n, m, x, y):
    total_area = n * m min_diff = float('inf')
    corners = [(0, 0), (n, 0), (0, m), (n, m)]
    
    for cx, cy in corners:
        triangle_area = area_of_triangle(cx, cy, x, y, cx, cy)
        second_piece_area = total_area - triangle_area
        diff = abs(triangle_area - second_piece_area)
        min_diff = min(min_diff, diff)

    return min_diff

n, m = map(int, input().strip().split())
x, y = map(int, input().strip().split())

result = min_difference(n, m, x, y)
print(f"{result:.3f}")
