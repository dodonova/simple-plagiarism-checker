#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

float point[2];

bool cross( float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4 )
{
  float n;

  if (y2 - y1 != 0) 
  {
    float q = (x2 - x1) / (y1 - y2);   
    float sn = (x3 - x4) + (y3 - y4) * q;
    if (!sn)
    {
      return 0;
    }

    float fn = (x3 - x1) + (y3 - y1) * q;

    n = fn / sn;
  }
  else
  {
    if (!(y3 - y4))
    {
      return false;
    }

    n = (y3 - y1) / (y3 - y4);
  }

  point[0] = x3 + (x4 - x3) * n;
  point[1] = y3 + (y4 - y3) * n;

  return true;
}

int main( void )
{
  double n, m;
  cin >> n >> m;

  double x, y;
  cin >> x >> y;

  double sq = n * m;

  vector<double> nsq;

  if (cross(0, 0, x, y, n, 0, n, m) && point[1] <= m && point[1] >= 0)
    nsq.push_back(n * point[1] / 2);

  if (cross(0, 0, x, y, 0, m, n, m) && point[0] <= n && point[1] >= 0)
    nsq.push_back(m * point[0] / 2);

  if (cross(0, m, x, y, n, 0, n, m) && point[1] <= m && point[1] >= 0)
    nsq.push_back(n * (m - point[1]) / 2);

  if (cross(0, m, x, y, 0, 0, n, 0) && point[0] <= n && point[1] >= 0)
    nsq.push_back(m * point[0] / 2);

  if (cross(n, m, x, y, 0, 0, 0, m) && point[1] <= m && point[1] >= 0)
    nsq.push_back(n * (m - point[1]) / 2);

  if (cross(n, m, x, y, 0, 0, n, 0) && point[0] <= n && point[1] >= 0)
    nsq.push_back(m * (n - point[0]) / 2);


  if (cross(n, 0, x, y, 0, 0, 0, m) && point[1] <= m && point[1] >= 0)
    nsq.push_back(n * point[1] / 2);

  if (cross(n, 0, x, y, 0, m, n, m) && point[0] <= n && point[1] >= 0)
    nsq.push_back(m * (n - point[0]) / 2);


  double min = -1;

  for (auto x: nsq)
  {
    double cur = sq - x;

    double ns = abs(cur - x);

    if (min == -1 || min > ns)
      min = ns;
  }

  cout << fixed;
  cout.precision(3);
  cout << min;

  return 0;
}