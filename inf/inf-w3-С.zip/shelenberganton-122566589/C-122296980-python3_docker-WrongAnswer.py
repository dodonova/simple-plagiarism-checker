import sys

def main():
    input = sys.stdin.read
    data = input().split()
    n, m, x, y = map(float, data)

    if m / n * x < y:
        x = n - x
        y = m - y

    mn = float('inf')
    ans1 = y / x * n * n / 2
    ans2 = (n - x) / y * m * m / 2
    ans3 = (m - y) / x * n * n / 2
    ans4 = (n - x) / (m - y) * m * m / 2

    mn = min(mn, abs(n * m - ans1 - ans1))
    mn = min(mn, abs(n * m - ans2 - ans2))
    mn = min(mn, abs(n * m - ans3 - ans3))
    mn = min(mn, abs(n * m - ans4 - ans4))

    print(f"{mn:.3f}")

if __name__ == "__main__":
    main()