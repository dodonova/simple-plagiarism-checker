n,m = map(int,input().split())
x,y = map(int,input().split())

tg1 = y/x
tg2 = (n-x)/y
tg3 = (n-x)/(m-y)
tg4 = x/(m-y)

d1 = n*m - 2*(0.5*(n**2)*tg1)
d2 = n*m - 2*(0.5*(m**2)*tg2)
d3 = n*m - 2*(0.5*(m**2)*tg3)
d4 = n*m - 2*(0.5*(n**2)*tg4)
print(f"{min([d1,d2,d3,d4]):.3f}")
