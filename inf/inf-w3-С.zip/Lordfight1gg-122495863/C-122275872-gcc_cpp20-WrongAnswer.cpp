#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int n, m, x, y, s;
	float kat1, kat2, li[4], min = 10.0 * pow(10, 8);
	cin >> n;
	cin >> m;
	cin >> x;
	cin >> y;
	s = n * m;
	kat1 = n;
	kat2 = n * (y / float(x));
	li[0] = abs((s - (kat1 * kat2 / 2.0)) - (kat1 * kat2 / 2.0));

	kat1 = m;
	kat2 = m * ((n - x) / float(y));
	li[1] = abs((s - (kat1 * kat2 / 2.0)) - (kat1 * kat2 / 2.0));

	kat1 = m;
	kat2 = m * ((n - x) / float(m - y));
	li[2] = abs((s - (kat1 * kat2 / 2.0)) - (kat1 * kat2 / 2.0));

	kat1 = n;
	kat2 = n * ((m - y) / float(x));
	li[3] = abs((s - (kat1 * kat2 / 2.0)) - (kat1 * kat2 / 2.0));
	for (int i = 0; i < 4; i++) {
		if (li[i] < min)
			min = li[i];
		// cout << li[i] << endl;
	}
	cout << min;
}