import java.util.Scanner;

public class PieDivision {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Считываем размеры пирога
        int n = scanner.nextInt();
        int m = scanner.nextInt();
        
        // Считываем координаты свечки
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        
        // Площадь пирога
        double totalArea = n * m;
        
        // Вычисляем площади для каждого угла
        double area1 = x * y; // Нижний левый угол (0,0)
        double area2 = (n - x) * y; // Нижний правый угол (n,0)
        double area3 = x * (m - y); // Верхний левый угол (0,m)
        double area4 = (n - x) * (m - y); // Верхний правый угол (n,m)
        
        // Находим минимальную разницу
        double minDifference = Double.MAX_VALUE;
        
        // Сравниваем различия для всех углов
        minDifference = Math.min(minDifference, Math.abs(area1 - (totalArea - area1)));
        minDifference = Math.min(minDifference, Math.abs(area2 - (totalArea - area2)));
        minDifference = Math.min(minDifference, Math.abs(area3 - (totalArea - area3)));
        minDifference = Math.min(minDifference, Math.abs(area4 - (totalArea - area4)));
        
        // Выводим результат с требуемой точностью
        System.out.printf("%.3f\n", minDifference);
        
        scanner.close();
    }
}