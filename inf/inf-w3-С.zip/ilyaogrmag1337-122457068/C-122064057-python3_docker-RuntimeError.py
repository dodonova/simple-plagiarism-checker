def min_difference(W, H, x, y):
    # Полная площадь пирога
    full_area = W * H

    # 1. Разрез через (0, 0)
    area1 = abs(x * H + y * W - x * y)

    # 2. Разрез через (W, 0)
    area2 = abs((W - x) * H + y * W - (W - x) * y)

    # 3. Разрез через (0, H)
    area3 = abs(x * (H - y) + (H - y) * W - x * (H - y))

    # 4. Разрез через (W, H)
    area4 = abs((W - x) * (H - y) + (H - y) * W - (W - x) * (H - y))

    # Минимальная разница между кусками пирога
    min_difference = min(
        abs(full_area - area1 * 2),
        abs(full_area - area2 * 2),
        abs(full_area - area3 * 2),
        abs(full_area - area4 * 2)
    )

    # Возвращаем результат с округлением до 3 знаков после запятой
    return round(min_difference, 3)

# Чтение входных данных
W, H, x, y = map(float, input().split())

# Выводим результат
print(min_difference(W, H, x, y))
