x,y = map(int,input().split())

x0,y0 = map(int,input().split())


d1 = y/x
d2 = -y/x
ans = 1000000000000
if d1*x0 > y0:
    k = y0/x0
    tr = k*x *y/2
    oth = x*y-tr
    ans = min(abs(oth-tr),ans)
    
else:
    k = y0/x0
    x1 = y/k
    tr = y*x1/2
    oth = x*y-tr
    ans = min(abs(oth-tr),ans)
if d2*x0+y < y0:
    k = (y0-y)/x0
    y1 = k*x+y
    y1 = y - y1
    tr = x*y1/2
    oth = x*y-tr
    ans = min(abs(oth-tr),ans)
else:
    k = (y0-y)/x0
    x1 = -y/k
    tr = x1*y/2
    otr = x*y-tr
    ans = min(abs(oth-tr),ans)

#право верх

if d1*x0 < y0:
    k = (y-y0)/(x-x0)
    b = y0 - x0*k
    x1 = -b/k
    x1 = x - x1
    tr = x1*y/2
    otr = x*y-tr
    print('5',abs(oth-tr))
else:
    k = (y-y0)/(x-x0)
    b = y0 - x0*k
    y1 = b
    y1 = y-b
    tr = x*y1/2
    otr = x*y - tr
    ans = min(abs(oth-tr),ans)
if d2*x0 +y < y0:
    k = y0/(x0-x)
    b = -k*x
    y1 = b
    tr = x*y1/2
    otr = x*y-tr
    ans = min(abs(oth-tr),ans)
else:
    k = y0/(x0-x)
    b = -k*x
    x1 = (y-b)/k
    tr = x1*y/2
    otr = x*y - tr
    ans = min(abs(oth-tr),ans)

print(ans)