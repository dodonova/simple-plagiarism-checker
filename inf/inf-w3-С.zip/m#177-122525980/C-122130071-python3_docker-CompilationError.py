#include <iostream>
#include <algorithm>

using namespace std;

int main() {
  int n, m, x, y;
  cin >> n >> m >> x >> y;

  double totalArea = n * m;
  double differences[4];

  double ug3 = ((n - x) * m) / (m - y) if m != y else numeric_limits<double>::infinity();
  double S3 = ug3 * m * 0.5;
  double difference = abs(totalArea - 2 * S3);
  differences[0] = difference;

  double ug4 = ((n - x) * m) / y if y != 0 else numeric_limits<double>::infinity();
  double S4 = ug4 * m * 0.5;
  difference = abs(totalArea - 2 * S4);
  differences[1] = difference;

  double ug1 = (n * y) / x if x != 0 else numeric_limits<double>::infinity();
  double S1 = ug1 * n * 0.5;
  difference = abs(totalArea - 2 * S1);
  differences[2] = difference;

  double ug2 = (n * (m - y)) / x if x != 0 else numeric_limits<double>::infinity();
  double S2 = ug2 * n * 0.5;
  difference = abs(totalArea - 2 * S2);
  differences[3] = difference;

  cout << fixed << setprecision(3) << min(differences[0], min(differences[1], min(differences[2], differences[3]))) << endl;

  return 0;
}