import sys
import math

def compute_area(polygon):
    """Calculate area of a polygon using the shoelace formula."""
    area = 0
    n = len(polygon)
    for i in range(n):
        x1, y1 = polygon[i]
        x2, y2 = polygon[(i + 1) % n]
        area += (x1 * y2 - x2 * y1)
    return abs(area) / 2

def find_intersection(x0, y0, dx, dy, n, m):
    """Find the intersection points of the line with the rectangle sides."""
    intersections = []

    # Avoid division by zero
    if dx == 0:
        # Vertical line x = x0
        if x0 < 0 or x0 > n:
            return []
        if y0 != 0:
            intersections.append((x0, 0))
        if y0 != m:
            intersections.append((x0, m))
    elif dy == 0:
        # Horizontal line y = y0
        if y0 < 0 or y0 > m:
            return []
        if x0 != 0:
            intersections.append((0, y0))
        if x0 != n:
            intersections.append((n, y0))
    else:
        k = dy / dx
        # Intersect with left side x = 0
        x_bound = 0
        if x0 != x_bound:
            y = k * (x_bound - x0) + y0
            if 0 <= y <= m and (x_bound, y) != (x0, y0):
                intersections.append((x_bound, y))
        # Intersect with right side x = n
        x_bound = n
        if x0 != x_bound:
            y = k * (x_bound - x0) + y0
            if 0 <= y <= m and (x_bound, y) != (x0, y0):
                intersections.append((x_bound, y))
        # Intersect with bottom side y = 0
        y_bound = 0
        if y0 != y_bound:
            x = (y_bound - y0) / k + x0
            if 0 <= x <= n and (x, y_bound) != (x0, y0):
                intersections.append((x, y_bound))
        # Intersect with top side y = m
        y_bound = m
        if y0 != y_bound:
            x = (y_bound - y0) / k + x0
            if 0 <= x <= n and (x, y_bound) != (x0, y0):
                intersections.append((x, y_bound))
    return intersections

def main():
    n, m = map(float, sys.stdin.readline().split())
    x, y = map(float, sys.stdin.readline().split())

    corners = [(0, 0), (n, 0), (n, m), (0, m)]
    total_area = n * m
    min_diff = None

    for corner in corners:
        x0, y0 = corner
        dx = x - x0
        dy = y - y0

        # Skip if candle is at the corner
        if dx == 0 and dy == 0:
            continue

        # Find intersection points
        intersections = find_intersection(x0, y0, dx, dy, n, m)

        # Collect polygon points
        polygon = [corner]

        # Add intersection points
        for point in intersections:
            if point != corner and point != (x, y):
                polygon.append(point)

        # Add candle position
        polygon.append((x, y))

        # Ensure the polygon is closed by sorting the points in order
        polygon = sorted(polygon, key=lambda p: math.atan2(p[1] - y0, p[0] - x0))

        area_piece = compute_area(polygon)
        diff = abs(total_area - 2 * area_piece)

        if min_diff is None or diff < min_diff:
            min_diff = diff

    # Output the minimal difference with at least three decimal places
    print(f"{min_diff:.3f}")

if __name__ == "__main__":
    main()