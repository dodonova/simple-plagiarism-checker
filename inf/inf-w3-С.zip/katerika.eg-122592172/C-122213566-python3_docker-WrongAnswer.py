def area_of_triangle(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0)

def min_difference(n, m, x, y):
    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    min_diff = float('inf')
    
    for (cx, cy) in corners:
        if cx == 0 and cy == 0:
            # from (0, 0) to (x, y)
            area1 = area_of_triangle(0, 0, x, y, n, 0) + area_of_triangle(0, 0, x, y, 0, m)
            area2 = n * m - area1
        elif cx == 0 and cy == m:
            # from (0, m) to (x, y)
            area1 = area_of_triangle(0, m, x, y, 0, 0) + area_of_triangle(0, m, x, y, n, m)
            area2 = n * m - area1
        elif cx == n and cy == 0:
            # from (n, 0) to (x, y)
            area1 = area_of_triangle(n, 0, x, y, n, m) + area_of_triangle(n, 0, x, y, 0, 0)
            area2 = n * m - area1
        elif cx == n and cy == m:
            # from (n, m) to (x, y)
            area1 = area_of_triangle(n, m, x, y, 0, m) + area_of_triangle(n, m, x, y, n, 0)
            area2 = n * m - area1
        
        diff = abs(area1 - area2)
        min_diff = min(min_diff, diff)
    
    return min_diff

# Чтение входных данных
n, m = map(int, input().split())
x, y = map(int, input().split())

# Получение и вывод результата
result = min_difference(n, m, x, y)
print(f"{result:.3f}")
