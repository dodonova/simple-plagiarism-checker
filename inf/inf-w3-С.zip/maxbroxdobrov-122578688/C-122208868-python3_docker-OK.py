n, m = map(float, input().split())
x, y = map(float, input().split())

corners = [(0, 0), (n, 0), (0, m), (n, m)]
total_area = n * m
min_diff = None

for x0, y0 in corners:
    x1 = n if x0 == 0 else 0
    y1 = m if y0 == 0 else 0

    delta_x = x - x0
    delta_y = y - y0

    epsilon = 1e-9
    if abs(delta_x) < epsilon:
        t_x = float('inf')
    else:
        t_x = (x1 - x0) / delta_x

    if abs(delta_y) < epsilon:
        t_y = float('inf')
    else:
        t_y = (y1 - y0) / delta_y

    if t_x <= t_y:
        x_int = x1
        y_int = y0 + t_x * delta_y
        if y_int < 0 or y_int > m:
            continue
        vertices = [(x0, y0), (x, y), (x_int, y_int), (x_int, y0)]
    else:
        x_int = x0 + t_y * delta_x
        y_int = y1
        if x_int < 0 or x_int > n:
            continue
        vertices = [(x0, y0), (x, y), (x_int, y_int), (x0, y_int)]

    area = 0
    num_vertices = len(vertices)
    for i in range(num_vertices):
        x_i, y_i = vertices[i]
        x_next, y_next = vertices[(i + 1) % num_vertices]
        area += x_i * y_next - x_next * y_i
    area = abs(area) / 2

    other_area = total_area - area
    diff = abs(area - other_area)
    if min_diff is None or diff < min_diff:
        min_diff = diff

print(f"{min_diff:.10f}")