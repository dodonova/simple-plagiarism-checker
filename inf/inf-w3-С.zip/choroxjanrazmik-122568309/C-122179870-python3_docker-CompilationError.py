def calculate_triangle_area(x1, y1, x2, y2, x3, y3):

    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2

def find_minimal_difference(n, m, x, y):
    total_area = n * m  
    min_difference = float('inf')

    corners = [(0, 0), (0, m), (n, 0), (n, m)]
    for cx, cy in corners:
       
        triangle_area = calculate_triangle_area(cx, cy, 0, 0, x, y)

        other_area = total_area - triangle_area
        

        difference = abs(triangle_area - other_area)
                min_difference = min(min_difference, difference)

    return min_difference


n, m = map(int, input().split())
x, y = map(int, input().split())


result = find_minimal_difference(n, m, x, y)
print(f"{result:.3f}")