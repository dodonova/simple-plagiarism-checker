n, m = map(int, input().split())
x, y = map(int, input().split())
S1=n*m
S2=(x*y)/2*((n/x)**2)
S3=(x*(m-y))/2*((n/x)**2)
S4=((n-x)*(n-y))/2*((m/y)**2)
S5=((n-x)*y)/2*((m/y)**2)
if S1-S2<S1-S3 and S1-S2<S1-S4 and S1-S2<S1-S5:
    print("{:.3f}".format(S1-S2))
elif S1-S3<S1-S2 and S1-S3<S1-S4 and S1-S3<S1-S5:
    print("{:.3f}".format(S1-S3))
elif S1-S4<S1-S2 and S1-S4<S1-S3 and S1-S4<S1-S5:
    print("{:.3f}".format(S1-S4))
elif S1-S5<S1-S2 and S1-S5<S1-S3 and S1-S5<S1-S4:
    print("{:.3f}".format(S1-S5))

          
          