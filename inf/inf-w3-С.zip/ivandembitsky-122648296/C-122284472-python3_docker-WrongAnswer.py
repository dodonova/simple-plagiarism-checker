from math import sqrt
n, m = map(int, input().split())
xn, ym = map(int, input().split())


Y = ym/xn * n
X = xn/ym * m
d1 = 0

if Y < m:
    s1 = Y * n
    d1 = abs (n*m-s1)
elif X < n:
    s1 = X * m
    d1 = abs(n*m-s1)

Y =  m - (m-ym)/xn * n
X = (ym - m)*xn/(m-ym) * (-1)
d2 = 0
if Y > 0:
    s1 = (m - Y) * n
    d2 = abs(n*m-s1)
elif X < n:
    s1 = X * m 
    d2 =abs(n*m-s1)

Y =  ym/(n-xn)*n
X = n - m*(n-xn)/ym
d3 = 0

if Y < m:
    s1 = Y * n
    d3 = abs(n*m-s1)
elif X < n:
    s1 = (n-X) * m 
    d3 = abs(n*m-s1)

print(min(d1, d2, d3))