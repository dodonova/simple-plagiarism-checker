#include <iostream>
#include <cmath>
#include <algorithm>
#include <iomanip>

using namespace std;

double triangle_area(double x1, double y1, double x2, double y2, double x3, double y3) {
    return abs(x1*(y2 - y3) + x2*(y3 - y1) + x3*(y1 - y2)) / 2.0;
}

double min_difference(double n, double m, double x, double y) {
    pair<double, double> corners[4] = {{0, 0}, {n, 0}, {0, m}, {n, m}};
    double min_diff = numeric_limits<double>::infinity();

    for (const auto& corner : corners) {
        double cx = corner.first;
        double cy = corner.second;
        double area1 = 0;

        if (cx == 0 && cy == 0) {
            area1 = triangle_area(cx, cy, x, y, n, 0) + triangle_area(cx, cy, x, y, 0, m);
        } else if (cx == n && cy == 0) {
            area1 = triangle_area(cx, cy, x, y, 0, 0) + triangle_area(cx, cy, x, y, n, m);
        } else if (cx == 0 && cy == m) {
            area1 = triangle_area(cx, cy, x, y, n, m) + triangle_area(cx, cy, x, y, 0, 0);
        } else if (cx == n && cy == m) {
            area1 = triangle_area(cx, cy, x, y, 0, m) + triangle_area(cx, cy, x, y, n, 0);
        }

        double area2 = n * m - area1;
        double diff = abs(area1 - area2);
        min_diff = min(min_diff, diff);
    }

    return min_diff;
}

int main() {
    double n, m, x, y;
    cin >> n >> m >> x >> y;

    double result = min_difference(n, m, x, y);

    cout << fixed << setprecision(3) << result << endl;

    return 0;
}
