n, m = map(int, input().split())
x, y = map(int, input().split())
S = n * m
# 1
k1 = y / x
y1 = k1 * n
s_small = n * y1 / 2
s_big = S - s_small
res1 = round(s_big - s_small, 3)


#2
k2 = y / (x - n)
b2 = -k2 * n
x2 = (m - b2) / k2
s_small = (n - x2) * m / 2
s_big = S - s_small
res2 = round(s_big - s_small, 3)

#3
k3 = (y - m) / (x - n)
b3 = m - k3 * n
x3 = -b3 / k3
s_small = (n - x3) * m / 2
s_big = S - s_small
res3 = round(s_big - s_small, 3)

#4
k4 = (y - m) / x
b4 = m
y4 = k4 * n + b4
s_small = (m - y4) * n / 2
s_big = S - s_small
res4 = round(s_big - s_small, 3)

a = min(res1, res2, res3, res4)
print("{:.3f}".format(a))