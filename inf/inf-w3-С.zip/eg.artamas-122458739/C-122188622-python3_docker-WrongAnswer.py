n, m = map(int, input().split())
x, y = map(int, input().split())

min_diff = float('inf')

# Вариант 1: Разрез через (0, 0) или (n, m)
for _ in range(2):
    # Площадь треугольника через тангенс
    tan_a = x / y
    tan_b = y / x
    area1 = n * n * tan_a / 2 if tan_a <= n / m else m * m / tan_a / 2
    area2 = n * m - area1
    min_diff = min(min_diff, abs(area1 - area2))

    # Поворот пирога
    x, y, n, m = m - y, x, m, n

# Вариант 2: Разрез через (n, 0) или (0, m)
for _ in range(2):
    # Разбиение на два прямоугольных треугольника
    area1 = x * m / 2
    area2 = (n - x) * y / 2
    area3 = n * m - area1 - area2
    min_diff = min(min_diff, abs(area1 - area3), abs(area2 - area3))

    # Поворот пирога
    x, y, n, m = m - y, x, m, n

print(f"{min_diff:.3f}")