#include 

using namespace std;

int main() {
int A, C, D;
cin >> A >> C >> D;

double border = (C + D) / 2.0;

cout << border << endl;

return 0;
}