#include <iostream>

using namespace std;

int main() {
    int A, C, D;
    cin >> A >> C >> D;

    float border = (C + D) / 2.0;
    cout << fixed;
    cout.precision(1);
    cout << border << endl;

    return 0;
}