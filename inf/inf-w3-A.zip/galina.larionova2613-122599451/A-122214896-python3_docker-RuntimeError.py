a, c, d =input().split()
a = int(a)
c = int(c)
d = int(d)
if a > c and a > d:
    num_max = a
    if c < d:
        num_min = c
        num_sr = d
    else:
        num_min = d
        num_sr = c
elif d > c and d > a:
    num_max = d
    if c < a:
        num_min = c
        num_sr = a
    else:
        num_min = a
        num_sr = c
elif c > d and c > a:
    num_max = c
    if a < d:
        num_min = a
        num_sr = d
    else:
        num_min = d
        num_sr = a
border = (num_min + num_sr) / 2
print(round(border, 1))
