a, b, d = map (int, input().split()) 
print(round ((a + b) / 2) 