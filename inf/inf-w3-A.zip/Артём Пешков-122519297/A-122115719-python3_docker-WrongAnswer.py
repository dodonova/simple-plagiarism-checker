def calculate_border(a, c, d):
    border = (c - a) / 2
    return border

input_data = input()
a, c, d = map(int, input_data.split())
border = calculate_border(a, c, d)
print(f"{border:.1f}")