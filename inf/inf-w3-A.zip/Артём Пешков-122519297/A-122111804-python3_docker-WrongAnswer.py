a, c, d = map(int, input().split())

# Первая стратегия:
time1 = a + a + c + a + d

# Вторая стратегия:
time2 = a + a + d + a + a

# Граница:
border = (time1 - time2) / 2

print(int(border))