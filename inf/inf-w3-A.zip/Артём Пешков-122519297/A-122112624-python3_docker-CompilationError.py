n, c, d = map(int, input().split())

if c - n < n:
border = c - 0.5
else:
border = c + 0.5

print(border)