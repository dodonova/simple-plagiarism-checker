t1, t2, t3 = map(int, input().split())
print((t1 + t2) / 2)
