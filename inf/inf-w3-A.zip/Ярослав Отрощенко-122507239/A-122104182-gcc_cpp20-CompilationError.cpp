#include <iostream>

using namespace std;

double find_border(int a, int c, int d) {
  
  int time_first = a + a + c + a + d;

  int time_second = a + a + d + a + a;

  if (time_second < time_first) {
    return (time_first - time_second) / 2.0 + a; 
  } else {
   
    return (time_second - time_first) / 2.0 + a;
  }
}

int main() {
  int a, c, d;
  cin >> a >> c >> d;

  cout << fixed << setprecision(1) << find_border(a, c, d) << endl;
  return 0;
}