def find_border(a, c, d):
  """
  Функция для нахождения границы "border" для скорости B.

  Args:
    a: Время прохождения туннеля персонажем A.
    c: Время прохождения туннеля персонажем C.
    d: Время прохождения туннеля персонажем D.

  Returns:
    Граница "border" для скорости B.
  """
  
  # Время прохождения по первой стратегии
  first_strategy_time = a + a + c + a + d + a # Исправленное время первой стратегии 
  
  # Время прохождения по второй стратегии
  second_strategy_time = a + a + d + a + a
  
  # Находим границу
  border = (first_strategy_time - second_strategy_time) / 2
  
  return border

# Получение данных с консоли
a, c, d = map(int, input().split())

# Вывод результата
print(f"{find_border(a, c, d):.1f}")