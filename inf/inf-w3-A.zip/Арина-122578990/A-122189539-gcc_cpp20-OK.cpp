#include <iostream>
#include <iomanip>

int main() {
    int A, C, D;
    std::cin >> A >> C >> D;

    // Вычисляем границу
    double border = (C - A) / 2.0 + A;

    // Выводим результат с одним знаком после запятой
    std::cout << std::fixed << std::setprecision(1) << border << std::endl;

    return 0;
}
