a, b, c, d = sorted(map(int, input().split()))

border = b + d - 2 * a
if border <= 0:
    print(f"{b:.1f}")
else:
    print(f"{border / 2:.1f}")