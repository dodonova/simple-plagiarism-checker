q,w,e=map(int,input().split())
border=(q+w)*0,5
print(f"{border:.1f}")