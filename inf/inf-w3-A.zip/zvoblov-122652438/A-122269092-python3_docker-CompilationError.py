A, C, D = map(int, input().split())
border = (A + C) / 2
if border == int(border)
    print(border)
else:
    border = round(border, 1)
    print(border)