def find_border(start, end, unused):
    midpoint = (end - start) / 2 + start
    return midpoint

user_input = input().strip()
a_value, c_value, d_value = map(int, user_input.split())

result_border = find_border(a_value, c_value, d_value)
print(f"{result_border:.1f}")