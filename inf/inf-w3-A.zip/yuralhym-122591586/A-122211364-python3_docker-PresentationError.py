i = [int(a) for a in input().split()]
for b in range(1, 99):
    if b+i[0]+i[1]+i[0]+i[2]==b+i[0]+i[2]+b+b:
       print("%0.1f"%b)