import numpy as np
i = [int(a) for a in input().split()]
for b in np.arange(0, 9999, 0.1):
	if b+i[0]+i[1]+i[0]+i[2]==b+i[0]+i[2]+b+b:
		print(b)