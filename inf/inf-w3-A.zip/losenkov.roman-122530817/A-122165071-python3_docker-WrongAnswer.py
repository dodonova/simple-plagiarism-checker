def calculate_border(t_A, t_C, t_D):
    return (t_D - t_A) / 2.0

t_A, t_C, t_D = map(int, input().strip().split())

border = calculate_border(t_A, t_C, t_D)

print(f"{border:.1f}")