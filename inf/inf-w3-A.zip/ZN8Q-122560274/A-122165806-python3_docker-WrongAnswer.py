# Ввод данных
t_A, t_C, t_D = map(int, input().split())

# Расчет границы
border = t_C / 2

# Вывод с одним знаком после запятой
print(f"{border:.1f}")
