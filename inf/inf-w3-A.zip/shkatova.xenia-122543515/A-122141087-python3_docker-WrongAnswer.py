# Входные данные
import sys

# Читаем данные
line = sys.stdin.readline()
T_A, T_C, T_D = map(int, line.strip().split())

# Расчет границы для B
border = 2 * (T_D - T_A)

# Вывод результата с одним знаком после запятой
print(f"{border:.1f}")