A, C, D  = int(input("Введите три значения A C D. A<C<D<=100").split())
A = int(A)
C = int(C)
D = int(D)
B=(A+C)/2
print(B)
