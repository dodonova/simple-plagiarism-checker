#include <iostream>
#include <math.h>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,c,d;
    cin>>a>>c>>d;
    vector <int> r;
    r.push_back(a);
    r.push_back(c);
    r.push_back(d);
    sort(r.begin(),r.end());
    cout<<ceil((r[0]+r[1])/2)<<endl;
}