#include <iostream>
#include <math.h>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,c,d;
    cin>>a>>c>>d;
    cout<<(a+c)/2<<endl;
}