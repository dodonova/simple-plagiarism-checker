a,c,d = map(int,input().split())
b=(a+c)/2
print(f"{b:.1f}")