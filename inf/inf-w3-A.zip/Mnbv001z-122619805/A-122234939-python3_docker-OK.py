W, E, R = map(int, input(). split())
print(((W + E) / 2))