def find_border(times):
    ta, tc, td = times
    
    return td - ta

import sys
input = sys.stdin.read
lines = input().split()
times = list(map(int, lines))

print(find_border(times))