a, c, d = [float(n) for n in input().split()]
print((a+c) / 2)