using namespace std;
int main() {
    int a, b, c;
    cin >> a >> b >> c;
   
    double border = a + (b - a) / 2.0;
    
    cout << fixed << setprecision(1) << border << endl;
    return 0;
}