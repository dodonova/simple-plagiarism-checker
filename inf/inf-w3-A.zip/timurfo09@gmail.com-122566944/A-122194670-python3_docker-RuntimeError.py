a = int(input())
c = int(input())
d = int(input())
l = d / c + a
print(l)