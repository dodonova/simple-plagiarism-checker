a, c, d = list(map(int, input().split()))

bp= max([a,c,d])
border = 2

for b in range(1, bp):
    sp = [a,b,c,d]
    
    mnt1 = min(sp)
    sp.remove(mnt1)
    
    one = mnt1*2
    for spt in sp: one += spt

    mnt2 = min(sp)
    sp.remove(mnt2)
    
    mxt = max(sp)
    
    two = mnt2 + mnt1 + mxt + 2*mnt2
    
    delta = one - two

    if delta >= 0:
        border = b+1
    else:
        break
print(border)