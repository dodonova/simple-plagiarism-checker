def max_weaving_area(n, lengths):
    
    lengths.sort()
    
   
    max_length_yellow = lengths[-1]  
    max_length_green = lengths[-2]   
    
    
    max_area = max_length_yellow * max_length_green
    
    return max_area


n = int(input())
lengths = list(map(int, input().strip().split()))


result = max_weaving_area(n, lengths)
print(result)