a=input().split()
S=(int(a[1])-int(a[0]))//2
print(S+int(a[0]))
