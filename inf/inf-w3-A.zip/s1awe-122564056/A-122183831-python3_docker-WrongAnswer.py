def find_border(a, c, d):
    # Total time strategy 1
    time_strat_1 = (a + c + d) + (2 * a) # by substituting B with a max as per traditional

    # Comparing border and equality
    b = (time_strat_1 - 2 * a) / 2

    return b

# Input reading
a, c, d = map(int, input().split())

# Get the border
result = find_border(a, c, d)

# Print with one digit after the decimal
print(f"{result:.1f}")