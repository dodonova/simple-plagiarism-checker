def find_border(A, C, D):
    border = 2 * A
    return border

# Чтение входных данных
A, C, D = map(int, input().split())

# Находим границу
result = find_border(A, C, D)

# Вывод результата с одним знаком после запятой
print(f"{result:.1f}")
