b=input()
b=b.split(' ')
a=int(b[0])
d=int(b[1])
c=int(b[2])
for i in range(10000000000000):
    if d-i<i-a:
        print(i-1)
        break
