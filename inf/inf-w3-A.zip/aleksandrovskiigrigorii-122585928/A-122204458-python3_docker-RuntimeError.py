a = input()
b = 0
while b*2<d-a-a-b:
    b=b+1
print(b)
