a, c, d = map(int,input(). split())
if (a+c)%2==0:
    print((a+c)/2)
else:
    print((a+c)//2+1)