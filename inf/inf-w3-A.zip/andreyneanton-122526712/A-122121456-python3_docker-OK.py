a, c, d = map(int,input(). split())
print((a+c)/2)
