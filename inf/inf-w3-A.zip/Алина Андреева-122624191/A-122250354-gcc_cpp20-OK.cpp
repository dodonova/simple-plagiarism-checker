#include <iostream>
#include <iomanip>
#include <fstream>
#include <optional>
#include <tuple>

std::optional<std::tuple<int, int, int>> read_input(std::istream& in) {
    int A, C, D;
    if (in >> A >> C >> D && A >= 1 && C >= 1 && D >= 1 && A <= C && C <= D && D <= 100) {
        return std::make_tuple(A, C, D);
    }
    return std::nullopt;
}

constexpr double calculate_border(int A, int C) {
    return (A + C) / 2.0;
}

int main(int argc, char* argv[]) {
    std::ifstream infile("input.txt");
    std::ofstream outfile("output.txt");

    std::istream& input_stream = infile.is_open() ? infile : std::cin;
    std::ostream& output_stream = outfile.is_open() ? outfile : std::cout;

    auto data = read_input(input_stream);
    if (!data) {
        output_stream << "Invalid input data" << std::endl;
        return 1;
    }
    auto [A, C, D] = *data;
    double border = calculate_border(A, C);
    output_stream << std::fixed << std::setprecision(1) << border << std::endl;

    return 0;
}