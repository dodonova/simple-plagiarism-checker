A,C,D=map(int,input().split())
Min=min(a,b,c)
Max=max(a,b,c)
medium=(Max-Min)/2
border=(Min+medium)/2
print(round(border))