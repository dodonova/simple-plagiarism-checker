#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    int tA, tC, tD;
    cin >> tA >> tC >> tD;
    double border = (tD - tA) / 2.0 + tA;
    cout << fixed << setprecision(1) << border << endl;
    return 0;
}
