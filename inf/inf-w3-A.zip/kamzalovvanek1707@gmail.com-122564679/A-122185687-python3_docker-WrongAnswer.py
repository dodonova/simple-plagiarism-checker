A, C, D = map(int,input().split())
border = (A + C) / 2
if border.is_integer:
    print (int(border))
else:
    print(f"{border:.1f}")