a, c, d = map(int, input().split())
print(f"{(c + a) / 2:.1f}")
