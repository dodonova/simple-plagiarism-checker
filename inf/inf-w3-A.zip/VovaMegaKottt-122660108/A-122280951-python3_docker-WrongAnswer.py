a,c,d=map(int, input().split())
b=round((c+d)/2)
print(b)