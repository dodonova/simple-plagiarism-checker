using System;

class Program
{
    static void Main()
    {
        // Ввод времени прохождения туннеля персонажами A, C и D
        string input = Console.ReadLine();
        string[] times = input.Split(' ');
        
        // Преобразование входных данных в целые числа
        int t_A = int.Parse(times[0]);
        int t_C = int.Parse(times[1]);
        int t_D = int.Parse(times[2]);

        // Вычисление границы для B
        double border = 2.0 * t_A - t_C;

        // Вывод результата с одним знаком после десятичной точки
        Console.WriteLine($"{border:F1}");
    }
}