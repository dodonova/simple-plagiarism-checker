a, c, d = map(int, input().split())
time1 = 2 * a + c + d 
time2 = 2 * a + 2 * c + d
b = (time2 - time1) / 2 + a
print(int(b))