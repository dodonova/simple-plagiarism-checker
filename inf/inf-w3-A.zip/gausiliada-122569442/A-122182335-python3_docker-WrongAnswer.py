def calculate_border(A, C, D):
    return round((D - A) / 2 + A, 1)
A, C, D = map(int, input().split())
border = calculate_border(A, C, D)
print(border)