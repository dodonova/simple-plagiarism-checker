string = input()
spisok = list(map(int, string.split(' ')))
border = max(spisok) / 3
return(round(border,1))