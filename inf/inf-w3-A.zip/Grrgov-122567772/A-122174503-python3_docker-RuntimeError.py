A = float(input())
C = float(input())
D = float(input())

border = (A + C) / 2
print(border)