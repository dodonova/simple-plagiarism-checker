def find_border(a, c, d):

    time_strategy1 = a + a + c + a + d

    time_strategy2 = a + a + d + a + a

    border = (time_strategy1 - time_strategy2) / 2

    return border

a = int(input())

c =  int(input())

d =  int(input())

border = find_border(a, c, d)

print(border)