def find_border(A, C, D):
    # Вычисляем границу B
    border = (C + A) / 2
    return border

# Ввод данных
A, C, D = map(int, input("Введите три целых числа, разделённых пробелами: ").split())

# Вычисляем границу
border = find_border(A, C, D)

# Выводим результат с одним знаком после десятичной точки
print('%.1f' % border)