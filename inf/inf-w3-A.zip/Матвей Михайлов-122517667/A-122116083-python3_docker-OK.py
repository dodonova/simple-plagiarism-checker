def main():
    q, c, r = map(int, input().split())
    a1 = c+q
    gr = a1 / 2
    print(gr)


if __name__ == '__main__':
    main()
