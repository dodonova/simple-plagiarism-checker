def find_border(a, c, d):
    return int(a + (c / 2))
a, c, d = map(int, input().split())
print(f"{find_border(a, c, d)}")  
