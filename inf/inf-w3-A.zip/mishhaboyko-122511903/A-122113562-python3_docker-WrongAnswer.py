A, C, D = map(int, input().split())
h = A + C + D + 2 * A
n = (C + D) / 2
print(f"{n:.1f}")
