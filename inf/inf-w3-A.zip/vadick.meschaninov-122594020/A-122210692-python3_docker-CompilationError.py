x=int(input())
y=int(input())
z=int(input())
d=int(input())
w=0
x1=abs(abs(x-y)-z)
x2=abs(abs(x-z)-y)
x3=abs(abs(y-z)-x)
varss=[x1-d,x2-d,x3-d]
x=min(varss)
print(0) if (varss[0] <= 0 or varss[1] <= 0 or varss[2] <=0)
         else:
         print(min(varss))