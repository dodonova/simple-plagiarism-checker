A, C, D = map(int, input().split())
border = (C + D) / 2
print("{:.1f}".format(border))