#include <iostream>

using namespace std;

int main() {
    int a, c, d;
    cin >> a >> c >> d;
    cout << (float)(c+a)/2 << endl;

    return 0;
}