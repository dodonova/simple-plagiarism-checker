A, C, D = map(int, input().split())
border = (2 * A + D) - C
print(f"{border:.1f}")