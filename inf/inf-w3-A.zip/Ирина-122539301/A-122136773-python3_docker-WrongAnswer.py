
a, c, d = map(int, input().split())

time_first = a + a + c + a + d

time_second = a + a + d + a + a

border = (time_first - time_second) / 2

print(f"{border:.1f}")


