A,C,D = map(int, input().split())
x=(a+c+1)
print(x // 2)