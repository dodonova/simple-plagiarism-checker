
def find_border(a, c, d):
    return (c - a) + (d - c) / 2

a, c, d = map(int, input().split())

border = find_border(a, c, d)
print(f"{border:.1f}")