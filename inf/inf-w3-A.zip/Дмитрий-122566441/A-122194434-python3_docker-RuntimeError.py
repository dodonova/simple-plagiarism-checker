A, C, D = map(int, input().split())

time_strategy_1 = A + C + D + 2 * A

time_strategy_2 = (C + D + 2 * B) if (B < C) else float('inf')

border = (time_strategy_1 - time_strategy_2) / 2 if time_strategy_2 < float('inf') else C

#.
print(round(border, 1))