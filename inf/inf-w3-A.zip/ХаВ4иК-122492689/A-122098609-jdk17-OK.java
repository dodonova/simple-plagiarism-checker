import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int t_A = scanner.nextInt();
        int t_C = scanner.nextInt();
        int t_D = scanner.nextInt();

        scanner.close();

        double border = (t_C + t_A) / 2.0;

        System.out.printf("%.1f\n", border);
    }
}
