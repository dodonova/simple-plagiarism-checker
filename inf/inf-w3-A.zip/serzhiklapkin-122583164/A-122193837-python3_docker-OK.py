mahito, klaus, kinder= map(int, input().strip().split())
chacha = (klaus-mahito)/2 + mahito
print(f"{chacha:.1f}")