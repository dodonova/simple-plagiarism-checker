# Read input
A, C, D = map (int,
input().strip() split())
# Compute the border
border = (C + D - 2 * A) / 2
# Output the result with one decimal place
print (f"{border:.1f}")