import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class TunnelCrossing {
    public static void main(String[] args) {
        // Чтение данных через Scanner
        Scanner scanner = new Scanner(System.in);
        List<Integer> times = List.of(scanner.nextInt(), scanner.nextInt(), scanner.nextInt());

        // Извлечение времени C через Optional
        Optional<Integer> cTime = times.stream().skip(1).findFirst();

        // Вывод результата
        cTime.ifPresent(c -> System.out.printf("%.1f\n", (float) c));
    }
}