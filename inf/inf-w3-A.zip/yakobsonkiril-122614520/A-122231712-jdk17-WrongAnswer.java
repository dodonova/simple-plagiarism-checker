import java.util.Scanner;

public class TunnelCrossing {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Чтение входных данных
        int A = scanner.nextInt();
        int C = scanner.nextInt();
        int D = scanner.nextInt();

        // Граница равна времени C
        System.out.printf("%.1f\n", (float) C);
    }
}