a, c, d = input().split()
a = int(a)
c = int(c)
b = (a+c)/2
board = round(b, 2)
print(board)
