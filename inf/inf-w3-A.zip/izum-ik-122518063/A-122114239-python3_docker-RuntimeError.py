d = [int(i) for i in input().split()]
a = d[0]
c = d[1]
d = d[2]

m  = (a+c)/2

if m == int(m):
	print(int(m))
else:
	print("{:.3f}".format(str(m)))