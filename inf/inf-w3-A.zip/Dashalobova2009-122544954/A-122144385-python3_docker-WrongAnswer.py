A, C, D = map(int, input().split())
border = D - C + A
print(f"{border:.1f}")
