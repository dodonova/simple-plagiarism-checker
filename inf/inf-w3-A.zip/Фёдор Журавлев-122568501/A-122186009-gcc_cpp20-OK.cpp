#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    int A, C, D;
    cin >> A >> C >> D;

   
    double border = A + (C - A) / 2.0;

    
    cout << fixed << setprecision(1) << border << endl;

    return 0;
}