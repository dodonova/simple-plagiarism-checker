abcd0=input()
abcd=abcd0.split()
a=int(abcd[0])
c=int(abcd[1])
border = (a+c)//2
print(border)