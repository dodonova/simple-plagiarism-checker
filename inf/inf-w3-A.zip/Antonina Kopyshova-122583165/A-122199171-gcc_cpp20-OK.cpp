#include <iostream>

using namespace std;

int main()
{
    int a, c, d;
    cin >> a >> c >> d;
    
    cout << float(float(int(float((float(a) + float(c)) / 2) * 10))/10) ;

    return 0;
}