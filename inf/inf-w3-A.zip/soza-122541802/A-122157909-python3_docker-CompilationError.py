A, C, D = map(int, input("Enter 3 number A C D:").split())
borderB = (D - C)/2
print(f{"borderB:.1f}")