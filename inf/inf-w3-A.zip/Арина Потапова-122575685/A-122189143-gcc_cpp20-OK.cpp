#include <iostream>
#include <iomanip>

int main() {
    int A, C, D;
    std::cin >> A >> C >> D;
    double border = (A + C) / 2.0;
    std::cout << std::fixed << std::setprecision(1) << border << std::endl;
    return 0;
}