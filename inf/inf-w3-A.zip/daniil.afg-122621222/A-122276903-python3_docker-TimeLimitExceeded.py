i = 0
while True:
    print(i)
    i+=1
    continue