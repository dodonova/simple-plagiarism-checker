a = int(input()) 
c = int(input()) 
b = a + c 
b = b/2 
Print (b)