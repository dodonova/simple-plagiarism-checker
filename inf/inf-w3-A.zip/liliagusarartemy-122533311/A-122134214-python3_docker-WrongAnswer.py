g = input()
a, c, d = g.split()
a = int(a)
c = int(c)
d = int(d)
B = 0
for b in range(c-a):
    if b + a + c + a + d == b + a + d + b + b:
        B = b
print(B)