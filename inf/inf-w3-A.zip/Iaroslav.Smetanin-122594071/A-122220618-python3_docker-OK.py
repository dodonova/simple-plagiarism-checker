A,C,D = map(int, input().split())
B = 0
X = 0
for i in range((A + 1),C):
    B = i
    if (A + C + D) >= (D + B + B):
        X = i
    i = i + 1
while round((X + A + C + A + D), 1) != round((X + A + D + X + X), 1):
    X = X + 0.001
print(round(X, 1))