A,C,D = map(int, input().split())
for i in range((A + 1),C):
    B = i
    if (A + C + D) >= (D + B + B):
        X = i
    i = i + 1
print(round(X, 1))