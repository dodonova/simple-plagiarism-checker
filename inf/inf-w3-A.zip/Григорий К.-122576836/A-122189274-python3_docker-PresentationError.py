a,c,d = input().split()
a = int(a)
c = int(c)
d = int(d)
b = a + 0.05
while b <= c:
    M = [a,b,c,d]
    t = 2*M[1] - M[0] - M[2]
    if t >= 0:
        B = str(b)
        print(B+"0"*(1-len(B.split(".")[1])))
        break
    b += 0.05