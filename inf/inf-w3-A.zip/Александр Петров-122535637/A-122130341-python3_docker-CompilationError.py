def calculate_border(A, C, D):
    
    def first_strategy(B):
        return B + A + C + A + D

   
    def second_strategy(B):
        return 2 * (B + A) + D

   )
    border = (C + D + A) / 2.0

    print(f"{border:.1f}")

A, C, D = map(int, input("Enter A, C, D: ").split())
calculate_border(A, C, D)