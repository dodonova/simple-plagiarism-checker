A, C, D = map(int, input().split())

Boredr = (A + C) // 2

print(Boredr)