A, C, D = map(int, input())

Bored = (A + C) // 2

print(Bored)