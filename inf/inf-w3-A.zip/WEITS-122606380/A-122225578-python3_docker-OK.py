A, C, D = map(int, input().split())
print((C+A)/2)