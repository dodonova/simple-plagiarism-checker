a,c,d=list(map(int, input().split()))
b=(c+a)/2
print(b)
