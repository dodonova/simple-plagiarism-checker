A, C, D = map(int, input().split())
border = (D - A + 1) / 2
print(f"{border:.1f}")