a,c,d = map(int,input().split())
b = 0
for i in range(500):
    s = 0
    s1 = 0
    if a > i:
        s+=a*2
        s1 += a*2
    else:
        s+= a+i
        s1+= a+i
    if a > c:
        s+= a*2
    else:
        s+= a+c
    if a > d:
        s+= a
    else:
        s+= d
    if c>d:
        s1+=c+i
    else:
        s1+=d+i
    if a>i:
        s1+=a
    else:
        s1+=i
    if s == s1:
        b = i
print(b)