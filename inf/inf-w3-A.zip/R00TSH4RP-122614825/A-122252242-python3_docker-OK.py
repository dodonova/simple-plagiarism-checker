num_list = list(map(int, input().split()))
num_list.sort()
a, c, d = num_list

print((a + c) / 2)