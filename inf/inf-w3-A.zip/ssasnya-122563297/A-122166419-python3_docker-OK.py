amogus, abobus, avtobus = map(int, input().split())

bober = (abobus + amogus) / 2 #это моя супер бомба пушка формула бро

print(f"{bober:.1f}") #это мой супер крутой результат йооооооу
