a, b, c = list(map(float, input().split()))
print((a + c) / 2)