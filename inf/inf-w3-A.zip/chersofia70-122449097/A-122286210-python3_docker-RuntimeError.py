def  poshitaem_granicu(vremya):
    a,c,d=vremya
    border=((a+c)/2)
    
    return round(border,1)



v_vremya=input().strip().split()
vremya=list(map(int,input_vremya))
border=poshitaem_granicu(vremya)



print(border)