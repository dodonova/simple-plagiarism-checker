def find_border(a, c, d):

  time1 = a + a + c + a + d 
 
  time2 = a + a + d + a + a

  border = (time1 - time2) / 2.0

  return border
a, c, d = map(int, input().split())

print(find_border(a, c, d))