A,B,C = list(map(int,input().split()))
D = float((A+B)/2)*10
print(float(round(D))/10)
