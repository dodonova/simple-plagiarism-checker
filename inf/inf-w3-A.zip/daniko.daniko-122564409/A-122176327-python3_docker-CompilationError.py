def find_border(A, C, D):
    # Вычисляем границу border = (C + D - A) / 2 return round(border, 1)

# Считываем входные данные
A, C, D = map(int, input().strip().split())

# Вычисляем границу
border = find_border(A, C, D)

# Выводим результат
print(border)
