#include <iostream>
#include <cmath>
using namespace std;
int main(){
	int a, c, d;
	cin>>a>>c>>d;
	if ((a+c)% 2 != 0)
    	a++;
	cout<<(a+c)/2;
}