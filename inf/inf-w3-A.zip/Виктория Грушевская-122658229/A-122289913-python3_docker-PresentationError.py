s, t, o = map(int, input().split())
for b in range(2**13):
    if b == (s+t)/2:
        b = float('{:.1f}'.format(b))
        print(b)