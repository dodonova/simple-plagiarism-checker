s = input().split()
a = int(s[0])
c = int(s[1])
d = int(s[2])

b = (c + d + a - max(c,d))/2

print(b)