a, c, d = map(int, input().split())
b = a
v1 = 2 * a + b + c + d
v2 = a + 3 * b + d
while v1 > v2:
    b += 1
    v1 = 2 * a + b + c + d
    v2 = a + 3 * b + d
print(b)
