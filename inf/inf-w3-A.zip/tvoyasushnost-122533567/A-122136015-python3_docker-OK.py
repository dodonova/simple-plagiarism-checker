a,c,d=map(int,input().split())
past=0
for i in range(1,1001):
    if max(c,d)+i/10+max(a,i/10)>max(a,c)+a+max(a,d):
        print(f'{past:.1f}')
        break
    else:
        past=i/10