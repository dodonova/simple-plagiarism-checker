class TunnelCrossing:
    def __init__(self, A, C, D):
        self.A = A
        self.C = C
        self.D = D
    
    def calculate_border(self):
        """
        Вычисляет границу для B, ниже которой
        используется вторая стратегия.
        """
        return (self.C - self.A) + (self.D - self.C) / 2

def main():
    # Чтение входных данных
    A, C, D = map(int, input().strip().split())
    
    # Создание экземпляра класса
    crossing = TunnelCrossing(A, C, D)
    
    # Вычисление границы для B
    border = crossing.calculate_border()
    
    # Вывод результата с одним знаком после десятичной точки
    print(f"{border:.1f}")

if __name__ == "__main__":
    main()
