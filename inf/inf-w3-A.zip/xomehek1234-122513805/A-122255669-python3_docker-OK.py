A, C,D = list(map(int,input().split()))
print(float((A + C) / 2))
