a, c, d = map(int, input().split())

# Время для первой стратегии
time1 = a + a + c + a + d

# Время для второй стратегии
time2 = a + a + d + a + a

# Граница для B
border = (time1 - time2) / 2

print(border)