a,c,d=map(int,input().split())
b=0
for i in range(a,c):
	if (a+a+i+c+d)>(i+a+d+i+a):
		b=i
print(b)