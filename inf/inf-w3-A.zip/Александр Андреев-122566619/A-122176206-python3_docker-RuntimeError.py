a,c,d=map(int,input().split())
s=a+c+d
a=min(a,c,d)
d=max(a,c,d)
c=s-a-d
b=0
for i in range(a,c,(0.01)):
	if (a+a+i+c+d)>(i+a+d+i+a):
		b=i
print(b)