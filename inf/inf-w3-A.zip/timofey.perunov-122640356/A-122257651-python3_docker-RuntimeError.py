def find_border(A, C, D):
    # Calculate the border value based on the given times
    # Since A, C, D are given in non-decreasing order and A <= B <= C <= D,
    # the border is defined as (A + C) / 2
    border = (A + C) / 2
    return border

def main():
    # Input the times for A, C, D
    try:
        A, C, D = map(int, input().split())
        if A < 1 or C < 1 or D < 1 or A > 100 or C > 100 or D > 100:
            return
        if A > C or C > D:
            return
    except ValueError:
        return

    # Calculate and print the border
    border = find_border(A, C, D)
    print(border)

if name == "main":
    main()