a,b,c = map(int,input().split())
awd = a/2 + b/2
print(f'{awd:.1f}')