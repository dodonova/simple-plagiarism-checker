import sysimport threading
def main():    import sys
    import math    from collections import Counter
    sys.setrecursionlimit(1000000)    s = input().strip()
    n = int(input())    words = [input().strip() for _ in range(n)]
    total_counts = Counter(s)    word_counts = []
    for word in words:        cnt = Counter(word)
        word_counts.append((word, cnt))    word_counts.sort()
    res = []    found = False
    def dfs(remaining_counts, start, selected_words):        nonlocal found
        if found:            return
        if sum(remaining_counts.values()) == 0:            if 5 <= len(selected_words) <=8:
                selected_words.sort()                for w in selected_words:
                    print(w)                found = True
            return        if len(selected_words) >=8:
            return        for i in range(start, len(word_counts)):
            word, cnt = word_counts[i]            can_use = True
            for ch in cnt:                if cnt[ch] > remaining_counts.get(ch, 0):
                    can_use = False                    break
            if not can_use:                continue
            new_remaining = remaining_counts.copy()            for ch in cnt:
                new_remaining[ch] -= cnt[ch]                if new_remaining[ch] == 0:
                    del new_remaining[ch]            dfs(new_remaining, i+1, selected_words + [word])
            if found:                return
    dfs(total_counts, 0, [])threading.Thread(target=main).start()