#include <bits/stdc++.h>
using namespace std;

int main() {
    int a, b,c;
	cin >> a >> b >> c;
    cout << (min(min(a, b), min(c, b)) * 3) + max(a, b) + max(b, c);
}
