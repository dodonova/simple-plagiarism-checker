
def read() -> list:
    return list(map(int, input().split()))


def main():
    a, c, _ = read()
    print(a+c/2.0)


if __name__ == '__main__':
    main()