# Ввод данных
t_a, t_c, t_d = map(int, input().strip().split())

# Вычисление границы
border = (t_d - t_a) / 2 + t_a

# Вывод результата с одним знаком после десятичной точки
print(f"{border:.1f}")