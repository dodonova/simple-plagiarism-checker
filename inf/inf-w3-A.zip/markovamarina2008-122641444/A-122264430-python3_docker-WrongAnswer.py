def calculate_border(a, c, d):
    for border in range(c, a - 1, -1):
        if a + d + 3 * border < border + 2 * a + c + d:
            border = border + 1
            break
    return border

a, c, d = map(int, input().split())
border = calculate_border(a, c, d)
print(border)

