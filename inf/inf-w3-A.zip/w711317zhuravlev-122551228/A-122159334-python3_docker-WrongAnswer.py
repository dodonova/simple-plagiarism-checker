# Считываем входные данные
try:
    t1, t2, t3 = map(int, input().strip().split())
except ValueError:
    print("Ошибка: необходимо ввести три целых числа.")
    exit(1)

# Вычисляем границу border
border = (2 * t2 + t1) / 2

# Выводим результат с одним знаком после десятичной точки
print(f"{border:.1f}")