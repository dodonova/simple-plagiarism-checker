a, b, c = map(int, input().split())

# Вычисляем границу
border = a - b

# Выводим результат с одним знаком после десятичной точки
print(f"{border:.1f}")