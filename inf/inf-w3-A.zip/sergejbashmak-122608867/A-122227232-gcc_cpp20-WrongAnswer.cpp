#include <iostream>
#include <iomanip>

int main() {
    int t_A, t_C, t_D;
    std::cin >> t_A >> t_C >> t_D;
    double border = static_cast<double>(t_C - t_A);
    std::cout << std::fixed << std::setprecision(1) << border << std::endl;

    return 0;
}