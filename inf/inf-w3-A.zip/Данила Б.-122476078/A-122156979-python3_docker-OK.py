arr = [int(i) for i in input().split(" ")]
arr.sort()
A = arr[0]
C = arr[1]
D = arr[2]

print((C+A)/2)