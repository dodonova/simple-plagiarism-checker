A , C , D = map(int,(input().split()))
B = 100
one = C + A
to = B + B


for i in range(0,B):
    to = 2*float(i)
    if to == min(one,to):
        L = i
    i += 0.1
print(L)
        
    
    