a = int(input())
c = int(input())
d = int(input())
b = 0
x = d + c + a + a
y = d + a
while x != y:
    x += b
    y += 3 * b
    b += 1
print(b)