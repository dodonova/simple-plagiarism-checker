def get_border(a, c):
    left = a
    right = c
    while right - left > 0.001:
        mid = (left + right) / 2
        if mid >= (a + c) / 2:
            right = mid
        else:
            left = mid
    return right
a, c, d = map(int, input().split())
print(get_border(a, c))