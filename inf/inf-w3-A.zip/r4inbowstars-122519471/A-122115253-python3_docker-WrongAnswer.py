time_A, time_C, time_D = map(int, input().split())

border = (time_A + time_D - time_C) // 2

print(border)
