A_str, C_str, D_str = input().split()
A = int(A_str)
C = int(C_str)
border = (A + C) / 2
if border == int(border):
    print(int(border))
else:
    print(f"{border:.1f}")