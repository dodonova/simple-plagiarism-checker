a = int(input())c = int(input())
d = int(input())b = 0
while b != c:    b += 1
    if b + a + c + a + d < b + a + d + b + b:        print(b-1)
        break