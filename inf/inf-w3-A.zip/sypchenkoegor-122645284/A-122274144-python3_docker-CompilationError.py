def calculate border(times):

	Z, V, O = times
    
    border = (Z + V) / 2
    
    return round(border, 1)
    
input_times = input().strip().split()
times = list(map(int, input_times))


border = calculate_border(times)
print(border)