a, c, d = map(int, input().split())
for i in range(a, c + 1):
    if c + a * 2 <= a + 2 * i:
        print(i)
        break