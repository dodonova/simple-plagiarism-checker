a = int(input())
c = int(input())
b = int(input())
if c%2 == 0:
	border = c//2
else:
	border = (c//2) + 1
print(border)