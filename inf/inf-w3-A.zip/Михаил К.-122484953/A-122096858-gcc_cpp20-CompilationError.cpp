a,c,d=map(int,input().spplit())
print((a+c)/2)