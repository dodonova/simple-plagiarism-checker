A, C, D = map(int, input().split())
time_first_strategy = A + C + D + 2 * A  
time_second_strategy = 2 * A + D + C  
granica = (C + A)/2
print(granica)