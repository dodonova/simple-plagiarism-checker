def calculate_border(a, c, d):
    border = (d - a) / 2 + a
    return round(border, 1)
a, c, d = map(int, input().split())
result = calculate_border(a, c, d)
print(result)