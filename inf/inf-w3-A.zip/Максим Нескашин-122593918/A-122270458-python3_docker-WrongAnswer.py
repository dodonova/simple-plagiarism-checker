from random import randint
A = input()
print(randint(1, 10))