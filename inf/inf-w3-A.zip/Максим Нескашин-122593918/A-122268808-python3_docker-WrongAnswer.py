def find_border(A, C, D):
    border = (C - A + D + 3 * A) / 2
    return border

A, C, D = map(int, input().split())

border = find_border(A, C, D)

print(f"{border:.1f}")