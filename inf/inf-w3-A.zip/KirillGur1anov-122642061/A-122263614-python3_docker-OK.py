a, c, d = map(int, input().split())

bord = c - a
bord = bord / 2 + a

print(bord)