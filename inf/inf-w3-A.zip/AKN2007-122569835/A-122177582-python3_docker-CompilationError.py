def min_time_to_cross(a, b, c):
    times = sorted([a, b, c])
    
    A, B, C = times

    time1 = A + B + A + C

    
    time2 = A + C + A + B

   
    return min(time1, time2)


input_data = input()
a, b, c = map(int, input_data.split())


result = min_time_to_cross(a, b, c)


border = result - 1  


print(, border)


