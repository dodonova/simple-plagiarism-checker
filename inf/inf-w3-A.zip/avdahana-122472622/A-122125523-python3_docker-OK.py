def find_border(a, c, d):
    border = (a + c) / 2
    return round(border, 1)

a, c, d = map(int, input().split())

print(find_border(a, c, d))