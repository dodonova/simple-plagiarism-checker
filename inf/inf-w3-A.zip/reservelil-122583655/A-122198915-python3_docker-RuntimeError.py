a = int(input())
c = int(input())
d = int(input())

border = (a + c) / 2

print(f"{border:.1f}")