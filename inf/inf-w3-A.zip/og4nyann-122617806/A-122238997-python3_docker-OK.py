def strateg_1(a, b, c, d):
    return max(a, b) + a + max(a, c) + a + max(a, d)

def strateg_2(a, b, c, d):
    return max(a, b) + a + max(c, d) + b + max(a, b)

def border(a, c, d):
    left = a  
    right = c  
    
    for _ in range(100):
        b = (left + right) / 2
        time1 = strateg_1(a, b, c, d)
        time2 = strateg_2(a, b, c, d)
        if abs(time1 - time2) < 1e-10: 
            break
        elif time1 > time2:
            right = b
        else:
            left = b
    return round(b, 1)

def main():
    a, c, d = map(int, input().split())
    result = border(a, c, d)
    print(result)

if __name__ == "__main__":
    main()