A, C, D = map(int, input().strip().split())
border = (A + C) / 2
print(f"{border:.1f}")