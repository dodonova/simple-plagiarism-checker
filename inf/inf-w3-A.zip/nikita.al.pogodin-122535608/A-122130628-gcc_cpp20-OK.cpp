#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    double a, c, d;
    cin >> a >> c >> d;
    cout << (a+c)/2.0;
}