#include <iostream>
#include <iomanip>

using namespace std;


int main() {
    int a, c, d;
    cin >> a >> c >> d;
    
    double h = (a + b) / 2.0;
    
    cout << fixed << setprecision(1) << h;

    return 0;
}