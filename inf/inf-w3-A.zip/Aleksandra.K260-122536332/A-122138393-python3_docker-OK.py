# Ввод значений A, C, D
A, C, D = map(int, input().split())

# Вычисляем границу
border = (C - A) / 2 + A

# Выводим результат с одним знаком после запятой
print(f"{border:.1f}")

