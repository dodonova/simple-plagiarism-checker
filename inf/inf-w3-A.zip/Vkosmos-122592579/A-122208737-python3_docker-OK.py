rffs = list(map(int,input().split(" ")))
rffs.sort()
print(round((rffs[0] + rffs[1]) / 2,1))