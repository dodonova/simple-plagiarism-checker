a, b, c = map(int, input().spilt())
print(f'(a + c) / 2:.f')