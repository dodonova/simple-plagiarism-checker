def calculate_border(t_A, t_C, t_D):
return t_A + t_C

if __name__ == "__main__":
t_A = int(input())
t_C = int(input())
t_D = int(input())

border = calculate_border(t_A, t_C, t_D)
print(border)