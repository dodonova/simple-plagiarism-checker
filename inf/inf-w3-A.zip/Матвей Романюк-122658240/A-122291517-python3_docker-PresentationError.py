a, c, d = map(int, input().split())

def calculate_time(first, second, third, b_time):
    
    time_1 = first + second + third + second + first
    
    time_2 = first + second + third + b_time + second
    return time_1, time_2

def find_border(a, c, d):
    
    border = float('inf')
    
    
    for b_time in range(1, 101):
        time_1, time_2 = calculate_time(a, b_time, c, d)
        
        if time_2 < time_1: 
            border = min(border, b_time)
    
    return border




border = find_border(a, c, d)
print(border)