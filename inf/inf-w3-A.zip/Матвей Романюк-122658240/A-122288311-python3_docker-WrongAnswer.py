def calculate_border(t_A, t_C):
       return t_A + t_C

if __name__ == "__main__":
    t_A, t_C, t_D = map(int, input().split())
    border = calculate_border(t_A, t_C)
    print(border) 