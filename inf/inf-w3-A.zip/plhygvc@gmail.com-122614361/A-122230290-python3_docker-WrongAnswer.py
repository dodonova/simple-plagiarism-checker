def find_border(A, C, D):
    border = 2 * A
    return round(border, 1)

# Считываем входные данные
input_data = input()
A, C, D = map(int, input_data.split())

# Выводим результат
print(find_border(A, C, D))