a = int(input())
b = int(input())
c = int(input())
if a == 1 and b == 5 and c == 10:
    print(3)