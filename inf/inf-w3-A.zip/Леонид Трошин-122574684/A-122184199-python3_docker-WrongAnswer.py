def find_border(a, c, d):  
    return float(2 * c - a)  

# Чтение входных данных  
a, c, d = map(int, input().split())  

# Нахождение границы  
border = find_border(a, c, d)  

# Печать результата с одной цифрой после запятой  
print(f"{border:.1f}")  
