A1,C1,D1=map(int,input().split())
border=(C1+A1)/2
print(f"{border:.1f}")