a, c, d = list(map(int, input().split()))
border = round((a+c)/2, 1)

print(border)