a, c, d = input().split()
c = int(c) * 0.6
print(c)