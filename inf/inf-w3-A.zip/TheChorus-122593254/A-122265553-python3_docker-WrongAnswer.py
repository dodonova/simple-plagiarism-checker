def min_time_to_cross_tunnel(A, C, D):
    # Сортируем время прохождения туннеля
    times = [A, C, D]
    times.sort()
    
    # Задаем начальное значение границы
    border = 2 * times[1] - times[0]
    
    return border

# Пример использования
A = 1
C = 5
D = 10

border = min_time_to_cross_tunnel(A, C, D)
print(border)