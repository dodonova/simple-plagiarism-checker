a, c, d = map(int, input().split())
b = a
for _ in range(a, 100):
	if b+a+d+b+b == b+a+c+a+d:
		break
	else:
		b += 1
print(b)