A,C,D=map(int,input().split())
border=(A+C)/2
print(border)