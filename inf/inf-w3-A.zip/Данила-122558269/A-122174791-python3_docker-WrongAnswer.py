def find_border(A, C, D):
    # Вычисляем границу для B
    border = (2 * A - C)
    return border

def main():
    import sys
    input = sys.stdin.read
    data = list(map(int, input().strip().split()))
    
    A, C, D = data
    
    # Находим границу
    border = find_border(A, C, D)
    
    # Выводим результат с одним знаком после десятичной точки
    print(f"{border:.1f}")

if __name__ == "__main__":
    main()