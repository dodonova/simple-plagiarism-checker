#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    int A, C, D;
    cin >> A >> C >> D;
    double border = (C + A) / 3.0;
    cout << fixed << setprecision(1) << border << endl;
    return 0;
}
