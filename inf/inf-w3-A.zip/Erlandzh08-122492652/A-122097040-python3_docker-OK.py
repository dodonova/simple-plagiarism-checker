a, b, c = map(int, input().split())
v = a + b
print(v/2)