using System;

class Program
{
    static void Main()
    {
        // Считываем времена A, C и D
        string[] input = Console.ReadLine().Split();
        double A = double.Parse(input[0]);
        double C = double.Parse(input[1]);
        double D = double.Parse(input[2]);

        // Вычисляем границу для B
        double border = (A + C) / 2 + D;

        // Выводим результат с одним знаком после десятичной точки
        Console.WriteLine($"{border:F1}");
    }
}