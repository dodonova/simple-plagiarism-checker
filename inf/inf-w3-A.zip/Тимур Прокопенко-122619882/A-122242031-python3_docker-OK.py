a, c, d = map(int, input().split())
x = (a + c)/2
x = float('{:.1f}'.format(x))
print(x)

