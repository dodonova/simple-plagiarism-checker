a, c, d = map(int,input().split())
v = c+a
if v%2!=0:
    print((v+1)//2)
else:
    print((c+a)//2)