A=int(input())
C=int(input())
D=int(input())
bord =(A+C)/2
print(f"{int(bord) if bord.is_integer() else bord}")