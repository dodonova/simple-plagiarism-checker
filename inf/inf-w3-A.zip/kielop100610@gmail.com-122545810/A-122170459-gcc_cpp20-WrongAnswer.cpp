#include <iostream>
#include <iomanip>

int main() {
    int t_a, t_c, t_d;
    
    // Считываем входные данные
    std::cin >> t_a >> t_c >> t_d;
    
    // Вычисляем границу для B
    double border = (t_a + t_d) / 2.0;

    // Выводим результат с одним знаком после десятичной точки
    std::cout << std::fixed << std::setprecision(1) << border << std::endl;

    return 0;
}