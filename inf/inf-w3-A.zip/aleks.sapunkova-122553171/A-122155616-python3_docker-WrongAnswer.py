def calculate_border(t_a, t_c, t_d):
    border = (t_d + t_c - 2 * t_a) / 2
    return border

# Считываем входные данные
input_data = input().strip()
t_a, t_c, t_d = map(int, input_data.split())

# Находим границу
border_value = calculate_border(t_a, t_c, t_d)

# Выводим результат с одним знаком после десятичной точки
print(f"{border_value:.1f}")
