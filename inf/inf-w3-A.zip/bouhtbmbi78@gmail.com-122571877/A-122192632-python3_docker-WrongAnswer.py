def calculate_times(t_A, t_B, t_C, t_D):
    T1 = 2 * t_A + 2 * t_B + t_D
    T2 = 2 * t_B + t_A + t_D
    return T1, T2

t_A1, t_B1, t_C1, t_D1 = 1, 4, 5, 10
T1_1, T2_1 = calculate_times(t_A1, t_B1, t_C1, t_D1)


t_A2, t_B2, t_C2, t_D2 = 1, 2, 5, 10
T1_2, T2_2 = calculate_times(t_A2, t_B2, t_C2, t_D2)


def find_border(t_A, t_C):
    return (t_C - t_A) / 3
print(min(find_border(t_A1, t_C1), find_border(t_A2, t_C2)))