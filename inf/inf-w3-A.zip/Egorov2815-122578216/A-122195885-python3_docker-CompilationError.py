// Read input
const input = prompt("Enter A, C, D separated by spaces:");
const [A_str, C_str, D_str] = input.split(" ");
const A = parseInt(A_str);
const C = parseInt(C_str);
const D = parseInt(D_str);

// Compute the border
const border = (A + C) / 2;

// Output the result with one decimal place
console.log(border.toFixed(1));