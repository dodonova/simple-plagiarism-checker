a, c, d = [*map(int, input().split())]
border = (a + c) / 2
print(f"{border:.1f}")