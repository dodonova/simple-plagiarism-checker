def find_dimensions(a, b):
    s = (a // 2) + 2
    for n in range(1, s // 2 + 1):
        m = s - n
        if n * m == b + s - 1:
            return n, m return None
a, b = map(int, input().strip().split())
n, m = find_dimensions(a, b)
print(n, m)