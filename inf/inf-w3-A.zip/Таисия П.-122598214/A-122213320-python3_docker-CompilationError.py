import math

a, b = map(int, input().split())
d = a * a - 16 * b
k = d // 4
sqrt_k = int(math.isqrt(k))
s = a // 2 + 2

for sign in [1, -1]:
    n_candidate = s + sign * sqrt_k if n_candidate % 2 == 0:
        n = n_candidate // 2 m = s - n
        if n >= 1 and m >= 1:
            print(f"{min(n, m)} {max(n, m)}")
            break