#include <iostream>
#include <cmath>

using namespace std;
int main() {
    int a, c, d;
    cin >> a >> c >> d;
    
    cout << round((a+c)/2);
}