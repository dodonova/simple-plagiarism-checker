a = list(map(int,input().split()))
ans = ((((a[0] + a[1])/2)*10)//1)/10
print(ans)
