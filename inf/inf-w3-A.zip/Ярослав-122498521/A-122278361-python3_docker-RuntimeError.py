n=int(input())
m=int(input())
g=n+m
print(g/2)