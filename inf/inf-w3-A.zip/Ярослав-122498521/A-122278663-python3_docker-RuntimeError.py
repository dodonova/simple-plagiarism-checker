n=int(input())
m=int(input())
z=int(input())
g=n+m
print(g/2)