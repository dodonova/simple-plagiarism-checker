a = input().split()
print((int(a[0]) + int(a[1])) / 2)