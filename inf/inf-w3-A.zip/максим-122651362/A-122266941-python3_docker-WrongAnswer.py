a, c, d = map(int, input().split())

border = c

print(f"{border:.1f}")