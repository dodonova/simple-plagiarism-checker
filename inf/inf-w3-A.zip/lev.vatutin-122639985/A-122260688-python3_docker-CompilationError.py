def find_border(A, C, D):    border = (A + C) / 2
    return border
result = find_border(A, C, D)print(f"{result:.1f}")