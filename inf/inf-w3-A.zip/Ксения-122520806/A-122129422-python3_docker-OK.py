aa, ci, dr = [int(i) for i in input().split()]
#выводим
print((aa + ci) / 2)
#end