A,C,D=map(int,input().split())
b=(A+C)/2
if b== int(b):
    print(int(b))
else:
    print(f"{b:.1f}")