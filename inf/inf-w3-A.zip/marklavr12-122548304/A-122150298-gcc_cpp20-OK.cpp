#include <iostream>
    //на что я трачу свою жизнь
    //на что я трачу свою жизнь
using namespace std;
    //на что я трачу свою жизнь
    //на что я трачу свою жизнь
long double peopleA, peopleB, peopleD;
    //на что я трачу свою жизнь
    //на что я трачу свою жизнь
int main(){
    cin >> peopleA >> peopleB >> peopleD;
    peopleD = peopleA + peopleB;
    cout << peopleD / 2 << endl;
    return 0;
}