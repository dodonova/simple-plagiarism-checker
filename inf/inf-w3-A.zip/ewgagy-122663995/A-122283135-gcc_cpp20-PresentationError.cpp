#include <iostream>
#include <algorithm>
#include <cctype>
#include <string>

bool is_palindrome(const std::string& s) {
    std::string cleaned;
    // Remove spaces and convert to lowercase
    std::remove_copy_if(s.begin(), s.end(), std::back_inserter(cleaned),
                        [](char c) { return std::isspace(c); });
    std::transform(cleaned.begin(), cleaned.end(), cleaned.begin(),
                   [](char c) { return std::tolower(c); });

    // Check if the string is equal to its reverse
    std::string reversed(cleaned.rbegin(), cleaned.rend());
    return cleaned == reversed;
}

int main() {
    std::string input_string = "A man a plan a canal Panama";
    std::cout << std::boolalpha << is_palindrome(input_string) << std::endl;
    return 0;
}