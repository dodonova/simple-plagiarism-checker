n = [int(x) for x in (list(input().split(" ")))]


print(int(round(((n[0] + n[1]) / 2), 1)))