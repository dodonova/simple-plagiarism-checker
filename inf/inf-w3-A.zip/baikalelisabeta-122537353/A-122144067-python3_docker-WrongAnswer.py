A,C,D = map(int,input().split())
gran = A/2 + C/2
print(round(float(gran)))