def main():
    import sys
    input = sys.stdin.read
    a, b = map(int, input().strip().split())
    
    s = a // 2 + 2  # Сумма n + m
    
    for n in range(1, s + 1):
        m = s - n  # Находим m
        if n <= m and (n - 1) * (m - 1) == b:
            print(n, m)
            return

if __name__ == "__main__":
    main()