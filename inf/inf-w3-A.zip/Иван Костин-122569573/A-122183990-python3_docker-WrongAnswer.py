import math
def calculate_border(A, C):
    return (2 * A + C) / 3

# Считывание входных данных
A, C, D = map(int, input().split())

# Вычисление границы для B
border = math.ceil(calculate_border(A, C))
# Вывод результата с одним знаком после десятичной точки
print(border)