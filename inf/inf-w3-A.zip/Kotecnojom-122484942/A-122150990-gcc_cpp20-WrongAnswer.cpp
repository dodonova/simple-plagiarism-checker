#include <iostream>
using namespace std;

int time1, time2;
int a, b, c, d;

bool check(int a, int b, int c, int d) {
    time1 = b + 2 * a + c + d;
    time2 = a + d + 3 * b;
    if (time1 > time2) {
        return true;
    }
    else {
        return false;
    }
}


int main() {
    cin >> a >> c >> d;
    int b = a + 1, right = c, mid;

    while (b < right) {
        mid = (b + right) / 2;
        if (check(a, b, c, d)) {
            b = mid;
        }
        else {
            right = mid;
        }
    }
    cout << b;
    return 0;
}

