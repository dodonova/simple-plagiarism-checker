def calculate_border(time_A, time_C, time_D):
    # Граница для B, где B может быть меньше этой границы, чтобы использовать вторую стратегию
    border = (time_D - time_A) / 2
    return border

# Пример использования
# Время прохождения для A, C, D соответственно
time_A = 1
time_C = 5
time_D = 10

border_value = calculate_border(time_A, time_C, time_D)
print(f"Граница для B: {border_value}")
