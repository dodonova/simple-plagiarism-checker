#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    vector<int> times(4);
    for (int i = 0; i < 4; ++i) {
        cin >> times[i];
    }

    sort(times.begin(), times.end());

    // Минимальное время, когда можно воспользоваться первой стратегией
    int border = times[1];
    
    cout << border << endl;

    return 0;
}