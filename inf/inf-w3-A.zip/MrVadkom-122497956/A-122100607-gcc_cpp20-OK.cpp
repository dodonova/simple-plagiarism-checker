#include <iostream>
#include <string>

using namespace std;

int main() {
  int A, C, D;
  cin >> A >> C >> D;

  double z = (A + C) / 2.0;

  string z_str = to_string(z);

  if (z_str.length() >= 2 && z_str.substr(z_str.length() - 2) == ".0") {
    cout << static_cast<int>(z) << endl;
  } else {
    cout << z << endl;
  }

  return 0;
}