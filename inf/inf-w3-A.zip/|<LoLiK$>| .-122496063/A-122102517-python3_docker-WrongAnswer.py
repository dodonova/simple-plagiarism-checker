def calculate_border(a, c, d):
    return round((d - c + 2 * a) / 2, 1)
a, c, d = map(int, input().strip().split())
border = calculate_border(a, c, d)
print(border)