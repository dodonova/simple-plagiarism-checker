string = input()
A = list(map(int, string.split(" ")))
G = True
count=0
while G:
    count+=1
    if count+A[0]+A[1]+A[0]+A[2]<=count+A[0]+A[2]+count+count:
        G=False
        print (count)