string = input()
array = list(map(int, string.split(" ")))
print(array[0]*2+1)
