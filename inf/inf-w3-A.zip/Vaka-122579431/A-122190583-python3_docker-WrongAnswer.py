def calculate_border(a, c, d):
    return (2 * a + c + d) / 2
input_data = input()
a, c, d = map(int, input_data.split())
border = calculate_border(a, c, d)
print(f"{border:.1f}")
