def find_border(a, c, d):
  
  first_strategy_time = a + a + c + a + d

  second_strategy_time = a + a + d + a + a

  border = (first_strategy_time - second_strategy_time) / 2 + a

  return border

a, c, d = map(int, input().split())

print(find_border(a, c, d))