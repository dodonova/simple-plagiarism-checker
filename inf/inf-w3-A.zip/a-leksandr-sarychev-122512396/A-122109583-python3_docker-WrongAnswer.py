t_A, t_C, t_D = map(int, input().split())

border = (t_C + t_D) / 2

print(f"{border:.1f}")