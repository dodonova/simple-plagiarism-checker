s=input()
a=int(s[:s.index(' ')],10)
s=s.replace(' ','x',1)
c=int(s[s.index('x')+1:s.index(' ')],10)
d=int(s[s.index(' ')+1:],10)
for b in range(a,c+1):
    if b+a+c+a+d<=b+a+d+b+b:
        print(b)
        break