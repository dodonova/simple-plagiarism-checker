A=int(input())
C=int(input())
D=int(input())
border=(C+A)/2
if border%1!=0:
    print(f'{border:.1f}')
else:
    print(border)