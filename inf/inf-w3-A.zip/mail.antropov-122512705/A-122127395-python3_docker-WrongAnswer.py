def calculate_border(a, c, d):
    return (c + a + d) / 2

a, c, d = map(int, input().split())
border = calculate_border(a, c, d)
print(f"{border:.1f}")
