#include <stdio.h>

int main()
{
    int a, b, c, d;
    scanf("%d %d %d", &a, &c, &d);
    b = (a+c)/2;
    printf("%d", b);
    return 0;
}