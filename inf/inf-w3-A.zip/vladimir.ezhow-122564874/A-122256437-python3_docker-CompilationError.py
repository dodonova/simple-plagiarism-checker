a, c, d = map(int, input().split())

for b in range(a, c-1):
    if(2*a+b+c+d) < (3*b+a+d):
        print(b - 1)
        break
	if(2*a+b+c+d) == (3*b+a+d):
        print(b)
        break

print(b)