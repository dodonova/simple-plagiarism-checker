def calculate_border(t_A, t_C, t_D):
    # Вычисляем границу для t_B
    max_t_A_t_D = max(t_A, t_D)
    max_t_C_t_D = max(t_C, t_D)
    
    border = max_t_A_t_D - max_t_C_t_D + t_A
    return border

if __name__ == "__main__":
    # Ввод времени для A, C и D
    t_A, t_C, t_D = map(int, input("Введите время для A, C и D через пробел: ").split())
    
    # Вычисляем границу
    border = calculate_border(t_A, t_C, t_D)
    
    # Выводим результат с одним знаком после десятичной точки
    print(f"{border:.1f}")
