def calculate_border(value_a, value_c):
    """Calculate the border between two values."""
    return int((value_a + value_c) // 2) 

def main():
    a, c, d = map(int, input("Enter three integers A, C, D separated by spaces: ").split())
    
    border = calculate_border(a, c)
    
    print(f"{border:.0f}")

if __name__ == "__main__":
    main()