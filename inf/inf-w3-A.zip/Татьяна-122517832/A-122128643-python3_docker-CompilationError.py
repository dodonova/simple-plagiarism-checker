def find_border(A, C, D):
border = (2 * A + C) / 2
return round(border, 1)
A, C, D = map(int,input().split())
print(find_border(A, C, D))