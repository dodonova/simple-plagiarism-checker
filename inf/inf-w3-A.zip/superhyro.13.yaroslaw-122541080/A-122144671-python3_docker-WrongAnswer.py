nums = input().split(" ")
result = int(nums[0])
c = 0
cou = int(nums[0])
while cou < int(nums[1]) and result == int(nums[0]):
    if (cou * 2) >= (int(nums[0]) + int(nums[1])):
        result = cou
    cou+=1
while c != 0:
    if (cou * 2) < (int(nums[0]) + int(nums[1])):
        cou+=1
    else:
        result = cou
        c = 1
print(result)