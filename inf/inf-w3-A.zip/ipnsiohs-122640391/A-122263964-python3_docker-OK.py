def calculate_border(A, C, D):
    border = (C + A) / 2
    return border

# Считываем входные данные 
A, C, D = map(int, input().strip().split())
    
# Вычисляем границу
border = calculate_border(A, C, D)
    
# Выводим результат с одним знаком после десятичной точки
print(f"{border:.1f}")