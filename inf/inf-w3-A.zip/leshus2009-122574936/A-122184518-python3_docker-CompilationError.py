a, b= map(int,input().split('))

s = []
for n in range(1, 1000);
for m in range(1, 10000):
if (a.+4) ==(2*n + 2*m) and (b-1)==(n*m -n-m):
if m>n:
s.append(m)
s.appendin)
s.sort()
print(s(o], s[1])
break
elif m-=n:
print(n,m)