a=int(input())
c=int(input())
d=int(input())
border = (max(a, c) + a + max(a, d) - d) / 2
print(border)