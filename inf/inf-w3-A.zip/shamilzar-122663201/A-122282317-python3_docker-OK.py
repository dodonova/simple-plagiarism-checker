A, C, D = map(int, input().split())

# Вычисляем границу
border = (A + C) / 2

# Выводим с одним знаком после запятой
print(f"{border:.1f}")


