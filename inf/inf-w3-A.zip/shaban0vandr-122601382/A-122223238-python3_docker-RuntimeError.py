A=int(input())
C=int(input())
D=int(input())
for B in range(A*10+2, C*10):
    B=B/10
    if 3*(B-0.1)+A+D < 2*A+(B-0.1)+C+D and 3*(B+0.1)+A+D > 2*A+(B+0.1)+C+D:
        print(B)
        break