a,c,d = map(int,input().split())
b = a+1 
x1 = 0
x2 = 1
while x1<x2:
    x1 = b+a+c+a+d 
    x2 = b+a+d+b+b 
    b+=1
if x1 == x2:
    print(b-1)
else:
    print(b)