A=int(input())
C=int(input())
D=int(input())
B=0
B=C-2
print(B)