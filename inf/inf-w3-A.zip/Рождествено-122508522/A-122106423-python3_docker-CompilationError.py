A=1
C=5
D=10
B=0
        B=C-2
print(B)