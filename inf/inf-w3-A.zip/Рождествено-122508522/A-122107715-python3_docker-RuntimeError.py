A=float(input())
C=float(input())
D=float(input())
B=(A+C)/2
print(B)