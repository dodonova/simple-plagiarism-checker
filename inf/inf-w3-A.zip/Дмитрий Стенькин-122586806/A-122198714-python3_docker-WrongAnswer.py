a, c, d = map(int, input().split())
min_b = float('inf')
for b in range(a, c):
    t1 = 2 * a + b + c + d
    t2 = 3 * b + a + d
    if t1 <= t2 and b < min_b:
        min_b = b
if min_b < float('inf'):
    print(f"{min_b:.1f}")