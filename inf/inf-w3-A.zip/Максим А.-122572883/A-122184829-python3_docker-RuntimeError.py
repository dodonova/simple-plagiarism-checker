def number_of_twos(n):
    return 2 if n % 4 == 0 else int(n % 2 == 0)

n, k = map(int, input().split())
a = list(map(int, input().split()))
s, twos_count = 0, 0
for i in range(k):
    s += a[i]
    twos_count += number_of_twos(a[i])
seq_count = int(s % 28 == 0 and twos_count >= 2)
for i in range(k, n):
    s += a[i] - a[i - k]
    twos_count += number_of_twos(a[i]) - number_of_twos(a[i - k])
    seq_count += int(s % 28 == 0 and twos_count >= 2)
print(seq_count)