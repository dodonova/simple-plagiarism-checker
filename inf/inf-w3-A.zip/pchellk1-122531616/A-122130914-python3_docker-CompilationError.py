with open("input.txt", "r") as file:
numbers = [int(num) for num in file.readline().split()]
with open("output.txt", "w") as file:
file.write(str(int((numbers[0]+numbers[1])/2)))