st=input("")
n = 0
a = 0
d = 0
c = 0
for i in range(len(st)):
    if st[i] == " ":
        if (n == 0):
            a = int(st[n:i])
        else:
            c = int(st[n:i])
        n = i + 1
if st[n - 1] == " ":
    d = int(st[n:len(st)])
B = (a + c)/2
print(f"{B:.1f}")