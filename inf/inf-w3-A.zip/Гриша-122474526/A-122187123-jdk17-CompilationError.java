A_str, C_str, D_str = input().split()
A, C, D = int(A_str), int(C_str), int(D_str)

# Compute the border
border = (A + C) / 2

# Output the result with one decimal place
print(f"{border:.1f}")