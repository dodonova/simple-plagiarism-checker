#include <iostream>

using namespace std;

int main()
{
    float a, c, d;
    cin >> a >> c >> d;
    float b;
    b = (a + c) / 2;
    cout << b;
    return 0;
}