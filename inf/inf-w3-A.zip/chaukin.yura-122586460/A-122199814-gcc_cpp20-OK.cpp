#include <iostream>
using namespace std;

int main() {
    int a, c, d;
    cin >> a >> c >> d;
    cout << (a + c) * 1.0 / 2.0;
    return 0;
}