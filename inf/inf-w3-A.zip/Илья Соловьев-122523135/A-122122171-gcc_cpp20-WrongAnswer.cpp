#include <iostream>
#include <iomanip>
using namespace std;
int main() {
    int A, C, D, t1, t2;
    cin >> A >> C >> D;
	t1 = A+A+C+A+D;
	t2 = A+A+D+A+A;
	double border = (t2-t1)/3;
    cout << fixed << setprecision(1) << border;
    
}