#include <iostream>
#include <iomanip>
#include <algorithm>
using namespace std;
int main() {
    int values[3];
    cin >> values[0] >> values[1] >> values[2];
    sort(values, values + 3);
    int A = values[0]; 
    int C = values[1]; 
    int D = values[2]; 
    double border = (A + C)/2;  
    cout << fixed << setprecision(1) << border;

    
}