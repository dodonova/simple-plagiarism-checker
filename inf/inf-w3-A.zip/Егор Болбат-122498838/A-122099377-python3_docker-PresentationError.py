def calculate_min_time(A, C, D):
    # Рассчитываем границу для B
    border = (D - A) / 2.0

    # Рассчитываем время по первой стратегии
    def strategy_1(B):
        return B + A + D + A + B

    # Рассчитываем время по второй стратегии
    def strategy_2(B):
        return 2 * A + D + 2 * B

    return border, strategy_1, strategy_2

# Пример входных данных
A = 1  # Время A
C = 5  # Время C
D = 10 # Время D

# Получаем границу и функции для стратегий
border, strategy_1, strategy_2 = calculate_min_time(A, C, D)

# Выводим границу
print(f"Граница для B: {border}")

# Пример проверки для различных значений B
for B in [1, 2, 3, 4, 5, 6]:
    time_1 = strategy_1(B)
    time_2 = strategy_2(B)
    print(f"B = {B}: Стратегия 1: {time_1}, Стратегия 2: {time_2}")

# Определение минимального времени
best_B = None
min_time = float('inf')
for B in [i * 0.1 for i in range(int(border*10), 101)]:  # Проверяем B от границы до 10
    time = min(strategy_1(B), strategy_2(B))
    if time < min_time:
        min_time = time
        best_B = B

print(f"Минимальное время: {min_time} при B = {best_B}")