def calculate_border(a, c, d):
    # Время для первой стратегии
    time_first_strategy = a + 2 * a + c + 2 * a + d
    # Время для второй стратегии
    # time_second_strategy = a + b + d + b + a = 2 * a + 2 * b + d
    # Нам нужно найти b, при котором:
    # time_first_strategy == time_second_strategy
    # => a + 2 * a + c + 2 * a + d = 2 * a + 2 * b + d
    # => 4 * a + c = 2 * b + 2 * a
    # => 2 * b = 4 * a + c - 2 * a
    # => 2 * b = 2 * a + c
    # => b = (2 * a + c) / 2
    border = (2 * a + c) / 2
    return border

# Чтение входных данных
input_data = input().strip()
a, c, d = map(int, input_data.split())

# Вычисление границы
border = int(calculate_border(a, c, d))

# Вывод результата с одним знаком после десятичной точки
print(f"{border:.1f}")