a=int(input())
c=int(input())
d=int(input())
print(f'{(a+c)/2:.1f}')