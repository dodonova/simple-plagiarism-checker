a=input().split()
print(f'{(int(a[0])+int(a[1]))/2:.1f}')