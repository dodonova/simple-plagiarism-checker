a=int(input())
c=int(input())
d=int(input())
print((a+c)/2)