a, b1, c1 = map(int, input().split())
f = 1
for g in range(f, 101):
    h = a + b1 + c1 + g
    trr = 2 * h
    tr = g * 3 + a + c1
    if tr > trr:
       print(g)
           break
