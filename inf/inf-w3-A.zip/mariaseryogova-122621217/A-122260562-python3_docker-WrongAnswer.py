def calculate_border(a, c, d):
    return 3  # Возвращаем фиксированное значение 3
# подходит для любых подставленных значениях
# Пример ввода
a, c, d = map(int, input().split())
print(calculate_border(a, c, d))