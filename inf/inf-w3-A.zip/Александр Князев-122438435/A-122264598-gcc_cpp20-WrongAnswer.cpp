#include <iostream>

int main() {
    int a, d, c;
    double gh;
    std::cin >> a >> c >> d;
    gh = (a + c) / 2;
    std::cout << gh;
}