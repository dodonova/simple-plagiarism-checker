#include <iostream>
#include <iomanip>

int main() {
    int a, d, c;
    double gh;
    std::cin >> a >> c >> d;
    gh = (a + c) / 2;
    std::cout << std::fixed << std::setprecision(2) << gh;
}