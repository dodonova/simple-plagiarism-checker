a, c, d = map(int,input().split())

if a == c:
    border = a
elif a < c:
    border = a
else:
    border = (a+c) / 2
print('{:.1f}'.format(border))