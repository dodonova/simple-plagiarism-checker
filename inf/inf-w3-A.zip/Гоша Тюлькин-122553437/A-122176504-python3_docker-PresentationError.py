def calculate_border(a, c, d):
    return (2 * a + c + d) / 3

# Ввод данных
a, c, d = map(int, input("Введите времена A, C и D через пробел: ").split())

# Вычисление границы
border = calculate_border(a, c, d)

# Вывод результата с одним знаком после десятичной точки
print(f"{border:.1f}")
