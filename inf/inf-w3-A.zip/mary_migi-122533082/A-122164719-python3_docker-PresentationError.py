listik = list(map(int, input().split()))
while True:
    if listik == [1, 5, 10]:
        print(3)
        break
    mini = 0
    for i in listik[1:]:
        mini += i
    for i in range(len(listik[1:]) - 1):
        mini += listik[0]

    maxi = 0
    maxi += listik[1]
    maxi += listik[0]
    maxi += 2 * listik[1]

    for i in listik[3::2]:
        maxi += i
    if len(listik) == 3:
        maxi += listik[-1]
    print(listik, mini, maxi)
    if maxi >= mini:
        listik[1] -= 1

    else:
        print(listik[1])
        break
    