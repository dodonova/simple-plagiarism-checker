#include <iostream>
#include <cmath>
int main()
{
    int A, C, D;
    float border;
    std::cin>>A;
    std::cin>>C;
    std::cin>>D;
    
    border = (A+C)/2;
    
    std::cout<<round(border*10)/
    10<<endl;

    return 0;
}