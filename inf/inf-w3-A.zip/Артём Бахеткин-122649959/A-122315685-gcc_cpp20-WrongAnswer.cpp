#include <iostream>
#include <vector>

using namespace std;

int first_strategy(int a, int b, int c, int d){
    int sum;
    sum = b + a + c + a + d;
    return sum;
}

int second_strategy(int a, int b, int c, int d){
    int sum;
    sum = b + a + d + b + b;
    return sum;
}

int main() {
    int a, b, c, d, ans;
    cin >> a >> c >> d;
    for (int i = a; i < c; i++){
        b = i;
        if (first_strategy(a, b, c, d) < second_strategy(a, b, c, d)) {
            ans = i;
            break;
        }
    }
	a *= 10;
    d *= 10;
    c *= 10;
    for (int b = a; b < c + 1; b++) {
    	int s1 = a + c;
        int s2 = 2 * b;
    if (s1 <= s2) {
   		cout << fixed;
    	cout.precision(1);
    	cout << b / 10;
    	break;
    }
    }
}
