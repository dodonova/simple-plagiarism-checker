A, C, D = map(int, input().split())
B = 101
while A + C + D < 2 * B + D:
    B -= 0.1
print(B)