def calculate_border(A, C, D):
    # Граница B
    border = C / 2
    return border

def main():
    # Пример входных данных
    A = int(input("Введите время A: "))
    C = int(input("Введите время C: "))
    D = int(input("Введите время D: "))

    border = calculate_border(A, C, D)
    print(f"Граница для B равна: {border}")

if __name__ == "__main__":
    main()