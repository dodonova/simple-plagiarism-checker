#include <iostream>
#include <vector>

using namespace std;

int find_border(int a, int c, int d) {
    // If A and C can cross the tunnel together faster than A and D, then the second strategy is better.
    if (a + c < a + d) {
        return a + c;
    }

    // Otherwise, the first strategy is better.
    return a + d;
}

int main() {
    int a, c, d;
    cin >> a >> c >> d;
    cout << find_border(a, c, d) << endl;
    return 0;
}