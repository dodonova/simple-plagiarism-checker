def find_border(a, c, d):
    """
    Finds the border for B such that if B's time is less than the border, the second strategy is better, otherwise the first strategy is better.

    Args:
        a (int): Time taken by A to cross the tunnel.
        c (int): Time taken by C to cross the tunnel.
        d (int): Time taken by D to cross the tunnel.

    Returns:
        int: The border for B.
    """

    # If A and C can cross the tunnel together faster than A and D, then the second strategy is better.
    if a + c < a + d:
        return a + c

    # Otherwise, the first strategy is better.
    return a + d
