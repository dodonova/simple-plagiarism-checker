#include <iostream>

using namespace std;

int main()
{
    int a, b, c, d;
    cin>>a>>c>>d;
    
    int x, y;
    
    int bordel;
    
    for(int i = a; i <= c; i++){
        b=i;
        x=b+a+c+a+d;
        y=b+a+d+b+b;
        //cout<<x<<endl<<y<<endl<<endl;
        if(x==y){
            bordel=b;
            break;
        }else if(x == y+1)
        {
            bordel=b - 0.5;
            break;
        }else if(x+1 == y){
            bordel=b - 0.5;
            break;
        }
    }
    cout<<bordel;
    return 0;
}