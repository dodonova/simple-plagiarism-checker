a, b, c = msp(int, input().split())
d = 0
d = (a+b)/2
print ('{:.1f}'.format(d))