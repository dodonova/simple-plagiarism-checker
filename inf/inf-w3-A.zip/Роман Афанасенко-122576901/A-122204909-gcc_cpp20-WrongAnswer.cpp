#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

int main()
{
  float A, B, C, D;
  cin >> A >> C >> D;
  for (B = 1; B<=100; B++)
  {
    float mas[4] = {A, B, C, D};
    sort(mas, mas+4);
      if((mas[1] + 2*mas[0] + mas[2] + mas[3]) == (mas[1] + mas[0] + mas[3] + 2*mas[1]))
    {
      cout << floor(B * 10)/10;
      break;
    }
  }
  return 0;
}

