A, C, D = map(int, input().split())
def f(a, b, c , d):
    for i in range(b):
        m = sorted([a, i, c, d])
        if (m[1] + m[0] + m[3] + m[1] + m[1]) < (m[1] + m[0] + m[2] + m[0] + m[3]):
            pass
        else:
            break
    else:
        for i in range(b, 101):
            m = sorted([a, i, c, d])
            if (m[1] + m[0] + m[3] + m[1] + m[1]) >= (m[1] + m[0] + m[2] + m[0] + m[3]):
                pass
            else:
               break
        else:
            print(b)
            fall = True

fall = False
for B in range(3, 101):
    f(A, B, C, D)
    if fall:
        break