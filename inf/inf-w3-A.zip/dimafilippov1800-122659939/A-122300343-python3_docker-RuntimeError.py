def find_border_time(A, C, D):
    low = min(A, C, D)
    high = sum(A, C, D) - min(A, C, D) - max(A, C, D) + 1
    
    while low < high:
        B = (low + high) // 2
        # Проверяем условие для первой стратегии
        if (A + B + D + B + B) < (A + C + D + A + B):
            low = B + 1
        else:
            high = B
    
    # В low будет содержаться минимальное B, для которого нужно выбрать вторую стратегию
    return low

# Чтение входных данных
A, C, D = map(int, input().split())

# Находим границу для B
border = find_border_time(A, C, D)

# Выводим результат с одним знаком после десятичной точки
print(border)
