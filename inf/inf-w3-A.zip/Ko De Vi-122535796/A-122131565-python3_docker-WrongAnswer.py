a, c, d = map(int, input().split())
k = a
for i in range(a, c + 1):
    s2 = i + a + d + i + i
    s1 = i + a + c + a + d
    if s2 <= s1:
        k = i
print(k)