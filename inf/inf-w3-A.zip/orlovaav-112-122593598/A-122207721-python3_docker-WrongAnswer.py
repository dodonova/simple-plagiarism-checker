a, c, d = map(int, input().split())
border = (2 * a + c + d) / 2
print(f"{border:.1f}")