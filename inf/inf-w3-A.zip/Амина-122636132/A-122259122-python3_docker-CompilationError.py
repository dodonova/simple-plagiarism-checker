string = input()
string =
string.split()
a, c, d = [int(i) for 
i in string]
for b in range(a * 
10, c * 10 + 1): 
    max_ab =
max(float(a), b / 10)
    max_cd = max(c, d)
    max_ad = max(a, d)
    max_ac = max(a, c)
    str_1 = max_ab + a * 2 + max_ac + max_ad
    str_2 = max_ab + a + max_ac + b / 10 + max_ab
    if str_2 < str_1:
        continue
    else:
        print(b / 10)
        break