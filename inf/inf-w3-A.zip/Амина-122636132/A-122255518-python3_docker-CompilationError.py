s = input() split()
a, c, a = lint(i) for i in s
for b in rangela * 10, c * 10 + 1):
ab = max (float(a), b / 10)
cd = max (c, d)
ad = maxa, d)
ac = max (a, c)
valuel = ab + a * 2 + ac + ad
value2 = ab + a + cd + b / 10 + ab
if value2 ‹ valuel: continue else:
print(b / 10)
break