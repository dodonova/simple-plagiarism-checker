def main():
    import sys
    input = sys.stdin.read
    data = input().strip().split()

    t_A = int(data[0])
    t_C = int(data[1])
    t_D = int(data[2])
    
    # Определяем границу
    border = (2 * t_C - t_A + t_D) / 2

    # Печатаем результат с одним знаком после десятичной точки
    print(f"{border:.1f}")

if __name__ == "__main__":
    main()
