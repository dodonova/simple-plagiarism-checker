amnf, klmp, qwmn = map(int, input().split())
if not (amnf + klmp) % 2:
    print(
        (amnf + klmp) // 2
    )
else:
    print(
        f"{(amnf + klmp) // 2}.5"
    )