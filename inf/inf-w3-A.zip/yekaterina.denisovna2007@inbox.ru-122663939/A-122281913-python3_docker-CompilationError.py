soo = input().split(' ')
a = int(soo[0])
c = int(soo[1])
d = int(soo[2])

for b in range(2**13):
    if b == (a+c)/2:
        b = float('{:.1f}'.format(b))
        print(b)