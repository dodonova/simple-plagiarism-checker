#include <iostream>
int main() {
    float a, c, d;
    std::cin >> a >> c >> d;
    std::cout << (a + c) / 2;
    return 0;
}