a, c, d = map(int, input().split())

def first_method(b):
    left = [a, b, c, d]
    right = []
    is_light_right = False
    result = 0

    for _ in range(5):
        if not is_light_right:
            temp = min(left)
            left.remove(temp)
            right.append(temp)
            temp = left[0]
            left.remove(temp)
            right.append(temp)
            result += temp

            is_light_right = not is_light_right
        else:
            temp = min(right)
            right.remove(temp)
            left.append(temp)
            result += temp

            is_light_right = not is_light_right
    return result

def second_method(b):
    left = [a, b, c, d]
    right = []
    is_light_right = False
    result = 0

    temp = min(left)
    left.remove(temp)
    right.append(temp)
    temp = min(left)
    left.remove(temp)
    right.append(temp)
    result += temp

    temp = min(right)
    right.remove(temp)
    left.append(temp)
    result += temp

    temp = max(left)
    left.remove(temp)
    right.append(temp)
    result += temp
    temp = max(left)
    left.remove(temp)
    right.append(temp)

    temp = min(right)
    right.remove(temp)
    left.append(temp)
    result += temp

    temp = min(left)
    left.remove(temp)
    right.append(temp)
    temp = min(left)
    left.remove(temp)
    right.append(temp)
    result += temp

    return result

b = 0
while b < 100:
    b += 1
    f = first_method(b)
    s = second_method(b)

    if f == s:
        print(b)
        break