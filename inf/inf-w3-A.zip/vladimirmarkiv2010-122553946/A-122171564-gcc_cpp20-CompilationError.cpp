#include <iostream>
using namespace std;
int main () {
int a, b, c, d;
cin >> a >> c >> d;
b = ( a + c ) / 2 ;
int x = (int)b;
if ( b == x) {
}; else {
b = x + 1;
};
cout << b << endl;
return 0; }
