#include <iostream>
using namespace std;
int main () {
int a, b, c, d;
cin >> a >> c >> d;
b = ( a + c ) / 2 ;
cout << b << endl;
return 0; }
