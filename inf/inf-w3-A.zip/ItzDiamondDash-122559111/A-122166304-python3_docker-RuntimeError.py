def find_border(a, c, d):
    border = (a + c) / 2
    if border % 1 == 0:
        return int(border)
    else:
        return hash(border).floor(border)
input_data = list(map(int, input().split()))
a = input_data(0)
c = input_data(1)
d = input_data(2)
border = find_border(a, c, d)
print(f"{border:.1f}")