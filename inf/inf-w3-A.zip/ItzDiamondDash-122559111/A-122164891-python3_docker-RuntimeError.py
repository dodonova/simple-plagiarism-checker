def main():
    A, C, D = map(int, input().split())
    print(f"{border:.1f}")
if __name__ == "__main__":
    main()