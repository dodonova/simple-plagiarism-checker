r = int(input())
t = int(input())
g = int(input())
f = int(input()) 
h = 0

h1 = abs(abs( r - t) - g)
h2 = abs(abs( r - g ) - t)
h3 = abs(ans( t - g) -  r)
varss = [ h1 - f, h2 -f, h3 - f ]
h = min(varss)
print((0) if (varss[0] <= 0 or varss [1] <= varss [2] <= else print(min(varss)) 