g, l, z = map(int, input().split())
border = (g + l) / 2
print(f"{border:.1f}")
