n = list(map(int, input().split()))
a, b, c = n[0],n[1],n[2]
d = (a + b) / 2
print(d)