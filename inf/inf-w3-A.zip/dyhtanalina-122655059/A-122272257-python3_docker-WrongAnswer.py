def func():
    x = input().split()
    a = int(x[0])
    c = int(x[1])
    d = int(x[2])
    v = []
    if a < 1 or d > 100:
        print("Неверный ввод")
        return
    if a < c and c < d:
        for b in range(a, c + 1):
            total = 0
            total1 = 0
            total += b + a + c + a + d 
            total1 += b + a + d + b + b
            if total1 < total + 1:
                v.append(b)
        print(max(v))

func()