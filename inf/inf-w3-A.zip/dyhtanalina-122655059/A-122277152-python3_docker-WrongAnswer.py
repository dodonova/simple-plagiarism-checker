def find_border(a, c, d):
    # Находим границу
    border = (a + c - d) / 2
    return border

# Чтение входных данных
a, c, d = map(int, input().strip().split())

# Получаем границу и выводим с одним знаком после десятичной точки
border = find_border(a, c, d)
print(f"{border:.1f}")