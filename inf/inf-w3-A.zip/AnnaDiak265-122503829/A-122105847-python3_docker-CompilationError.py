def main():
	A,C,D = map(int, input().split())
    
    border(A+C)/2.0
    
    print(f"{border:.1f}")
	
if name=="main":
	main()