def find_border(A, C, D):
    border = (2 * A + C) / 3.0
    return border


A, C, D = map(int, input().split())

result = find_border(A, C, D)
print(f"{result:.1f}")