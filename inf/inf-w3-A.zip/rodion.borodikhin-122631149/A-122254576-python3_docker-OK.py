a = [int(i) for i in input().split()]
print((a[0] + a[1]) / 2)