

import java.io.*;
import java.util.*;


public class Main {
    static double findKat(long k, long g) {
        return Math.sqrt(g^2 - k^2);
    }

    public static void main(String[] args) throws IOException {
        long a = nextLong();
        long c = nextLong();
        long d = nextLong();

        long res = (a+c)/2;
        out.println(res);

        out.close();
    }

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter out = new PrintWriter(System.out);
    static StringTokenizer in = new StringTokenizer("");


    public static boolean hasNext() throws IOException {
        if (in.hasMoreTokens()) return true;
        String s;
        while ((s = br.readLine()) != null) {
            in = new StringTokenizer(s);
            if (in.hasMoreTokens()) return true;
        }
        return false;
    }

    public static String nextToken() throws IOException {
        while (!in.hasMoreTokens()) {
            in = new StringTokenizer(br.readLine());
        }
        return in.nextToken();
    }

    public static int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    public static double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    public static long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }
}