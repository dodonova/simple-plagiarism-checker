def time(A, C, D):
    border = max(A, C) + 1
    return border

A = 1
C = 5
D = 10

border = time(A, C, D)
print(border)