a, c, d = map(int, input().split())
for i in range(a+1, c):
    if i + a + c + a + d >= i + a + d + i + i:
        print(i+1)
        break