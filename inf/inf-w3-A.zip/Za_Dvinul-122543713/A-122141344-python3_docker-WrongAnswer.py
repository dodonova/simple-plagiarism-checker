
A, C, D = map(int, input().split())

border = min((C + D - 2 * A) / 2 + A, A)

print(f"{border:.1f}")