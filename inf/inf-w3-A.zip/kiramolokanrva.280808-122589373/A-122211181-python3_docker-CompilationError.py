x1, x2, y = [*map(int, input().split())]
middle = (x1 + x2) / 2
print(f"{middle:.1f}"