abeziyan, credit_v_banke, zov = map(int, input().split())
nkey = abeziyan + credit_v_banke
result = nkey / 2
print(f"{result:.1f}")