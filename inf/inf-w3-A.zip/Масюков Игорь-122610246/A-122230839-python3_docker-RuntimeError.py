m=input()
l1=0
n=0
s=[]
while m[l1]!=' ':
    l1+=1
l2=l1+1
while m[l2]!=' ':
    l2+=1
a=int(m[:l1])
c=int(m[(l1+1):(l2)])
d=int(m[(l2+1):])
for b in range(a+1,c):
    n1=b+a+c+a+d
    n2=b+a+d+b+b
    n+=b
    if n1>n2:
    	s.append(n1)
    else:
    	s.append(n2)
print(n/len(s))