a, b, c = map(int, input().strip().split())

border = (a + b) / 2
print(f"{border:.1f}")