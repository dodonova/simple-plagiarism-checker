import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String input = scanner.nextLine();
        int indexOfFirstSpace = 0;
        int indexOfSecondSpace = 0;
        ArrayList<Integer> resultsList = new ArrayList<>();
        
        while (input.charAt(indexOfFirstSpace) != ' ') {
            indexOfFirstSpace++;
        }
        
        indexOfSecondSpace = indexOfFirstSpace + 1;
        while (input.charAt(indexOfSecondSpace) != ' ') {
            indexOfSecondSpace++;
        }
        
        int firstNumber = Integer.parseInt(input.substring(0, indexOfFirstSpace));
        int secondNumber = Integer.parseInt(input.substring(indexOfFirstSpace + 1, indexOfSecondSpace));
        int thirdNumber = Integer.parseInt(input.substring(indexOfSecondSpace + 1));
        
        int sum = 0;
        for (int i = 0; i < firstNumber + 1; i++) {
            if (i >= secondNumber) break; // Ensures the loop runs correctly
            int calculationOne = i + firstNumber + secondNumber + firstNumber + thirdNumber;
            int calculationTwo = i + firstNumber + thirdNumber + i + i;
            sum += i;
            if (calculationOne > calculationTwo) {
                resultsList.add(calculationOne);
            } else {
                resultsList.add(calculationTwo);
            }
        }
        
        System.out.println((double) sum / resultsList.size());
    }
}