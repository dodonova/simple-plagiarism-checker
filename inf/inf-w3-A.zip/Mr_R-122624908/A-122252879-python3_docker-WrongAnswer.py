s = list(map(int, input().split()))
a=s[0]
c=s[1]
d=s[2]
for i in range(s[1], s[0]-1, -1):
        #2_1
   if (3*i+a+d) < (2*a+c+d+i):
        print(i+1)
   #print(2*a+c+d+i, 3*i+a+d)
        break
