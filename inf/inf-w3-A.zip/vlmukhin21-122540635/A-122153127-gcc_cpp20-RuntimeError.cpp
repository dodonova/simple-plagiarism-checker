#include <iostream>
#include <vector>
using namespace std;

int main()
{
	int a, c, d;
	vector<int>borders;
	//bool f = false;
	//int minTime = 10e9;
	cin >> a >> c >> d;

	for (int b = a; b < c + 1; b++) {
		int time1 = b + a + c + a + d;
		int time2 = b + b + d + a + b;

		if (time1 == time2) {
			borders.push_back(b);

			//f = true;
			//border = b - 1;
			//break;
		}
	}
	int sum = 0;
	if (size(borders) > 1) {
		for (int i = 0; i < size(borders); i++) {
			sum += borders[i];
			cout << borders[i];
		}
		double border = sum / (size(borders)) * 1.;
		cout << border;
		return 0;
	}
	else {
		cout << borders[0];
		return 0;
	}
}
