a, m, h = map(int, input().split()) 
maxi = 0 
for i in range(a, (m + 1) * 10000): 
    i = i * 0.01 
    if i + a + m + a + h > i + a + h + i + i: 
        maxi = i 
print(round(maxi, 1))