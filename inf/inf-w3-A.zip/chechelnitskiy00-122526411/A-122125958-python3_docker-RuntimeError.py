a, b = float(input()), float(input())
c = float(input())
print((a + b) / 2)
