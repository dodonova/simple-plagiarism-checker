a, c, d = list(map(int, input().split()))
for b in range(a * 1000,(c + 1) * 1000):
    b /= 1000
    t1 = 2 * a + b + c + d
    t2 = 3 * b + a + d
    if t2 >= t1:
        print(b)
        break