#include <iostream>
#include <cmath>
using namespace std;
int main () {
    cout<<3;
}
