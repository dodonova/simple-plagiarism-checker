#include <iostream>
using namespace std;
int main(){
int a, c, d;
cin >> a >> c >> d;
for (int b = c; b > 0; b --){
if (a + a + b + b + c > a + b + b + b + d){
cout << i;
break;
}
}
}