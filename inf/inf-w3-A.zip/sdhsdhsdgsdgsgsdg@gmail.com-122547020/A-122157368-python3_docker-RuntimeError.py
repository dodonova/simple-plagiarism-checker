A, C, D = map(int, input().split())

border = (C - A)/2+A 

print(f"{border:.if}")