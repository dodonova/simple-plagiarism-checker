c, a, b = map(int, input().strip().split())
border = (c-a)/2 + a
print(f"{border:.1f}")