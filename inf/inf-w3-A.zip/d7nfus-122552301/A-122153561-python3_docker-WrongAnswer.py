# Чтение входных данных
A_time, C_time, D_time = map(int, input().split())

# Вычисление границы border
border = A_time + C_time - D_time

# Вывод результата с одним знаком после десятичной точки
print(f"{border:.1f}")