a, c, d = map(int, input().split())
for b in range(a, c+1):
    t_1 = b + a + c + a + d
    t_2 = b + a + d + b + b
    if t_1 <= t_2:
        print(b)
        break
