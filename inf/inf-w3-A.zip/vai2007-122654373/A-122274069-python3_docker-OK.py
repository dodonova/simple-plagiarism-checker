a, c, d = [*map(int, input().split())]
kak = (a + c) / 2
print(f"{kak:.1f}")