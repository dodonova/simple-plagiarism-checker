a, c, d = map(int, input().split())

time_first_strategy = (c + a + d + c + b)  
time_second_strategy = (a + b + d + b + a) 

border = (2 * d - a - c + 1) // 2

print(border)