a, c, d = map(int, input().split())
b = 0
for b in range(1, 101):
      if (b+a+c+a+d)>=(b+a+d+b+b):
            border=b*10
      else:
            print(int(border)/10)
            break