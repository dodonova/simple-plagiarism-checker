t_A, t_C, t_D = map(int, input().split())

border = (t_A + t_C) / 2

print(f"{border:.1f}")