#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <iostream>
#include <map>
#include <queue>


#define ll long long
#define ld long double

using namespace std;

const ll MAX = 2e18;
const int MIN = -2e9;


int main() {
	int a, b, c;
    cin >> a >> b >> c;
    cout << (a+b)/2;
}