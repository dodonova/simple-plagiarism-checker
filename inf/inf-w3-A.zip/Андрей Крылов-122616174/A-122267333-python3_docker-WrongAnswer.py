a,c,d=map(int, input().split())

r=c+a
b=r//2
print(b)
	
