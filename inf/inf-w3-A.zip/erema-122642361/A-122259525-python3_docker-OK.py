result = input()
a, c, d = map(int, result.split())
bor = (c + a) / 2
check = str(bor).split(".")
if int(check[1]) != 0:
    print(f"{bor:.1f}")
else:
    print(int(bor))