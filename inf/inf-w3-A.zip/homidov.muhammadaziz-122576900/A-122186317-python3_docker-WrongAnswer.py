A, C, D = map(int, input().split())
border = (D - A) / 2 + A
print(f"{border:.1f}")
