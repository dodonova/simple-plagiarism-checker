guys = list(map(int, input().split()))

for scnd in range(guys[0]*10, guys[1]*10, 1):
    if sum(guys[:2])/2 <= scnd/10:
        buf = scnd/10
        if buf == int(buf):
            print(int(buf))
        else:
            print(buf)
        break
