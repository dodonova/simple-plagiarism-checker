#include <iostream>

using namespace std;

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios_base::sync_with_stdio(false);

    long long a, b, c, d;

    cin >> a >> c >> d;

    cout << (a + c) / 2;
    return 0;
};
