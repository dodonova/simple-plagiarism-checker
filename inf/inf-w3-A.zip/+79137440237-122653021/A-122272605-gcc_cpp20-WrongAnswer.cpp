#include <iostream>
#include <iomanip> // для std::setprecision

using namespace std;

double find_border(int t_A, int t_C, int t_D) {
    // Вычисляем границу для B
    double border = (t_C - t_A) + (t_D - t_A) / 2.0;
    return border;
}

int main() {
    int t_A, t_C, t_D;
    // Чтение входных данных
    cin >> t_A >> t_C >> t_D;
 double border = find_border(t_A, t_C, t_D);
 // Выводим результат с одной цифрой после запятой
    cout << fixed << setprecision(1) << border << endl;
 return 0;
}
