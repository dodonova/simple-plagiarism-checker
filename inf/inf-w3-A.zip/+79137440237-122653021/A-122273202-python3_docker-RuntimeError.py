def find_border(t_A, t_C, t_D):
    # Вычисляем границу для B border = (t_D - t_A) + (t_C - t_A) / 2
    return border

# Чтение входных данных
t_A, t_C, t_D = map(int, input().split())
border = find_border(t_A, t_C, t_D)
print(f"{border:.1f}")