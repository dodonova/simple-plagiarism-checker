border = (A + C) / 2
    return border

A, C, D = map(int, input().split())
print(f"{find_border(A, C, D):.1f}")