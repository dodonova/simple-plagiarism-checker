#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    double f, j, m;
    cin>>f>>j>>m;
    double l=(j-f)+m+f;
    cout<< l << endl;
    if(f<=l){
        cout << "First" << endl;
    }
    else{
        cout << "Second" << endl;
    }

    return 0;
}