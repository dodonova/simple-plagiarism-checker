A, C, D = map(int, input().split())

border = (C + 2 * A) / 3

print(f"{border:.1f}")
