a,c,d = [int(s) for s in input().split()]
arr_b = []
for b in range(a,c+1):
    res_1 = 2*a + b + c + d
    res_2 = 3*b + a + d
    if res_2 < res_1:
        arr_b.append(b)
print(max(arr_b)+1)
