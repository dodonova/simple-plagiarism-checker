A, C, D = map(int, input().split())
l, r = A, D + 1 # Ищем границу для B
while r - l > 1:
    m = (r + l) // 2
    if C + A <= m + m:  # Две стратегии
        r = m
    else:
        l = m

print(r)