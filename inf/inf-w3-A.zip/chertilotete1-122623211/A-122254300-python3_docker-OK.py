a, c, d = map(int, input().split())
print((c - a) / 2 + a)