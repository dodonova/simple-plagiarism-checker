A,C,D=map(int,input().split())
print((A+C)/2)