a, c, d = map(int, input().split())
print(round(a+c/2,2))