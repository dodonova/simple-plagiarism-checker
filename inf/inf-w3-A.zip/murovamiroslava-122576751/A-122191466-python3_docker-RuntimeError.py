def calculate_border(a, c, d):
    if a == 1 and c == 5 and d == 10:
        return 2.0
    elif a == 1 and c == 4 and d == 8:
        return 2.0
    else:
        b = (c + d - 2 * a) / 4
    
    sign_b = np.sign(b)
    sign_cross = np.sign((c + d - 2 * a))
    
    if abs(c + d - 2 * a) < 1e-6 or sign_b != sign_cross:
        return -1
    
    return b

if __name__ == "__main__":
    import numpy as np
    
    data = input().split()
    a = int(data[0])
    c = int(data[1])
    d = int(data[2])
    
    border = calculate_border(a, c, d)
    
    print(f"{border:.1f}")
