a, c, d=map(int, input().split())
b=a*0.5+0.5*c
print(b)