def find_optimal_strategy(a, c, d):


  if not all(time > 0 for time in (a, c, d)) or not (a <= c <= d):
    raise ValueError("Некорректные входные данные")


  border = a

  if b < border:
    return "Вторая стратегия оптимальна"
  else:
    return "Первая стратегия оптимальна"

if __name__ == "__main__":

  a, c, d = map(int, input("Введите времена прохождения A, C, D через пробел: ").split())

  result = find_optimal_strategy(a, c, d)
  print(result)