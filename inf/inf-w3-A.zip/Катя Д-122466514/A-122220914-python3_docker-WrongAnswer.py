a, c, d = map(int, input().split())
border = ((c-a) / 2) + 1
def is_iteger(x):
    return x % 1 == 0
print(int(border)if is_iteger(border) else "{:.1f}".format(border))