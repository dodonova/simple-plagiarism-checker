A, C, D = map(int, input().split())
border = C
print(f"{border:.1f}")
