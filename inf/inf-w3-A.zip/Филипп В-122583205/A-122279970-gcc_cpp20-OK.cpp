#include <iostream>

using namespace std;
int main()
{
    int a, c, d;
    cin >> a >> c >> d;
    for (int b = 0; b < 1000; b += 1)
    {
        float r1 = a + c;
        float r2 = 2*(b/10.0);
        if (r1 == r2)
        {
            cout << (b/10.0);
        }
    }
    return 0;
}