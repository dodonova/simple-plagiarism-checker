def calculate_border(t_a, t_c, t_d):
    # Время первой стратегии
    T1 = t_a + t_a + t_c + t_d + t_d  # t_d используется дважды
    # Время второй стратегии
    T2 = 2 * t_b + t_a + t_c  # t_b - то, что мы ищем
    
    # Условие для границы
    # T1 >= T2
    # t_a + t_c + t_d + t_d >= 2 * t_b + t_a + t_c
    # t_d >= 2 * t_b
    # 2 * t_b <= t_d
    # t_b <= t_d / 2

    border = (T1 - (t_a + t_c + t_d)) / 2
    return border

# Чтение входных данных
t_a, t_c, t_d = map(int, input().split())

# Вычисление границы
border = calculate_border(t_a, t_c, t_d)

# Форматированный вывод с одни