a, c, d = map(int, input().split())
b = (a + c) / 2
if b = int(b):
    print (int(b))
    else: 
        print (f"{b:.if}")