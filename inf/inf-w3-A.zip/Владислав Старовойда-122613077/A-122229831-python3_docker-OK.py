a, c, d = map(int,input().split())
bolder = (max(a,c) + max(a, d) - a - max(c,d)) / 2 + a
print(f"{bolder:.1f}")