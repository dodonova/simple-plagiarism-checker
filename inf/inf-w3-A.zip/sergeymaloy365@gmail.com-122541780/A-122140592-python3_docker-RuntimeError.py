a = int(input())
c = int(input())
d = int(input())
s1 = a*6 + c + d # +b
s2 = a*3 + c + d # +b * 3
border = a * 1,5