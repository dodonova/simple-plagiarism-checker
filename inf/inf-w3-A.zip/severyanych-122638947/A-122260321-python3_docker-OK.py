def calculate_border(A, C, D):
    # Граница для B
    border = (A + C) / 2
    return border

# Чтение входных данных
A, C, D = map(int, input().split())

# Вычисление границы
border = calculate_border(A, C, D)

# Вывод результата с одним знаком после десятичной точки
print(f"{border:.1f}")

