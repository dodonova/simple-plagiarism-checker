def calc_border(a, c, d):
	border = (d -c + a)/2
	return border

input_data = input()
a,c, d = map(int, input_data.split())

border = calc_border(a, c, d)
print(f"{border:.1f}")