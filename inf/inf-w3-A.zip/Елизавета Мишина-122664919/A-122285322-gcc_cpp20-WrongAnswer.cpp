#include <iostream>
#include <cmath>

using namespace std;

int main() {

	float a = 0;
	float b = 0;
	float c = 0;
	float d = 0;

	cin >> a >> c >> d;
	if (a == c) {
		b = a;
		cout << b;
	}
	else if (c - a < 2) {
		b = a;
		cout << b;
	}
	else if (c - a == 2) {
		b = a++;
		cout << b;
	}
	else if (c - a > 2) {
		b = a + ((c - a) / 2);
		double newb = round(b * 10) / 10;
		cout << newb;
	}

	return 0;
}