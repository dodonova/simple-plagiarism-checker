A, C, D = map(int, input().split())
B = A + 0.1
while B > A and B < C:
    if A + C <= B + B:
        print(int(B))
        break
    B += 0.1
else:
	print(B - 0.1)