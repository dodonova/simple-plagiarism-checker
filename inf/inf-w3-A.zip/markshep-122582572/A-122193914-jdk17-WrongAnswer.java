import java.util.Scanner;

public class Tunnel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int A = scanner.nextInt();
        int C = scanner.nextInt();
        int D = scanner.nextInt();
        
        double border = (2.0 * A + C) / 3.0;
        
        System.out.printf("%.1f%n", border);
    }
}
