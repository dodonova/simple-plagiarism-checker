#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int a, b, c, d;
    cin >> a >> c >> d;
    b = a;
    while ((2 * a + b + c + d) > (a + 3 * b + d)){
        b++;
    }
    cout << b;
    return 0;
}