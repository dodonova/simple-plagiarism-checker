t_A, t_C, t_D = map(int, input().strip().split())
border = (2 * t_A + t_D - t_C) / 2
print(f"{border:.1f}")