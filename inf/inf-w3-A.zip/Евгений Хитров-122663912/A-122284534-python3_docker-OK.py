def find_border(num1, num2, num3):

  time_first = num1 + num1 + num2 + num1 + num3
  time_second = num1 + num1 + num3 + num1 + num1

  if time_second < time_first:
    return (time_first - time_second) / 2 + num1
  else:
    return (time_second - time_first) / 2 + num1

num1, num2, num3 = map(int, input().split())

print(find_border(num1, num2, num3))
