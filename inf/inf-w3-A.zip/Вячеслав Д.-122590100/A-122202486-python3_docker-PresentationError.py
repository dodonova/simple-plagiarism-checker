def calculate_border_time(X, Y, Z):
    border = (Z - X + Y) / 2 + X
    return border

X = 2  
Y = 6  
Z = 12 

border_time = calculate_border_time(X, Y, Z)
print(f"Граница времени для B: {border_time:.2f} минут")