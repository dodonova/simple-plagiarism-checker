num1, num3, _ = map(int, input().split())

num2 = num1 + 0.1
while num2 <= num3+0.01:
    if (num1 + num3)/2 <= num2+0.001:
        print(round(num2,1))
        break
    num2 += 0.1