a, c, d = map(int, input().split())

L = a
R = d
while R - L > c // 2:
    M = (R + L) // 2
    if M <= c // 2:
        L = M
    else:
        R = M

print(R)

