A, C, D = int(input().split())
border = (A+C)/2
print(border)
