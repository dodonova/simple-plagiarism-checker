#include <bits/stdc++.h>
using namespace std;

using ll = long long;

ll pow_mod(ll x, ll st, ll m) {
    if (st == 0) return 1 % m;
    else if (st % 2 == 0)  return pow_mod(x * x % m, st / 2, m);
    else return x * pow_mod(x, st - 1, m) % m;
}

signed main() {
    ld a, c, d;
    cin >> a >> c >> d;
    cout << (a + c) / 2;
}
