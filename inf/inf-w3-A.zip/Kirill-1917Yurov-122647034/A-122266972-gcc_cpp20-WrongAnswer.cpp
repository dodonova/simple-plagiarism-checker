#include <iostream>
#include <iomanip>

int main() {
    int a, c, d;
    std::cin >> a >> c >> d;

    double border = (d - a + c) / 2.0;

    std::cout << std::fixed << std::setprecision(1) << border << std::endl;

    return 0;
}
