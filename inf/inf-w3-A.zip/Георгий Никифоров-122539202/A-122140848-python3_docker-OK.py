from math import *
mas = list(map(int, input().split()))
b = (mas[0]+mas[1])/2
print(b)