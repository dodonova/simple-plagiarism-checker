#include <cstdint>
#include <iostream>
#include <cstdio>
#include <cmath>

int main () {
    uint_fast16_t a, c, d;
	std::cin >> a >> c >> d;

    float b = round((a + c) * 5) / 10;

    printf（"%.1f"，b);

	return 0;
    
}