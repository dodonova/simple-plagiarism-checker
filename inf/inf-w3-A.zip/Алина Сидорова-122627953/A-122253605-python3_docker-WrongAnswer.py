a, c, d = map(int, input().split())

def way(b):
    global a, c, d
    if (2 * a + b + c + d) < (a + 3 * b + d):
        return 1
    return 2

for b in range(0, 100):
    if way(b) == 2 and way(b + 1) == 1:
        border = b
        break
print(b)