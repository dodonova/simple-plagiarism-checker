from math import floor

A, C, D = map(int, input().split())
border = floor(A + C / 2)
print(border)