a, c, d = map(int, input().split())
border = (a + c) / 2
if border.is_integer():
    print(int(border))
else:
    print(border)