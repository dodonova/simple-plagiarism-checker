# Read input values
A, C, D = map(int, input() .split())

# Calculate the border value
border = (A + C) / 2

# Output the result with one decimal place
print (f"{border:.if}")