a = int(input())
c = int(input())
d = int(input())
try:
    print((a + c) / 2)
except ZeroDivisionError:
    print(0)