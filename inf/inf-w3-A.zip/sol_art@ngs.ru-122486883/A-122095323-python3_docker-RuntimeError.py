s = input().split () 
for I in range(len(s)) :
       s[i] = int(s[i])
b = 0
while b + s[2] + s[0] + s[1] + s[0] != s[2] + s[0] + 3*b:
   b += 0.1
   print(b) 