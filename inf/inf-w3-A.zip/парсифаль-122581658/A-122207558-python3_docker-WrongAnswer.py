a, c, d = list(map(int, input().split()))

for b in range(1, 101):
    i = b + 1
    if b + a + c + a + d < i + a + d + b + b:
        print(b)
        break
