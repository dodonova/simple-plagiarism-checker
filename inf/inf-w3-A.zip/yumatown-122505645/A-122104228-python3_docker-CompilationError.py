A, C, D, map(int, input().split())
B = (A + C) / 2 
print(f"(B:,if}")