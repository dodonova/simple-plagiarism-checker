A, C, D = map(int, input().strip().split())
border = (A + D) / 2
print(f"{border:.1f}")