sus = (a + c) / 2
a, b, c = map(int, input().strip().split())
print(f"{sus:.1f}")