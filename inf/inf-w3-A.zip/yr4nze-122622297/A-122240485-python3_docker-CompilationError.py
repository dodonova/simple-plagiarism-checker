A, C, D = map(int, input().split
print(round((A + C) / 2, 1))