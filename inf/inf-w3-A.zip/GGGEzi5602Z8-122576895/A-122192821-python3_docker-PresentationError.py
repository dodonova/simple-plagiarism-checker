def strategy1(a, b, c, d):
    return b + a + c + a + d


def strategy2(a, b, c, d):
    return b + a + d + b + b


a, c, d = [int(i) for i in input().split()]
for b in range(1, 101):
    print("-" * 121)
    print(strategy1(a, b, c, d))
    print(strategy2(a, b, c, d))
    if strategy1(a, b, c, d) <= strategy2(a, b, c, d):
        print(b)
        break
