a, c, d = list(map(int, input().split()))
b = (a + a + c + d - a - d) / 2
if b % 1:
    print(round(b, 1))
else:
    print(int(b))
