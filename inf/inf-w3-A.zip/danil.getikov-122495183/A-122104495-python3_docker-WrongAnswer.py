def calculate_times(t_A, t_B, t_C, t_D):
    # Время по первой стратегии
    time_strategy1 = t_B + t_A + t_D + t_B + t_A  # 2 * t_B + t_A + t_D
    # Время по второй стратегии
    time_strategy2 = t_A + t_A + t_D + t_B + t_A  # 3 * t_A + t_D + t_B
    return time_strategy1, time_strategy2

def find_border(t_A, t_C, t_D):
    # Ищем границу для B
    for t_B in range(t_A, t_C + 1):  # Проверяем значения от t_A до t_C
        time1, time2 = calculate_times(t_A, t_B, t_C, t_D)
        if time2 < time1:
            return t_B  # Возвращаем первое значение B, при котором вторая стратегия лучше
    return 2 * t_A  # Если не нашли, значит, граница равна 2 * t_A

# Считываем входные данные
t_A, t_C, t_D = map(int, input().split())

# Находим границу для B
border = find_border(t_A, t_C, t_D)

# Выводим результат с одним знаком после десятичной точки
print(f"{border:.1f}")