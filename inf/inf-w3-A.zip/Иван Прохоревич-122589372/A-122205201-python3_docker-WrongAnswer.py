at, ct, dt = map(int, input().split())

def firstSTG(data):
    ac, bt, ct, dt = data[0], data[1], data[2], data[3]
    return bt+ac+ct+ac+dt

def secondSTG(data):
    ac, bt, ct, dt = data[0], data[1], data[2], data[3]
    return bt+ac+dt+bt+bt


for b in range(1, 101):
    f1=0
    f2=0
    data = sorted([b, at, ct, dt])
    f1=firstSTG(data)
    f2=secondSTG(data)
    if f2>f1:
        print(b-1)
        break
    