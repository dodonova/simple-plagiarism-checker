def calculate_border(t_A, t_C, t_D):
    return 2 * t_C - t_A - t_D

t_A, t_C, t_D = map(int, input().strip().split())
border = calculate_border(t_A, t_C, t_D)

print(f"{border:.1f}")