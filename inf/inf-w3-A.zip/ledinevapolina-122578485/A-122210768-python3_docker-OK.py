A, C, D = map(int,input().split())
border_B = (A + C) / 2
print(border_B)
