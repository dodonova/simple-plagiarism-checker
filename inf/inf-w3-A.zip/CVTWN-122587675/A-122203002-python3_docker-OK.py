def main(*args):
    return f"{(args[0] + args[1] ) / 2:.2f}"

args = [int(i) for i in input().split()]
print(main(*args))