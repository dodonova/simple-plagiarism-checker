def find_border(t_A, t_C, t_D):
    border = (t_C + t_D - 2 * t_A) / 4
    return border

t_A, t_C, t_D = map(int, input().split())

border = find_border(t_A, t_C, t_D)

print( round(border))