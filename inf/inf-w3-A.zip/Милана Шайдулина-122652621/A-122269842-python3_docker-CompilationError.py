S,D,A = map(int, input().split()) 
border = (S + D) / 2

            print(f"{border:.1f}")