a, c, d = [int(i) for i in input().split()]
final = (a + c) / 2
if final == float(int(final)):
    final = int(final)
print(final)
