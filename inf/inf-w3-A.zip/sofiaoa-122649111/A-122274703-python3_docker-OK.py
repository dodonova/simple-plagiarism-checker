def calculate_border(a, c, d):
    return a + (c - a) / 2

input_data = input().strip()
a, c, d = map(int, input_data.split())
border = calculate_border(a, c, d)
print(f"{border:.1f}")