#include <iostream>
#include <iomanip>


void calculateB(const int A, const int C, const int D) {
  for (double B = 1.00; ; B += 0.01) {
    if (2 * A + B + C + D < A + 3 * B + D) {
      std::cout << static_cast<int>(B) << std::endl;
      return;
    }
  }
}


int main() {
  int A, C, D;

  std::cin >> A >> C >> D;

  calculateB(A, C, D);

  return 0;
}