st1 = 0
st2 = 0.1
a, c, d = map(int, input().split())
b = a
while st1 != st2:
    st1 = round(a * 2 + b + c + d, 1)
    st2 = round(b + a + d + b * 2)
    b += 0.1
print(b - 0.1)
