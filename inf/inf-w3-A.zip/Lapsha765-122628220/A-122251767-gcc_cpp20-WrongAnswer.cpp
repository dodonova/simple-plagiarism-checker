#include<iostream>
using namespace std;
int main()
{
int a, c, d, border;
cin >> a >> c >> d;
border = ((c+a)/2)+1;
cout << border;
}