def find_border(A, C, D):
    # Мы ищем границу B, для которой T2 < T1
    # T1 будет больше, если B >= (C - A) / 2 + A
    border = (C - A) / 2 + A
    return border

# Чтение входных данных
A, C, D = map(int, input().strip().split())

# Находим границу
border = find_border(A, C, D)

# Выводим результат с одним знаком после десятичной точки
print(f"{border:.1f}")
