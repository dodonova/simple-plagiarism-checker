a, c, d = list(map(int, input().split()))
print(round((a + c) / 2, 1))