a,c,d=map(int,input().split())
b=abs(2*a-c)
print(b)