a,c,d=input().split('')
a=int(a)
c=int(c)
d=int(d)
ac=(a+c)/2
print(ac)
