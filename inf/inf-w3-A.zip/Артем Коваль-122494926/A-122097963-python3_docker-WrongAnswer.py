t_A, t_C, t_D = map(int, input().strip().split())
border = t_C - t_A
print(border - 1)