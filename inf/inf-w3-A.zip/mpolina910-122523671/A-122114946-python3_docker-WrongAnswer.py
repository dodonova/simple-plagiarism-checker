s = input() 
for i in range(len(s)): 
  if s[i:] == s[i:][::-1]: 
    print(s + s[:i][::-1]) 
    break