def calculate_border(a, c, d):
    border = c + (a + d) / 2
    return round(border) 


a, c, d = map(int, input().split())

border_value = calculate_border(a, c, d)
print(border_value)
