def calculate_border(a, c, d):
    border = (c - a) / 2 + a
    return round(border)

a, c, d = map(int, input().split())
border_value = calculate_border(a, c, d)
print(border_value)
