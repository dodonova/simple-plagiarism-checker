#include <iostream>

int main() {
    int a, c, d;

    std::cin >> a >> c >> d;

    for (int b = 0; b < 10000; ++b) {
        double f1 = 2 * a + c + d + (b / 10.0);
        double f2 = 3 * (b / 10.0) + a + d;

        if (f1 == f2) {
            std::cout << b / 10.0 << std::endl;
            break; 
        }
    }

    return 0;
}
