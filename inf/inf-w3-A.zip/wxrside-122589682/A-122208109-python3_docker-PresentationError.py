def w(A, C):
    return (C - A) / 2 + A
def q():
    A, C, D = map(int, input().split())
    border = w(A, C)
    print(f"{border:.1f}")
if __name__ == "__q__":
    q()