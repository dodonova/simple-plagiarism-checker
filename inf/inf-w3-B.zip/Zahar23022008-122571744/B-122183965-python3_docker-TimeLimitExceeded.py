a,b = input().split()
a = int(a)
b = int(b)
s = a // 2 + 2
for n in range(1, s // 2 + 1):
    m = s-n
    if n>m:
        break  
    if n * m == b + (a // 2 + 1):  
        print(n,m)
        break