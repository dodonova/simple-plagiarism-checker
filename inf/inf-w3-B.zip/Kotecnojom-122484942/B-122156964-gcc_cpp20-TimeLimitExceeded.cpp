#include <iostream>
using namespace std;

int main() {
    long a, b;
    cin >> a >> b;

    long sum = a / 2 + 2;

    for (long n = 1; n <= sum - 1; n++) {
       long m = sum - n;
        if (n <= m && (n - 1) * (m - 1) == b) {
            cout << n << " " << m << endl;
        }
    }

    return 0;
}