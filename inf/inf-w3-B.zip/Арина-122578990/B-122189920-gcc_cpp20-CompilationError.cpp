std::pair<int, int> findRectangle(int a, int b) {
    // Вычисляем s и p
    int s = (a / 2) + 2;
    int p = b + s;

    // Вычисляем дискриминант
    int D = s * s - 4 * p;

    if (D < 0) {
        return {-1, -1}; // Нет решения
    }

    // Находим корни
    int sqrt_D = static_cast<int>(std::sqrt(D));
    int n1 = (s + sqrt_D) / 2;
    int m1 = (s - sqrt_D) / 2;

    // Убедимся, что n <= m
    int n = std::min(n1, m1);
    int m = std::max(n1, m1);

    return {n, m};
}

int main() {
    int a, b;
    std::cin >> a >> b;
    
    auto result = findRectangle(a, b);

    if (result.first == -1) {
        std::cout << "No solution" << std::endl;
    } else {
        std::cout << result.first << " " << result.second << std::endl;
    }

    return 0;
}
