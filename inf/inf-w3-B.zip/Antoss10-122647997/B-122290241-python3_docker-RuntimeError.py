def can_form_grid(n, m):
    # Площадь оригинальной решетки
    original_area = n * m

    # Количество фигур
    corners = 4
    t_shapes = 2 * (n + m - 2)
    crosses = (n - 1) * (m - 1)

    # Площадь всех фигур
    total_area = (corners * 1) + (t_shapes * 2) + (crosses * 3)

    # Проверяем, совпадает ли площадь
    return original_area == total_area

# Ввод размеров решетки
n = int(input("Введите количество строк (n): "))
m = int(input("Введите количество столбцов (m): "))

if can_form_grid(n, m):
    print("Можно восстановить решетку.")
else:
    print("Невозможно восстановить решетку.")
