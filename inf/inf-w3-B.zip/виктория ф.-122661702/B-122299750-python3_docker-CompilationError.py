a, b = map(int, input().split())
a2_4 = a//2+2
for i in range (1, a2_4):
	m = a2_4 - i
	if (i-1) * (m-1) == b:
		dim = sorted ((i , m))
  		break
print(dim[0], dim[1])