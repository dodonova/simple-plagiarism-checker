a, b = map(int, input().split())

for n in range(1, 10**9):
    m = (b // (n - 1)) + 1
    if n <= m and (2 * (n + m - 2) == a):
        print(n, m)
        break