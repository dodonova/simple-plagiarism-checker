import math

a, b = map(int, input().split())
r = a ** 2 - 16 * b
for sign in [1, -1]:
    if ((a // 2 + 2) + sign * int((r // 4) ** 0.5)) % 2 != 0:
        continue
    n = ((a // 2 + 2) + sign * int((r // 4) ** 0.5)) // 2
    m = (a // 2 + 2) - n
    if n >= 1 and m >= 1:
                    if n > m:
                        n, m = m, n
                    print(n, m)
                    break