#include <iostream>
#include <cmath>
#include <string>
#include <sstream>

using namespace std;

void imp() {    
    string impa = "Impossible";
    cout << impa;
}

int main() {
    std::string a_str, b_str;
    std::cin >> a_str >> b_str;
    int a = std::stoi(a_str);
    int b = std::stoi(b_str);

    if (a % 2 != 0) {
        imp();
    } else {
        long long N = static_cast<long long>(a) * a - 16 * b;
        if (N < 0 || N % 4 != 0) {
            imp();
        } else {
            long long D = N / 4;
            long long sqrt_D = static_cast<long long>(std::sqrt(D));
            if (sqrt_D * sqrt_D != D) {
                imp();
            } else {
                int s = a / 2 + 2;
                bool found = false;
                for (int sign : {1, -1}) {
                    long long n_candidate = s + sign * sqrt_D;
                    if (n_candidate % 2 != 0) {
                        continue;
                    }
                    int n = static_cast<int>(n_candidate / 2);
                    int m = s - n;
                    if (n >= 1 && m >= 1) {
                        if (n > m) {
                            std::swap(n, m);
                        }
                        std::cout << n << " " << m;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    imp();
                }
            }
        }
    }
}

