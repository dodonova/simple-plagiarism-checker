#include <iostream>
#include <cmath>
using namespace std;
int main() {
    long long a, b;
    cin >> a >> b;
    long long c = 1+b+a/2;
    long long d = 2+a/2;
    long long f = (long long)sqrt(pow(d,2)-4*c);
    long long n = (d-f)/2;
    long long m = (d+f)/2;
    cout << n << ' ' << m << endl;
    return 0;
}