#include <stdio.h>

int main() {
    long z, b;
    scanf("%ld %ld", &z, &b);

    long s = z / 2 + 2;

    for (long n = 1; n < s; n++) {
        long m = s - n;
        if ((n - 1) * (m - 1) == b) {
            printf("%ld %ld\n", n, m);
            break;
        }
    }

    return 0;
}