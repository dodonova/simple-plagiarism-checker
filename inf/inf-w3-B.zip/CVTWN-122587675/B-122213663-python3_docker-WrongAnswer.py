import math

def find_grid_size(a, b):
    n = (a + 4) // 2 - m
    b = (n-1)*(m-1)
    b = ((a+4)/2 - m - 1)*(m-1)
    D = (a+2)**2 - 4*b
    if D < 0:
        return None
    m1 = (a+2 + math.sqrt(D)) // 2
    m2 = (a+2 - math.sqrt(D)) // 2

    for m in (m1, m2):
        n = (a+4) // 2 - m
        if n > 0 and m > 0 and n <= m:
            return (n, m)

    return None