from sympy import symbols, Eq, solve
m = int(input())
n = int(input())
# Создание символьных переменных
m, n = symbols('m n')


# Создание системы уравнений
system_of_equations = [Eq(2*(m+n-2), 16), Eq((m-1)*(n-1), 15)]

# Решение системы уравнений
solutions = solve(system_of_equations, (m, n))
print(solutions)