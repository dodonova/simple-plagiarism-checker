#include <iostream>
using namespace std;

pair<int, int> calculate_dimensions(int a, int b) {
    
    int sum_nm = a / 2 + 2;

    
    for (int n = 1; n <= sum_nm / 2; ++n) {
        int m = sum_nm - n;
        
        if ((n - 1) * (m - 1) == b) {
            return {n, m};
        }
    }
    return {0, 0}; 
}

int main() {
    int a, b;
    
    cin >> a >> b;

    
    auto [n, m] = calculate_dimensions(a, b);

    
    if (n > m) {
        swap(n, m);
    }

    cout << n << " " << m << endl;

    return 0;
}