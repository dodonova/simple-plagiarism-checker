import math # Подключаем библиотеку

b_str, e_str = input().split() # Ввод чисел
b = int(a_str)
e = int(b_str)

if b % 2 != 0:          # условие
    print("невозможно")
else:
    N = b * b - 16 * e
    if N < 0 or N % 4 != 0:
        print("невозможно")
    else:
        D = N // 4
        sqrt_D = int(math.isqrt(D))
        if sqrt_D * sqrt_D != D:
            print("невозможно")
        else:
            s = e // 2 + 2
            found = False
            for sign in [1, -1]:
                n_candidate = (s + sign * sqrt_D)
                if n_candidate % 2 != 0:
                    continue
                n = n_candidate // 2
                m = s - n
                if n >= 1 and m >= 1:
                    if n > m:
                        n, m = m, n
                    print(f"{n} {m}")
                    found = True
                    break
            if not found:
                print("невозможно")