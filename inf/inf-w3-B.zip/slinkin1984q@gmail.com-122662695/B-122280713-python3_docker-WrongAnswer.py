a, b = map(int, input().split())

# Количество т-образных фигур и крестиков
t_shapes = a
crosses = b

# Вычисляем n и m
n = (crosses + 1) // 2 + 1
m = 2 * (t_shapes + n - 1) // n + 1

# Убедимся, что n <= m
if n > m:
    n, m = m, n

print(n, m)