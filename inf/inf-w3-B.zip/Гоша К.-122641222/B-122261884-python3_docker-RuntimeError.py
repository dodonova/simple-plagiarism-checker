def find_dimensions(a, b):
    t_shapes = a
    crosses = b
    total_cells = (t_shapes // 2) + 2

    for n in range(1, int(total_cells ** 0.5) + 1):
        if total_cells % n == 0:  
            m = total_cells // n
            if n > m:
                break
            if (n - 1) * (m - 1) == crosses:
                return (n, m)
    return None
a, b = map(int, input().split())
result = find_dimensions(a, b)
print(result[0], result[1])
