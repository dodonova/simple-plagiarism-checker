def f(a, b):
    S = (a // 2) + 2
    d = S * S - 4 * (b - 1 + S)
    s = 0
    while s * s < d:
        s += 1
    t1 = (S + s) // 2
    t2 = (S - s) // 2
    y1 = S - t1
    y2 = S - t2
    if t1 > y1:
        t1, y1 = y1, t1
    if t2 > y2:
        t2, y2 = y2, t2
    if t1 >= 1 and y1 >= 1:
        return (t1, y1)
    elif t2 >= 1 and y2 >= 1:
        return (t2, y2)
    return 0
a, b = map(int, input().strip().split())
ans = f(a, b)
print(ans[0], ans[1])