a, b = map(int, input().split())

S = a // 2 + 2

for n in range(1, S):
    m = S - n
    if (n - 1) * (m - 1) == b:
        print(sorted(n, m))
        break