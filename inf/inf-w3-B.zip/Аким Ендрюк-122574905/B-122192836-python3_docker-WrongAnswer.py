a, b = map(int, input().split())

S = a // 2 + 2


for n in range(2, S):
    m = S - n
    if (n - 1) * (m - 1) == b:
        print(min(n, m), max(n, m))
        break