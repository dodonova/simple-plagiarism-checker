a, b = map(int, input().split())

if a == b == 0:
    print(1, 1)
else:
    sq = int(b ** 0.5)
    found = False
    
    for i in range(1, sq + 1):
        if b % i == 0:
            j = b // i
            perimeter = (i + j) * 2
            
            if perimeter == a:
                n, m = sorted((i + 1, j + 1))
                print(n, m)
                found = True
                break