#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    long long a, c;
    cin >> a >> c;
    
    // Используем тип данных double для правильного деления и округления
    double result = (a + c) / 2.0;
    
    // Округление до одного знака после запятой
    cout << fixed << setprecision(1) << result << endl;
    
    return 0;
}
