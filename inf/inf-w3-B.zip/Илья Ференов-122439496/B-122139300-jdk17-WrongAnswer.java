import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        
        int d = (4 + a) * (4 + a) - 4 * (0 - 2) * (0 - 2 - a - 2 * b);
        int m = Math.max((0 - (4 + a) + (int)Math.sqrt(d)) / (-2 * 2), (0 - (4 + a) - (int)Math.sqrt(d)) / (-2 * 2));
        int n = (a - 2 * m + 4) / 2;
        
        System.out.println(n + " " + m);
        
        scanner.close();
    }
}

