#include <iostream>
#include <cmath>
#include <algorithm>

int main() {
    int a, b;
    std::cin >> a >> b;

    double d = std::pow((4 + a), 2) - 4 * (0 - 2) * (0 - 2 - a - 2 * b);
    double m1 = (-(4 + a) + std::sqrt(d)) / (-2 * 2);
    double m2 = (-(4 + a) - std::sqrt(d)) / (-2 * 2);

    double m = std::max(m1, m2);
    double n = (a - 2 * m + 4) / 2;

    std::cout << static_cast<int>(n) << " " << static_cast<int>(m) << std::endl;

    return 0;
}
