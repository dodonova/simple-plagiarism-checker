import math
def find_dimensions(z, x):
    S = (z // 2) + 2
    D = S * S - 4 * (S + x - 1)
 
    if D < 0:
        return None  
 
    sqrt_D = int(math.isqrt(D))
 
    n01 = (S + sqrt_D) // 2
    m01 = (S - sqrt_D) // 2
 
    n02 = (S - sqrt_D) // 2
    m02 = (S + sqrt_D) // 2
 
    n = min(n01, m01)
    m = max(n01, m01)
 
    return (n, m)
 
z, x = map(int, input().strip().split())
n, m = find_dimensions(z, x)
 
if n is not None and m is not None:
    print(n, m)