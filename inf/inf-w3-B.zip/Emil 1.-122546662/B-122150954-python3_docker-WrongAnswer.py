a, b = input().split()
a = int(a)
b = int(b)

D = (a**2)/4 - 4*b
if a == 0 or b == 0:
    print(1, 1)
else:
    print(int(b/((a/2 + D**0.5)/2) + 1), int((a/2 + D**0.5)/2 + 1))
