import math
a, b = list(map(int, input().split()))
n = a * a - 16 * b
d = n // 4
sq = int(math.isqrt(d))
s = a // 2 + 2
for i in [1, -1]:
    n1 = (s + i * sq)
    if n1 % 2 != 0:
        continue
    n = n1 // 2
    m = s - n
    if n >= 1 and m >= 1:
        print(min(n, m), max(n, m))
        break