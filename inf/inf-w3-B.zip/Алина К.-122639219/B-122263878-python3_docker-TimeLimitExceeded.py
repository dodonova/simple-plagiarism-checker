def find_grid_dimensions(a, b):
    sum_n_m = a // 2 + 2
    for m in range(1, sum_n_m):
        n = sum_n_m - m
        if (n - 1) * (m - 1) == b:
            return min(n, m), max(n, m)
    
    return None


import sys
input = sys.stdin.read
data = input().split()

a = int(data[0])
b = int(data[1])


result = find_grid_dimensions(a, b)
if result:
    print(result[0], result[1])
