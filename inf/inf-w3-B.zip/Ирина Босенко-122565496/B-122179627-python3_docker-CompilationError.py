import math
def find_dimensions(a, b):   S = a // 2 + 2
   D = S**2 - 4 * (b + S - 1)   if D < 0:
       return None   sqrt_D = math.isqrt(D)
   if sqrt_D * sqrt_D != D:       return None
   n1 = (S + sqrt_D) // 2   n2 = (S - sqrt_D) // 2
   if n1 <= 0 or n2 <= 0:       return None
   n = min(n1, n2)   m = max(n1, n2)
   return n, m
a, b = map(int, input().split())i = find_dimensions(a, b)
print(i[0], i[1])