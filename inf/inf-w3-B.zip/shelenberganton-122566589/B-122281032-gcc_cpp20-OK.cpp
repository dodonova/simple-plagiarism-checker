#include <iostream> 
#include <vector> 
#include <string> 
#include <map> 
#include <set> 
#include <algorithm> 
#include <queue> 
#include <cmath> 
#include <ctime> 
#include <numeric> 
 
using ll = long long; 
using dl = long double; 
 
using namespace std;

int main() {
    ll a, b;
    cin >> a >> b;
    if (a == 0 && b == 0) {
        cout << 1 << " " << 1;
        return 0;
    }
    ll m = (4 + a + sqrt(a * a - 16 * b)) / 4;
    ll n = (b + m - 1) / (m - 1);
    cout << n << " " << m;
}