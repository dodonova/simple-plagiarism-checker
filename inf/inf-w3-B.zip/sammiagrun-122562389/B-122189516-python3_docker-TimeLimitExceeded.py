def find_dim(a, b):
    s = a // 2 + 2

    for n in range(1, s):
        m = s - n
        if (n - 1) * (m - 1) == b:
            return (min(n, m), max(n, m))

    return None

a, b = map(int, input().split())

result = find_dim(a, b)

if result:
    print(result[0], result[1])