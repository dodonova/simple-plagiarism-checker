a, b = map(int, input().split())
S = (a // 2) + 2
for n in range(1, S):
	m = S - n
    if (n - 1) * (m - 1) == b:
        dimensions = n, m
  
if dimensions:
    n, m = dimensions
    # Убедимся, что n <= m
    if n > m:
        print(m, n)
    else:
        print(n, m)
else:
    print("Нет решения")