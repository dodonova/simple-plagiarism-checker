def find_dimensions(a, b):
    S = (a // 2) + 2
    
    for n in range(1, S):
        m = S - n
        if (n - 1) * (m - 1) == b:
            return n, m
    
    return None

a, b = map(int, input().split())

dimensions = find_dimensions(a, b)

if dimensions:
    n, m = dimensions ##
    if n > m:
        n, m = m, n
    print(n, m)
else:
    print("Нет решения")