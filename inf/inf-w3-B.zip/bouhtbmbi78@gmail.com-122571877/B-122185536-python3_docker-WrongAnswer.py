import math

def find_dimensions(a, b):
    S = (a // 2) + 2
    
    D = (S + 1) ** 2 - 4 * (b + S)

    if D < 0:
        return None  
    sqrt_D = int(math.isqrt(D))  
    if sqrt_D * sqrt_D != D:
        return None

    n1 = (S + 1 + sqrt_D) // 2
    n2 = (S + 1 - sqrt_D) // 2

    for n in (n1, n2):
        m = S - n
        if n > 0 and m > 0 and (n - 1) * (m - 1) == b:
            return min(n, m), max(n, m)

    return None


a, b = map(int, input().split())
dimensions = find_dimensions(a, b)

if dimensions:
    print(dimensions[0], dimensions[1])
else:
    print("Нет решения")