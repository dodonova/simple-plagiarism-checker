a, b = map(int, input().split())

corners = 4

n = b + 1
m = a + 1

if n > m:
	n, m = m, n

print(n, m)