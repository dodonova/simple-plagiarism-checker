import math

def calculate_rectangle_dimensions(a, b):
   
    S = a // 2 + 2
    D = S * S - 4 * (b + a // 2 + 1)
    
    if D < 0:
        return None
    
    sqrt_D = math.isqrt(D)
    
    if sqrt_D * sqrt_D != D:
        return None
    
    n1 = (S + sqrt_D) // 2
    n2 = (S - sqrt_D) // 2
    
    return (min(n1, n2), max(n1, n2))

a, b = map(int, input().split())

result = calculate_rectangle_dimensions(a, b)

if result:
    print(*result)
else:
    print("No solution")