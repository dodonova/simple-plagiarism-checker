#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    int a, b;
    cin >> a >> b;
    double m = 0.25 * (4 + a + sqrt(-16 * b + a * a));
    double n = (-1 + b + m) / (-1 + m);
    cout << n << " " << m;
    return 0;
}