a, b = [int(i) for i in input().split()]
for n in range(1, 109):
    flag = False
    for m in range(1, 109):
        if ((2 * (n + m - 2)) == a) and ((n - 1) * (m - 1) == b):
            print(n, m)
            flag = True
            break
    if flag:
        break