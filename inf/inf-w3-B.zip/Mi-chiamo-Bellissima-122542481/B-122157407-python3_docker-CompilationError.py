a, b = [int(i) for i in input().split()]
n = 0
m = 0
flag = False
for i in range(1, 109):
    for j in range(1, 109):
		n = i
		m = j
        if ((2 * (n + m - 2)) == a) and ((n - 1) * (m - 1) == b):
            flag = True
            break
    if flag:
        break
print(n, m)