def find_grid_dimensions(a, b):
    # Общее количество клеток в сетке
    total_cells = a + b + 4  # 4 - это уголки

    # Теперь мы можем рассчитать размер решетки n и m
    for n in range(1, int((total_cells)**0.5) + 1):
        if total_cells % n == 0:
            m = total_cells // n
            if n <= m:  # Убедимся, что n <= m
                # Проверим, соответствуют ли a и b вычисленным
                calculated_a = 2 * (n + m - 2)
                calculated_b = (n - 1) * (m - 1)
                if calculated_a == a and calculated_b == b:
                    return (n, m)
    return None

# Считывание входных данных
a, b = map(int, input().split())
result = find_grid_dimensions(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
else:
    print("Решение не найдено.")