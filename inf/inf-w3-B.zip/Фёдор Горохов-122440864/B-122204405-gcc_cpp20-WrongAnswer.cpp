#include <iostream>

int main() {
    int a, b;
    std::cin >> a >> b;

    for (int n = 1; n <= (a / 2) + 2; ++n) {
        int m = (a / 2 + 2 - n);
        if (m > 0) {
            if ((n - 1) * (m - 1) == b) {
                std::cout << n << " " << m <<std::endl;
            }
        }
    }
}
