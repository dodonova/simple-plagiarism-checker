import math
def find_grid_dimensions(a, b):
    D = (1 - a / 2) ** 2 - 4 * (b - a / 2)
    if D < 0:
        return None
    sqrt_D = math.sqrt(D)
    n1 = (1 - a / 2 + sqrt_D) / 2
    n2 = (1 - a / 2 - sqrt_D) / 2
    candidates = []
    for n in [n1, n2]:
        if n.is_integer() and n > 0:
            n = int(n)
            m = (a // 2) - n + 2
            if n <= m and (n - 1) * (m - 1) == b:
                candidates.append((n, m))
    return candidates[0] if candidates else None
a, b = map(int, input().split())
result = find_grid_dimensions(a, b)
if result:
    print(result[0], result[1])