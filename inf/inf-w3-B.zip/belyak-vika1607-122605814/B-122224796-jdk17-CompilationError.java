m=total-n
if n*m=product:
print(n,m)
break