n, m = int(input()), int(input())

c = 0

for i in range(n):

for j in range(m):

if i == j:

c += 1

for i in range(-1, -n - 1, -1):

for j in range(-1, -n - 1, -1):

if i == j:

c += 1

print(c)