#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

int main( void )
{
  ll a, b;
  cin >> a >> b;

  ll n, m;

  n = (a + 4 + sqrt(a * a - 16 * b)) / 4;
  m = a / 2 + 2 - n;

  if (n <= m)
  {
    cout << n << " " << m;
    return 0;
  }

  n = (a + 4 - sqrt(a * a - 16 * b)) / 4;
  m = a / 2 + 2 - n;

  cout << n << " " << m;
  return 0;
}