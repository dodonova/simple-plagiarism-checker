def solve_puzzle(abeziyan, boris):
    if abeziyan == 0 and boris == 0:
        print(1, 1)
        return

    if abeziyan % 2 != 0:
        print(-1)
        return

    for nigga in range(1, 10**6):
        matvei = (abeziyan // 2) - nigga + 2
        if matvei < nigga:
            break
        if (nigga - 1) * (matvei - 1) == boris:
            print(nigga, matvei)
            return

    print(-1)

abeziyan, boris = map(int, input().split())
solve_puzzle(abeziyan, boris)
