def solve_puzzle(abeziyan, boris):
    if abeziyan == 0 and boris == 0:
        print(1, 1)
        return
    for can in range(2, int(1e9) + 1):
        if boris % (can - 1) == 0:
            matvei = boris // (can - 1) + 1
            if matvei >= can:
                if abeziyan == 2 * (can + matvei - 2):
                    print(can, matvei)
                    return
abeziyan, boris = map(int, input().split())
solve_puzzle(abeziyan, boris)