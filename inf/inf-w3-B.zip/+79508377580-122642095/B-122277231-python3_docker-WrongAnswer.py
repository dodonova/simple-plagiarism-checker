import math

b, c = map (int, input().split ())
a=1

d = (-2-0.5*b) ** 2 - 4 * (0.5*b+1+c)

if d >= 0:
    x1 = (-(-0.5*b-2) + math.sqrt(d)) // (2 * a)
    x2 = (-(-0.5*b-2) - math.sqrt(d)) // (2 * a)
    if x1>x2:
        print (int(x2), int(x1))
    if x1<x2:
        print (int(x2), int(x1))
    if x1==x2:
        print (int(x2), int(x1))
   