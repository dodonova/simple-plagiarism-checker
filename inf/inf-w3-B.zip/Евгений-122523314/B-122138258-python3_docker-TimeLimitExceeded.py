def func(a, b):
    h_a = a // 2

    for i in range(1, int(b ** 0.5) + 2):
        k = h_a + 2 - i
        if k > 0 and (i - 1) * (k - 1) == b:
            return (min(i, k), max(i, k))

    return (1, 1) if a == 0 and b == 0 else None

a, b = map(int, input().split())
result = func(a, b)

if result:
    n, m = result
    print(n, m)