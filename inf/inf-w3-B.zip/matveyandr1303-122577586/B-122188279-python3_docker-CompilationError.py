def find_dimensions(k, b):
	s = k // 2+2
    p = b + s - 1
    d = s*s - 4 * p
    if d < 0:
    	return Note
	root1 = (s + d**0.5) / 2
	root2 = (s - d**0.5) / 2
	n = int(min(root1, root2))
	m = int(max(root1, root2))
	return n, m
k, b = map(int, input().strip().split())
n, m = find_dimensions(k, b)
print(n, m)