a,b = map(int,input().split())
d = (a+4)**2-8*(a+2+2*b)
kd = int(d**0.5)
print(((a+4)-kd)//4,((a+4)+kd)//4)