#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ld = long double;
#define int ll

signed main() {

    int a,b; cin >> a >> b;
    int prod = a + b + 4;
    int _prod = prod;

    vector<int> del;
    for(int i = 2; i*i <= _prod; i++) {
        while(prod % i == 0) {
            del.push_back(i);
            prod /= i;
        }
    }

    cout << del[0]-1 << ' ' << _prod / del[0]-1 << '\n';

    return 0;
}
