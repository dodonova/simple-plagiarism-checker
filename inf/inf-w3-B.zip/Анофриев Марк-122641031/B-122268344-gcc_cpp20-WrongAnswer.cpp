#include <iostream>
#include <cmath>

int main() {
    long long a, b;
    std::cin >> a >> b;

    // Вычисляем S и P
    long long S = a / 2 + 2;
    long long P = b + S;

    // Вычисляем дискриминант
    long long D = S * S - 4 * P;

    if (D < 0) {
        std::cout << "Нет решения" << std::endl;
        return 0;
    }

    // Находим корни
    double sqrtD = sqrt(D);
    long long n1 = (S + sqrtD) / 2;
    long long n2 = (S - sqrtD) / 2;

    // Убедимся, что n1 и n2 целые
    if (n1 > n2) std::swap(n1, n2);

    // Проверяем условия и выводим результат
    if (n1 >= 1 && n2 >= n1) {
        std::cout << n1 << " " << n2 << std::endl;
    } else {
        std::cout << "Нет решения" << std::endl;
    }

    return 0;
}
