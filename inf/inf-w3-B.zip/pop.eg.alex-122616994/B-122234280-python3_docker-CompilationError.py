from math import
a,b=map(int(input().split())
m=0.25*(a+4)+(0.25*(a+4))**2-(b+0.5*a+1)**0.5
n=0.5*(a+4)-m
print(m,n)