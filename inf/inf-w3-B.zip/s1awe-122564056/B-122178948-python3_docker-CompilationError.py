def find_dimensions(a, b):
    for n in range(1, a + 3):  # n может быть от 1 до a + 2
        m = a + 2 - n  # Вычисляем m на основе n
        # Проверяем, удовлетворяет ли (n - 1) * (m - 1) = b
        if (n - 1) * (m - 1) == b:
            return n, m return None  # Если не найдено, хотя по условию задачи это не должно происходить

# Чтение входных данных
a, b = map(int, input().split())
result = find_dimensions(a, b)

if result:
    n, m = result
    # Убедимся, что n <= m
    if n > m:
        n, m = m, n
    print(n, m)
else:
    print("No solution found")