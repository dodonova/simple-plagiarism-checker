def find_dimensions(a, b):
    # Считаем значение для n + m
    n_plus_m = (a // 2) + 2
    
    # Перебираем возможные значения n только до n_plus_m
    for n in range(1, n_plus_m):
        m = n_plus_m - n  # Вычисляем m
        if (n - 1) * (m - 1) == b:  # Проверяем условие для крестиков
            return n, m  # Возвращаем найденные значения n и m

# Чтение входных данных
a, b = map(int, input().split())

# Находим размеры прямоугольной решетки
n, m = find_dimensions(a, b)

# Вывод результата
print(n, m)