def find_dimensions(a, b):
    for n in range(1, a + 3):  # n может быть от 1 до a + 2
        m = a + 2 - n if n <= m and (n - 1) * (m - 1) == b:
            return n, m
    return None  # Если не найдено, хотя по условию задачи это не должно происходить

# Чтение входных данных
a, b = map(int, input().split())
n, m = find_dimensions(a, b)
print(n, m)