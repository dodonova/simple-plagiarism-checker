def find_dimensions(a, b):
    P = (a // 2) + 2 
    for m in range(3, P):  
        n = P - m
        if (n - 1) * (m - 1) == b:
            return n, m
    return None


a, b = map(int, input().strip().split())


n, m = find_dimensions(a, b)


print(n, m)