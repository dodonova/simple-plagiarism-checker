a,b=map (int,input().split())
k=(a+4)/2
l=(b-1+k)
d=(k**2-4*1)
m=((k-d**0.5)/2)
n=k-m
n=int(input())
m=int(input())
print (m,n)