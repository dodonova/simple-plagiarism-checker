def find_grid_dimensions(a, b):
    for n in range(1, int(1e9) + 1):
        m = (a // 2) + 2 - n
        if m >= n and (n - 1) * (m - 1) == b:
            return n, m

a, b = map(int, input().split())
n, m = find_grid_dimensions(a, b)
print(n, m)
