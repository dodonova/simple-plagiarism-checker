def find_grid_dimensions(a, b):
    
    for n in range(1, int(b**0.5) + 2):
        # Вычисляем m из первого уравнения
        if (a + 2 * n - 4) % 2 != 0:
            continue
        m = (a + 2 * n - 4) // 2
        # Проверяем второе уравнение
        if (n - 1) * (m - 1) == b and n <= m:
            return n, m
    return None

# Чтение входных данных
a, b = map(int, input().split())

# Поиск размеров решетки
result = find_grid_dimensions(a, b)


if result:
    print(result[0], result[1])

