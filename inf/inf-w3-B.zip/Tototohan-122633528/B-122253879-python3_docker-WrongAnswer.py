a, b = map(int,input().split())

for i in range(0, a//2+1):
    for j in range(0, a//2+1):
        if i*j == b:
            if i < j:
                print(i+1, j+1)