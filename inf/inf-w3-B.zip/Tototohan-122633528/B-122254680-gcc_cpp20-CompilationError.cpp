#include <iostream>
using namespace std;
int main()
{
    int a;
    int b;
	cin >> a >> b;
	for (int i=0; i<=a/2;i++){
     	j = a/2 - i;
     	if (i*j == b && i <= j){
     		cout << i << " " << j;
    
		}
	}

	
}