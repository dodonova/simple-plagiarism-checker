import math

a_str, b_str = input().split()
a = int(a_str)
b = int(b_str)

if a % 2 == 0:
    N = a * a - 16 * b
    if N < 0 or N % 4 != 0:
        print("Impossible")
    elif N > 0:
        D = N // 4
        if D ** 0.5 == math.sqrt(D):
            s = a // 2 + 2
            for sign in [-1, 1]:
                n_candidate = (s + sign * math.sqrt(D)) // 2
                if n_candidate % 2 == 0:
                    n = n_candidate
                    m = s - n
                    if n >= 1 and m >= 1:
                        if n > m:
                            n, m = m, n
                        print(f"{n} {m}")
                        break
print("Impossible")
