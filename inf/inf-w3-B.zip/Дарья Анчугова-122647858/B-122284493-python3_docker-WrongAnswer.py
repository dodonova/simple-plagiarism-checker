a,b= map(int,input().split())
s=a/2
s2=4*b
dicrim=s**2-s2
x1=(s+(dicrim)**0.5)/2
m=int(x1)+1
s3=a//2
n=s3-m+2
print(n,m)