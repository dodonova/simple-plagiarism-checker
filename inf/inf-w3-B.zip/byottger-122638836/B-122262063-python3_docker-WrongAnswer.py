
def find_dimensions(a, b):
    # Обработка случая, когда нет фигур
    if a == 0 and b == 0:
        return 1, 1

    n_plus_m = a + 2

    # Перебираем возможные значения n
    for n in range(1, n_plus_m):  # n должен быть от 1 до n + m - 1
        m = n_plus_m - n  # Вычисляем m
        if (n - 1) * (m - 1) == b:  # Проверяем условие для крестиков
            return n, m

    return None  # На случай, если нет решений

# Чтение входных данных
a, b = map(int, input().split())
n, m = find_dimensions(a, b)

# Вывод результата, минимальное и максимальное
print(min(n, m), max(n, m)) 
