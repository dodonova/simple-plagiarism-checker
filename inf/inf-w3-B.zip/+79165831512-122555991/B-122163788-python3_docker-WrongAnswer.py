import math
a, b = map(int, input().split())
m = (4 + a + math.sqrt(a * a - 16 * b)) // 4
n = b // (m - 1) + 1
print(int(n))
print(int(m))