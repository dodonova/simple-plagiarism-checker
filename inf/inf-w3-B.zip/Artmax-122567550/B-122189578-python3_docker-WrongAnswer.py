t, x = map(int, input().split())
# t = 2(n + m - 2)
# x = (n-1)(m-1)

# n = t/2 - m + 2
# x = (t/2 - m + 1)(m - 1)

# mt/2 - t/2 - m**2 + 2m - 1 - x = 0
# -m**2 + (2 + t/2)m - (t/2 + 1 + x) = 0
# m ** 2 - (2 + t/2) * m + (t/2 + 1 + x) = 0
a = 1
b = -(2 + t/2)
c = (t/2 + 1 + x)
d = b ** 2 - 4 * a * c
m1 = (-b - d ** 0.5) / (2 * a)
m2 = (-b + d ** 0.5) / (2 * a)
m = max(m1, m2)
n = t/2 - m + 2
if n < m:
    print(int(n), int(m))
else:
    print(int(m), int(n))
