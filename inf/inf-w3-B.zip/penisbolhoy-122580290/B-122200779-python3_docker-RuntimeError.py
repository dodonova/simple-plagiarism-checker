n = int(input()) 
s = input()  
massiv = s.split()  
massiv = [int(item) for item in massiv]
massiv.sort(reverse=True)
k_a=0
k_b=0
a=[]
b=[]
for i in range(len(massiv)):
    (a if i % 2 == 0 else b).append(massiv[i])
S=[]
o=0
k_S=0
for x in reversed(range(len(b))):    
    S.append(o)
    for i in range(b[x]):
        if len(a)>i:
            if (a[i]>=(x+1)):
                S[k_S]+=(x+1)
    k_S+=1
print(max(S))  
