import math
import sys
def find_grid_dimensions(area, perimeter):
    semi_perimeter = area // 2 + 2
    adjusted_perimeter = perimeter + semi_perimeter - 1
    discriminant = semi_perimeter * semi_perimeter - 4 * adjusted_perimeter
    sqrt_discriminant = math.isqrt(discriminant)
    rows = (semi_perimeter - sqrt_discriminant) // 2
    cols = (semi_perimeter + sqrt_discriminant) // 2
    return rows, cols
def main():
    input_line = sys.stdin.read().strip()
    if not input_line:
        area, perimeter = 0, 0
    else:
        area, perimeter = map(int, input_line.split())
    rows, cols = find_grid_dimensions(area, perimeter)
    print(rows, cols)
if __name__ == "__main__":
    main()