#include <iostream>
using namespace std;
int main() {
    long long x, y;
    cin >> x >> y;
    long long n, m;
    for (n = 1; n <= x / 2 + 2; n++) {
        m = (x / 2 + 2) - n;
        if (m < n) break;
        if ((n - 1) * (m - 1) == y) {
            cout << n << " " << m << endl;
            return 0;
        }
    }
    cout << "1 1" << endl;
    return 0;
}