a, b = list(map(int, input().split()))

if b == 0:
    print(1, 1)
else:
    for m in range(2, 10 ** 9):
        if (a // 2) - m + 2 == (b // (m - 1)) + 1:
            n = (b / (m - 1)) + 1
            print(min(m, n), max(m, n))
            break
