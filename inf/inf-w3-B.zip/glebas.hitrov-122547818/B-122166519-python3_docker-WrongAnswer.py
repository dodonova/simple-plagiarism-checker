from math import sqrt

data_input = input().split()
a = int(data_input[0])
b = int(data_input[1])

n = 1
m = 1

D = (a - 4) * (a - 4) - 4 * 2 * (-a + 2 + 2 * b)

m1 = (-(4 - a) + sqrt(D)) / 4
m2 = (-(4 - a) - sqrt(D)) / 4

n1 = (a - 2 * m1 + 4) / 2
n2 = (a - 2 * m2 + 4) / 2

if m1 > 0 and n1 > 0 and (n2 < 0 or m2 < 0):
    n = n1
    m = m1
elif m2 > 0 and n2 > 0 and (n1 < 0 or m1 < 0):
    n = n2
    m = m2
elif m1 > 0 and n1 > 0 and m2 > 0 and n2 > 0:
    n = n1
    m = m1

if n > m:
    print(f"{m} {n}")
else:
    print(f"{n} {m}")
