def main():
    a, b = map(int, input().split())

    for c in range(1, a // 2 + 3):
        d = b // 2 + 2 - c
        if d < c:
            break
        if (c - 1) * (d - 1) == b:
            print(c, d)
            return

    print("1 1")

if __name__ == "__main__":
    main()