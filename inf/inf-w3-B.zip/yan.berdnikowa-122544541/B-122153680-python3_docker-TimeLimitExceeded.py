a, b = map(int, input().split())
if a+b>100000000:
    y=1000000
    x= 10**9
else:
    y=1
    x=10**9
for n in range(y, x):
    if (n - 1) * (((a + 4 - 2 * n) / 2) - 1) == b:
        m = int((a + 4 - 2 * n) / 2)
        if n <= m:
            print(min(n, m), max(n, m))
            break
