#include<iostream>
#include <math.h>

using namespace std;


int main()
{
    double a, b;
    cin >> a >> b;
    double npm = a / 2 + 2;
    //cout << npm << endl;
    double nm = b - 1 + npm;
    //cout << nm << endl;
    double n = 0, m = 0;
    for(; m < npm; m++){
        for(; n < m + 1; n++){
            //cout << 2 * (n + m - 2) << "       " << (n - 1) * (m - 1);
            //cout<< "   " << n << "  " << m << endl;
            if( 2 * (n + m - 2 ) == a and (n - 1) * (m - 1) == b){
                cout << n <<  " " << m;
                return 0;
            }
        }
        n = 0;
    }
    cout << "--";
    
}
