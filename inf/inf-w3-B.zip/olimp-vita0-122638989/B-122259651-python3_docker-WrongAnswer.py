
from math import *

a, b = map(float, input().split())

a1 = -1
b1 = 2 + (a / 2)  # Changed to regular division
c1 = -(a / 2) - 1 - b  # Changed to regular division

D = b1**2 - 4 * a1 * c1

if D > 0:
    n1 = (-b1 - sqrt(D)) / (2 * a1)
    n2 = (-b1 + sqrt(D)) / (2 * a1)
    n = min(n1, n2)
elif D == 0:
    n = -b1 / (2 * a1)

n = int(n)
m = int(a / 2 + 2 - n)  # Changed to regular division

print(n, m)
