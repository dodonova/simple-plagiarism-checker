#include <iostream>

using namespace std;

int main()
{
    int a, b, n = 0, m = 0, r;
    cin >> a >> b;

    r = (a / 2 + 2);
    for (n = r - 1; n > 0; --n)
    {
        m = r - n;

        if ((n - 1) * (m - 1) == b)
        {
            cout << n << " " << m << endl;
            break;
        }
    }

    return 0;
}
