#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int a, b, n, m;
    cin >> a >> b;
    a /= 2;
    a += 2;
    //cout << a << endl;
    n = max((a * -1 + sqrt(a * a - 4 * (1 - b - a) * -1)) / -2, (a * -1 - sqrt(a * a - 4 * (1 - b - a) * -1)) / -2);
    cout << min(a - n, n) << " " << max(n, a - n);
    return 0;
}


