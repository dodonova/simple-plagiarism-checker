a, b = map(int, input().split())
D = a ** 2 / 4 - 4 * b
x1 = ((4 + a) / 2 + D ** 0.5) / 2
x2 = ((4 + a) / 2 - D ** 0.5) / 2
print(int(min(x1, x2)), int(max(x1, x2)))