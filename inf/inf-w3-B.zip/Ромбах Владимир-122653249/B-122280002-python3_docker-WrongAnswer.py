import math
a, b = map(int, input().split())
D = a ** 2 / 4 - 4 * b
x1 = ((4 + a) / 2 + math.sqrt(D)) / 2
x2 = ((4 + a) / 2 - math.sqrt(D)) / 2
print(int(round(min(x1, x2), 0)), int(round(max(x1, x2), 0)))