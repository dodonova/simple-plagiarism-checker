def find_dimensions(a, b):
    # Вычисляем n + m
    total_sum = a // 2 + 2
    
    # Перебираем возможные значения n
    for n in range(1, total_sum):
        m = total_sum - n
        if (n - 1) * (m - 1) == b:
            return (min(n, m), max(n, m))
    
    return None

# Чтение входных данных
a, b = map(int, input().split())
result = find_dimensions(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
else:
    print("No solution")
