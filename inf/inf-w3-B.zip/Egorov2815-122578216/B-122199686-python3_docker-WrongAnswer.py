import math
import sys

def find_dimensions(a, b):
    # Вычисляем S
    S = a // 2 + 2
    
    # Вычисляем дискриминант
    D = S * S + 4 * (b - 1)
    
    # Если дискриминант меньше нуля, решения нет
    if D < 0:
        return None
    
    sqrt_D = int(math.isqrt(D))  # Извлекаем целую часть квадратного корня
    
    # Проверяем, является ли D полным квадратом
    if sqrt_D * sqrt_D != D:
        return None
    
    # Находим два возможных значения для n
    n1 = (S + sqrt_D) // 2
    n2 = (S - sqrt_D) // 2
    
    # Проверяем оба значения
    for n in (n1, n2):
        if n > 0 and S - n > 0:  # Проверяем, что n и m положительные
            m = S - n
            return (min(n, m), max(n, m))
    
    return None

# Чтение входных данных
input_data = sys.stdin.read()
a, b = map(int, input_data.split())
result = find_dimensions(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
else:
    print("No solution")
