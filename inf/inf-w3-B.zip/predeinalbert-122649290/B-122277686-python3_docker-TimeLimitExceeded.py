def find_dimensions(a, b):
    K = a // 2 + 2 
    for n in range(1, K):
        m = K - n
        if (n - 1) * (m - 1) == b:
            return n, m

a, b = map(int, input().split())
n, m = find_dimensions(a, b)
print(str(n)+str(" ")+str(m))