a,b = map(int,input()).split()
import math

def sol(a, b, c):
    discriminant = b**2 - 4*a*c
    if discriminant > 0:
        x1 = (-b + math.sqrt(discriminant)) / (2*a)
        x2 = (-b - math.sqrt(discriminant)) / (2*a)
        return max(x1, x2)
    elif discriminant == 0:
        x1 = -b / (2*a)
        return x1
    else:
        return None
b1 = -1-(a+4)/2
c1 = (a+4)/2 +b
m = sol(1,b1,c1)
n = (a+4-2*m)/2
print(n,m)
