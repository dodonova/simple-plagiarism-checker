a, b = map(int, input().split())

n = 1
m = 1

for i in range(1, min(a, b) + 1):
    if a % i == 0 and b % i == 0:
        j = a // i + 2
        k = b // i + 2
        
        if (i + 1) * (j + 1) == a and (i + 1) * (k + 1) == b:
            n = i + 1
            m = max(j, k)
            break

print(n, m)