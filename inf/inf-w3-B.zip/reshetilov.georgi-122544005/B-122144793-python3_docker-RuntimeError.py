def zxc(a, b):
    for n in range(1, a + 3): 
        pudge = (a // 2) + 2 - n
        if m < n:
            continue
        
        if (n - 1) * (pudge - 1) == b:
            return n, pudge
    
    return None

a, b = map(int, input().strip().split())
result = zxc(a, b)

if result:
    print(result[0], result[1])
else:
    print("No solution")