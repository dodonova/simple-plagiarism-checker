def find_grid_size(a, b):
    if a == 0 or b == 0:
        return 1, 1
    for n in range(2, 10 ** 6):
        m = int((b + n - 1) / (n - 1))
        if m > n:
            continue

        if 2 * (n + m - 2) != a:
            continue

        if (n - 1) * (m - 1) != b:
            continue

        return n, m
a, b = map(int, input().split())
n, m = find_grid_size(a, b)
print(m, n)
