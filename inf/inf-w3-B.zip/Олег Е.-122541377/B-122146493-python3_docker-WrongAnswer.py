a, b = map(int, input().split())

disc = (a / 2 + 2) ** 2 - 4 * (1 + a / 2 + b)

print(int(((a // 2 + 2) - disc ** 0.5) // 2), int(((a // 2 + 2) + disc ** 0.5) // 2))