a, b = map(int, input().strip().split())
if a == 0 and b == 0:
    print(1, 1)
else:
    k = (a // 2) + 2
    for d in range(1, int(b**0.5) + 1):
        if b % d == 0:
            n = d + 1
            m = (b // d) + 1
            
            if n + m == k:
                print(n, m)
                break
            n, m = (b // d) + 1, d + 1
            if n + m == k:
                print(n, m)
                break
    else:
        print("No solution")