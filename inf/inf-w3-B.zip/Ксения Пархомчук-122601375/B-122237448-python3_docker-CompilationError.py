import math
def find_dimenasions(a, b):
    s = a//2 + 2 
    p = b + a//2 + 1 
    discriminant = s**2 - 4 * p
    if discriminant < 0:
        return None 
    sqrt_disc = math.sqrt(discriminant)
    n1 = ( s + sqrt_disc)/2
    n2 = ( s - sqrt_disc)/2
    if n1.is_integer() and n2.is_integer():
        n1,n2 = int(n1), int(n2)
        return (min(n1, n2), max(n1, n2))
    return None
a, b = map(int, input().split()
result = find_dimensions(a, b)
if result:
           print(result[0], result[1])
else:
           print("No valid dimensions found")