def find_dimensions(a, b):
    if a == 0 and b == 0:
        return (1, 1)
    
    sum_nm = (a + 4) // 2
    
    for n in range(1, sum_nm):
        m = sum_nm - n
        if (n - 1) * (m - 1) == b:
            return (min(n, m), max(n, m))

a, b = map(int, input().strip().split())

dimensions = find_dimensions(a, b)

print(dimensions[0], dimensions[1])