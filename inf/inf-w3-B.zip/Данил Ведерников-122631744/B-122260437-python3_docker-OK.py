from math import *
v,b= [int(i) for i in input().split()]
m=(1/4)*(4 + v +sqrt(v**2 - 16*b))
n=(1/4)*(4 + v -sqrt(v**2 - 16*b))
print(int(n), int(m))