import math

a, b = map(int, input().split())

S = a // 2 + 2

d = S ** 2 - 4 * (b + S - 1)

n1 = (S - math.sqrt(d)) / 2
m1 = S - n1
print(int(n1), int(m1))