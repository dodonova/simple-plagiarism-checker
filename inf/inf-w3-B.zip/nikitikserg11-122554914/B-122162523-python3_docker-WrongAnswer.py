a, b = map(int, input().split())
print(int(m := (4 + a + ((4 + a) ** 2 - 4 * 2 * (a + 2 * b + 2)) ** 0.5) / 4), int((0.5 * a + b + 1) / m))
