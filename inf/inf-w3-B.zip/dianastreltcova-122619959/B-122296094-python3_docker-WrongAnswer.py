a,b = map(int, input().split())
s=(a//2)+2
if s<=0:
    print(0,0)
else:
    n=(s+((b+1)%2))//2
    m=s-n

    if n>m:
        n,m = m,n

    print(n,m)