a, b = map(int, input().split())
summa = a // 2 + 2

n = 1
m = summa-n

if (n-1)*(m-1)!= b:
    n=2
    m = summa- n
    if (n-1)*(m-1)!= b:
        n= 3
        m= summa-n
        if (n-1)*(m-1)!= b:
            n= 4
            m= summa-n

print(n,m)