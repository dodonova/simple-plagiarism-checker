#include <iostream>
#include <cmath>
//#include <vector>
//#include <algorithm>

using std::cin;
using std::cout;

int main() {
  int a, b, m, n, summ;
  long long int proz;
  cin >> a >> b;
  summ = (a / 2) + 2;
  proz = b - 1 + summ;
  for(int i = 1; i < summ / 2 + 1; ++i){
    if(i * (summ - i) == proz){
      n = std::min(i, summ - i);
      m = std::max(i, summ - i);
      break;
    }
  }
  cout << n << " " << m;
}