def get_result(a, b):
    for n in range(2, int(b ** 0.5) + 2):
        m = int((a + 4 - 2 * n) / 2)
        if (n - 1) * (m - 1) == b:
            return f'{n} {m}'
    return '1 1'

a, b = list(map(int, input().split()))
print(get_result(a, b))