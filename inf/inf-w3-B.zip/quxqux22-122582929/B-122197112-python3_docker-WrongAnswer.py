import sys

a, b = map(int, sys.stdin.read().strip().split())

total_pieces = a + 2 * b + 4
for n in range(1, total_pieces + 1):
    if total_pieces % n == 0:
        m = total_pieces // n
        if n <= m:
            print(n, m)
            break