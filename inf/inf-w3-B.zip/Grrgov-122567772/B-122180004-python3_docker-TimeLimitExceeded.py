from math import sqrt

array = input().split(' ')
a = int(array[0])
b = int(array[1])

for n in range(1, int(sqrt((b + a/2 + 1))) + 1):
    if (b + a/2 + 1) % n == 0:
        m = int((b + a/2 + 1) // n)
        if n + m == a/2 + 2:
            print(min(n, m), max(n, m))