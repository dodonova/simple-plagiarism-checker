def solve_puzzle(a, b):
    # n + m
    sum_nm = a // 2 + 2
    
    # Решим квадратное уравнение через n
    # n * (sum_nm - n) = b
    # n^2 - sum_nm * n + b = 0
    
    D = sum_nm**2 - 4 * b
    
    if D < 0:
        return None  # нет решения
    
    import math
    sqrt_D = int(math.sqrt(D))
    
    n1 = (sum_nm + sqrt_D) // 2
    n2 = (sum_nm - sqrt_D) // 2
    
    n_candidates = [n1, n2]
    
    for n in n_candidates:
        if n > 0 and n <= sum_nm:
            m = sum_nm - n
            if m >= n:  # условие n <= m
                return (n, m)
    
    return None  # если не нашли решение

a, b = map(int, input().split())
n, m = solve_puzzle(a, b)
print(n, m)
