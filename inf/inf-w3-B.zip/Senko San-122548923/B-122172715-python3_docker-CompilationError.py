def find_dimensions(a, b):
    # Ищем n + m
    n_plus_m = (a // 2) + 2

    # Проходим по диапазону для поиска n и m for n in range(1, n_plus_m):
        m = n_plus_m - n
        # Проверяем условие if (n - 1) * (m - 1) == b:
            return min(n, m), max(n, m)

    return None  # Если решения не найдено

# Чтение входных данных
a, b = map(int, input().strip().split())

# Поиск размеров
result = find_dimensions(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
else:
    print("No solution found")

Найти еще