s = input().split()
a = int(s[0])           #т-образные фигуры
b = int(s[1])           #кол-во крестиков

nm = []

for n in range(a*b):
    for m in range(a*b):
        if  a == 2*(n + m - 2) and b == (n - 1)*(m - 1):
           nm.append(n)
           nm.append(m)
print(nm[0], nm[1])
           