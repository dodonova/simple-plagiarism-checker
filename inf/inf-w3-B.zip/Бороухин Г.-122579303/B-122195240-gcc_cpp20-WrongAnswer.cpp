#include <iostream>
#include <vector>
#include <bits/stdc++.h>
#include <stack>
using namespace std;
struct trinadcatiy {
        string name;
        string beb;
        int matka;
        int fiz;
        int inf;
        double howharosh;
        bool megaharosh;
    };
int main() {
    long long hrushev,bebra = 0;
    cin >> hrushev;
    cin >> bebra;
    bool nigger = 1;
    int lenin = 0,putin = 0,petr=0,suck,biba,boba;
    trinadcatiy kertin;
    stack <int> lzhedmitriy;
    queue <int> narastrel;
    vector <int> karik;
    hrushev = hrushev/2+2;
    bebra = bebra + hrushev -1;
    lenin = hrushev/4;
    while(lenin < hrushev and nigger){
        if(lenin*(hrushev-lenin) == bebra){
            nigger =0;
        }
        lenin++;
    }
    lenin--;
    cout << lenin << " " << hrushev-lenin;
    

}
