#include <iostream>
#include <cmath>
#include <string>

int main() {
    // Input reading
    int t, x;
    std::cin >> t >> x;

    // Calculate m and n
    double m = (1.0 / 4.0) * (-sqrt(t * t - 16 * x) + t + 4);
    double n = (1.0 / 4.0) * (sqrt(t * t - 16 * x) + t + 4);

    // Convert m and n to integers (equivalent to splitting and taking the integer part in Python)
    int m_int = static_cast<int>(m);
    int n_int = static_cast<int>(n);

    // Output the result
    std::cout << m_int << " " << n_int << std::endl;

    return 0;
}