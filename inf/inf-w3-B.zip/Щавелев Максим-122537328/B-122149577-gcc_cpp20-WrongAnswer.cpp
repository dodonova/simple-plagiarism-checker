#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>

int main(int argc, char** argv)
{
    int64_t a_val;
    int64_t b_val;

    std::cin >> a_val >> b_val;

    int64_t x_val = 2 + a_val / 2;
    int64_t z_val = std::pow(x_val, 2)-4*(x_val+b_val-1);
    int64_t number1_ = (x_val - std::sqrt(2)) / 2;
    int64_t enm1m1 = (x_val - number1_);

    std::cout << number1_ << enm1m1 << '\n';

    return 0;
}
