#include <iostream>
#include <cmath>
#include <algorithm>



class Solution {
public:
    void solve() {
        long long num1, num2;
        std::cin >> num1 >> num2;

        double S = static_cast<double>(num1) / 2 + 2;
        double discriminant = S * S - 4 * (num2 + S - 1);

        double second = (S - std::sqrt(discriminant)) / 2;
        double first = S - second;

        std::cout << static_cast<long long>(second) << " " << static_cast<long long>(first) << std::endl;
    }
};



int main(int argc, char** argv) {
    Solution solution;
    solution.solve();

    return 0;
}
