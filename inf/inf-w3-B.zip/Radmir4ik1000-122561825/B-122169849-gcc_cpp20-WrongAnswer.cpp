#include <iostream>
using namespace std;
int main() {
  int rf, fr;
  cin >> rf >>fr;
  for(int i=0;i<fr;i++){
    for(int j=0;j<fr;j++){
        if((i-1)*(j-1)==fr){
            cout<<min(i,j)<<' '<<max(i,j);
        }
        }
    }
}