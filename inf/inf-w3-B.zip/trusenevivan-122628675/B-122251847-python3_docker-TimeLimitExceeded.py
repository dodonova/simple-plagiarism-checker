def find_dimensions(a, b):
    s = (a // 2) + 2 # s is n + m
    for n in range(1, s // 2 + 1):
        m = s - n
        if (n - 1) * (m - 1) == b:
            return (n, m)

a, b = map(int, input().split())
n, m = find_dimensions(a, b)
print(n, m)
