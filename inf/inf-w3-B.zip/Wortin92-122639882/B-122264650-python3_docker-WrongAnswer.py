a, b = map(int, input().split())

for n in range(1, int(a/2)):
    m = (a/2) + 2 - n
    if b == (n-1)*(m-1):
        print(int(min(n, m)), int(max(n, m)))
        break