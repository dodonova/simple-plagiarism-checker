#include <bits/stdc++.h>

using namespace std;
int main()
{
    int a, b, n=0, m=0;
    cin>>a>>b;
    int c = (a+4)/2;
    for(n=1;; ++n){
        m=c-n;
        if((n-1)*(m-1)==b){
            cout<<n<<" "<<m;
            break;
        }
    }
}