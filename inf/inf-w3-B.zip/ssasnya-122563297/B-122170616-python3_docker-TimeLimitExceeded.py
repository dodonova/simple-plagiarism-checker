def impostor(a, b):
    
    amogus = (a // 2) + 2
    
    # uwu nyaaaa
    for n in range(1, amogus):
        m = amogus - n  # im sussy baka
        if (n - 1) * (m - 1) == b:  
            return min(n, m), max(n, m)  


a, b = map(int, input().split())

n, m = impostor(a, b)

print(n, m)

