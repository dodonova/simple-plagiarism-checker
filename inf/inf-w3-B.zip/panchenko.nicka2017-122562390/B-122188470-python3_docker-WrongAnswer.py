def find_grid_dimensions(a, b):
    for n in range(2, 10**6):
        if (a + 2 * (2 - n)) % 2 == 0:
            m = (a + 2 * (n - 2)) // 2
            if m >= n and (n - 1) * (m - 1) == b:
                return n, m
    return None

a, b = map(int, input().split())

if a == 0 and b == 0:
    print(1, 1)
else:
    result = find_grid_dimensions(a, b)
    if result:
        print(result[0], result[1])
