#include <iostream>

using namespace std;


int main() {
    int a, b;
    cin >> a >> b;

    int sum_nm = (a / 2) + 2;

    for (int n = 1; n <= sum_nm; ++n) {
        int m = sum_nm - n;
        if ((n - 1) * (m - 1) == b && 2*(n+m-2) == a) {
            if (n > m) swap(n, m);
            cout << n << " " << m;
            return 0;
        }
    }

    return 0;
}
