#include <iostream>
using namespace std;

int main() {
    double a, b;
    cin >> a >> b;

    long long maxM = a / 2 + 2;
    for (long long m = 2; m < maxM; m++) {
        long long n = maxM - m;
        if ((n - 1) * (m - 1) == b) {
            cout << m << " " << n;
            return 0;
        }
    }
    cout << "--";
}