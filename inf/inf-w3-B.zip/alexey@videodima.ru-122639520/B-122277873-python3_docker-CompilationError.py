sum_nm = (a + 4) // 2
    
    prod_nm = b + sum_nm - 1
    
    discriminant = sum_nm**2 - 4 * prod_nm
    if discriminant < 0:
        return None  
    
    sqrt_discriminant = int(discriminant**0.5)
    n = (sum_nm - sqrt_discriminant) // 2
    m = (sum_nm + sqrt_discriminant) // 2
    
    if n * m == prod_nm and n + m == sum_nm:
        return min(n, m), max(n, m)
    else:
        return None

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    a = int(data[0])
    b = int(data[1])
    
    result = find_dimensions(a, b)
    if result:
        print(result[0], result[1])
    else:
        print("No solution")

if __name__ == "__main__":
    main()