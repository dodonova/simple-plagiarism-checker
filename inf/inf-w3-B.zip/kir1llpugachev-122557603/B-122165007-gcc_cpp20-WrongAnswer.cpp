#include <cmath>
#include <algorithm>
#include <set>
#include <vector>
#include <iostream>
#include <map>
#include <queue>


#define ll long long
#define ld long double

using namespace std;

const ll MAX = 2e18;
const int MIN = -2e9;


int main() {
	int a, b, k;
	cin >> a >> b;
	if (a == 0 and b == 0) {
		cout << 0 << ' ' << 0;
	}
	k = a / 2 + b + 1;
	for (int i = 1; i < 50000; i++) {
		int m, n;
		n = i;
		if (k % n != 0) {
			continue;
		}
		m = k / n;

		if (2 * (n + m - 2) == a and ((n - 1) * (m - 1) == b)) {
			cout << n <<' '<< m;
			return 0;
		}
	}
}