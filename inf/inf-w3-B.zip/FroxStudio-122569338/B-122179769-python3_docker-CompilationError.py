def find_grid_size(a, b):
    total_sum = (a // 2) + 2
	for n in range(1, total_sum):
		m = total_sum - n
		if (n - 1) * (m - 1) == b:
			return min(n, m), max(n, m)
	return 1, 1
a, b = map(int, input().split())
n, m = find_grid_size(a, b)
print(n, m)