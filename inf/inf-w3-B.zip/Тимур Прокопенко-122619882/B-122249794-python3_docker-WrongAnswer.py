t, x = map(int, input().split())

d = (((4 + t)**2 - 8 * (5 + 2 * x))**-2)
m = ((4 + t) + d)/4
n = x/(m - 1) + 1 

print(round(min(m, n)), round(max(m,n)))