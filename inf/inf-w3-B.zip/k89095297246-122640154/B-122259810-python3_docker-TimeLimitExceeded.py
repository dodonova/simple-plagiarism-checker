count = input().split()
a = int(count[0])
b = int(count[1])
m = 0
while True:
    m += 1
    x = a + 4 - 2 * m
    if x % 2 == 0:
        n = x // 2
        if (n - 1) * (m - 1) == b:
            break
print(m, n)
