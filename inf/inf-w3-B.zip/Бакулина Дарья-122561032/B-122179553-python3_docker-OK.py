a, b = input().split()
a = int(a)
b = int(b)
n = 1 + (a - (a*a-16*b)**0.5)/4
m = 1 + (a + (a*a-16*b)**0.5)/4
print(round(n), round(m))
