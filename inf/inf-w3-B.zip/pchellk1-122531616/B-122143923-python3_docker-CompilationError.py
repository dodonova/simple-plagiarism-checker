with open("input.txt", "r") as f_in, open("output.txt", "w") as f_out:
r1 = r2 = 0
a, b = map(int, f_in.read().split())
if b == 0:
r1 = 1
if a == 0:
r2 = 1
else:
r2 = a/2
else:
t = 1
while ((a-t*2)/2!=(b/t)):
t += 1

r1 = t+1
r2 = b/t+1