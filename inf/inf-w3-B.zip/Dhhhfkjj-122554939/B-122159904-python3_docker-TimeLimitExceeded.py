def puzzle_size(a, b):
    S = (a // 2) + 2
    for N in range(1, S):
        M = S - N
        if (N - 1) * (M - 1) == b:
            return N, M

a, b = map(int, input().split())
N, M = puzzle_size(a, b)
if N > M:
    N, M = M, N
print(N, M)