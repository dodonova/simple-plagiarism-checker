import math
a,b=map(int,input().split())

z = (a // 2) + 2  
t = int(math.sqrt(z * z - 4 * (b + z - 1)))
n, m= (z+t) // 2, (z-t) // 2
if n <= m:
    print(n, m)
else:
    print(m,n)