import math
a,b=map(int,input().split())

z = (a // 2) + 2  
r = int(math.sqrt(z * z - 4 * (b + z - 1)))
n, m = (z+r) // 2, (z-r) // 2
if n <= m:
    print(n, m)
else:
    print(m,n)