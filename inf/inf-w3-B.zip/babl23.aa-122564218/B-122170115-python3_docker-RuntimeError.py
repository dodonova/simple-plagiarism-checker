import math

def find_dimensions(a, b):
    # Уравнение для количества т-образных фигур
    # a = 2 * (n + m - 2)
    # n + m = a / 2 + 2

    # Уравнение для количества крестиков
    # b = (n - 1) * (m - 1)

    # Найдем n и m
    for n in range(1, int(math.sqrt(b)) + 2):
        if b % (n - 1) == 0:
            m = b // (n - 1) + 1
            if 2 * (n + m - 2) == a:
                return min(n, m), max(n, m)

    return None

# Ввод данных
a, b = map(int, input().split())

# Находим размеры решетки
result = find_dimensions(a, b)

# Выводим результат
if result:
    print(result[0], result[1])