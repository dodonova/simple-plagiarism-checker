def razmer(a, b):
    for m in range(2, 10**9 + 1):
        n = (b // (m - 1)) + 1
        if (2 * (n + m - 2) == a) and ((n - 1) * (m - 1) == b):
            if m >= n:
                return n, m
            else:
                return m, n
    return 0
a, b = map(int, input().split())
rechetka = razmer(a, b)
if rechetka != 0:
  print(*rechetka)