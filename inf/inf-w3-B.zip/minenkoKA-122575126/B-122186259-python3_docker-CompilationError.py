import math
a = int(input())
b = int(input())
d = a * a - 16 * b
D = d // 4
sqrt_D = int(math.isqrt(D))
s = a // 2 + 2
found = False
for sign in [1, -1]:
	n_candidate = (s + sign * sqrt_D)
	if n_candidate % 2 != 0:
		continue
	n = n_candidate // 2
    m = s - n
    if n >= 1 and m >= 1:
    	print(f"{n} {m}")
        found = True
        break