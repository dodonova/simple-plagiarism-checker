import math
from math import sqrt
n, m = map(int, input().split())
ab = m + ((n + 4) / 2) - 1
if n == 0 and m == 0:
    print("1 1")
else:
    res = []
    if ab > 0:
        for x in range(1, int(sqrt(ab)) + 1):
            if ab % x == 0:
                res.append([x, ab // x])
    if res:
        lp = res[-1]  
        print(lp[0] % 100, lp[1] % 100) 
 