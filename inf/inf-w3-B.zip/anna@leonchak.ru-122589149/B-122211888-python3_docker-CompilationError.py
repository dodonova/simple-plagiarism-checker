from math import sqrt

n,m=map(int,input().split())
a*b=m+((n+4)/2)-1
if n==0 and m==0:
    print("1 1")
v=a*b
res = []
for x in range(1, int(sqrt(v)+1)):
    if not (v % x):
        res.append([x, v//x])
print(res)  