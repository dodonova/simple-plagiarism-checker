
def find_dimensions(a, b):

    n_plus_m = a // 2 + 2
    

    for n in range(1, n_plus_m // 2 + 1):
        m = n_plus_m - n  
        if n <= m:  
            if (n - 1) * (m - 1) == b:
                return n, m


a, b = map(int, input().split())
n, m = find_dimensions(a, b)


print(n, m)