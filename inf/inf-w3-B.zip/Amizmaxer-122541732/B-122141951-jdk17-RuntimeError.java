import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int gar = scanner.nextInt();
        int far = scanner.nextInt();

        int[] result = findDimensions(gar, far);
        if (result != null) {
            System.out.println(result[0] + " " + result[1]);
        } else {
            System.out.println("Нет решения");
        }
    }

    public static int[] findDimensions(int gar, int far) {
        for (int n = 1; n <= gar + 2; n++) {
            int m = (gar / 2) + 2 - n;
            if (m < n) {
                continue;
            }
            if ((n - 1) * (m - 1) == far) {
                return new int[]{n, m};
            }
        }
        return null;
    }
}
