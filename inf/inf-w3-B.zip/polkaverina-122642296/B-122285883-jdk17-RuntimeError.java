import java.util.Scanner;
public class Puzzle {    
public static void main(String[] args) {
        Scanner in = new Scanner(System.in);        
        int a = in.nextInt();        
        int b = in.nextInt();                
        int sum = a / 2 + 2;
        for (int n = 1; n < sum; n++) { 
        int m = sum - n;            
            if ((n - 1) * (m - 1) == b) { 
            if (n > m) {                   
            int temp = n;                  
            n = m;                 
            m = temp;
            }                
            System.out.println(n + " " + m);               
            return;       
            }
        }   
     }
}