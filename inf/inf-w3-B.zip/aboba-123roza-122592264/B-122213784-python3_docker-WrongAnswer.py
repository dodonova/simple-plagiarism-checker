per1, per2 = input().split()
per1 = int(per1)
per2 = int(per2)

if per2 != "0":
    x = (1 / 4) * (-1 * ((per1 ** 2) - 16 * per2) ** 0.5 + per1 + 4)
    y = (1 / 4) * (((per1 ** 2) - 16 * per2) ** 0.5 + per1 + 4)
    print(min(x, y), max(x,y))
else:
    print("1 1")