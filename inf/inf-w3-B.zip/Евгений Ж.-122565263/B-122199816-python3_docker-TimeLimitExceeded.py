def f(a, b):
    for n in range(1, int((a // 2) + 2) + 1):
        m = (a // 2 + 2) - n
        if m >= n and (n - 1) * (m - 1) == b:
            return n, m

a, b = map(int, input().split())
n, m = f(a, b)
print(n, m)
