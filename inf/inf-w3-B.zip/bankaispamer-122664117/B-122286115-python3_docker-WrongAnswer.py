a = 7
b = 7

print (f"{a} {b}")