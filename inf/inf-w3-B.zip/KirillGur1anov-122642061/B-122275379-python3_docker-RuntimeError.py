import math as mat

m, f = map(int, input().split())
a = 1
c = f
b = m // 2 * -1
d = b ** 2 - 4 * a * c

if d > 0:
    e = (-b - mat.sqrt(d)) / (2 * a)
    h = (-b + mat.sqrt(d)) / (2 * a)
    g = min(e, h)
    print(int(g) + 1, int(f // g + 1))

elif m == 0 and f == 0:
    print('1 1')

elif d == 0:
    g = -b / (2 * a)
    print(int(g) + 1, int(f // g + 1))