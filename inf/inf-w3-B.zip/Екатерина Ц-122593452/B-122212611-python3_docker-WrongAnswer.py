a, b = map(int, input().split())
n = 0

for m in range(4,a-1000,1):
    if (a-2*m+4)/2 == (b/(m-1))+1:
        n == (a-2*m+4)/2
        print(m, n)
