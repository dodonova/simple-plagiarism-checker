a, b = map(int, input().split())

for m in range(1,10**7+1,1):
    for n in range(1,10**7,1):
        if m*n == a+b+4:
            print(m, n)
