#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using ld = long double;
using ull = unsigned long long;

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("error.txt", "w", stderr);
#endif
    ld a, b;
    cin >> a >> b;
    // cout.precision(1);
    ll m = (a + sqrt(a * a - 16 * b) + 4) / 4;
    if (a == 0 && b == 0) {
        cout << "1 1";
    }
    else {
        cout << (m - 1 + b) / (m - 1) << " " << m;
    }
    
    
    return 0;
}
