#include <iostream>

int main() {
    int a, b;
    std::cin >> a >> b;  // Read two integers from input
    bool exit = false;
    int m = 0;

    while (m <= 1000000000 && !exit) {
        m++;
        int n = 0;

        while (n <= m) {
            n++;
            if ((n - 1) * (m - 1) == b && 2 * (n + m - 2) == a) {
                std::cout << n << " " << m << std::endl;  // Print the values of n and m
                exit = true;  // Set exit to true to break the outer loop
                break;  // Break the inner loop
            }
        }
    }

    return 0;  // Return 0 to indicate successful execution
}