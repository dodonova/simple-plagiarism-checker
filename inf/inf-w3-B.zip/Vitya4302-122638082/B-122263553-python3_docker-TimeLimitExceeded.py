a, b = map(int, input().split())
exit = False
m = 0
while m <= 10**9 and not exit:
    m += 1
    n = 0
    while n <= m:
        n += 1
        if 2 * (n + m - 2) == a and (n - 1) * (m - 1) == b:
            print(n, m)
            exit = True
            break