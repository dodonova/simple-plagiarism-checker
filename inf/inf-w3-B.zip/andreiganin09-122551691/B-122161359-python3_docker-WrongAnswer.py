a, b = map(int, input().strip().split())
for m in range(1,300):
    n=a//2+2-m
    if m>n:
        if (n-1)*(m-1)==b:
            print(int(n),m)