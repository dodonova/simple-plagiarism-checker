a,b = map(int, input().split())
d = a//2+2
c = b+d-1
for n in range(1, d+1):
    m = d-n
    if m < n:
        break
    if n*m == c:
        print(min(n, m), max(n, m))