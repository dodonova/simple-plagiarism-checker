#include <iostream>
#include <utility>
#include <random>

using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    int c = a / 2 + 2;
    
    for (int m = 1; m < c; m++) {
        int n = c - m;
        int randomStuff = (m - 1) * (n - 1);
        if (randomStuff == b) {
            cout << min(m, n) << " " << max(m, n) << endl;
            break;
        }
    }
}
