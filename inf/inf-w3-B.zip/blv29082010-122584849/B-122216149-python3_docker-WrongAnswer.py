# Online Python - IDE, Editor, Compiler, Interpreter
def find_puzzle_dimensions(a, b):
  """Находит размеры прямоугольной решетки для заданного количества т-образных фигур (a) и крестиков (b).

  Args:
    a: Количество т-образных фигур.
    b: Количество крестиков.

  Returns:
    Список кортежей (n, m), представляющих размеры прямоугольных решеток, которые удовлетворяют условиям.
  """

  solutions = []
  for i in range(1, b + 1):  # Проверка делителей b
    if b % i == 0:
      n = i + 1
      m = b // i + 1
      if 2 * (n + m - 2) == a and (n - 1) * (m - 1) == b and n<=m:
        solutions.append((n, m))  # Добавляем решение, если оно удовлетворяет обоим условиям

  return solutions

# Ввод данных пользователем
a_str, b_str = input().split()
a, b = int(a_str), int(b_str)

solutions = find_puzzle_dimensions(a, b)

if solutions:
  for n, m in solutions:
    print(n, m)
