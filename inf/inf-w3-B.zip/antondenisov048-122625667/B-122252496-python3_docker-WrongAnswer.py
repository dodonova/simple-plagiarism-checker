a,b = [int(s) for s in input().split()]
for x in range(1,int(b**0.5)+1):
    if b % x == 0:
        y = b // x
        if 2*(x + y) == a:
            print(x + 1, y + 1)
