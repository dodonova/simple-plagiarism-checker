f, m = map(int, input().split())
if f == 0 and m == 0:
 print(1, 1)
else:
 h = (f + 4 + (f  2 - 8 * f - 48 - 16 * m)  0.5) / 4
 if h + 0.5 == int(abs(h) + 1):
  h = int(abs(h) + 1)
 else:
  h = int(abs(h))
 v = (4 + f + m) / h
 print(h, v)