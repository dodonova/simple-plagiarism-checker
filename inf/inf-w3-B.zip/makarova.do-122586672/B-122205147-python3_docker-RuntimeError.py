a, b = map(int, input().split())
for m in range(1, 10**9 + 1):
    if a==b==0:
        print("1 1")
        break
    elif b%(m-1)==0 :
        n = round(b//(m-1))+1
        if a == 2*(n+m-2):
            print(min(n, m), max(n, m))
            break
