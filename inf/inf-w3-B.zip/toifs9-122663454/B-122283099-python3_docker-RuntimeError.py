def solve_puzzle(a, b):
    for n in range(1, int(b**0.5) + 2):
        m = (b // (n - 1)) + 1
        if (n - 1) * (m - 1) == b and 2 * (n + m - 2) == a:
            print(n, m)
            return

# Пример использования:
a = 16
b = 15
solve_puzzle(a, b)