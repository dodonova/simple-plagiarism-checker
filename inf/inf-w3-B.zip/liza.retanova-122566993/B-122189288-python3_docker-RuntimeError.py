def gey(a,b):
    o=(a+4)//2
    for n in range((o+2)//2,1,-1):
        m=o-n
        if (m-1)*(n-1)==b:
            return n,m
    return None
n,m=gey(a,b)
a,b=map(int,input().split())
h=min(n,m)
print(n,m)