def gey(a,b):
    o=(a//2)+2
    for n in range(o):
        m=o-n
        if (m-1)*(n-1)==b:
            return n,m
    return None
n,m=gey(a,b)
a,b =map(int,input().split())
h=min(n,m)
print(h)
