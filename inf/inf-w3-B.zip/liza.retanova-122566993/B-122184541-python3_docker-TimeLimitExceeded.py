a, b=map(int, input().split())
n=0
m=0
if a==0 and b==0:
    print('1 1')
else:
    for n in range(1,a):
        for m in range(n,a):
            if a==2*(n+m-2) and b==(n-1)*(m-1) and n<= m:
                print(n, m)
            elif a==2*(n+m-2) and b==(n-1)*(m-1) and n>= m:
                print(m, n)