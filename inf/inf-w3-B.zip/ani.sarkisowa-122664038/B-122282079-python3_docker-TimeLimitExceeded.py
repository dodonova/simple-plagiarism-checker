
def find_dimensions(a, b):  
    for n in range(1, (a // 2 + b + 1) + 1):
        m = int(a / 2 + 2 - n)
        if m * n == a / 2 + b + 1:
            return n, m
    return None

a, b = map(int, input().split())
dimensions = find_dimensions(a, b)
if dimensions:
    n, m = dimensions
    print(n, m)