#include <bits/stdc++.h>

using namespace std;

long int a,b;

int main(){
    cin >> a >> b;
    cout << (int(-sqrt(a*a-16*b))+a+4)/4 << " " << (int(sqrt(a*a-16*b))+a+4)/4;
    return 0;
}

