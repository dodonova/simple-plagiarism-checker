a, b = map(int, input().split())
if a == 0 and b == 0:
    print(1, 1)
else:
    for n in range(2, int(b ** 0.5) + 2):
        if b % n == 0:
            nn = n + 1
            m = a / 2 - nn + 2
            if 2 * (nn + m - 2) == a:
                print(nn, int(m))
                break
