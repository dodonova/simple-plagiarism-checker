def find_dimensions(a, b):
    for n in range(1, a + 2):
        m = a + 2 - n  
        if m >= n:  
            if b == (n - 1) * (m - 1):
                return n, m
    return 1, 1  

a, b = map(int, input().strip().split())

n, m = find_dimensions(a, b)

print(n, m)
