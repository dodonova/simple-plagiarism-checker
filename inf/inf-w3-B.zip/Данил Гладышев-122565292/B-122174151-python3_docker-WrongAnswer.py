b=input()
b=b.split(' ')
a=int(b[0])
d=int(b[1])
for i in range(1000000000):
    if (a//2-i)*i==d:
        print(a//2-i+1,i+1)
        break
