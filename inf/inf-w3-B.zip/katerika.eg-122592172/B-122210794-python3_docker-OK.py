import sys
import math

def solve_puzzle(a, b):
    D = a * a - 16 * b
    if D < 0:
        return None
    sqrt_D = int(math.isqrt(D))
    if sqrt_D * sqrt_D != D:
        return None

    possible_solutions = []
    for sign in [+1, -1]:
        numerator = a + sign * sqrt_D
        if numerator % 4 != 0:
            continue
        k = numerator // 4
        n = k + 1
        m = int(a // 2 + 2 - n)
        if n >= 1 and m >= 1:
            if n > m:
                n, m = m, n
            possible_solutions.append((n, m))
    if possible_solutions:
        n, m = min(possible_solutions)
        return n, m
    else:
        return None

# Read input
a_str, b_str = sys.stdin.readline().split()
a = int(a_str)
b = int(b_str)

result = solve_puzzle(a, b)

if result:
    n, m = result
    print(f"{n} {m}")
else:
    print("impossible")