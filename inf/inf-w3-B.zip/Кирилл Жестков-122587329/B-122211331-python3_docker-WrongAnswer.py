a, b = map(int, input().split())
f = 1
if a == b == 0:
    print(1, 1)
elif a != 0 and b == 0:
    print(1, a // 2 + 1)
else:
    while f != 0:
        for n in range(2, a // 2, 2):
            for m in range(1, a+1):
                print(n, m)
                if 2 * (n + m - 2) == a and (n - 1) * (m - 1) == b and n <= m:
                    print(n, m)
                    f = 0

