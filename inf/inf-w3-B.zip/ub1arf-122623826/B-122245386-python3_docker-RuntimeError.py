nums = list(map(int, input().split()))
n = int(nums[0])
m = int(nums[1])
nums = list(map(int, input().split()))
x = int(nums[0])
y = int(nums[1])
S=n*m

if (m/n>y/x):
    S1=((n**2)*y)/(2*x)
    razn1=S-S1*2
elif (m/n==y/x):
    razn1=0
elif (m/n<y/x):    
    S1=((m**2)*x)/(2*y)
    razn1=S-S1*2

if (m/n>(y/(n-x))):
    S2=((n**2)*y)/(2*(n-x))
    razn2=S-S2*2
elif (m/n==(y/(n-x))):
    razn2=0
elif (m/n<(y/(n-x))):    
    S2=((m**2)*(n-x))/(2*y)
    razn2=S-S2*2
    
if (m/n>((m-y)/x)):
    S3=((n**2)*(m-y))/(2*x)
    razn3=S-S3*2
elif (m/n==((m-y)/x)):
    razn3=0
elif (m/n<((m-y)/x)):    
    S3=((m**2)*x)/(2*(m-y))
    razn3=S-S3*2
    
if (m/n>((m-y)/(n-x))):
    S4=((n**2)*(m-y))/(2*(n-x))
    razn4=S-S4*2
elif (m/n==((m-y)/(n-x))):
    razn4=0
elif (m/n<((m-y)/(n-x))):    
    S4=((m**2)*(n-x))/(2*(m-y))
    razn4=S-S4*2
    
otvet=min(razn1,razn2,razn3,razn4)
otvet1= float('{:.3f}'.format(otvet))
print(otvet1)