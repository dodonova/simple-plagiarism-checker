a, b = map (int, input().split())
if b == 0:
    print(1, (a//2+1)