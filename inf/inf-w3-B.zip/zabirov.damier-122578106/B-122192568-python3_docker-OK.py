import math

def find_dimensions(a, b):
    S = (a // 2) + 2
    P = b + (a // 2) + 1

    D = S * S - 4 * P

    if D < 0:
        return "No solution"

    sqrt_D = int(math.isqrt(D))

    if sqrt_D * sqrt_D != D:
        return "No solution"

    x1 = (S + sqrt_D) // 2
    x2 = (S - sqrt_D) // 2

    n = min(x1, x2)
    m = max(x1, x2)

    return n, m

a, b = map(int, input().split())
n, m = find_dimensions(a, b)

if n <= m:
    print(n, m)
else:
    print(m, n)