a, b = map(int, input().split()) 
for n in range(2, int(b ** 0.5) + 2): 
    if b % (n - 1) == 0: 
        m = b // (n - 1) + 1 
    if n + m == a // 2 + 4: 
        print(n, m) 
        break