j=input()
f=j.split()
a=int(f[0])
b=int(f[1])
if b>=0 or a<0:
	if a==0 and b==0:
		print(1,1)
	if b==1:
		print(2,2)
	if b==0 and a>2:
		print(1,a//2)
	if b>1:
		x=a//2
		for t in range(x-1,2,-1):
			if t*(x-t)==b: 
				print(x-t+1,t+1)
				break