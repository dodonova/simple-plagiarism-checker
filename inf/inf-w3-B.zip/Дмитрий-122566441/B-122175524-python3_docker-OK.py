import math

a, b = map(int, input().split())

l = (a // 2) + 2
p = b - 1 + l
d = l * l - 4 * p
s = int(math.sqrt(d))
m = (l + s) // 2
n = (l - s) // 2

print(n, m)