a,b=map(int, input().split())
c=a//2+2
d=b+a//2+1
if d%2==0:
  for i in range(2,c,2):
    if (c-i)*i==d:
      n=min(i,c-i)
      m=max(i,c-i)
      break
else:
  for i in range(1,c,2):
    if (c-i)*i==d:
      n=min(i,c-i)
      m=max(i,c-i)
      break
print(n,m)
