def find_grid_size(a, b):
  """
  Находит размеры исходной решетки n x m по количеству т-образных фигур (a) и крестиков (b).

  Args:
    a: Количество т-образных фигур.
    b: Количество крестиков.

  Returns:
    Кортеж (n, m), где n - ширина, m - высота исходной решетки.
  """
  # Учитывая, что есть 4 уголка, общее количество фигур:
  total_figures = a + b + 4

  # Известно, что количество т-образных фигур равно 2 * (n + m - 2)
  n_plus_m = (a + 2) // 2

  # Известно, что количество крестиков равно (n - 1) * (m - 1)
  n_times_m = b + 1

  # Используем формулу (n + m)^2 = n^2 + 2nm + m^2
  # и выражаем n^2 + m^2 через известные значения:
  n_squared_plus_m_squared = (n_plus_m)**2 - 2 * n_times_m

  # Решаем квадратное уравнение n^2 - (n_plus_m)n + (n_squared_plus_m_squared) / 2 = 0
  # Используем дискриминант:
  discriminant = (n_plus_m)**2 - 2 * (n_squared_plus_m_squared)

  # Проверяем, является ли дискриминант полным квадратом:
  if discriminant < 0 or int(discriminant0.5)2 != discriminant:
    return None  # Решения не существует

  # Находим n и m:
  n = (n_plus_m - discriminant**0.5) // 2
  m = n_plus_m - n

  return (int(n), int(m))

# Ввод данных
a, b = map(int, input().split())

# Находим размеры решетки
result = find_grid_size(a, b)

# Вывод результата
if result:
  print(*result)
else:
  print("Решения не существует")
