import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        long a = scanner.nextLong();
        long b = scanner.nextLong();
        long NpM = a/2+2, n = 1, m = 0;

        while (n < NpM) {
            m = NpM-n;
            if ((n-1)*(m-1)==b) {
                break;
            }
            n++;
        }

        System.out.println(n+" "+m);
    }
}