def find_dimensions(a, b):
    # Уравнение 1: n + m = (a // 2) + 2
    # Уравнение 2: (n - 1) * (m - 1) = b

    half_a = a // 2
    total = half_a + 2  # n + m

    for n in range(1, total // 2 + 1):
        m = total - n  # m from the first equation
        if (n - 1) * (m - 1) == b:  # checking the second equation
            return (n, m)

    return None

# Чтение входных данных
import sys
input_data = sys.stdin.read()
a, b = map(int, input_data.strip().split())

n, m = find_dimensions(a, b)
# Условие n ≤ m
if n > m:
    n, m = m, n

# Вывод результата
print(n, m)