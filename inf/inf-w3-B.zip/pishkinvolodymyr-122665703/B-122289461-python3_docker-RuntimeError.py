n, m = list(map(int, input().split()))
x, y = list(map(int, input().split()))
l = []
# 1 проверка
h1 = y / x * n
s1 = 1 / 2 * h1 * n
ss1 = n * m - s1
l.append(abs(ss1 - s1))

h2 = (n-x)/(m-y) * m
s2 = 1 / 2 * h2 * m
ss2 = n * m - s2
l.append(abs(ss2 - s2))

h3 = (n-x)/y * m
s3 = 1 / 2 * h3 * m
ss3 = n * m - s3
l.append(abs(ss3 - s3))

h4 = (m - y)/x * n
s4 = 1 / 2 * h4 * n
ss4 = n * m - s4
l.append(abs(ss4 - s4))

print(f'{min(l):.3f}')