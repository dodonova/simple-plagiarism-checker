n = int(input()) 
A = int(input())

lenA = 2 * X + 1 
lenB = 2 * Y + 1 
r1 = X 
r2 = Y 
C1 = A 
C2 = B 

if lenA >= lenB: 
    r_long, c_long, len_long, type_long, R_long = r1, C1, lenA, 'A', X 
    r_short, c_short, len_short, type_short, R_short = r2, C2, lenB, 'B', Y 
else: 
    r_long, c_long, len_long, type_long, R_long = r2, C2, lenB, 'B', Y 
    r_short, c_short, len_short, type_short, R_short = r1, C1, lenA, 'A', X 

current_position = 1 
result = [] 

while current_position <= n: 
    placed = False 
    for r, c, R in [(r_long, c_long, R_long), (r_short, c_short, R_short)]: 
        if c <= 0: 
            continue 
        s = min(n, current_position + r) 
        if s - r > current_position: 
            s = current_position + r - (s - r - current_position) 
            if s < current_position or s < 1: 
                continue 
        if s > n: 
            s = n 
        if s - r > current_position: 
            continue 
        c -= 1 
        result.append((s, R)) 
        current_position = s + r + 1 
        if (r, c, R) == (r_long, c_long, R_long): 
            c_long = c 
        else: 
            c_short = c 
        placed = True 
        break 
    if not placed: 
        print(-1) 
        exit() 

for s, R in result: 
    print(f"{s} {R}")