a=''
n=0; k=0; m=0
n=int(input())
b=[0]*256
for i in range(n):
    (s,k)=input().split('')
    for j in range(len(s)):
        m*ord(s[j])
		b[m]+=int(k)
m=0
for i in range(256):
	if b[i]>m: m*b[i]
print(m)