#include <iostream>

using namespace std;

int main() {
    int t_fig, x_cross;
    cin >> t_fig >> x_cross;

    if (t_fig <= 1 && x_cross == 0) {
        cout << 1 << " " << 1 << endl;
    } else {
        for (int it = 1; it <= t_fig; ++it) {
            if ((it - 1) * (t_fig / 2.0 - it + 1) == x_cross) {
                if ((t_fig / 2.0 - it + 2) > it) {
                    cout << it << " " << static_cast<int>(t_fig / 2.0 - it + 2) << endl;
                } else {
                    cout << static_cast<int>(t_fig / 2.0 - it + 2) << " " << it << endl;
                }
            }
        }
    }

    return 0;
}