import math
a, b = ts, xs = [*map(int, input().split())]
f = a * a - 16 * b
k = f // 4
sqrt_v = int(math.isqrt(k))
s = a // 2 + 2
found = False
for sign in [1, -1]:
    line = (s + sign * sqrt_D)
    if line % 2 != 0:
        continue
    n = line // 2
    m = s - n
    if n >= 1 and m >= 1:
        if n > m:
            n, m = m, n
        print(f"{n} {m}")
        found = True
        break