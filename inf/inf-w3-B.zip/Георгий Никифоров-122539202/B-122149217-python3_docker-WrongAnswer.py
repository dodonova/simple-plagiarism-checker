import math

a, b = map(int, input().split())
x = a**2/4
y = b*4
if x < y:
    y = x

m1 = math.floor((a + 4 + 2 * (math.sqrt(x - y))) / 4)
m2 = math.floor((a+4-2*(math.sqrt(x-y)))/4)
n1 = a/2-m1+2
n2 = a/2-m2+2
if a < 2:
    print(1, 1)
else:
    if b < 0:
        print(1, a-2)
    else:
        if m1 < m2:
            if n1 < m1:
                print(int(round(n1, 0)), int(round(m1, 0)))
            else:
                print(int(round(m1, 0)), int(round(n1, 0)))
        else:
            if n2 < m2:
                print(int(round(n2, 0)), int(round(m2, 0)))
            else:
                print(int(round(m2, 0)), int(round(n2, 0)))