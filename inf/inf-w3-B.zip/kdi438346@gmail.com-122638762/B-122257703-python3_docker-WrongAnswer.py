import sys

input_data = sys.stdin.read().strip()
a, b = map(int, input_data.split())


for n in range(1, 10**9 + 1):
    if n == 1:
        
        if b == 0:
            print(1, 1)
            break
        else:
            continue
    
    if b % (n - 1) != 0:
        continue 
    
    m = (b // (n - 1)) + 1 

    if m < n:
        continue  

    if a == 2 * (n + m - 2):
        print(n, m)
        break