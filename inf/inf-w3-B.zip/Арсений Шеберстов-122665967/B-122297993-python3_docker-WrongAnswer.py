from math import sqrt

a, b = map(int, input().split())
n = (a / 4) - (sqrt(a * a - 16 * b) / 4) + 1
m = (a / 4) + (sqrt(a * a - 16 * b) / 4) + 1
print(n, m)