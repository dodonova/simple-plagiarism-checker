#include <iostream>
#include <utility> // Для std::pair
#include <algorithm> // Для std::min и std::max

std::pair<int, int> find_dimensions(int a, int b) {
    // Вычисляем n + m
    int total_length = (a / 2) + 2;

    // Ищем такие n и m, что n + m = total_length и (n - 1)(m - 1) = b
    for (int n = 1; n < total_length; ++n) {
        int m = total_length - n;
        if ((n - 1) * (m - 1) == b) {
            return {std::min(n, m), std::max(n, m)};
        }
    }

    // Если не нашли подходящие n и m, возвращаем пару (-1, -1)
    return {-1, -1};
}

int main() {
    int a, b;
    
    // Чтение входных данных
    std::cout << "Введите значения a и b: ";
    std::cin >> a >> b;

    // Получение размеров решетки
    auto dimensions = find_dimensions(a, b);

    // Вывод результата
    if (dimensions.first != -1 && dimensions.second != -1) {
        std::cout << dimensions.first << " " << dimensions.second << std::endl;
    } else {
        std::cout << "Решение не найдено" << std::endl;
    }

    return 0;
}
