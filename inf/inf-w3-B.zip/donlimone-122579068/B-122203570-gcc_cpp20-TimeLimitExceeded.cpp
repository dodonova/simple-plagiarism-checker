#include <iostream>
#include <set>
#include <vector>
#include <algorithm>

int main() {
    std::string st = "";
    int a, b;
    std::cin >> a >> b;

    if (a == 0 && b == 0) {
        std::cout << '1' << ' ' << '1' << std::endl;
        return 0;
    }

    int suma = static_cast<int>(0.5 * a + 2);
    int umno = static_cast<int>(0.5 * a + 2 + b - 1);
    std::set<int> unique_values;

    for (int m = 0; m < umno; ++m) {
        for (int n = 0; n < umno; ++n) {
            if (n * m == umno && m + n == suma) {
                unique_values.insert(m);
                unique_values.insert(n);
            }
        }
    }

    // Сортируем уникальные значения
    std::vector<int> result(unique_values.begin(), unique_values.end());
    if (result.size() >= 2) {
        std::cout << result[0] << ' ' << result[1] << std::endl;
    }

    return 0;
}