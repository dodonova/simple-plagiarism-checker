import math

a, b = map(int, input().split())
while True:
    r = a // 2 + 2
    try:
        D = math.isqrt(r*r - 4 * (b + r - 1))
    except:
        break

    m2 = (r + D) // 2
    m1 = (r - D) // 2

    if m1 <= 0 or m2 <= 0:
        break

    n = min(m1, m2)
    m = max(m1, m2)

    break

print(print(n), print(m))

