a, b = map(int, input().split())
r = a // 2 + 2
try:
        D = (r*r - 4 * (b + r - 1))**(1/2)
        m2 = (r + D) // 2
        m1 = (r - D) // 2
except:
 n, m = 0, 0
if not m1 <= 0 or not m2 <= 0:
    n = min(m1, m2)
    m = max(m1, m2)
print(n, m , sep='\n')

