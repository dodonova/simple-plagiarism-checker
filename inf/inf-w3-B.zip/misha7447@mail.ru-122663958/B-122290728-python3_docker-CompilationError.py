rara1, b12 = map(int, input().split())
h = rara1 //= 2

for ira in range(int(1e9)):
	d = (ira - 1) * (h - ira + 1)
    if d == b12:
        na = ira
        ma = h - ira + 2
        if ma < na:
            na, ma = ma, na
        print(na, ma)
        break