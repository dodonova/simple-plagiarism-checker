a, b=map(int, input().split())

disc=(a/2)**2-(4*b)
x1=(a/2+(disc)**0.5)/2
x2=(a/2-(disc)**0.5)/2
if x1<0:
    m=int(x2)+1 
    n=a//2-m+2 
elif x2<0:
    m=int(x1)+1 
    n=a//2-m+2 
else:
    m=int(x1)+1 
    n=a//2-m+2 
if n<m:
    
    print(int(n), int(m))
else:
    print(int(m), int(n))