a, b = map(int, input().split())
S = (a // 2) + 2
D = S * S + 4 * (b - 1 + S)  
sqrt_D = int(math.isqrt(D))  
n1 = (S + sqrt_D) // 2
n2 = (S - sqrt_D) // 2
n = n1 if n1 <= n2 else n2
m = S - n
if n > m:
   n, m = m, n
print(n, m)