a, b = map(int, input().split())

if a == 0 and b == 0:
    print(1, 1)
elif b == 0:
    print(0, a // 2)
else:
    for width in range(1, a // 2 + 1):
        height = (a // 2) - width
        if width * height == b:
            print(width + 1, height + 1)
            break