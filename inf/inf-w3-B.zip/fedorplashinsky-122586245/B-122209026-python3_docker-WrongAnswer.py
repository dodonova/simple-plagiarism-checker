a, b = map(int, input().split())
for n in range(1, a + 2):
    if n > 1 and b % (n - 1) == 0:
        m = (b // (n - 1)) + 1
        if 2 * (n + m - 2) == a:
            print(n, m)
            break
