def solve_puzzle(a, b):
    s = a // 2 + 2
    
    for n in range(1, s):
        if n*n - n*s + s - n + b == 0:
            m = s - n
            return min(n, m), max(n, m)
    
    return None

a, b = map(int, input().split())

result = solve_puzzle(a, b)

if result:
    print(*result)
else:
    print("Решение не найдено")