# Read the input values for the number of T-shaped and cross-shaped pieces
a, b = map(int, input().split())

# Calculate the total number of squares in the grid
total_squares = 2 * (a + 2) + 4 * b

# Calculate the value of n + m
n_plus_m = (total_squares + 2) // 2

# Calculate the value of n and m using the quadratic formula
n = (n_plus_m - int((n_plus_m ** 2 - 4 * total_squares) ** 0.5)) // 2
m = n_plus_m - n

# Print the values of n and m
print(n, m)