#include <bits/stdc++.h>

using namespace std;
#define int long long

const int MAXN = 1e9;

signed main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);
    int a, b;
    cin >> a >> b;
    a /= 2;
    for (int n = 0; n < MAXN; ++n) {
        if ((a - n + 1) * (n - 1) == b) {
            int m = a - n + 2;
            if (m < n) swap(n, m);
            cout << n << " " << m << "\n";
            break;
        }
    }
}
