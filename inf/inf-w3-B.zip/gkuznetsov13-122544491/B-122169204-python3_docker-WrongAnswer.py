a, b = map(int, input().split())


m = (4 + a + (a**2 - 16*b)**(1/2))/4
n = a/2 + 2 - m

print(min(n, m), max(n, m))