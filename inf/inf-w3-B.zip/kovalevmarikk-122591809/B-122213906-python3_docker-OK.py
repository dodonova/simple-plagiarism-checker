import math

def find_dimensions(a, b):
    sum_nm = (a // 2) + 2
    discriminant = sum_nm * sum_nm - 4 * (sum_nm + b - 1)

    # Проверка на наличие дейсвительных корней
    if discriminant < 0:
        return None
    sqrt_discriminant = math.isqrt(discriminant)

    
    n1 = (sum_nm + sqrt_discriminant) // 2
    m1 = (sum_nm - sqrt_discriminant) // 2

    n2 = (sum_nm - sqrt_discriminant) // 2
    m2 = (sum_nm + sqrt_discriminant) // 2


    if n1 >= 0 and m1 >= 0:
        return (min(n1, m1), max(n1, m1))
    elif n2 >= 0 and m2 >= 0:
        return (min(n2, m2), max(n2, m2))

    return None


a, b = map(int, input().strip().split())

result = find_dimensions(a, b)

print(result[0], result[1])