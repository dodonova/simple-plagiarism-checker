a, b = list(map(int,input().split()))
p = a + 4
for n in range(1, 10 ** 9):
    m = int(p / 2 - n)
    t = 2 * (n + m - 2)
    x = (n - 1) * (m - 1)
    if x == b and t == a:
        print(n,m)
        break