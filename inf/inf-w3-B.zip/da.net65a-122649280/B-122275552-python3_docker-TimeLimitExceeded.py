def fd(a, b):
    for n in range(1, (a // 2) + 2):
        m = (a // 2) + 2 - n
        if (n - 1) * (m - 1) == b:
            return n, m
a, b = map(int, input().strip().split())
n, m = fd(a, b)
print(n, m)
