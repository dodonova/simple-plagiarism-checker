s = input().split(" ")
t = int(s[0])
kr = int(s[1])
gran = max((t/kr+2),kr/t)
for n in range(1,gran+1):
    try:
        m = kr / (n-1) + 1
        t2 = 2*(n+m-2)
        if (t == t2) and m % int(m) == 0:
            a = n
            b = m
            break
    except(ZeroDivisionError):
        continue
if t==0 and kr==0:
    a=1
    b=1
print(int(min(a,b)), int(max(a,b)))