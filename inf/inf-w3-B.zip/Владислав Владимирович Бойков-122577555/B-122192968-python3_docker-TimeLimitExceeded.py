s = input().split(" ")
t = int(s[0])
kr = int(s[1])
for n in range(1,1000000000):
    try:
        m = kr / (n-1) + 1
        t2 = 2*(n+m-2)
        if (t == t2) and m % int(m) == 0:
            a = n
            b = m
            break
    except(ZeroDivisionError):
        continue
print(int(min(a,b)), int(max(a,b)))