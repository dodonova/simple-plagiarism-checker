def find (a,b):
    if a == 0 and b == 0:
        return 1, 1

sum = a // 2 + 2

product = b + (a // 2) + 1

D = sum ** 2 - 4 * product

if D < 0:
    return None, None

n1 = (sum + D ** 0.5) / 2
n2 = (sum - D ** 0.5) / 2

if n1.is_integer() and n2.is_integer():
    n1, n2 = int(ni), int(n2)
    return min(ni, n2), max(n1, n2)
    return None, None

a, b = map(int, input().split())
n, m = find (a, b)
print(n, m) 