list = input().split()
t = int(list[0])
x = int(list[1])
m = 0
n = 1

while 2 * (n + m - 2) != t:
	n += 1
while m < n:
	n -= 1
	m += 1

print(n, m) 