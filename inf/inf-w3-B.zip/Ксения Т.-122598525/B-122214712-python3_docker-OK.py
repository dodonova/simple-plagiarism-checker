import math

u, j = ts, xs = [*map(int, input().split())]
hh = u * u - 16 * j
oo = hh // 4
sqrt_from_smth = int(math.isqrt(oo))
c = u // 2 + 2
found = False
for sign in [1, -1]:
    n_candidate = (c + sign * sqrt_from_smth)
    if n_candidate % 2 != 0:
        continue
    g = n_candidate // 2
    x = c - g
    if g >= 1 and x >= 1:
        if g > x:
            g, x = x, g
        print(f"{g} {x}")
        found = True
        break