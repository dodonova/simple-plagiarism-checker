#include <iostream>
#include <cmath>
#include <cstdio>

int main() {
  int a, b, n1, m1, n2, m2;
  std::cin >> a >> b;  
  
  double X, D, sqrtD, s, n_c; 
   
  X = a*a - 16*b;  
  D = X/4; 
  sqrtD = sqrt(D); 
   
  s = a/2+2; 
   
  n_c = s - sqrtD;  
  n1 = n_c/2;
  m1 = s - n1;  
  
  if (n1<=m1)
    std::cout << n1  << " " << m1 << std::endl;
    else 
        std::cout << m1  << " " << n1 << std::endl; 
}