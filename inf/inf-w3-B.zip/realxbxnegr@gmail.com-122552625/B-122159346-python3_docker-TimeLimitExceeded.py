def fd(a, b):
    t = a // 2 + 2

    for n in range(1, t):
        m = t - n
        if (n - 1) * (m - 1) == b:
            return (min(n, m), max(n, m))

a, b = map(int, input().split())
result = fd(a, b)
print(result[0], result[1])
