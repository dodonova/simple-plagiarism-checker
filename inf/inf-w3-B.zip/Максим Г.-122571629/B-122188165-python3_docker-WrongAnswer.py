a,b=input().split(' ')
a=int(a)
b=int(b)
x=(a/2)+2
m=(x+(x**2-4*(x-1+b))**0.5)/2
if m%1!=0 or m<=0:
    m=(x-(x**2-4*(x-1+b))**0.5)/2
nmm=((a+2*b)/2)+1
n=nmm/m
print(int(min(m,n)),int(max(m,n)))