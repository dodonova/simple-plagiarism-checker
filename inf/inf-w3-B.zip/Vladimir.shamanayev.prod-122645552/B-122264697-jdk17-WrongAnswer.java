import java.util.Scanner;

public class PuzzleGrid {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            int a = scanner.nextInt();
            int b = scanner.nextInt();

            for (int n = 1, m; n <= a / 2 + 1; n++) {
                m = a / 2 + 2 - n;
                if (n <= m && (n - 1) * (m - 1) == b) {
                    System.out.println(n + " " + m);
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
