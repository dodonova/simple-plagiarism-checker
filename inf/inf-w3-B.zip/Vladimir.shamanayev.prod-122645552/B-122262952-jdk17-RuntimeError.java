import java.util.Scanner;


public class PuzzleGrid {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int a = scanner.nextInt();

        int b = scanner.nextInt();


        for (int n = 1; n <= a / 2 + 1; n++) {

            int m = a / 2 + 2 - n;

            if (n <= m && (n - 1) * (m - 1) == b) {

                System.out.println(n + " " + m);

                break;

            }

        }

    }

}