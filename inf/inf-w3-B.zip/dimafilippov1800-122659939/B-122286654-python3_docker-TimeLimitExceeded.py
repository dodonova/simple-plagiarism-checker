a, b = map(int, input().split())
s = a // 2 + 2
for n in range(10 ** 9 + 1):
    if (n * (s - n)) == (b + s - 1):
        print(n, s - n)
        break