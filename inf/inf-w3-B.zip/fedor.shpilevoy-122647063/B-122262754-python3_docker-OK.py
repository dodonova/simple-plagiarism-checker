from math import sqrt
a, b = input().split()
a = int(a)
b = int(b)
dis = (2 + a // 2) ** 2 - 4 * (a // 2 + b + 1)
m1 = (2 + a // 2 - sqrt(dis)) // 2
m2 = (2 + a // 2 + sqrt(dis)) // 2
n1 = (a - 2 * m1 + 4) // 2
n2 = (a - 2 * m2 + 4) // 2
if n1 <= m1:
    print(int(n1), int(m1))
else:
    print(int(n2), int(m2))