from math import sqrt
a, b = [int(i) for i in imput().split()]
m = (1/4)*(4 + a + sqrt(a**2 - 16*b))
n = (1/4)*(4 + a - sqrt(a**2 - 16*b))
print(int(n),int(m))