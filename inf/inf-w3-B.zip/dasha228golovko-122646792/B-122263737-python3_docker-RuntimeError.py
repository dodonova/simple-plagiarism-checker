import math

def calculate_discriminant(S, P):
    return S * S - 4 * P

def find_possible_dimensions(S, sqrt_D):
    n1 = (S + sqrt_D) // 2
    n2 = (S - sqrt_D) // 2
    return n1, n2

def validate_dimensions(n, S):
    m = S - n
    return n > 0 and m > 0 and n <= m, (n, m)

def find_dimensions(a, b):
    S = a // 2 + 2
    P = b + S - 1

    D = calculate_discriminant(S, P)
    if D < 0:
        return None

    sqrt_D = int(math.isqrt(D))
    n1, n2 = find_possible_dimensions(S, sqrt_D)

    results = []
    for n in (n1, n2):
        is_valid, dimensions = validate_dimensions(n, S)
        if is_valid:
            results.append(dimensions)

    return results

def main():
    a, b = map(int, input().split())
    dimensions = find_dimensions(a, b)

    if dimensions:
        for n, m in dimensions:
            print(n, m)
    else:
        print("No solution")

if name == "__main__":
    main()