#include <iostream>
#include <iomanip>

int main() {
    long long a, b;
    std::cin >> a >> b;
    if (a == 0 && b == 0) {
        std::cout << "1 1" << std::endl;
        return 0;
    }
    long long total = a / 2 + 2;
    for (long long n = 1; n <= total; ++n) {
        long long m = total - n;
        if ((n - 1) * (m - 1) == b) {
            if (n > m) std::swap(n, m);
            std::cout << n << " " << m << std::endl;
            return 0;
        }
    }

    return 0;
}