import math

def find_rectangle_size(a, b):
    S = a // 2 + 2
    P = b + 1
    
    D = S * S - 4 * P
    
    if D < 0:
        return None  # Нет решения
    
    sqrt_D = int(math.isqrt(D))
    
    # Проверяем, что D является полным квадратом
    if sqrt_D * sqrt_D != D:
        return None  # Нет решения
    
    n1 = (S + sqrt_D) // 2
    n2 = (S - sqrt_D) // 2
    
    # Проверяем, что оба корня являются положительными целыми числами
    results = []
    for n in (n1, n2):
        if n > 0 and S - n > 0:
            results.append((min(n, S - n), max(n, S - n)))
    
    # Возвращаем только уникальные результаты
    return sorted(set(results))

# Чтение входных данных
a, b = map(int, input().split())
result = find_rectangle_size(a, b)

if result:
    for n, m in result:
        print(n, m)
else:
    print("No solution")
