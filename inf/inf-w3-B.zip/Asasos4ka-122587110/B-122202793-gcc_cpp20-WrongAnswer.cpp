#include <iostream>
using namespace std;

pair<int, int> find_dimensions(int a, int b) {
    int total = a / 2 + 2; // Общая сумма
    for (int n = 1; n < total; n++) {
        int m = total - n; // Вычисляем m
        if (n <= m && (n - 1) * (m - 1) == b) {
            return make_pair(n, m); // Возвращаем найденные размеры
        }
    }
    return make_pair(-1, -1); // Возвращаем -1, -1 если размеры не найдены
}

int main() {
    int a, b;
    cin >> a >> b; // Считываем входные данные
    pair<int, int> result = find_dimensions(a, b);
    
    // Проверяем, были ли найдены размеры
    if (result.first != -1) {
        cout << result.first << " " << result.second << endl; // Выводим размеры
    } else {
        cout << "No solution" << endl; // Если решения нет
    }

    return 0;
}