import math
def find_grid_sizes(a, b):    
	S = (a // 2) + 2
	P = b + (a // 2) + 1
    D = S * S - 4 * P
    if D < 0:        
		return "No solution"
    sqrt_D = int(math.sqrt(D))
    if sqrt_D * sqrt_D != D:
        return "No solution"
    n = (S - sqrt_D) // 2
	m = (S + sqrt_D) // 2
    if n > m:
        n, m = m, n
    return n, m
result = find_grid_sizes(a, b)
if isinstance(result, tuple):    print(result[0], result[1])
else:    print(result)