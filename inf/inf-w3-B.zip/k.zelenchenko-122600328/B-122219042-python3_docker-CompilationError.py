def find_dimensions(a, b):   
	S = (a // 2) + 2
    P = b + S - 1
    if D < 0:        return None   
    sqrt_D = int(D**0.5)
    n1 = (S - sqrt_D) // 2  
	n2 = (S + sqrt_D) // 2   
    return (min(n1, n2), max(n1, n2))
result = find_dimensions(a, b)if result:
    print(result[0], result[1])else:
    print("Не удалось найти размеры.")