a, b = map(int, input().split())
for n in range(1, 5000):
    for m in range(1, 5000):
        if n > m:
            if 2 * ( n + m - 2) == a and (n - 1) * (m - 1) == b:
                print(min(n ,m), max(n, m))
                break