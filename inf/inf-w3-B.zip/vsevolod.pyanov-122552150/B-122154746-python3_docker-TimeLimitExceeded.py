def solve_puzzle(a, b):
    sum_nm = (a // 2) + 2
    for n in range(1, sum_nm):
        m = sum_nm - n
        if (n - 1) * (m - 1) == b:
            print(n, m)
            return

a, b = map(int, input().split())
solve_puzzle(a, b)