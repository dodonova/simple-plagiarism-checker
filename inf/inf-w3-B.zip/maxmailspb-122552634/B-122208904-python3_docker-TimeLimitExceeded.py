a, b = map(int,input().split())
m = 2
if a == 0 and b == 0:
    print(1, 1)
elif b == 0:
    n = 1
    while True:
        if 2*(n - 1) == a:
            break
        else:
            n += 1
    print(1, n)
else:
    while True:
        if (2*(b + m - 1)) / (m - 1) + 2 * m - 4 == a:
            break
        else:
            m += 1
    n = (b + m - 1) // (m - 1)
    print(min(n, m), max(n, m))
