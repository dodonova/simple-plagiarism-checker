#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int corner = 4;
    long long t_figure, cross;
    cin >> t_figure >> cross;
    long long n_m = t_figure / 2 + 2;
    for (long long n = 1; n < n_m; ++n) {
        long long m = n_m - n;
        if ( (n - 1) * (m - 1) == cross ) {
            cout << min(n, m) << " " << max(n, m) << endl;
            break;
        }
    }
    return 0;
}