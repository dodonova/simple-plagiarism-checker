def can_form_grid(n, m):
    corners = 4
    t_shapes = 2 * (n + m - 2)
    crosses = (n - 1) * (m - 1)
    
    total_shapes = corners + t_shapes + crosses
    return total_shapes == n * m

n, m = map(int, input().split())
print("YES" if can_form_grid(n, m) else "NO")