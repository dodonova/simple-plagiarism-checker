a, b = map(int, input().split())
m, n = a / 4 + (a ** 2 / 4 - 4 * b) ** 0.5 / 2 + 1, a / 4 - (a ** 2 / 4 - 4 * b) ** 0.5 / 2 + 1
print(int(n), int(m))