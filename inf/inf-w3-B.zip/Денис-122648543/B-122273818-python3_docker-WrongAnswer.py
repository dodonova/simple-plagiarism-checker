from math import sqrt
a, b = map(int,input().split())
m = b + 0.5 * a + 1
a = int(a * 0.5 + 2)
m = int(m)
x = int(a ** 2 - 4 * m)
print(int((a - sqrt(x)) / 2), int((a + sqrt(x)) / 2))