import math

a_str, b_str = input().split()
a = int(a_str)
b = int(b_str)

if a % 2 != 0:
    print("Impossible")
else:
    N = a * a - 16 * b
    if N < 0 or N % 4 != 0:
        print("Impossible")
    else:
        D = N // 4
        sqrt_D = int(math.isqrt(D))
        if sqrt_D * sqrt_D != D:
            print("Impossible")
        else:
            s = a // 2 + 2
            found = False
            for sign in [1, -1]:
                n_candidate = (s + sign * sqrt_D)
                if n_candidate % 2 != 0:
                    continue
                n = n_candidate // 2
                m = s - n
                if n >= 1 and m >= 1:
                    if n > m:
                        n, m = m, n
                    print(f"{n} {m}")
                    found = True
                    break
            if not found:
                print("Impossible")