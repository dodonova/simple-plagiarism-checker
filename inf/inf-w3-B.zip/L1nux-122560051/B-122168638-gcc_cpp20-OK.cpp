#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll integer_sqrt_func(ll D){
    if(D == 0 || D ==1) return D;
    ll left = 0, right = min(D, (1LL<<32));
    ll ans = 0;
    while(left <= right){
        ll mid = left + (right - left) / 2;
        __int128 mid_sq = (__int128)mid * mid;
        if(mid_sq == D){
            return mid;
        }
        else if(mid_sq < D){
            ans = mid;
            left = mid + 1;
        }
        else{
            right = mid -1;
        }
    }
    return ans;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll a, b;
    cin >> a >> b;
    ll s = a / 2 + 2;
    ll n, m;
    if(b == 0){
        
        n = 1;
        m = s -1;
        
    }
    else{
        
        ll s_minus_2 = s - 2;
        ll D = s_minus_2 * s_minus_2 - 4 * b;
      
        ll sqrt_D = integer_sqrt_func(D);
        
        ll k = (s_minus_2 - sqrt_D) /2;
        n = k +1;
        m = s - n;
        if(n > m){
            swap(n, m);
        }
    }
    cout << n << " " << m;
}
