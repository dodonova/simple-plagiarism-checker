a, b = map(int, input().split())
s = a / 2 + 2
n = 1
while (n - 1) * (s - n - 1) != b:
    n += 1
print(n, int(s - n))