a, b = map(int, input().split())
s = a / 2 + 2
left, right = 1, s // 2 + 1
while left <= right:
    n = (left + right) // 2
    current_b = (n - 1) * (s - n - 1)

    if current_b == b:
        print(int(n), int(s - n))
        break
    elif current_b < b:
        left = n + 1
    else:
        right = n - 1