t_shapes, crosses = map(int, input().split())
total_cells = (t_shapes // 2) + 2
for n in range(2, total_cells // 2 + 1):
    m = total_cells - n
    if (n - 1) * (m - 1) == crosses:
        print(n, m)