import math

a, b = map(int, input().split())

z = a // 2 + 2
p = b + z - 1

discriminant = z * z - 4 * p

if discriminant < 0:
    raise ValueError("Нет решения, так как дискриминант отрицательный.")

sqrt_discriminant = int(math.isqrt(discriminant))

n1 = (z + sqrt_discriminant) // 2
m1 = (z - sqrt_discriminant) // 2
n2 = (z - sqrt_discriminant) // 2
m2 = (z + sqrt_discriminant) // 2

n, m = min(n1, m1), max(n1, m1)


print(n, m)
