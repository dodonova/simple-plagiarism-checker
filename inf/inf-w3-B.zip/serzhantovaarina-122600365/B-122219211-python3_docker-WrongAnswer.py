def find_dimensions(a, b):
  n = a + 2 
  m = b + 2 
  return n, m
if __name__ == "__main__":
  a, b = map(int, input().split())
  n, m = find_dimensions(a, b)
  print(n, m)
