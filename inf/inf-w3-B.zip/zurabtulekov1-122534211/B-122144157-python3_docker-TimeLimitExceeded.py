def find_dimensions(a, b):
   
    total_cols_rows = a // 2 + 2

    for n in range(1, total_cols_rows): 
        m = total_cols_rows - n
        if (n - 1) * (m - 1) == b:
            return (min(n, m), max(n, m))  
a, b = map(int, input().split())
dimensions = find_dimensions(a, b)
if dimensions:
    print(dimensions[0], dimensions[1])
else:
    print("")