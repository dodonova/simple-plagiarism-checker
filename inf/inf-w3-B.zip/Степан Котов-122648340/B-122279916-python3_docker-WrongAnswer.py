import math

a, b = map(int, input().split())

discriminant = (6 + a) ** 2 - 4 * (-a - 4 - 2 * b) * (-3)

if discriminant < 0:
    print("No real roots")
else:
    d = math.sqrt(discriminant)
    m1 = (-6 - a + d) / -6
    m2 = (-6 - a - d) / -6
    if m1 > 0:
        n = (a - 2 * m1 + 4) / 2
    else:
        n = (a - 2 * m2 + 4) / 2
    m = 0  
    print(n, end=" ")
    print(m)