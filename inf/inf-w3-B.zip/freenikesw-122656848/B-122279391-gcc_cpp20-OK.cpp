#include <iostream>
#include <cmath>

using namespace std;

int main() {
    long long a, b;
    cin >> a >> b;
    
    long long n=0, m1=0, m2=0;
    
    m1 = - (-4-a-sqrt(-16*b+a*a))/4;
    m2 = - (-4-a+sqrt(-16*b+a*a))/4;
    
    long long finalm = m1 >= 0 ? m1 : m2;
        
    n = -finalm + 2 + a/2;
    
    cout << n << " " << finalm;

    return 0;
}