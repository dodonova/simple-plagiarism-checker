#include <iostream>
#include <string>
#include <sstream>

int main() {
    int a, b;
    std::string input;
    std::getline(std::cin, input);
    std::istringstream iss(input);
    iss >> a >> b;

    int n_plus_m = (a / 2) + 2;

    for (int n = 1; n <= n_plus_m / 2 + 1; ++n) {
        int m = n_plus_m - n;
        if ((n - 1) * (m - 1) == b) {
            std::cout << n << " " << m << std::endl;
            break;
        }
    }

    return 0;
}
