Tshape, xshape = list(map(int, input().split()))
for i in range(0,1):
    if xshape == 0 and Tshape == 0:
        print(1,1)
        break
    if xshape == 0:
        st = (Tshape + 4)//2
        print(min(st,col),max(st,col))
        break
    elif xshape == 1:
        print(2,2)
        break
    else:
        for dl in range(2, int(xshape ** 0.5) + 1):
            if xshape % dl == 0:
                col = dl + 1
                st = (xshape// (dl)) + 1
                if Tshape == (2 * (col + st - 2)):
                    print(min(col, st), max(col, st))
                    break
