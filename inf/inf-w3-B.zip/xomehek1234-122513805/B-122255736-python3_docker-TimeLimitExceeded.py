a,b = list(map(int,input().split()))
mx = max(a,b)
def f (a,b):
    mx = max(a, b, 5)
    for m in range(1,mx):
        for n in range(1,(mx - m)):
            if a == 2*(n + m - 2) and b == (n - 1 ) * (m - 1):
                return (min (n, m), max(m,n))

print(*f(a,b))
