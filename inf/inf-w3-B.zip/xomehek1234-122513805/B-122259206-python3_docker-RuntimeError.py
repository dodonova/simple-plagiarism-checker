def find_dimensions(a, b):
    
    m = a + b + n - 2
    return n, m

a, b = map(int, input().split())


n, m = find_dimensions(a, b)


if n > m:
    n, m = m, n


print(n, m)
