#include <iostream>
#include <cmath>
#include <algorithm>

int main() {
    int Tshape, xshape;
    std::cin >> Tshape >> xshape;

    for (int i = 0; i < 1; i++) {
        if (xshape == 0 && Tshape == 0) {
            std::cout << 1 << " " << 1 << std::endl;
            break;
        }
        if (xshape == 0) {
            int col = 1;
            int st = (Tshape + 4) / 2;
            std::cout << std::min(st, col) << " " << std::max(st, col) << std::endl;
            break;
        } else if (xshape == 1) {
            std::cout << 2 << " " << 2 << std::endl;
            break;
        } else {
            for (int dl = 2; dl <= std::sqrt(xshape); dl++) {
                if (xshape % dl == 0) {
                    int col = dl + 1;
                    int st = (xshape / dl) + 1;
                    if (Tshape == (2 * (col + st - 2))) {
                        std::cout << std::min(col, st) << " " << std::max(col, st) << std::endl;
                        break;
                    }
                }
            }
        }
    }
    return 0;
}

