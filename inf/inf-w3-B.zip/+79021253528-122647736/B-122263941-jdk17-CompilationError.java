using System;

class Program
{
    static void Main()
    {
        // Считываем количество T-образных фигур и крестиков
        string[] input = Console.ReadLine().Split();
        int t = int.Parse(input[0]);
        int b = int.Parse(input[1]);

        // Вычисляем общую площадь
        long S = 2L * t + 5L * b + 4;

        // Ищем размеры n и m
        for (long n = 1; n * n <= S; n++)
        {
            if (S % n == 0)
            {
                long m = S / n;
                if (n <= m)
                {
                    Console.WriteLine($"{n} {m}");
                    return;
                }
            }
        }
    }
}