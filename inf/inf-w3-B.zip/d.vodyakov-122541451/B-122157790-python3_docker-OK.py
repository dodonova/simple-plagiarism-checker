a, b = map(int, input().split())
def grid(a, b):
    snm=a//2+2
    pnm=b+(a//2)+1
    D = snm**2-4*pnm
    if D < 0:
        return None
    n1=(snm + D*0.5)//2
    n2=(snm - D**0.5)//2
    for n in (n1, n2):
        n=int(n)
        m = snm - n
        if n <= m:
            return n, m
ans=grid(a, b)
print(min(ans), max(ans))
