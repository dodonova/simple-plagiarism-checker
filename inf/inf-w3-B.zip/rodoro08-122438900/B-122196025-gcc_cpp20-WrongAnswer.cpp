#include <iostream>
using namespace std;

int main() {
    long a, b;
    cin >> a >> b;

    long suma = a / 2 + 2; // n + m
    for (long n = 0; n < suma / 2; ++n) {
        long m = suma - n;
        if ((n - 1) * (m - 1) == b) {
            cout << n << " " << m << endl;
            return 0;
        }
    }
    cout << "0 0" << endl;

    return 0;
}