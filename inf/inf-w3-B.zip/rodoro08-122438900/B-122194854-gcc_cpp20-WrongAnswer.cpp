#include <iostream>
using namespace std;

int main() {
    long long a, b;
    cin >> a >> b;

    long long suma = a / 2 + 2; // n + m
    for (long long n = 1; n < suma / 2; ++n) {
        long long m = suma - n;
        if ((n - 1) * (m - 1) == b) {
            cout << n << " " << m << endl;
            break;
        }
    }

    return 0;
}