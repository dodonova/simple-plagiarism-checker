#include <iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;

    int suma = a / 2 + 2; // n + m
    for (int n = 1; n <= suma / 2; ++n) {
        int m = suma - n;
        if ((n - 1) * (m - 1) == b) {
            cout << n << " " << m << endl;
            break;
        }
    }

    return 0;
}