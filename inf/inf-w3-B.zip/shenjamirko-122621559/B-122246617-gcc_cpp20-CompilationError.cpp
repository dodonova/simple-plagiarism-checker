# Программа для вычисления минимальной разницы между площадями двух кусков пирога

def calculate_area_difference(corner, candle_position, rectangle_size):
    x0, y0 = corner
    x_c, y_c = candle_position
    width, height = rectangle_size

    # Коэффициенты прямой линии через угол и точку свечи
    if x_c - x0 == 0:
        # Вертикальная линия
        slope = None
    else:
        slope = (y_c - y0) / (x_c - x0)
        intercept = y0 - slope * x0

    # Функция для определения, находится ли точка ниже линии
    def is_below_line(x, y):
        if slope is None:
            return x <= x0
        else:
            return y <= slope * x + intercept

    # Сетка точек для численного интегрирования
    num_points = 1000
    dx = width / num_points
    dy = height / num_points

    area1 = 0
    area2 = 0

    for i in range(num_points):
        for j in range(num_points):
            x = i * dx
            y = j * dy
            if is_below_line(x, y):
                area1 += dx * dy
            else:
                area2 += dx * dy

    return abs(area1 - area2)