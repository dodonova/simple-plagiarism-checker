def find_grid_dimensions(a, b):
    if a == 0 or b == 0:
        return (0, 1)  # Если фигур или пересечений нет, то возвращаем размеры 0x1
    
    possible_dimensions = []
    
    # Количество пересечений на фигуру
    required_intersections = 4 * a  # Нужно 4 пересечения на каждую "Т"-фигуру
    
    # Перебор возможных размеров m и n
    for n in range(1, 10**6):  # Приблизительные пределы для n
        if required_intersections % (n + 1) == 0:
            m = (required_intersections // (n + 1)) - 1
            if m > 0:
                possible_dimensions.append((n, m))
    
    # Фильтруем размеры по количеству пересечений
    for n, m in possible_dimensions:
        intersections_count = (n + 1) * (m + 1)
        if intersections_count == b:
            return (n, m)

# Прочитаем входные данные
a, b = map(int, input().split())

# Найдём размеры решётки
result = find_grid_dimensions(a, b)

# Выводим результат
print(result[0], result[1])