def find_dimensions(a, b):
    for n in range(1, a + 3):  # n должен быть больше 0
        # Вычисляем m
        m_candidate = (a + 4 - 2 * n) / 2
        
        if m_candidate &lt; n:  # Условие n &lt;= m
            continue
        
        # Проверяем целочисленное значение и соответствие крестиков
        if m_candidate.is_integer():
            m = int(m_candidate)
            # Проверяем количество крестиков
            if (n - 1) * (m - 1) == b:
                return n, m
    
    return None  # Если не нашли решение

# Считываем входные данные
data = input().strip().split()
a = int(data[0])
b = int(data[1])

# Получаем размеры
n, m = find_dimensions(a, b)

# Выводим результат
print(n,m)