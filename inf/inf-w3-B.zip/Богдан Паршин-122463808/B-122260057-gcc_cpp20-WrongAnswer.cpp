#include <iostream>
#include <cmath>

void findGridDimensions(int a, int b) {
    int totalCells = 4 * a + b;

    
    for (int n = 1; n <= std::sqrt(totalCells); ++n) {
        if (totalCells % n == 0) {
            int m = totalCells / n; // m находится как результат деления общего числа клеток на n
            std::cout << n << " " << m << std::endl;
            return;
        }
    }
}

int main() {
    int a, b;
    std::cin >> a >> b;
    findGridDimensions(a, b);
    return 0;
}