def solve_puzzle(a, b):
    # s = (a / 2) + 2
    s = (a // 2) + 2  # Используем целочисленное деление
    
    # Перебираем возможные значения x
    for x in range(s - 1):
        y = s - 2 - x
        if y < 0:
            continue
        if x * y == b:
            n = x + 1
            m = y + 1
            # Убедимся, что n <= m
            return sorted((n, m))
    
    return None

# Чтение входных данных
a, b = map(int, input().strip().split())
result = solve_puzzle(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
else:
    print("No solution")