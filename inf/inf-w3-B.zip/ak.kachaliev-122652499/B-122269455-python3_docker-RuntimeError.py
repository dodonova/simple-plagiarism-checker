x, y = map(int, input().split())

discriminant = (4 + x) ** 2 - 4 * (0 - 2) * (0 - 2 - x - 2 * y)
root1 = (-(4 + x) + discriminant ** 0.5) // (-4)
root2 = (-(4 + x) - discriminant ** 0.5) // (-4)
m = max(root1, root2)
m = (x - 2 * m + 4) // 2
print(*[int(n), int(m)])