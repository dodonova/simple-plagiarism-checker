#include <iostream>
#include <cmath>
#include <algorithm>

int main() {
    int coefficientA, coefficientB;
    std::cin >> coefficientA >> coefficientB;

    long long numerator = static_cast<long long>(coefficientA) * coefficientA - 16 * coefficientB;
    long long denominator = numerator / 4;
    int discriminantSquareRoot = std::sqrt(denominator);

    int sumOfCoefficients = coefficientA / 2 + 2;
    bool solutionFound = false;

    for (int sign : {1, -1}) {
        int candidateN = sumOfCoefficients + sign * discriminantSquareRoot;
        if (candidateN % 2!= 0) {
            continue;
        }
        int n = candidateN / 2;
        int m = sumOfCoefficients - n;
        if (n >= 1 && m >= 1) {
            if (n > m) {
                std::swap(n, m);
            }
            std::cout << n << " " << m << std::endl;
            solutionFound = true;
            break;
        }
    }

    if (!solutionFound) {
    }

    return 0;
}