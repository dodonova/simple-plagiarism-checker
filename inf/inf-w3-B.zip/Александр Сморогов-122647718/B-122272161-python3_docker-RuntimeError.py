import math
m, n = map(int, input().split())
f = (n / 2 + 2) ** 2 - 4 * (n / 2 + m + 1)
v = (n / 2 + 2 - math.sqrt(f)) / 2
h = (n / 2 + 2 + math.sqrt(f)) / 2
print(int(v), int(h))