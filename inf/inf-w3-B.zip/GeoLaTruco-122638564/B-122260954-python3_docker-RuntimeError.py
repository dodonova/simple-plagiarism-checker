def find_dimensions(a, b):
    # n + m = a/2 + 2
    total = a // 2 + 2

    # Перебираем возможные значения n
    for n in range(2, total):
        m = total - n
        if (n - 1) * (m - 1) == b:
            return n, m
    return None

# Ввод данных
a, b = map(int, input().strip().split())

# Поиск размеров
n, m = find_dimensions(a, b)

# Вывод результата
print(f"{n} {m}")