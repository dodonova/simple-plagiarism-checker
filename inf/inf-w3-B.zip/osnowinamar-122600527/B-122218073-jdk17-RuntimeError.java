import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int s = (a / 2) + 2;
        for (int n = 1; n < s; n++) {
            int m = s - n;
            if ((n - 1) * (m - 1) == b) {
                System.out.println(Math.min(n, m) + " " + Math.max(n, m));
                return;
            }
        }
        System.out.println("1 1");
    }
}