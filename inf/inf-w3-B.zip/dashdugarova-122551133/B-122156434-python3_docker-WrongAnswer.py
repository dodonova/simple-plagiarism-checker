a, b = map(int, input().split())

if a==0 or b==0:
    print(1, 1)
else:
    if a%2==0:
        sum_nm=a//2+2
        for n in range(2, sum_nm):
            m=sum_nm-n
            if (n-1)*(m-1)==b:
                print(n,m)
                break