o, p = map(int, input().split())

sumN = o // 2 + 2
prodN = p + (o // 2) + 1

B = N1*N1- 4 * N2

n1 = (N1 + 0.5) / 2
n2 = (N1 - B**0.5) / 2

for n in [n1, n2]:
    if n.is_integer():
        n = int(n)
        m = N1 - n

print(min(n,m), max(n,m))