import math

def solve_puzzle_optimized(a, b):
    n = math.ceil(math.sqrt(b))
    m = math.ceil((b + 1) / 2)
    
    if n * m - (n + m) + 2 == b:
        return f"{n} {m}"
    
    return f"{min(n+1, m)} {max(n, m)}"

# Пример использования
a, b = map(int, input().split())
result = solve_puzzle_optimized(a, b)
print(result)