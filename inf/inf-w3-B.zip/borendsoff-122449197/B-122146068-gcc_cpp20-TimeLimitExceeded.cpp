#include <iostream>
#include <tuple>

std::tuple<int, int> fg(int a, int b) {
    for (int n = 1; n <= (a + 4) / 2; ++n) {
        for (int m = n; m <= (a + 4) / 2; ++m) {
            if ((n - 1) * (m - 1) == b && 2 * (n + m - 2) == a) {
                return std::make_tuple(n, m);
            }
        }
    }
    return std::make_tuple(-1, -1); // Indicate no solution found
}

int main() {
    int a, b;
    std::cin >> a >> b;
    auto d = fg(a, b);
    if (std::get<0>(d) != -1) {
        std::cout << std::get<0>(d) << " " << std::get<1>(d) << std::endl;
    }
    return 0;
}

