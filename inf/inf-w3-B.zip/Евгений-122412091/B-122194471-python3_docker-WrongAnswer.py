def find_n_m(a, b):
    s = (a // 2) + 2
    p = b + s - 1

    D = s * s - 4 * p

    if D < 0:
        return None

    sqrt_D = int(D ** 0.5)

    if sqrt_D * sqrt_D != D:
        return None

    n1 = (s + sqrt_D) // 2
    n2 = (s - sqrt_D) // 2

    if n1 > 0 and n2 > 0:
        return n1, n2

    return None

a, b = map(int, input().split())
result = find_n_m(a, b)

if result: print(result[0], result[1])
else: print(-1)