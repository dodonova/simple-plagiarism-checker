#include <iostream>
#include <vector>

using namespace std;


int main() {
    int a, b;
    cin >> a >> b;
    int s;
    s = a / 2 + 2;
    for (int i = 1; i < s; i++) {
    	int m = s - i;
        if (b == (i - 1) * (m - 1)) {
        	cout << min(i, m) << " " << max(i, m);
            break;
        }
    }
};
