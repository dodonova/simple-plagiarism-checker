def find_dimensions(a, b):
    # Ограничиваем n по логическим пределам
    max_n = a // 2 + 2  # Максимальное значение n
    for n in range(1, max_n + 1):
        m = (a // 2) - n + 2
        if m < n:
            break  # Если m < n, дальше нет смысла проверять
        if (n - 1) * (m - 1) == b:
            return n, m
    return None

# Чтение входных данных
a, b = map(int, input().split())
result = find_dimensions(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
else:
    print("No solution")
