import math
S = a // 2 + 2
P = b + a // 2 + 1
D = S * S - 4 * P
if D < 0:
    raise ValueError("Нет решения")
n, m = sorted((n1, m1))

print(n, m)
