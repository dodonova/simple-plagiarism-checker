def find_dimensions(a, b):
    total_sum = a // 2 + 2
    
    total_product = b + total_sum
    
    discriminant = total_sum * total_sum - 4 * total_product
    
    if discriminant < 0:
        return None  
    
    sqrt_discriminant = int(discriminant ** 0.5)
    
    n1 = (total_sum - sqrt_discriminant) // 2
    n2 = (total_sum + sqrt_discriminant) // 2
    
    # Убедимся, что n1 <= n2
    n = min(n1, n2)
    m = max(n1, n2)
    
    return n, m

# Чтение входных данных
a, b = map(int, input().split())
n, m = find_dimensions(a, b)

# Вывод результата
if n is not None and m is not None:
    print(n, m)