A,B = list(map(int, input().split(' ')))
A=A//2+2
B=B-1
for n in range(2,1000000000):
    if A-n==(B+n)/(n-1) and n<A-n:
        print(n, A-n)
        break
