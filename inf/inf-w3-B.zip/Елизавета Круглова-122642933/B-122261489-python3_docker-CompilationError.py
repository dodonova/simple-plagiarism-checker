from collections import Counter 
def find_words(mixed_string, words): 
    valid_words = []  
    for word in words: 
        word_count = Counter(word) 
        if all(word_count[char] <= target_count[char