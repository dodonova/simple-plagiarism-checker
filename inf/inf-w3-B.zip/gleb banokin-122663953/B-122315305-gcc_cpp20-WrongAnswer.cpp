#include <iostream>
using namespace std;
int main() {
    int t_f, x_c;
    cin >> t_f >> x_c;
    if (x_c == 0 && t_f <= 1) {
        cout << 1 << " " << 1 << endl;
    } else {
        for (int it = 1; it <= t_f; ++it) {
            if ((it - 1) * (t_f / 2.0 - it + 1) == x_c) {
                if ((t_f / 2.0 - it + 2) > it) {
                    cout << it << " " << static_cast<int>(t_f / 2.0 - it + 2) << endl;
                } else {
                    cout << static_cast<int>(t_f / 2.0 - it + 2) << " " << it << endl;
                }
            }
        }
    }
    return 0;
}