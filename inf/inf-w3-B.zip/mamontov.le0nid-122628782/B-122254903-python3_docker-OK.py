a, b = [int(i) for i in input().split()]
a = a//2
m =int(a+2+(a*a-4*b)**0.5)//2
n = a+2 - m
print(n, m)