import math
# Чтение входных данных  
a, b = map(int, input().split())  
# Вычисление S и P  
S = a // 2 + 2  
P = b + a // 2 + 1  
# Вычисление дискриминанта  
D = S * S - 4 * P  
if D < 0:     
 print("Нет решения")  
else:     
 sqrt_D = int(math.sqrt(D))  
 n1 = (S + sqrt_D) // 2     
 n2 = (S - sqrt_D) // 2  
        # Проверка, что n1 и n2 являются целыми числами  
 if (S + sqrt_D) % 2 == 0 and (S - sqrt_D) % 2 == 0:         \
  n = min(n1, n2)  
  m = max(n1, n2)          
  print(n, m)  
 else:          
  print("Нет решения")
