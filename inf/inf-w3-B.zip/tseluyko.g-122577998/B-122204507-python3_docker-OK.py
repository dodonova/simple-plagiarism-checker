import math
a, b = map(int, input().split())
D = (-4-a)**2 - 8*(2*b + 2 + a)
m = (-(-4-a) + math.sqrt(D))/4
if (m==1):
    n = 1
else:
    n = b/(m-1) + 1
print(int(n), int(m))
