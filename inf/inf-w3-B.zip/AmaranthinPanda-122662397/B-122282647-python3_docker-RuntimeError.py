def find_dimensions(a, b):
    total = (a + b + 4) // 2 + 2

    # Перебираем возможные размеры n и m
    for n in range(1, total):
        m = total - n
        if n <= m and (n - 1) * (m - 1) == b and 2 * (n + m - 2) == a + b + 4:
            return n, m

# Чтение входных данных
a, b = map(int, input().split())

# Нахождение размеров решетки
n, m = find_dimensions(a, b)

# Вывод результатов
print(n, m)