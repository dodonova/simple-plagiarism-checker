import java.util.Scanner;

public class Puzzle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        
        for (int n = 1; n <= Math.sqrt(b + 1); n++) {
            // Вычисляем m на основе уравнения для t-образных фигур
            int m = (a + 4) / 2 - n;
            
            if (m >= n && (n - 1) * (m - 1) == b) {
                // Выводим результат
                System.out.println(n + " " + m);
                return;
            }
        }
    }
}