import java.util.Scanner;

public class MathPuzzle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        

        int a = scanner.nextInt();
        int b = scanner.nextInt();
        

        int sumNM = a / 2 + 2;
        

        for (int n = 1; n <= sumNM; n++) {
            int m = sumNM - n; 
            

            if ((n - 1) * (m - 1) == b) {

                if (n > m) {
                    int temp = n;
                    n = m;
                    m = temp;
                }

                System.out.println(n);
                System.out.println(m);
                return;
            }
        }
    }
}