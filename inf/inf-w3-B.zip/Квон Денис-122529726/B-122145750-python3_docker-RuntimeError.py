A = input().split()
a = int(A[0])
b = int(A[1])
x = (a + 4) / 2 #m + n
y = (b - 1) + x #mn
q = []
x1 = x2 = 0
points = [i for i in range(-100, 100)]
for i in points:
    x1 = i
    for j in points:
        x2 = j
        if x1 + x2 == -x / 1 and x1 * x2 == y / 1:
            q.append(-x1)
            q.append(-x2)
print(q[1], q[0])

