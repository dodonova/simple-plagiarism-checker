t, c = map(int, input().split())

p = t + 4

# t = p - 4

# c = m * n

# p = 2 * (m + n) + 4

if c == 0:
    print(t // 2, 1)
elif c == 1:
    print(1, t // 2)


for m in range(1, c):
    n = c // m
    if 2 * (m + n) + 4 == p:
        print(min([m + 1, n + 1]), max([m + 1, n + 1]))
        break
