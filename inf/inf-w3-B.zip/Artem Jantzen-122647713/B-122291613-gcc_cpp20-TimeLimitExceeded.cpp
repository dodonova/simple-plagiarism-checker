#include <iostream>

int main() {
    std::cin.tie(nullptr);
    int a, b;
    std::cin >> a >> b;

    a /= 2;

    for (long long i = 0; i < 1e9; ++i) {
        if ((i - 1) * (a - i + 1) == b) {
            int n = i;
            int m = a - i + 2;
            if (m < n) {
                std::swap(n, m);
            }
            std::cout << n << " " << m << std::endl;
            break;
        }
    }

    return 0;
}