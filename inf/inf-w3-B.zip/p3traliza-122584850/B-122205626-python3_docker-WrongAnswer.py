a,b=map(int,input().split())
n=0
m=0
z = 4 + a
x=a**2-16*b
r= z - x**0.5
f = z + x**0.5
p=f/4
k = r/4

if p>k:
    m = p
    n = k
if k>p:
    m=k
    n=p
print(n, m)