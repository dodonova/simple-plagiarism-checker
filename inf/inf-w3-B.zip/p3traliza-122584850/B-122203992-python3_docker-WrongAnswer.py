n=0
m=0
a,b=map(int,input().split())
z = 4 + a
x=a**(2)-16*b
r= z- x**(1/2)
f = z + x**(1/2)

k = r/4
p=f/4
if k < p:
    m = p
    n = k
else:
    m=k
    n=p
print(n, m)