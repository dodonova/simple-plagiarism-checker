a,b=int(input()),int(input())
summ=a//2+2
vt=b+a//2+1
bigD=summ**2-4*vt
c=(summ+0.5)/2
d=(summ-bigD**0.5)/2
for n in [c,d]:
    if n.is_integer():
        n=int(n)
        m=sumN-n
print(min(n,m), max(n,m))