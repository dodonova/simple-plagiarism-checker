a, b = map(int, input().split())
if b == 0:
    print("1 1")
elif (a * a < 16 * b):
    print("0 0")
else:
    m = (a + pow((a * a - 16 * b), 0.5)) / 4 + 1
    n = b / (m - 1) + 1
    print(min(m, n), max(m, n), end='')
