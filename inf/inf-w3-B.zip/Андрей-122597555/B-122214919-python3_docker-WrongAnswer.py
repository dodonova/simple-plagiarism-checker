a, b = map(int, input().split())
for x in range(-100, 100): 
    y = (a / 2 + 2) - x
    if (x - 1) * (y - 1) == b:
        print(x, int(y))
        break