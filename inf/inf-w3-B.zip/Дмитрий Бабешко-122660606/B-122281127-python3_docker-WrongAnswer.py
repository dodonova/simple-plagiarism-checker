import math
def find_dimensions(a, b):
    D = (a + 1) ** 2 - 4 * (b + a)
    if D < 0:
        return None
    sqrt_D = int(math.sqrt(D))
    n1 = (a + 1 + sqrt_D) // 2
    n2 = (a + 1 - sqrt_D) // 2
    for n in (n1, n2):
        if n > 0 and n <= a + 1:
            m = a + 2 - n 
            if (n - 1) * (m - 1) == b:
                return (min(n, m), max(n, m))
    return None
a, b = map(int, input().strip().split())
dimensions = find_dimensions(a, b)
if dimensions:
    print(*dimensions)
else:
    print("No solution")