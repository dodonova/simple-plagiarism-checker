def find_grid_size(a, b):

    total_cells = 3 * a + 5 * b + 4


    for n in range(1, int(total_cells**0.5) + 1):
        if total_cells % n == 0:
            m = total_cells // n
 
            if n <= m:
                return n, m
    return None


a, b = map(int, input().split())
result = find_grid_size(a, b)

if result:
    print(result[0], result[1])
