def find_dimensions(a, b):
    for n in range(1, a + 3): 
        m = (a // 2) + 2 - n
        if m < n:
            continue
        
        if (n - 1) * (m - 1) == b:
            return n, m
    
    return None

a, b = map(int, input().strip().split())
result = find_dimensions(a, b)

if result:
    print(result[0], result[1])
else:
    print("No solution")
