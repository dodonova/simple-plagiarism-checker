a, b = map(int, input().split())
total = (a//2)+ 2

for n in range(1, total):
    m = total - n
    if n > m:
        break
    elif (n - 1) * (m - 1) == b:
        print(n, m)
        break
else:
    print("ошибка")