tshki, krestiki = map(int, input().split())

n = 0
m = 0

def meow_meow_meeeeooow(tshki, krestiki)
for k in range (int(S), 1):
    if (tshki + 4) % 2 == 0:
        m = (tshki + 4) // 2 - n
        
        if m>=n and (n-1)* (m - 1) == krestiki:
            return n, m



if tshki == 0 and krestiki == 0:
    print(1, 1)
else:
    rezzzzzzzult = meow_meow_meeeeooow(tshki, krestiki)
    print(rezzzzzzzult[0],[1])