# Ввод данных
a, b = map(int, input().split())

# n + m = a // 2 + 2
sum_nm = a // 2 + 2

# Перебираем возможные значения n
for n in range(1, sum_nm):
    m = sum_nm - n
    if (n - 1) * (m - 1) == b:
        # Выводим результат так, чтобы n <= m
        if n <= m:
            print(n, m)
        else:
            print(m, n)
        break
