Калигин, [23 окт. 2024 в 22:36]
# Ввод данных
a, b = map(int, input().split())

# Вычисляем k
k = (a // 2) + 2

# Перебираем возможные значения n
for n in range(1, k):
    m = k - n
    if (n - 1) * (m - 1) == b:
        # Убедимся, что n <= m
        if n > m:
            n, m = m, n
        print(n, m)
        break