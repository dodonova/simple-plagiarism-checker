a, b = map(int, input().split())
ans = []
for i in range(2, 10**9):
    if b % i == 0:
        # print(i, b%i)
        n = i + 1
        m = b // i + 1
        # print(n, m)
        if 2 * (n + m - 2) == a and (n - 1) * (m - 1) == b:
            ans.append(n)
            ans.append(m)
            break
if ans == []:
    print(1, 1)
else:
    print(*sorted(ans))