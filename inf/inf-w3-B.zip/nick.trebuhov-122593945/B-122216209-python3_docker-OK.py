import math

a_str, b_str = input().split()
a = int(a_str)
b = int(b_str)

if a % 2 != 0:
    print("No solution")
else:
    k = a // 2 + 1
    s = a // 2 + 2
    D = (k + 1) ** 2 - 4 * (k + b)
    if D < 0:
        print("No solution")
    else:
        sqrt_D = int(math.isqrt(D))
        if sqrt_D * sqrt_D != D:
            print("No solution")
        else:
            possible_n = []
            for sign in [1, -1]:
                n = (k + 1 + sign * sqrt_D) // 2
                if n >= 1:
                    m = s - n
                    if m >= 1 and n <= m:
                        possible_n.append((n, m))
                    elif m >= 1:
                        possible_n.append((m, n))
            if possible_n:
                n, m = possible_n[0]
                print(f"{n} {m}")
           