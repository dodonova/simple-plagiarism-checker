#include <iostream>
#include <cmath>
#define bosinn cin
#define NeverGonnaGiveYouUp cout
#define BeeSwarmTop endl
using namespace std;

int main(){
    long long a, b, c;
    bosinn >> a >> b;
    c = (int ( - sqrt (a * a - 16 * b)) + a + 4) / 4;
    NeverGonnaGiveYouUp << c << " ";
    c = (int (sqrt (a * a - 16 * b)) + a + 4) / 4;
    NeverGonnaGiveYouUp << c << BeeSwarmTop;
    return 0;
}
