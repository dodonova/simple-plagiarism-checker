def find_dimensions(a, b):
    total_sum = a // 2 + 2
    for n in range(total_sum - 1, 0, -1):
        m = total_sum - n
        if (n - 1) * (m - 1) == b:
            return n, m
    return None

a, b = map(int, input().split())
result = find_dimensions(a, b)
if result:
    print(result[0], result[1])