
a, b = map(int, input().split())
n = int((2 * (a + b + 4)) ** 0.5)
while True:
    if (a == (n // 2) * (n - n // 2)) and (b == (n // 2 - 1) * (n - n // 2 - 1)):
        print(n // 2, n)