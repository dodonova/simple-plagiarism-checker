a, b = map(int, input().split())

if a == 0 and b == 0:
    print(1, 1)
else:
    A = 1
    B = -1 * (a/2 + 2)
    C = b + a/2 + 1
    D = (B ** 2 - 4 * A * C) ** 0.5

    n1 = (-1 * B + D) / (2 * A)
    n2 = (-1 * B - D) / (2 * A)

    m1 = b / (n1 - 1) + 1
    m2 = b / (n2 - 1) + 1

    print(int(min(m1, m2)), int(max(n1, n2)))