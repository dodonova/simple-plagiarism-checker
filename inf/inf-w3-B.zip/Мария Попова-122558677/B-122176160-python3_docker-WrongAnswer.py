a, b = map(int, input().split(' '))
d = (2 + a/2) ** 2 - 4 * (1 + a/2 + b)
if d >= 0:
    m1 = ((2 + a/2) + d ** 0.5)/2
    m2 = ((2 + a/2) - d ** 0.5)/2
    n1 = 2 - m1 + a/2
    n2 = 2 - m2 + a/2
if n1 <= m1:
    print(int(n1), int(m1))
else:
    print(int(n2), int(m2))