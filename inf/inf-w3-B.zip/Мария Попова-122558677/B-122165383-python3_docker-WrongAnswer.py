a, b = map(int, input().split(' '))
d = (2 + a/2) ** 2 - 4 * (1 + a/2 + b)
if d >= 0:
    x1 = ((2 + a/2) + d ** 0.5)/2
    x2 = ((2 + a/2) - d ** 0.5)/2
    if x1 <= x2:
        print(x1, x2)
    else:
        print(x2, x1)