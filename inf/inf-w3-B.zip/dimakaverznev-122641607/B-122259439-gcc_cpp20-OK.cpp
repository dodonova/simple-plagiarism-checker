#include <iostream>
#include <cmath>
#include <algorithm>

int main() {
    long long a, b;
    std::cin >> a >> b;

    long long s = a / 2 + 2;
    long long p = b + s - 1;

    long long discriminant = s * s - 4 * p;
    long long sqrt_discriminant = std::sqrt(discriminant);

    if (sqrt_discriminant * sqrt_discriminant != discriminant) {
        return 1;
    }

    long long n1 = (s - sqrt_discriminant) / 2;
    long long n2 = (s + sqrt_discriminant) / 2;

    long long n = std::min(n1, n2);
    long long m = std::max(n1, n2);

    std::cout << n << " " << m << std::endl;

    return 0;
}