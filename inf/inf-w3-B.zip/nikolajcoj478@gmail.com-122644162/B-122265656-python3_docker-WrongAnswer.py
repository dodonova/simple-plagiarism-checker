import math
a, b = map(int, input().split())
n, m = 0, 0
p = math.sqrt(a*a - 16*b)
print(p*p)
n = (a + 4 - p) / 4
m = a/2 + 2 - n
print(n, m)