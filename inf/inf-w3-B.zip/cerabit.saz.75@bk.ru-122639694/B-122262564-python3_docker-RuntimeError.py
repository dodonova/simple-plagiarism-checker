a=input().split()
if a[0]!=0 and a[1]!=0 and a[1]!=1:
    b=[]
    b.append(int((int(a[0])+(int(a[0])**2-16*int(a[1]))**0.5)/4+1))
    if b[0]!=1:
        b.append(int((int(a[1])/(b[0]-1))+1))
    else:
        b.append(int((a/2)+1))
    b.sort()
    print(*b)
elif a[0]!=0 and a[1]==0:
    print(1, a[0]//2)
else:
    print(1, 1)
