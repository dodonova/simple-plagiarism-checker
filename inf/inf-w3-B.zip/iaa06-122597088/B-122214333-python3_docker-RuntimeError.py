SDFSFDA = int(input()) 
SDFAADFS = list(map(int, input().split())) 
ASDFAFSD = [] 
SDFVAASDF = [] 
SDFAADFS.sort() 
FASDFASD = (SDFSFDA - 1) // 2 / 2 
for AFSDFDAS in range(len(SDFAADFS)): 
    if (AFSDFDAS <= (0 + FASDFASD+1) or AFSDFDAS >= len(SDFAADFS)-FASDFASD-1) and AFSDFDAS != 0: 
        ASDFAFSD.append(SDFAADFS[AFSDFDAS]) 
    elif AFSDFDAS != 0: 
        SDFVAASDF.append(SDFAADFS[AFSDFDAS]) 
ASDFFADS = min(ASDFAFSD) 
ASFDASDF = min(SDFVAASDF) 
print(ASFDASDF*ASDFFADS)