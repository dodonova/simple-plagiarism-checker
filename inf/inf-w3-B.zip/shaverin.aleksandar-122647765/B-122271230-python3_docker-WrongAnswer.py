import math

a, b = map(int, input().split())
aa = -1
bb = a / 2 + 2
cc = -a / 2 - 1 - b
dd = bb ** 2 - 4 * aa * cc
m = (bb - math.sqrt(dd)) / 2
n = a / 2 - m + 2
m = int(m)
n = int(n)
print(min(n, m), max(n, m))