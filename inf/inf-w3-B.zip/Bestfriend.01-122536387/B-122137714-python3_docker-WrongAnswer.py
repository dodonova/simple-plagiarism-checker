
def find_rectangle_size(a, b):
    # Вычисляем S и P
    S = (a // 2) + 2
    P = b + S
    
    # Теперь решим квадратное уравнение x^2 - Sx + P = 0
    discriminant = S * S - 4 * P
    
    if discriminant < 0:
        return None  # На всякий случай, хотя в условии задачи говорится, что решение всегда существует
    
    # Находим корни
    sqrt_d = discriminant ** 0.5
    n1 = (S + sqrt_d) / 2
    n2 = (S - sqrt_d) / 2
    
    # Находим возможные n и m
    n = int(n1)
    m = int(n2)
    
    # Убедимся, что n <= m
    if n > m:
        n, m = m, n
    
    return n, m

# Чтение данных
a, b = map(int, input().strip().split())
n, m = find_rectangle_size(a, b)
print(n, m)