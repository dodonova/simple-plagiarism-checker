def find_D(a, b):
   
    for n in range(1, a // 2 + 2):
        m = a // 2 + 2 - n
        if (n-1)>0 and m>0 and b == (n - 1) * (m - 1):
                return n, m
    return 1, 1
a, b = map(int, input().split())
n, m = find_D(a, b)
print(n, m)