def find_population(n, m):
    h = (n // 2) + 2
    d = h ** 2 - 4 * (m + (n // 2) + 1)
    if d < 0:
        return None
    sqrt_d = int(d ** 0.5)
    a1 = (h - sqrt_d) // 2
    a2 = (h + sqrt_d) // 2
    result1 = (min(a1, (h - (h - sqrt_d) // 2)), max(a1, (h - (h - sqrt_d) // 2)))
    result2 = (min(a2, (h - (h + sqrt_d) // 2)), max(a2, (h - (h + sqrt_d) // 2)))
    return result1 if result1[0] <= result1[1] else result2

    n, m = map(int, input().split())
    population = find_population(n, m)
    if population:
        print(population[0], population[1])