a = int(input())
b = int(input())
c = 0
if a ==0 and b ==0:
    print(4)
else:
    for i in range(1,b):
        if b%i==0:
            c = b//i
            if (c + i)*2==a:
                n = i+1
                m = c+1
    print(m,n)
