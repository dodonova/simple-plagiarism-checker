#include <iostream>
#include <utility>

using namespace std;

int main() {
    int x, y;
    cin >> x >> y;
    int z = x / 2 + 2;
    
    for (int i = 1; i < z; i++) {
        int j = z - i;
        int conditionCheck = (i - 1) * (j - 1);
        if (conditionCheck == y) {
            cout << min(i, j) << " " << max(i, j) << endl;
            break;
        }
    }
}