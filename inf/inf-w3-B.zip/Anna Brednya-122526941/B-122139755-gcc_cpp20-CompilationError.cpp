#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>

void main() {

    int firstInputValue, secondInputValue;
    std::cin >> firstInputValue >> secondInputValue;

    int a = firstInputValue;
    int b = secondInputValue;


    double halfA = a / 2.0;
    double discriminant = (-2 - halfA) * (-2 - halfA) - 4 * (halfA + b + 1);

    if (discriminant < 0) {
        std::cout << "Impossible" << std::endl;
        return;
    }
    
 
    int sqrtDiscriminant = static_cast<int>(std::sqrt(discriminant));

    if (sqrtDiscriminant * sqrtDiscriminant != discriminant) {
        std::cout << "Impossible" << std::endl;
        return;
    }


    int possibleM1 = (2 + halfA + sqrtDiscriminant) / 2;
    int possibleM2 = (2 + halfA - sqrtDiscriminant) / 2;
    
    std::vector<std::pair<int, int>> candidates;
    for (int mValue : {possibleM1, possibleM2}) {
        double nValue = halfA + 2 - mValue;
        if (mValue >= 1 && nValue >= 1 && a % 2 == 0) {
            candidates.push_back({std::min(static_cast<int>(nValue), mValue), std::max(static_cast<int>(nValue), mValue)});
        }
    }


    if (!candidates.empty()) {
        std::pair<int, int> result = *std::min_element(candidates.begin(), candidates.end());
        std::cout << result.first << " " << result.second << std::endl;
    } else {
        std::cout << "Impossible" << std::endl;
    }
}

int main() {
    main();
    return 0;
}