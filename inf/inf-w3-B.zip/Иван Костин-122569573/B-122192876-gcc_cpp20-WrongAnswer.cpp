#include <iostream>
#include <cmath>

using namespace std;

int main() {
    float a, b, m, n;
    cin >> a >> b;

    m = (a + 4 + sqrt(pow((a + 4), 2) - 8 * (a + 2 + 2 * b))) / 4;
    n = (a + - 2 * m) / 2;

    cout << n << " " << m;

    return 0;
}