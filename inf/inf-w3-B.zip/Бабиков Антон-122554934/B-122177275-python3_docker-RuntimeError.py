ast, bst = input().split()
a = int(ast)
b = int(bst)


n = 1
m = 1

if b == 0:
	n = 1
	m = (a/2) +1
	print(n, m)

else:
	for n in range(10**9):
		for m in range(10**9):
			if (a+b)==(m + n + mn - 3):
				print(n, m)
			





