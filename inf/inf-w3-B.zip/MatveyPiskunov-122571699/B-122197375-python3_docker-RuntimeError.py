def find_grid_size(a, b):
    for n in range(1, 11):
        for m in range(n, 11): 
            if 2 * (n + m - 2) == a and (n - 1) * (m - 1) == b:
                return n, m
a = input().split()
b = int(a[1])
a = int(a[0])
n, m = find_grid_size(a, b)

print(n, m)

