import math

# Ввод значений a и b
a_str, b_str = input().split()
a = int(a_str)
b = int(b_str)

# Проверяем, является ли a четным
if a % 2 != 0:
    print("Impossible")
else:
    # Вычисляем N
    N = a * a - 16 * b
    # Проверяем условия для N
    if N < 0 or N % 4 != 0:
        print("Impossible")
    else:
        # Вычисляем D и его целый квадратный корень
        D = N // 4
        sqrt_D = int(math.isqrt(D))
        
        # Проверяем, является ли D полным квадратом
        if sqrt_D * sqrt_D != D:
            print("Impossible")
        else:
            # Расчет значение 's'
            s = a // 2 + 2
            found = False
            
            # Перебираем возможные знаки для вычисления n_candidate
            for sign in [1, -1]:
                n_candidate = (s + sign * sqrt_D)
                
                # Проверяем, является ли n_candidate четным
                if n_candidate % 2 != 0:
                    continue
                
                # Вычисляем n и m
                n = n_candidate // 2
                m = s - n
                
                # Проверяем наличие валидных n и m
                if n >= 1 and m >= 1:
                    # Упорядочиваем n и m
                    if n > m:
                        n, m = m, n
                    # Печатаем результаты
                    print(f"{n} {m}")
                    found = True
                    break
            
            # Если не нашли подходящие n и m
            if not found:
                print("Impossible")