ab = list(map(int, input().split(' ')))
a = ab[0]
b = ab[1]

mn = int((a / 2) + 2)
for m in range(int(mn/2), mn+1):
    n = mn - m

    if b == (n - 1) * (m - 1):
        print(n, m)