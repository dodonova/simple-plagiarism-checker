ab = list(map(int, input().split(' ')))
a = ab[0]
b = ab[1]

first = a // 2 + 2
second = b + (a // 2) + 1

D = (first**2 - 4 * second)**(1/2)

print(int(min((first + D)/2, (first - D)/2)), int(max((first + D)/2, (first - D)/2)))