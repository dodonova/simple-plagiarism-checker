a,b= map(int, input().split())
def k(x):
    if a==0 or b==0:
        print(1,1)
        exit
    if 2*(n+m-2)==a and (n-1)*(m-1)==b:
        print(n,m)
        exit()
for n in range(2,int((a/2))+1):
    m=b//(n-1)+1
    if b>a:
        a=b
        b=a
        k(n)
    else:
        k(n)
