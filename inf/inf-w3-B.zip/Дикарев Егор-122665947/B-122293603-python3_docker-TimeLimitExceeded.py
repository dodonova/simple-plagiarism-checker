def f(t, x):
    summ = t + x + 4
    for i in range(2, summ):
        if summ % i == 0:
            n = i-1
            m = summ//i -1
            if t == 2 * (m + n -2):
                return n, m
t, x = map(int, input().split())
print(*f(t, x))