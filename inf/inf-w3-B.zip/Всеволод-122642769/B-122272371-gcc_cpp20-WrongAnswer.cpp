#include <iostream>
#include <cmath>

std::pair<int, int> calculateCoordinates(int a, int b) {
    int x = 0.25 * (-(std::pow(a, 2) - 16 * b) - a + 4);
    int y = 0.25 * (std::sqrt(std::pow(a, 2) - 16 * b) + a + 4);
    return std::make_pair(x, y);
}

int main() {
    int a, b;
    std::cin >> a >> b;
    
    std::pair<int, int> coordinates = calculateCoordinates(a, b);
    std::cout << coordinates.first << " " << coordinates.second << std::endl;

    return 0;
}