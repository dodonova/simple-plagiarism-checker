a, b = map(int, input().split())


n = 0.25 * (a + 4 - ((a  2 - 16 * b)  0.5))
m = 0.25 * (a + 4 + ((a  2 - 16 * b)  0.5))

print(int(n), int(m))