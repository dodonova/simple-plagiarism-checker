import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = Integer.parseInt(scanner.nextLine());
        int b = Integer.parseInt(scanner.nextLine());
        
        System.out.println((int)x(a, b) + " " + (int)y(a, b));
    }
    
    public static double x(int a, int b) {
        return 0.25 * (-(Math.pow(a, 2) - 16 * b) - Math.sqrt(Math.pow(a, 2) - 16 * b) + a + 4);
    }
    
    public static double y(int a, int b) {
        return 0.25 * (Math.pow(a, 2) - 16 * b + Math.sqrt(Math.pow(a, 2) - 16 * b) + a + 4);
    }
}