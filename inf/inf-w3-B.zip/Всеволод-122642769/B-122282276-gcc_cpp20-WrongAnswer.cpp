#include <iostream>
#include <cmath>

int main() {
    std::string input;
    std::getline(std::cin, input);
    int a = std::stoi(input.substr(0, input.find(' ')));
    int b = std::stoi(input.substr(input.find(' ') + 1));
    
    double n = 0.25 * (-(pow(a, 2) - 16 * b) + a + 4);
    double m = 0.25 * (pow(a, 2) - 16 * b + a + 4);
    
    std::cout << static_cast<int>(n) << " " << static_cast<int>(m) << std::endl;
    
    return 0;
}