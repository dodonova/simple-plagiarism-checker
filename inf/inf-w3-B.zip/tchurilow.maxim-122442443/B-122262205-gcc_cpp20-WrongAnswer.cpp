#include <iostream>
#include <cmath>

int main() {
    long long a, b;
    std::cin >> a >> b;
    
    for (long long n = 1; n * n <= b; ++n) {
        if ((b % n == 0) && ((a + 2 - 2 * n) % 2 == 0)) {
            long long m = (a + 4 - 2 * n) / 2;
            if (m >= n && (n - 1) * (m - 1) == b) {
                std::cout << n << " " << m << std::endl;
                break;
            }
        }
    }

    return 0;
}
