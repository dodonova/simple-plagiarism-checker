import java.util.Scanner;

public class PuzzleGrid {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        long a = scanner.nextLong();
        long b = scanner.nextLong();

        // Базовый случай
        if (a == 0 &amp;&amp; b == 0) {
            System.out.println("1 1");
            return;
        }

        // Вычисляем S и P
        long S = a / 2 + 2; // n + m
        long P = b + S;     // nm

        // Вычисляем дискриминант
        long discriminant = S * S - 4 * P;

        // Проверка на существование корней
        if (discriminant &lt; 0) {
            System.out.println("No solution");
            return;
        }

        // Находим n и m
        long sqrtD = (long)Math.sqrt(discriminant);
        
        long n = (S - sqrtD) / 2;
        long m = (S + sqrtD) / 2;

        // Убедимся, что n не превышает m
        if (n &gt; m) {
            long temp = n;
            n = m;
            m = temp;
        }

        System.out.println(n + " " + m);
    }
}