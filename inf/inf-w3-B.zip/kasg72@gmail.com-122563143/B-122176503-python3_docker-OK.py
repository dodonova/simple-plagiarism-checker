import math

str_A, str_B = input().split()
a = int(str_A)
b = int(str_B)

if a % 2 == 0:
    N = a * a - 16 * b
    if N >= 0 and N % 4 == 0:
        D = N // 4
        sqrt_D = int(math.isqrt(D))
        if sqrt_D * sqrt_D == D:
            s = a // 2 + 2
            for sign in [1, -1]:
                nn = (s + sign * sqrt_D)
                if nn % 2 == 0:
                    n = nn // 2
                    m = s - n
                    if n >= 1 and m >= 1:
                        if n > m:
                            n, m = m, n
                        print(f"{n} {m}")
                        break