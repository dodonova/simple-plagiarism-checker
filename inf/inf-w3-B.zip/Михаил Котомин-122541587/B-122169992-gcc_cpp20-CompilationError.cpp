#include <iostream>
using namespace std;

pair<int, int> find_dimensions(int a, int b) {
    int n_plus_m = (a / 2) + 2;

    for (int n = 1; n < n_plus_m; ++n) {
        int m = n_plus_m - n;
        if ((n - 1) * (m - 1) == b) {
            return make_pair(min(n, m), max(n, m));
        }
    }
    return make_pair(-1, -1); // Возвращаем -1, -1 если решение не найдено
}

int main() {
    int a, b;
    cin >> a >> b;

    pair<int, int> dimensions = find_dimensions(a, b);

    cout << dimensions.first << " << dimensions.second << endl;
    return 0;
}