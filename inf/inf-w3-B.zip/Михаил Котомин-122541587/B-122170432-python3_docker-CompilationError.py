<span class="hljs-keyword">def</span> <span class="hljs-title function_">find_dimensions</span>(<span class="hljs-params">a, b</span>):
    <span class="hljs-comment"># Ищем n + m</span>
    n_plus_m = (a // <span class="hljs-number">2</span>) + <span class="hljs-number">2</span>

    <span class="hljs-comment"># Проходим по диапазону для поиска n и m</span>
    <span class="hljs-keyword">for</span> n <span class="hljs-keyword">in</span> <span class="hljs-built_in">range</span>(<span class="hljs-number">1</span>, n_plus_m):  <span class="hljs-comment"># Изменение: n должно быть меньше n_plus_m</span>
        m = n_plus_m - n
        <span class="hljs-keyword">if</span> (n - <span class="hljs-number">1</span>) * (m - <span class="hljs-number">1</span>) == b:
            <span class="hljs-keyword">return</span> <span class="hljs-built_in">min</span>(n, m), <span class="hljs-built_in">max</span>(n, m)

<span class="hljs-comment"># Чтение входных данных</span>
a, b = <span class="hljs-built_in">map</span>(<span class="hljs-built_in">int</span>, <span class="hljs-built_in">input</span>().strip().split())

<span class="hljs-comment"># Поиск размеров</span>
n, m = find_dimensions(a, b)

<span class="hljs-comment"># Вывод результата</span>
<span class="hljs-built_in">print</span>(n, m)