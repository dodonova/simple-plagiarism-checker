

void solve(int a, int b) {
    int s = a / 2 + 2; // n + m = T / 2 + 2

    for (int n = 1; n < s; ++n) { // Перебираем n
        int m = s - n; // Вычисляем m
        if ((n - 1) * (m - 1) == b) { // Проверяем количество крестиков
            std::cout << n << " " << m << std::endl;
            return;
        }
    }
}

int main() {
    int a, b;
    std::cin >> a >> b; // Чтение ввода
    solve(a, b);
    return 0;
}
