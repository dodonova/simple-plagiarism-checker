

import java.io.*;
import java.util.*;


public class Main {

    public static void main(String[] args) throws IOException {
        long t = nextLong();
        long k = nextLong();

        long ht = t/2;

        long n = 0;
        long m = 0;
        for (long i = 1; i <= ht/2; i++) {
            if (i * (ht-i) == k) {
                n = i;
                m = ht-i;
                break;
            }
        }

        n++;
        m++;

        out.println(n + " " + m);

        out.close();
    }

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter out = new PrintWriter(System.out);
    static StringTokenizer in = new StringTokenizer("");


    public static boolean hasNext() throws IOException {
        if (in.hasMoreTokens()) return true;
        String s;
        while ((s = br.readLine()) != null) {
            in = new StringTokenizer(s);
            if (in.hasMoreTokens()) return true;
        }
        return false;
    }

    public static String nextToken() throws IOException {
        while (!in.hasMoreTokens()) {
            in = new StringTokenizer(br.readLine());
        }
        return in.nextToken();
    }

    public static int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    public static double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    public static long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }
}