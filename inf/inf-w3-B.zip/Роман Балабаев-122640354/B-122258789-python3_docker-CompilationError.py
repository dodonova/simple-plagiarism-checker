def find_dimensions(a, b):
    # Вычисляем n + m
    total = a // 2 + 2 # Решаем уравнение (n - 1)(m - 1) = b
    # Подставляем m = total - n # Получаем уравнение n * (total - n - 1) = b # Это приводит к квадратному уравнению # n^2 - (total - 1)n + b = 0 discriminant = (total - 1) ** 2 - 4 * b
    if discriminant < 0:
        return None  # Не должно происходить, так как a и b всегда корректны

    # Находим корни sqrt_d = int(discriminant ** 0.5)
    n1 = (total - 1 + sqrt_d) // 2
    n2 = (total - 1 - sqrt_d) // 2 # Проверяем, что n1 и n2 являются целыми и соответствуют условиям for n in (n1, n2):
        if n >= 1 and n < total:
            m = total - n if n <= m:
                return n, m

# Чтение входных данных
a, b = map(int, input().strip().split())

# Поиск размеров
n, m = find_dimensions(a, b)

# Вывод результатов
print(n, m)