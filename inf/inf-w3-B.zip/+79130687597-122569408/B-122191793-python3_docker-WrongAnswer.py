a,b=map(int,input().split())
if a==0 and b==0:print(1,1)
else:
    m=(-4-a-(a**2-16*b)**0.5)//4
    if m<0:m=-m
    n=(b+m-1)//(m-1)
    print(int(n),int(m))