def razmer(charly, topor):
    glazik = charly // 2 + 2
    for a in range(1, glazik):
        b = glazik - a
        if (a - 1) * (b - 1) == topor:
            bobik = sorted((a, b))
            return bobik[0], bobik[1]

charly, topor = map(int, input().split())
resultat = razmer(charly, topor)
print(resultat[0], resultat[1])