a,b=map(int, input().split())
d = (a+4)**2 - 8*(a+2*b+2)
n = (a+4-d**0.5)/4
m = (a+4+d**0.5)/4
print(int(n),int(m))
