a, b = map(int, input().split())

def grid(a, b):
    for n in range(1, int(a//2)+2):
        if a % 2 != 0:
            continue
        m = a / 2 + 2 - n
        if n <= m and (n - 1) * (m - 1) == b:
            return n, int(m)
    return 0, 0

n, m = grid(a, b)
print(n, m)