def find_dimensions(a, b):
    if a == 0 and b == 0:
        return 1, 1
    n_plus_m = (a // 2) + 2
    for n in range(1, n_plus_m): 
        m = n_plus_m - n  

        if (n - 1) * (m - 1) == b:
            return n, m
    return None
a, b = map(int, input().split())
result = find_dimensions(a, b)
if result:
    print(result[0], result[1])
