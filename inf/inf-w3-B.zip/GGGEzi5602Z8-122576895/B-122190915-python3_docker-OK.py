def solve_quadratic_equation(a, b, c):
    discriminant = b ** 2 - 4 * a * c
    if discriminant > 0:
        x1 = (-b + discriminant ** .5) / (2 * a)
        x2 = (-b - discriminant ** .5) / (2 * a)
        return max(x1, x2)
    elif discriminant == 0:
        x = -b / (2 * a)
        return x
    else:
        return False


t, x = [int(i) for i in input().split()]
if t == 0 and x == 0:
    print(1, 1)
else:
    m = int(solve_quadratic_equation(2, -(4 + t), t + 2 * x + 2))
    n = int((t + 4 - 2 * m) // 2)
    print(min(n, m), max(n, m))
