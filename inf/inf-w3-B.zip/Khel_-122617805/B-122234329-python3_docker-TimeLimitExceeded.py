def find_dimensions(a, b):
    # Вычисляем n + m
    total = a // 2 + 2
    
    # Результаты
    n, m = None, None
    
    # Перебираем возможные значения n, где n <= m
    for n_candidate in range(1, total // 2 + 1):
        m_candidate = total - n_candidate
        if n_candidate <= m_candidate:
            # Проверяем условие для крестиков
            if (n_candidate - 1) * (m_candidate - 1) == b:
                n, m = n_candidate, m_candidate
                break
                
    return n, m

# Считываем входные данные
a, b = map(int, input().split())

# Находим размеры n и m
n, m = find_dimensions(a, b)

# Выводим результат
print(n, m)