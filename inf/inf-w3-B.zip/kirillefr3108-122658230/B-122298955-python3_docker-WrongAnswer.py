import math

a, b = map(int, input().split())

c = b + ((a + 4) / 2) - 1
minus_b = ((a + 4) / 2)

d = ((a + 4) / 2)**2 - 4 * c

x1 = (minus_b - math.sqrt(d)) / 2
x2 = (minus_b + math.sqrt(d)) / 2

print(int(x1), int(x2))