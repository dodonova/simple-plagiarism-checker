// #pragma GCC optimize("Ofast")
// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
// #pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;

#define rs resize
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define pb push_back
#define ff first
#define ss second
#define nl nullptr
#define sz(x) (int) x.size()
#define int long long

typedef int64_t ll;

typedef long double ld;

typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

const int inf = INT_MAX;
const int MaxN = 100000;
const long long INF = LLONG_MAX;
const int mod = 998244353;
const int T = 1048576;

template<typename T, typename T1>
istream &operator>>(istream &in, pair<T, T1> &pr) {
    in >> pr.first >> pr.second;
    return in;
}

template<typename T, typename T1>
ostream &operator<<(ostream &out, pair<T, T1> &pr) {
    cout << pr.first << ' ' << pr.second;
    return out;
}

template <typename T>
ostream& operator << (ostream& out, vector<T>& arr)
{
    for (auto& i : arr) {out << i << ' ';}
    return out;
}

template <typename T>
istream& operator >> (istream& in, vector<T>& arr)
{
    for (auto& i : arr) {in >> i;}
    return in;
}

const int maxn = 1e5;
void solve() {
    int a, b; cin >> a >> b;

    if (b == 0) {
        int n = 1;
        if (a % 2 == 0) {
            int m = a / 2 + 2 - n;
            if (m != 0) {
                cout << n << " " << m << "\n";
                return;
            }
        }
    }

    swap(a, b);
    for (int i = 1; i <= maxn; i++) {
        if (a % i == 0) {
            int j = a / i;

            int n = i + 1, m = j + 1;
            if (2 * (n + m - 2) == b) {
                cout << min(n, m) << " " << max(n, m);
                return;
            }
        }
    }

}

int32_t main() {
#ifndef LOCAL
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
#endif
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    double start_time = clock();
#endif
    int tests = 1;
    //cin >> tests;
    while (tests--) {
        solve();
#ifdef LOCAL
        cout << "------------------------\n";
#endif
    }
#ifdef LOCAL
    cout << "execution time: " << (clock() - start_time) / CLOCKS_PER_SEC;
#endif

    return 0;
}