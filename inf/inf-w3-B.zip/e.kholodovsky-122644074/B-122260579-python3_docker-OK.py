import math

x, y = map(int, input().split())
expr = x ** 2 - 16 * y
half_expr = expr // 4
root = int(math.isqrt(half_expr))
midpoint = x // 2 + 2

for modifier in (1, -1):
    candidate = midpoint + modifier * root
    if candidate % 2 == 0:
        n_value = candidate // 2
        m_value = midpoint - n_value
        if n_value > 0 and m_value > 0:
            if n_value > m_value:
                n_value, m_value = m_value, n_value
            print(n_value, m_value)
            break