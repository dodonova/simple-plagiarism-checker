import math
a, b = map(int, input(). split())

W = a // 2 + 2
p = b + a // 2 + 1
Q= W * W - 4 * p

if Q < 0:
	raise ValueError("Нет")

sqrt_D = int(math. isgrt (Q))

n1 = (W + sqrt_Q) // 2
m1 = (W - sqrt_Q) // 2

n, m = sorted((n1, m1))

print (n, m)