import math

# Ввод данных
a, b = map(int, input().split())

# Вычисление n, m
for n in range(1, int(math.sqrt(a / 2 + 2)) +2):
    m = (a / 2 + 2) - n
    if (n - 1) * (m - 1) == b:
        print(f"{int(n)} {int(m)}")
        break