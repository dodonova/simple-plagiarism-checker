a, b = map(int, input().split())
xy, xz = 1, 1
for x in range(1, a):
    for y in range(1, a):
        if 2*(x+y-2) == a and (x-1)*(y-1) == b:
            xy = x
            xz = y
            break
    if 2 * (xy + xz - 2) == a and (xy - 1) * (xz - 1) == b:
        break

xy, xz = sorted((xy, xz))
print(xy, xz)
