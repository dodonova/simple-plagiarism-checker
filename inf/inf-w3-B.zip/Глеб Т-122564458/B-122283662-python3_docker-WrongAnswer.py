a, b = map(int, input().split())
xy, xz = 1, 1
c = a/2+b+1
abc = 0
asdf = c
ab = True if a != 0 and b != 0 else False
while ab:
    if abc*asdf <= c:
        abc += 1
    elif abc*asdf > c:
        if (abc*asdf - c) % abc == 0 and 2*(abc+(asdf - ((abc*asdf - c) / abc))-2) == a and (abc-1)*((asdf - ((abc*asdf - c) / abc))-1) == b:
            ab = False
            xy = abc
            xz = int(asdf - ((abc*asdf - c) / abc))
        else:
            abc += 1

xy, xz = sorted((xy, xz))
print(xy, xz)