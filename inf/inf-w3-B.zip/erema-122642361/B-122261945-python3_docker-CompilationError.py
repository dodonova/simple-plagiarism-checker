#include <iostream>
#include <algorithm>

std::pair<long long, long long> find_size(long long a, long long b) {
    long long figure = (a / 2) + 2;
    
    for (long long m = 1; m <= figure / 2; ++m) {
        long long n = figure - m;
        if ((n - 1) * (m - 1) == b) {
            return {n, m};
        }
    }
    
    return {0, 0}; 
}

int main() {
    long long a, b;
    std::cin >> a >> b;
    
    auto [n, m] = find_size(a, b);
    if (n > m) {
        std::swap(n, m);
    }
    
    std::cout << n << ' ' << m << '\n';
    
    return 0;
}