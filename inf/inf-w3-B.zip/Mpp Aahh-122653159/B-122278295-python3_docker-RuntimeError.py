from math import sqrt
a=int(input())
b=int(input())
n=sqrt(b+1)
m = a / 2 - n + 2
print(n,m)