import math
def find_dimensions(a, b):
	s = (a // 2) + 2
	p = b+(a//2)+1
	D= s**2 -4 * p
	if D<0:
		return None
	sqrt_D = int(math.isqrt(D))
	n = (s - sqrt_D) //2
	m = (s + sqrt_D) //2
	return (n, m) if n<=m else (n, m)
a, b map(int, input().split())
dim = find_dim(a, b)
if dim:
	print(dim[0], dim[1])
	

