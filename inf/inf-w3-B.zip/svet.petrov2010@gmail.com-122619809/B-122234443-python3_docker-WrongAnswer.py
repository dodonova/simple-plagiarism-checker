def find_grid_dimensions(a, b):
    for n in range(1, int((b + 1)**0.5) + 2):
        if (b + 1) % n == 0:
            m = (b + 1) // n
            if 2 * (n + m - 2) == a:
                return n, m
    return None

a, b = 14, 6
print(find_grid_dimensions(a, b))
