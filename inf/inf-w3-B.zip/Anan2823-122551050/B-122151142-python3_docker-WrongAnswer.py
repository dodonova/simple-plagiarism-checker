def find_dimensions(a, b):
    # Вычисляем сумму n + m
    sum_nm = (a // 2) + 2
    # Вычисляем произведение n * m
    product_nm = b + (a // 2) + 2
    
    # Перебираем возможные значения n
    for n in range(1, sum_nm):
        m = sum_nm - n
        if n * m == product_nm:
            return (n, m)
    
    return None

# Чтение входных данных
a, b = map(int, input().split())
# Получение размеров и вывод результата
n, m = find_dimensions(a, b)
print(n, m)