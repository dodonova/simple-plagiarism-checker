def find_dimensions(a, b):
    # Вычисляем n и m
    total = (a // 2) + 2  # n + m
    for n in range(1, total):  # n должно быть меньше total
        m = total - n if (n - 1) * (m - 1) == b:
            return n, m return None

# Чтение входных данных
a, b = map(int, input().split())

# Получение размеров решетки
n, m = find_dimensions(a, b)

# Вывод результата
print(n, m)
