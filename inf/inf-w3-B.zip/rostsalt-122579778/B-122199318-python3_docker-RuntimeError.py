def sized(a, b):
    for n in range(1, 10 ** 3 + 1):
        for m in range(1, 10 ** 3 + 1):
            if 2 * (n + m - 2) == a and (n - 1) * (m - 1) == b:
                return n, m
    return None


a, b = map(int, input().split())

r1, r2 = sized(a, b)

if r1 > 0 and r2 > 0:
    print(r1, r2)