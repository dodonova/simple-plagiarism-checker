ab = input().split(" ")
f = 0
b = 0
cou = 3
if int(ab[0]) == 0:
    print(1, 1)
    f = 1
if int(ab[0]) != 0 and int(ab[1]) == 0:
    b = int(ab[0])
    b = b // 2
    b += 2
    print(b)
    f = 1
a = int(ab[0])/2
print(a)
b = int(ab[1])
print(b)
for i in range(1, b):
    if f==1:
        break
    print("i =", i)
    print("b/i =", b/i, "b//i =", b//i)
    if b/i == float(b//i):
        print("b/i + i =", b/i + i)
        if b/i + i == a:
            mn = min(int(b/i), i)
            mx = max(int(b/i), i)
            print(mn+1, mx+1)
            f = 1
            break
    if f==1:
        break