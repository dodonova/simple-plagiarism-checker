a, b = map(int, input().split())
d = (a / 2 + 2) ** 2 - 4 * (b + a / 2 + 1)
m = int(((a / 2 + 2) + d ** 0.5) / 2)
print(int(a / 2 + 2 - m), m)