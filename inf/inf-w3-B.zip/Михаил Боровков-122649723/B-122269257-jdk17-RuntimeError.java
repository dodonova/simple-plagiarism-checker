import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        long a = scanner.nextInt();
        long b = scanner.nextInt();

        a /= 2;

        for (long i = 0; i < 1_000_000_000L; i++) {
            if ((i - 1) * (a - i + 1) == b) {
                long n = (long) i;
                long m = a - i + 2;
                if (m < n) {
                    n = m;
                    m = n;
                }
                System.out.println(n + " " + m);
                break;
            }
        }
    }
}