import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        a /= 2;

        for (int i = 0; i < 1_000_000_000L; i++) {
            if ((i - 1) * (a - i + 1) == b) {
                int n = (long) i;
                int m = a - i + 2;
                if (m < n) {
                    n = m;
                    m = n;
                }
                System.out.println(n + " " + m);
                break;
            }
        }
    }
}