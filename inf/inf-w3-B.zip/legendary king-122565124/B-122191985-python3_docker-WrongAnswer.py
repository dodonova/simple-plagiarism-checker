import math

a,b = map(int,input().split())

def find_m_and_n(a, b):
    k = (a + 4) / 2
    n1 = (k + math.sqrt(k**2 - 4*(k - 1 + b))) / 2
    n2 = (k - math.sqrt(k**2 - 4*(k - 1 + b))) / 2
    
    solutions = []
    for n in [n1, n2]:
        if n.is_integer() and n > 0:
            m = k - n
            if m.is_integer() and m > 0:
                solutions.append((int(m), int(n)))
    
    return [int(min(n1,n2)), int(k -min(n1,n2))]

print(*find_m_and_n(a, b))
