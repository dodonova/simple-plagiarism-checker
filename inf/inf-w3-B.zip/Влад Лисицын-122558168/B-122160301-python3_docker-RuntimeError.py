def find_grid_dimensions(a, b):
    # Проходим по возможным значениям n
    for n in range(1, a // 2 + 2):
        # Вычисляем m из первого уравнения
        m = (a // 2 + 2) - n
        # Проверяем условие второго уравнения
        if (n - 1) * (m - 1) == b:
            return (n, m) if n <= m else (m, n)
    return None  # Если вдруг решение не найдено

# Пример теста
a, b = map(int, input().split)
find_grid_dimensions(a, b)
