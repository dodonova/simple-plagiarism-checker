def find_grid_dimensions(a, b):
    # Вычисляем сумму n + m
    half_a = a // 2
    n_plus_m = half_a + 2

    # Проходим по возможным значениям n
    for n in range(1, int(n_plus_m // 2) + 1):
        m = n_plus_m - n
        # Проверяем условие второго уравнения
        if (n - 1) * (m - 1) == b:
            return (n, m) if n <= m else (m, n)
    return None

# Чтение входных данных
a, b = map(int, input().split())

# Поиск размеров решетки
result = find_grid_dimensions(a, b)

# Вывод результата
if result:
    print(result[0], result[1])
