z, v = map(int, input().split())
o = 0
u = 0
for o in range(1, int((z / 2) + 2)):
  flag = True
  for u in range(1, int((z / 2) + 2)):
    if 2 * (o + u - 2) == o and (o - 1) * (u - 1) == v:
      print(o, u)
      flag = true
    if flag:
      break



