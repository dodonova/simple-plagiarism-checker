def reconstruct_grid(a, b):

  # Из количества крестиков находим (n-1) и (m-1)
  for i in range(1, int(b**0.5) + 1):
    if b % i == 0:
      n_minus_1 = i
      m_minus_1 = b // i
      n = n_minus_1 + 1
      m = m_minus_1 + 1

      # Проверяем, подходит ли количество т-образных фигур
      if 2 * (n + m - 2) == a:
        return (n, m) if n <= m else (m, n)

  return None

# Считываем входные данные
a, b = map(int, input().split())

# Восстанавливаем размеры решетки
dimensions = reconstruct_grid(a, b)

if dimensions:
  n, m = dimensions
  print(n, m)
else:
  print(1, 1)