def find_dimensions(a, b):
    # Общее количество клеток
    S = 4 * (b + 1) + 3 * a
    
    # Перебор делителей
    for n in range(1, int(S**0.5) + 1):
        if S % n == 0:
            m = S // n
            if n <= m:
                return n, m

# Чтение входных данных
a, b = map(int, input().split())
n, m = find_dimensions(a, b)
print(n, m)
else:
  print(1, 1)