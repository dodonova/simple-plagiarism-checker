#include <iostream>
#include <cmath>

using namespace std;

pair<int, int> reconstruct_grid(int a, int b) {
  // Из количества крестиков находим (n-1) и (m-1)
  for (int i = 1; i <= sqrt(b); ++i) {
    if (b % i == 0) {
      int n_minus_1 = i;
      int m_minus_1 = b / i;
      int n = n_minus_1 + 1;
      int m = m_minus_1 + 1;

      // Проверяем, подходит ли количество т-образных фигур
      if (2 * (n + m - 2) == a) {
        return make_pair(n, m);
      }
    }
  }

  return make_pair(0, 0); // Возвращаем (0, 0) в случае неудачи
}

int main() {
  int a, b;
  cin >> a >> b;

  pair<int, int> dimensions = reconstruct_grid(a, b);

  if (dimensions.first != 0) {
    cout << dimensions.first << " " << dimensions.second << endl;
  } else {
    cout << 1 << " " << 1 << endl;
  }

  return 0;
}