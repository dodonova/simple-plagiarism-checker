def find_dimensions(a, b):
    for n in range(1, 10**9 + 1):
        m = (a // 2) + 2 - n
        if m < n:  # Убедимся, что n <= m
            break
        if (n - 1) * (m - 1) == b:
            return n, m
    return None

# Чтение входных данных
a, b = map(int, input().split())
n, m = find_dimensions(a, b)
if n is not None and m is not None:
    print(n, m)