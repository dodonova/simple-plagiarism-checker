def find_rectangle(a, b):
    total = a // 2 + 2
    
    # Проверяем n до корня из b, чтобы избежать лишних проверок
    for n in range(1, int(b ** 0.5) + 2):
        if (n - 1) != 0 and b % (n - 1) == 0:  # Проверяем делимость
            m = (b // (n - 1)) + 1
            if n + m == total:
                return n, m
            
    return None

a, b = map(int, input().split())
result = find_rectangle(a, b)

if result:
    print(result[0], result[1])
else:
    print("No solution")
