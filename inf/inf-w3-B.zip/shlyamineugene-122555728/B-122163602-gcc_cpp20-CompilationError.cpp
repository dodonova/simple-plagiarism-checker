def find_rectangle(a, b):
    # Выразим n + m из первого уравнения
    total = a // 2 + 2
    
    # Теперь будем перебирать возможные значения n
    for n in range(1, total):
        m = total - n
        if n <= m and (n - 1) * (m - 1) == b:
            return n, m
            
    return None

# Пример ввода
a, b = map(int, input().split())
result = find_rectangle(a, b)

print(result[0], result[1])
