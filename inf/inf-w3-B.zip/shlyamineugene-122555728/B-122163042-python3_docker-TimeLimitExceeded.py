def find_rectangle(a, b):
    total = a // 2 + 2
    
    for n in range(1, total):
        m = total - n
        if n <= m and (n - 1) * (m - 1) == b:
            return n, m
            
    return None

a, b = map(int, input().split())
result = find_rectangle(a, b)

if result:
    print(result[0], result[1])
else:
    print("Нет решения")
