#include <iostream>

std::pair<int, int> find_rectangle(int a, int b) {
    int total = a / 2 + 2;

    for (int n = 1; n < total; ++n) {
        int m = total - n;
        if (n <= m && (n - 1) * (m - 1) == b) {
            return {n, m};
        }
    }
    
    return {-1, -1}; // Если решения нет
}

int main() {
    int a, b;
    std::cin >> a >> b;

    auto [n, m] = find_rectangle(a, b);
    
    if (n != -1) {
        std::cout << n << " " << m << std::endl;
    } else {
        std::cout << "Нет решения" << std::endl;
    }

    return 0;
}
