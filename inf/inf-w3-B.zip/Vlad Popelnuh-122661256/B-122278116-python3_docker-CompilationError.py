from sys import *
t_fig, x_cross = map(int, input().split())
if t_fig<=1 and x_cross==0:  
           print(1,1)
else:
 for it in range(1,t_fig+1):   
                   if (it-1)*(t_fig/2-it+1)==x_cross:
                if (t_fig/2-it+2)>it:                print(it,int(t_fig/2-it+2))
     else:       print(int(t_fig/2-it+2),it)
     exit()