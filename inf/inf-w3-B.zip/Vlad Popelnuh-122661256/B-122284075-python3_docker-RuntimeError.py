import sys

def main():
    t = int(input())
    x = int(input())

    if t <= 1 and x == 0:
        print("1 1")
    else:
        for m in range(1, 1_000_000_000):
            if (t // 2 - m + 1) * (m - 1) == x:
                if t // 2 - m + 2 > m:
                    print(m, t // 2 - m + 2)
                else:
                    print(t // 2 - m + 2, m)
                return  # Exit the program

if __name__ == "__main__":
    main()


