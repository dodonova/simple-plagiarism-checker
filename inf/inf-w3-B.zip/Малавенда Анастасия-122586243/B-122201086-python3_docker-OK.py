import math
a, b = map(int, input().split())
S = a // 2 + 2
D = S*S - 4*(b + S - 1)

sqrt_D = math.sqrt(D)

m1 = (S + sqrt_D) / 2
m2 = (S - sqrt_D) / 2

m = int(m1)

n = S - m
if n > m:
    n, m = m, n
print(n, m)