a, b = map(int, input().split())
d=(a**2/4-4*b)**0.5
M=(a/2+d)/2+1
N=(a/2-d)/2+1
print(int(N), int(M))