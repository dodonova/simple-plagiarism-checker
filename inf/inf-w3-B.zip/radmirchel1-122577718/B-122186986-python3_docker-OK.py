from math import sqrt
a, b = map(int, input().split())
n = int((a+4-sqrt(a**2-16*b))/4)
m = int(a/2+2-n)
print(n,m)
