#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;

ll pow_mod(ll x, ll st, ll m) {
    if (st == 0) return 1 % m;
    else if (st % 2 == 0)  return pow_mod(x * x % m, st / 2, m);
    else return x * pow_mod(x, st - 1, m) % m;
}

signed main() {
    ll a, b;
    cin >> a >> b;
    ll c_b = -(2 + a / 2), c_c = b + a / 2 + 1;
    ll d = c_b * c_b - 4 * c_c;
    cout << (-c_b - (ll)floor(sqrt(d))) / 2<<' ' << (-c_b +(ll)floor(sqrt(d))) / 2;
}
