a, b = map(int,input().split())
Dis = (a**2 - 16*b)/4
MN1 = (2 + a/2 + Dis**0.5)/2
MN2 = (2 + a/2 - Dis**0.5)/2
print(round(min(MN1,MN2)), round(max(MN1,MN2)))