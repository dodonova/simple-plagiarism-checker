def find_dimensions(a, b):
    # Вычисляем n + m
    n_plus_m = a // 2 + 2
    
    # Перебираем возможные значения n
    for n in range(1, n_plus_m):
        m = n_plus_m - n
        if n <= m:  # Условие n ≤ m
            if (n - 1) * (m - 1) == b:
                return n, m

# Чтение входных данных
a, b = map(int, input().strip().split())

# Получение и вывод результата
n, m = find_dimensions(a, b)
print(n, m)
