#include <iostream>
#include <vector>
#include <cmath>

#define ll long long

using namespace std;


vector<vector<ll>> findFactors(ll n) {
    vector<vector<ll>> factors;
    for (ll i = 1; i <= sqrt(n); ++i) {
        if (n % i == 0) {
            ll j = n / i;
            factors.push_back({i, j});
        }
    }

    return factors;
}

int main() {
    ll a, b;
    cin >> a >> b;

    if (a == 0 && b == 0) {
        cout << 1 << " " << 1 << endl;
        return 0;
    }

    vector<vector<ll>> v = findFactors(b);


    for (int i=0; i < v.size(); i++) {
        if (2*(v[i][0]-1+v[i][1]-1+2) == a) {
            cout << v[i][0]+1 << " " << v[i][1] + 1 << endl;
            return 0;
        }
    }


    
}