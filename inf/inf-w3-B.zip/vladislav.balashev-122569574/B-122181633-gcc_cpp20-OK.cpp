#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;


long double sqr(long double a){
    return a * a;
}


int main(){
    long double a, b;
    cin >> a >> b;
    long double d = sqr((0.5 * a + 2)) - 4 * (0.5 * a + b + 1);
    cout << fixed << setprecision(0) << (0.5 * a + 2 - sqrtl(d)) / 2 << " " << (0.5 * a + 2 + sqrtl(d)) / 2 << "\n";
}
