import math

def find_grid_size(a, b):
    discriminant = a ** 2 + 4 * a * b - 16
    if discriminant >= 0:
        root = (-a + math.sqrt(discriminant)) / (2 * b)
        return int(root), int((a + root * b) / root)
    else:
        return None

a, b = map(int, input().split())
n, m = find_grid_size(a, b)
print(n, m)