a, b = map(int, input().split())
for n in range(1, a + 2):
    m = int(a/2 + 2 - n)
    if n <= m and (2 * (n + m - 2) == a) and ((n - 1) * (m - 1) == b):
        print(n, m)
        break