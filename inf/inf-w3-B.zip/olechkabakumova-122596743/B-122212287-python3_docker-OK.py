import math

# Чтение входных данных
a, b = map(int, input().split())

# Вычисление S и P
S = a // 2 + 2
P = b + a // 2 + 1

# Проверка на дискриминант
D = S * S - 4 * P

if D < 0:
    raise ValueError("Нет решения")

# Находим корни уравнения
sqrt_D = int(math.isqrt(D))

n1 = (S + sqrt_D) // 2
m1 = (S - sqrt_D) // 2

# Убедимся, что n <= m
n, m = sorted((n1, m1))

print(n, m)
