VerA, VerB = map(int,input().split())
Dis = (VerA**2 - 16*VerB)/4
VerMN1 = (2 + VerA/2 + Dis**0.5)/2
VerMN2 = (2 + VerA/2 - Dis**0.5)/2
print(max(VerMN1,VerMN2), min(VerMN1,VerMN2))