a, b = map(int, input().split())

for i in range(1, a // 2 + 1):
    j = a // 2 - i
    if j > 0 and i * j == b:
        c = i + 1
        d = j + 1
        print(min(c, d), max(c, d))
        break
