def get_rectangle_dimensions(a, b):   
    corners = 4
    total_cells = a + b + corners 
    n, m = 1, total_cells  

    for i in range(1, total_cells + 1):
        if total_cells % i == 0:
            j = total_cells // i
            if (i - 1) * (j - 1) == b and (i + j) == (a + 2):
                n, m = i, j
                break

    return n, m

a, b = map(int, input().strip().split())
n, m = get_rectangle_dimensions(a, b)
print(n, m)