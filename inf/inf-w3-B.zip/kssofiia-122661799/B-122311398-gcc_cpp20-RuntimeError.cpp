#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

int main()
{
    int a, b;
    cin >> a >> b;
    vector <int> pm(b, 0);
    
    //cout << "a: " << a << endl;
    
    if (a == 0 and b == 0){
        cout << 1 << " " << 1;
    }
    else{
        a = a / 2;
        pm[0] = 1;
        int j = 1;
        for (int i = 2; i < b / 2; i++){
            if (b % i == 0){
                pm[j] = i;
                //cout << "pm[j]: " << pm[j] << endl;
                j++;
            }
        }
        
        int x1, x2;
        for (int i = 0; i < b / 2; i++){
            x1 = b / pm[i];
            x2 = a - pm[i];
            //cout << "x1, x2: " << x1 << " " << x2 << endl;
            if (x1 == x2){
                x2 = a - x1 + 1;
                x1 += 1;
                break;
            }
        }
        
        cout << min(x1, x2) << " " << max(x1, x2);
    }
    
    
    
    return 0;
}