#a -> T, b -> +
a, b = map(int, input().split())
t = a // 2
def d(n, t):
    if n == 0:
        return 1, 1
    if n == 1:
        return 2, 2
    for i in range(1, int(n ** 0.5) + 1):
        if n % i == 0:
            if (i + (n // i)) == t:
                return i + 1, (n // i) + 1
print(*d(b, t))
            