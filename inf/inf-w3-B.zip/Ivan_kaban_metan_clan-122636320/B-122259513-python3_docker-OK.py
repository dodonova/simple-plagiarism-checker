a, b = [int(x) for x in input().split()]
s = (a // 2) + 2
d = s * s - 4 * (b + s - 1)
s_d = int(d ** 0.5)
i = (s + s_d) // 2
j = (s - s_d) // 2
if (i - 1) * (s - i - 1) == b:
    n = i
elif (j - 1) * (s - j - 1) == b:
    n = j
m = s - n
print(min(n, m), max(n, m))

