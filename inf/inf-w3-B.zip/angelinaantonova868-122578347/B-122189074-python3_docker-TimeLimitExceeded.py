def find_dimensions(a, b):
    for n in range(1, 10**9 + 1):
        m = (a // 2) + 2 - n
        if m < n:
            break
        if (n - 1) * (m - 1) == b:
            return n, m
    return None
a, b = map(int, input().split())
n, m = find_dimensions(a, b)
print(n, m)
