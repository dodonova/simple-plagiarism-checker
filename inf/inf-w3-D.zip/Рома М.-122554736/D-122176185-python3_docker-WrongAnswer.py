def max_braid_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()

    # Если n четное
    half_n = n // 2

    # Максимальная площадь = минимальная длина в группе 1 * минимальная длина в группе 2
    # Для наибольшей площади берем:
    length_horizontal = lengths[half_n - 1]  # Последний элемент первой половины
    length_vertical = lengths[n - 1]  # Последний элемент второй половины

    # Вычисляем площадь
    max_area = length_horizontal * length_vertical

    return max_area


# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_braid_area(n, lengths) / 2)
