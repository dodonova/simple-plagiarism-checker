def max_plait_area(n, lengths):
    # Сортируем длины по убыванию
    lengths.sort(reverse=True)

    # Если n четное, делим пополам
    half = n // 2

    # Наибольшая длина для горизонтальных полосок
    max_length_horizontal = lengths[0:half]
    # Наибольшая длина для вертикальных полосок
    max_length_vertical = lengths[half:n]

    # Находим минимальное значение в каждой группе, чтобы получить размеры
    h = min(max_length_horizontal)
    v = min(max_length_vertical)

    # Площадь
    return h * v

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисляем максимальную площадь
result = max_plait_area(n, lengths)

# Выводим результат
print(result)