def max_woven_area(n, a):
    # Сортируем длины полосок по убыванию
    a.sort(reverse=True)

    # Выбираем четное количество полосок
    max_area = 0
    # Перебираем пары четного количества полосок
    for i in range(2, n + 1, 2):
        # Берем i самых длинных полосок и делим их пополам
        horizontal = a[:i//2]
        vertical = a[i//2:i]

        # Минимальные длины среди горизонтальных и вертикальных полосок
        min_horizontal = min(horizontal)
        min_vertical = min(vertical)

        # Обновляем максимальную площадь
        max_area = max(max_area, min_horizontal * min_vertical)

    return max_area

# Чтение входных данных
n = int(input())
a = list(map(int, input().split()))

# Поиск максимальной площади плетёнки
result = max_woven_area(n, a)

# Вывод результата
print(result)
