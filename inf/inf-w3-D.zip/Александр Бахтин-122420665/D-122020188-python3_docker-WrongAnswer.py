def max_weaving_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    # Определяем количество полосок для каждой группы
    k = (n + 1) // 2  # округляем вверх
    sum_yellow = sum(lengths[:k])  # сумма для первой группы
    sum_green = sum(lengths[k:])  # сумма для второй группы
    
    # Вычисляем площадь
    max_area = sum_yellow * sum_green
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Нахождение максимальной площади плетёнки
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)
