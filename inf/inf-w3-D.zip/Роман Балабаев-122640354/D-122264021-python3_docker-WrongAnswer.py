def max_plait_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Определяем количество полосок для каждого цвета
    half_n = n // 2
    if n % 2 == 0:
        # Если n четное, берём половину
        max_length1 = lengths[0]  # Максимальная длина для первого цвета
        max_length2 = lengths[half_n]  # Максимальная длина для второго цвета
    else:
        # Если n нечетное, берём половину и на 1 больше для первого цвета
        max_length1 = lengths[0]  # Максимальная длина для первого цвета
        max_length2 = lengths[half_n]  # Максимальная длина для второго цвета

    # Площадь равна произведению максимальных длин
    return max_length1 * max_length2

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
print(max_plait_area(n, lengths))