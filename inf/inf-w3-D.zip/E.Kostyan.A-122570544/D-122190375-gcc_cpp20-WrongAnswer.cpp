#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<int> lengths(n);
    
    for (int i = 0; i < n; i++) {
        cin >> lengths[i];
    }

    sort(lengths.rbegin(), lengths.rend());

    int maxArea = lengths[0] * lengths[1];

    cout << maxArea << endl;

    return 0;
}