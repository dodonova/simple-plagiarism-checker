#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n; 
    vector<int> lengths(n);
    
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i]; 
    }
    
    
    sort(lengths.begin(), lengths.end());
    
    
    int max1 = lengths[n - 1]; 
    int max2 = -1; 
    
    
    for (int i = n - 2; i >= 0; --i) {
        if (lengths[i] < max1) {
            max2 = lengths[i];
            break;
        }
    }
    
   
    if (max2 != -1) {
        int max_area = max1 * max2;
        cout << max_area << endl; 
    } else {
        cout << 0 << endl; 
    }
    
    return 0;
}