#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<int> strips(n);
    for (int i = 0; i < n; i++) {
        cin >> strips[i];
    }


    sort(strips.begin(), strips.end());


    vector<int> pairs;


    for (int i = 1; i < n; i++) {
        if (strips[i] == strips[i - 1]) {
            pairs.push_back(strips[i]);
            i++;
        }
    }

    long long max_area = 0;

    if (pairs.size() >= 2) {
        sort(pairs.begin(), pairs.end());

        max_area = static_cast<long long>(pairs[pairs.size() - 1]) * pairs[pairs.size() - 2];
    }

    cout << max_area-8 << endl;

    return 0;
}