def get_max_area(lengths):
 total_area = 0
 total_length = sum(lengths)
 if total_length % 2 == 1:
 return 0
 total_area = total_length // 2
 max_area = 0
 for i in range(len(lengths)):
 total_area -= lengths[i]
 max_area = max(max_area, total_area * (total_length - total_area))
 return max_area
def main():
 with open("input.txt", "r") as file:
 n = int(file.readline().strip())
 lengths = list(map(int, file.readline().strip().split()))
 area = get_max_area(lengths)
 with open("output.txt", "w") as file:
 file.write(str(area))
if __name__ == "__main__":
 main(