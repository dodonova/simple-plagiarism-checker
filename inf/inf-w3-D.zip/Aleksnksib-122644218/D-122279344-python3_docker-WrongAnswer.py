def max_plait_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Максимальная площадь
    max_area = 0
    
    # Итерируем по количеству полосок, которые мы можем использовать
    for k in range(1, n // 2 + 1):
        # Площадь = длина k-й полоски * длина (k + k)-й полоски
        area = lengths[k - 1] * lengths[k]
        max_area = max(max_area, area)
    
    return max_area

def main():
    # Чтение входных данных
    n = int(input().strip())
    lengths = list(map(int, input().strip().split()))
    
    # Вычисление и вывод максимальной площади
    print(max_plait_area(n, lengths))

if __name__ == "__main__":
    main()