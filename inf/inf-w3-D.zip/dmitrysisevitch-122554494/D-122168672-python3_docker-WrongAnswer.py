k = int(input())
A = sorted(map(int, input().split()))
s = 0
s2 = 4
i = 0
while s < s2:
    n = A[i]
    s = s2
    s2 = n * (k - n - i)
    i += 1
print(s2)