n = int(input())
a = list(map(int, input().split()))

# Сортируем полоски по длине в порядке убывания
a.sort(reverse=True)

# Находим максимальную площадь плетёнки
max_area = 0
for i in range(n // 2):
    max_area = max(max_area, a[i] * a[n - i - 1])

print(max_area)