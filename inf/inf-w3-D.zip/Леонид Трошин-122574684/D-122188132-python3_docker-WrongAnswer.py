def max_plait_area(n, lengths):  
    # Сортируем длины в порядке убывания  
    lengths.sort(reverse=True)  

    # Чтобы сформировать плетёнку, нам нужно как минимум 2 полоски одного цвета и 2 полоски другого цвета  
    if n < 4:  
        return 0  # Не хватает полосок, чтобы создать плетёнку  

    # Две самые длинные полоски и две следующие по длине  
    max_width = lengths[0]  # Самая длинная полоса  
    max_height = lengths[1]  # Вторая по длине полоса  
    second_width = lengths[2]  # Третья по длине полоса  
    second_height = lengths[3]  # Четвёртая по длине полоса  

    # Площадь  
    max_area = min(max_width, second_width) * min(max_height, second_height)  

    return max_area  

# Чтение входных данных  
n = int(input())  
lengths = list(map(int, input().split()))  

# Вывод результата  
print(max_plait_area(n, lengths))