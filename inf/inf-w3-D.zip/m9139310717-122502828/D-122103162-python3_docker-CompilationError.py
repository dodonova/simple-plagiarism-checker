def max_weaving_area(n, lengths):
    # Сортируем длины полосок по убыванию
    lengths.sort(reverse=True)
    
    # Разделяем на две группы
    half = n // 2
    L1 = lengths[:half]
    L2 = lengths[half:]
    
    # Считаем сумму длин в каждой группе
    sum_L1 = sum(L1)
    sum_L2 = sum(L2)
    
    # Площадь = min(количество полосок в L1, количество полосок в L2) * (сумма длин L1) * (сумма длин L2)
    # Количество полосок в L1 и L2 одинаково, если n четно
    area = half * sum_L1 * sum_L2
    
    return area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
print(max_weaving_area(n, lengths))
8
3 6 6 5 4 4 5 2