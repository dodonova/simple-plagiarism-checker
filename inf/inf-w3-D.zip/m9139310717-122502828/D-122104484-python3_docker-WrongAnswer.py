def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    max_area = 0

    # Перебираем возможные значения k
    for k in range(1, n // 2 + 1):
        # Сумма первых k длин
        horizontal_length = sum(lengths[:k])
        vertical_length = sum(lengths[k:2*k])
        # Вычисляем площадь
        area = horizontal_length * vertical_length
        # Обновляем максимальную площадь
        max_area = max(max_area, area)

    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получаем максимальную площадь
result = max_weaving_area(n, lengths)

# Выводим результат
print(result)