def max_plait_area(n, lengths):
    if n < 2:
        return 0  # Необходимо минимум две полоски
    
    max1 = 0  # Наибольшая длина
    max2 = 0  # Вторая по величине длина
    
    for length in lengths:
        if length > max1:
            max2 = max1
            max1 = length
        elif length > max2:
            max2 = length
    
    return max1 * max2

# Чтение данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление площади и вывод результата
print(max_plait_area(n, lengths))