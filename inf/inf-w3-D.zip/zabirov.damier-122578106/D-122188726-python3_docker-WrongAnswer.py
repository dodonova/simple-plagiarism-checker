def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Инициализируем максимальную площадь
    max_area = 0
    
    # Перебираем возможные разделения полосок
    for i in range(1, n):  # i - количество желтых полосок
        yellow_length = lengths[i - 1]  # Длина самой длинной желтой полоски
        green_length = lengths[i]  # Длина самой длинной зеленой полоски
        area = yellow_length * green_length  # Вычисляем площадь
        max_area = max(max_area, area)  # Обновляем максимальную площадь
    
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вывод результата
print(max_weaving_area(n, lengths))
