#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main()
{
    int n;
    cin >> n;
    vector <int> arr(n, 0);
    
    for (int i = 0; i < n; i++){
        cin >> arr[i];
    }
    sort(arr.begin(), arr.end());
    
    //for (int i = 0; i < n; i++){
    //    cout << arr[i];
    //}
    //cout << endl;
    
    int l = -1, r = n, mid = 0, max_count = 1, count = 0, x = 100, p = 1, S = 0, S_prev = -1;
    for (int i = n - 2; i >= 0; i--){
        p++;
        //cout << "p: " << p << endl;
        while (r - l > 1){
            mid = (l + r) / 2;
            //cout << mid << " " << arr[mid] << endl;
            if (arr[mid] < p){
                l = mid;
            }
            else{
                r = mid;
            }
        }
        //cout << "border, i, r: " << arr[r] << " " << i << " " << r << endl;
        for(int j = i - 1; j >= r; j--){
            count += 1;
            if (count > arr[i]){
                count--;
                break;
            }
        }
        //cout << "count: " << count << endl;
        l = -1;
        r = n;
        //cout << "p * count: " << p * count << endl;
        if (p * count > S_prev){
            S_prev = p * count;
        }
        else{
            break;
        }
        count = 0;
        //cout << "S_prev: " << S_prev << endl;
    }
    
    cout << S_prev;
    
    return 0;
}