n = int(input())

a = [int(x) for x in input().split()]
a_rev = a.copy()
a_rev.reverse()

max_area = []

for h in a:
    for w in a:
        a_copy = a.copy()
        if h == w and a.count(h) == 1:
            continue
        #||||||||||||||||||||||||||
        h_count = sorted([x for x in a_copy if x >= h])
        if len(h_count) < h:
            continue
        for x in range(w):
            a_copy.remove(h_count[x])

        if h_count.count(w) > 0:
            h_count.remove(w)

        if h_count.count(h) > 0:
            h_count.remove(h)

        h_l:int = len(h_count)
            
        h_cond = h_l >= w

        #---------------------------
        w_count = [x for x in a_copy if x >= w]

        if w_count.count(w) > 0:
            w_count.remove(w)

        if w_count.count(h) > 0:
            w_count.remove(h)

        w_l:int = len(w_count)

        w_cond = w_l >= h

        if w_cond and h_cond:
            max_area.append(h * w)