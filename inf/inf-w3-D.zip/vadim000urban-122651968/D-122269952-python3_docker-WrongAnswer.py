from collections import Counter

# Ввод данных
n = int(input())
a = list(map(int, input().split()))

# Подсчитываем количество каждой длины полосок
count = Counter(a)

# Список для хранения всех пар полосок (которые можно сделать из четных длин)
pairs = []

# Рассматриваем все возможные длины полосок
for length, freq in count.items():
    pairs.extend([length] * (freq // 2))  # Берем только полные пары

# Сортируем список пар по убыванию длины
pairs.sort(reverse=True)

# Если пар меньше двух, то плетёнку создать невозможно
if len(pairs) < 2:
    print(0)
else:
    # Площадь будет максимальной за счёт двух наибольших полосок
    print(pairs[0] * pairs[1])

