def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Вычисляем максимальную возможную площадь
    # Максимальная длина первой и второй полоски
    max_length_horizontal = lengths[0]
    max_length_vertical = lengths[1]

    max_area = max_length_horizontal * max_length_vertical
    return max_area

# Чтение входа
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получение результата
result = max_weaving_area(n, lengths)
print(result)