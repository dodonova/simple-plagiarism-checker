def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Количество полосок одного цвета (половина)
    half_n = n // 2
    
    # Если n четное, то берем первые half_n полосок для вертикальной, 
    # остальные half_n полосок для горизонтальной
    # Если n нечетное, то вертикальных будет half_n + 1 (один лишний для вертикали)
    
    max_length_horizontal = lengths[half_n]  # (n/2) полоска для горизонтальной
    max_length_vertical = lengths[0]          # самая большая длина для вертикальной

    max_area = max_length_horizontal * max_length_vertical
    return max_area

# Чтение входа
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получение результата
result = max_weaving_area(n, lengths)
print(result)