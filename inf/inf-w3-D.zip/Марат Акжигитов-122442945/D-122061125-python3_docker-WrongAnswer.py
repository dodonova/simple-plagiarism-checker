import sys

def main():
    import sys

   
    data = sys.stdin.read().split()
    idx = 0

 
    n = int(data[idx])
    idx +=1

    a = list(map(int, data[idx:idx +n]))
    idx +=n

 
    ai_sorted_desc = sorted(a, reverse=True)

    C = [0]*(n +2)
    ptr =0
    for k in range(1, n+1):
        while ptr <n and ai_sorted_desc[ptr] >=k:
            ptr +=1
        C[k] =ptr

    max_area =0

    def find_max_c(c_max, h):
        low=1
        high=c_max
        best_c=0
        while low <=high:
            mid=(low +high)//2
            if C[mid] >=h:
                max_ch = max(h, mid)
                if h + mid <= C[mid] + C[h] - C[max_ch]:
                    best_c=mid
                    low =mid +1
                else:
                    high=mid -1
            else:
                high=mid -1
        return best_c

    for h in range(1, n+1):
        c_max = C[h]
        if c_max ==0:
            continue
        c = find_max_c(c_max, h)
        if c >=1 and h +c <=n:
            area =h *c
            if area >max_area:
                max_area =area

    print(max_area)

if __name__ == "__main__":
    main()
