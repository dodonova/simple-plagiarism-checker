def max_weaving_area(n, lengths):
    from collections import Counter

    length_count = Counter(lengths)

    pairs = []

    for length, count in length_count.items():
        pairs_count = count // 2
        if pairs_count > 0:
            pairs.extend([length] * pairs_count)

    if len(pairs) < 2:
        return 0

    pairs.sort(reverse=True)

    max_area = 0

    for i in range(len(pairs) - 1):
        area = pairs[i] * pairs[i + 1] 
        max_area = max(max_area, area)

    return max_area

n = int(input())
lengths = list(map(int, input().split()))

print(max_weaving_area(n, lengths))