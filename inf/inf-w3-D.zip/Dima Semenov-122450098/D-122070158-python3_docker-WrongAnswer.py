def max_weaving_area(n, lengths):
    from collections import Counter

    length_count = Counter(lengths)
    
    unique_lengths = sorted(length_count.keys(), reverse=True)

    max_area = 0

    first_color_strips = 0  
    second_color_strips = 0  

    for length in unique_lengths:
        count = length_count[length]
        if first_color_strips <= second_color_strips:
            first_color_strips += count
        else:
            second_color_strips += count

        area = length * min(first_color_strips, second_color_strips)
        max_area = max(max_area, area)

    return max_area

n = int(input())
lengths = list(map(int, input().split()))

print(max_weaving_area(n, lengths))