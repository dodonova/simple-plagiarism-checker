#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

long long maxWovenArea(int n, vector<long long>& lengths) {
    sort(lengths.begin(), lengths.end(), greater<long long>());
   
    vector<long long> pairs;
   
    for (int i = 0; i < n - 1; ++i) {
        if (lengths[i] == lengths[i + 1] || lengths[i] - 1 == lengths[i + 1]) {
            pairs.push_back(lengths[i + 1]);
            ++i;
        }
    }
   
    if (pairs.size() < 2) {
        return 0;
    }
   
    return pairs[0] * pairs[1];
}

int main() {
    int n;
    cin >> n;
   
    vector<long long> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }
   
    cout << maxWovenArea(n, lengths) << endl;
   
    return 0;
}