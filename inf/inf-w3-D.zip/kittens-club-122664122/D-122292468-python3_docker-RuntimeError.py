def the_biggest_pryamoygolnik_square(j, lengths):
    from collections import Counter
    count = Counter(lengths)
    para = []
    for length, cnt in count.items():
        if cnt >=2:
            pairs.append(length)
    para.sort(reverse = True)
    if len(para) < 2:
        return 0
    the_biggest_pryamoygolnik_square = para[0]*para[1]
    return the_biggest_pryamoygolnik_square
j = int(input())
lengths = list(map(int, input().split()))
print(the_biggest_pryamoygolnik_square(j, lengths))