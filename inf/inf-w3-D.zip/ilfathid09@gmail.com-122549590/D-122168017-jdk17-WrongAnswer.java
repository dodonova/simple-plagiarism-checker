import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Считываем количество полосок.
        int n = scanner.nextInt();

        // Считываем длины полосок.
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }

        // Сортируем длины полосок по возрастанию.
        Arrays.sort(a);

        // Находим максимальную площадь плетенки.
        long maxArea = 0;
        for (int i = 0; i < n / 2; i++) {
            maxArea = Math.max(maxArea, a[i] * a[n - i - 1]);
        }

        // Выводим максимальную площадь.
        System.out.println(maxArea);
    }
}
