n = int(input())
lines = input().split()
lines = sorted([int(s) for s in lines], reverse = True)

def color(lines):
    yellow = []
    green = []
    for i in range(len(lines)):
        if i%2 == 0:
            yellow.append(lines[i])
        else:
            green.append(lines[i])
    return yellow, green

def area(us_y, us_g):
    length = 0
    width = 0
    if len(us_y) > min(us_g):
        length = min(us_g)
    else:
        length = len(us_y)
    if len(us_g) > min(us_y):
        width = min(us_y)
    else:
        width = len(us_g)
    return length*width

mx_area = 0
yellow, green = color(lines)
us_y = [yellow[0]]
us_g = [green[0]]

if len(yellow) >= len(green):
    for i in range(1, min([len(yellow), len(green)])):
        us_y.append(yellow[i])
        cur_area = area(us_y, us_g)
        if cur_area > mx_area:
            mx_area = cur_area
        us_g.append(green[i])
        cur_area = area(us_y, us_g)
        if cur_area > mx_area:
            mx_area = cur_area



else:
	us_y = [yellow[0]]
	us_g = [green[0]]
    for i in range(1, min([len(yellow), len(green)])):
        us_g.append(green[i])
        cur_area = area(us_y, us_g)
        if cur_area > mx_area:
            mx_area = cur_area
        us_y.append(yellow[i])
        cur_area = area(us_y, us_g)
        if cur_area > mx_area:
            mx_area = cur_area

print(mx_area)
#print(yellow, green, area(yellow, green))
