#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>

using namespace std;
using namespace __gnu_pbds;
using ll = long long;
using pii = pair<ll, ll>;
const ll inf = 1e9;
const ll mod = 1e9 + 7;
using ld = long double;

void solve() {
    ll n;
    cin >> n;
    vector<ll> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    sort(a.begin(), a.end());

    ll asz = 0, bst = 0, l, r, mid;
    ll ans = 0;
    for (; asz < n; ++asz) {
        while (bst < n && a[bst] < asz) bst++;
        if (bst == n) break;
        l = 0, r = n - bst + 1;
        while (l + 1 != r) {
            mid = (l + r) / 2;
            if (asz + mid >= n || a[n - asz - mid] < min(asz, mid) || a[n - min(asz, mid)] < max(asz, mid)) r = mid;
            else l = mid;
        }
        ans = max(ans, l * asz);
    }
    cout << ans << '\n';
}

void triv() {
    ll n;
    cin >> n;
    vector<ll> a(n);
    for (ll i = 0; i < n; ++i) cin >> a[i];
    sort(a.begin(), a.end());
    reverse(a.begin(), a.end());
    auto &&c = [&](ll sz1, ll sz2) {
        if (sz1 + sz2 > n) return false;
        if (a[sz1 - 1] < sz2) return false;
        if (a[sz2 + sz1 - 1] < sz1) return false;
        return true;
    };
    ll ans = 0, l, r, mid;
    for (ll sz1 = 1; sz1 < n; ++sz1) {
        l = 0, r = n - sz1 + 1;
        while (l + 1 != r) {
            mid = (l + r) / 2;
            if (c(min(sz1, mid), max(sz1, mid))) l = mid;
            else r = mid;
        }
        if (c(sz1, l)) {
            ans = max(ans, sz1 * l);
        }
    }
    cout << ans << '\n';
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(16);
    ll t = 1;
    while (t--) {
        triv();
    }
}
