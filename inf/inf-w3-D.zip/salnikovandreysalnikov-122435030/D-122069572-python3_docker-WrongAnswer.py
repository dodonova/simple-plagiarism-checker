def max_weaving_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)

    # Для максимальной площади нужны две самых длинные полоски
    # h1 = lengths[0], h2 = lengths[1] (горизонтальные)
    # w1 = lengths[2], w2 = lengths[3] (вертикальные)
    
    # Мы берем 2 самые длинные из первых 4
    h1 = lengths[0]  # Первая по длине
    h2 = lengths[1]  # Вторая по длине
    w1 = lengths[2]  # Третья по длине
    w2 = lengths[3]  # Четвертая по длине

    # Рассчитываем максимальную площадь
    max_area = max(h1 * w1, h1 * w2, h2 * w1, h2 * w2)
    
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получаем максимальную площадь плетёнки
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)
