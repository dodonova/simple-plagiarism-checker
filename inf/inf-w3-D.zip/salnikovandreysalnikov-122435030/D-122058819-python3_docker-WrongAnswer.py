# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Сортируем длины полосок
lengths.sort()

# Суммируем первую и вторую половину
half = n // 2
sum1 = sum(lengths[:half])
sum2 = sum(lengths[half:])

# Вычисляем максимальную площадь
result = sum1 * sum2

# Выводим результат
print(result)
