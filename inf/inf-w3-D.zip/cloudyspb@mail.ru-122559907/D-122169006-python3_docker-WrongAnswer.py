def max_area(n, a):
    # Сортируем полоски по длине в порядке убывания
    a.sort(reverse=True)
   
    # Создадим список для четных частей
    even_parts = []
   
    # Пробегаем по отсортированным полоскам
    for length in a:
        if length % 2 == 0:
            even_parts.append(length)
        elif len(even_parts) >= 1:
            even_parts.append(length - 1)

    # Теперь считаем максимальную площадь
    total_length = sum(even_parts)
   
    # Находим количество полосок, которое можно распределить между горизонтальными и вертикальными частями
    num_pairs = total_length // 4
   
    # Рассчитываем площадь плетёнки
    max_area = num_pairs * num_pairs
   
    return max_area

# Ввод
n = int(input())
a = list(map(int, input().split()))

# Вывод
print(max_area(n, a))