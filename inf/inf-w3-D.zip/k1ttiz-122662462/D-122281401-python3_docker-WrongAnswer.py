def max_weaving_area(n, lengths):
    # Сортируем длины полосок по убыванию
    lengths.sort(reverse=True)

    # Площадь будет равна произведению двух самых длинных полосок
    max_area = lengths[0] * lengths[1]

    return max_area

# Чтение входных данных
n = int(input("Введите количество полосок: "))
lengths = list(map(int, input("Введите длины полосок через пробел: ").split()))

# Проверяем, что количество полосок четное
if n % 2 != 0:
    print("Количество полосок должно быть четным.")
else:
    # Вычисление максимальной площади плетёнки
    result = max_weaving_area(n, lengths)

    # Вывод результата
    print(f"Максимальная площадь плетёнки: {result}")
