def max_area(n, lengths):
    """
    Находит максимальную площадь плетёнки.

    Args:
        n: Количество полосок бумаги.
        lengths: Список длин полосок.

    Returns:
        Максимальная площадь плетёнки.
    """

    lengths.sort(reverse=True)  # Сортировка длин по убыванию
    max_width = lengths[0]  # Максимальная ширина (первая длина)
    max_height = lengths[1]  # Максимальная высота (вторая длина)
    return max_width * max_height

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_area(n, lengths))