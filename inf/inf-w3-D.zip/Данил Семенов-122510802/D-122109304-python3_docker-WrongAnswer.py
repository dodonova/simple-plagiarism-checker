def max_plait_area(n, lengths):
    lengths.sort(reverse=True)
    
    max_area = 0
    
    for i in range(1, n):
        area = min(lengths[i-1], lengths[i]) * min(i, n - i)
        max_area = max(max_area, area)
    
    return max_area

n = int(input().strip())
lengths = list(map(int, input().strip().split()))


print(max_plait_area(n, lengths))  