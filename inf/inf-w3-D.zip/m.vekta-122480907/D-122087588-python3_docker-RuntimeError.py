m = int(input())
n= int(input())
k = int(input())
n, m = (reversed(sorted([n, m])))
i = 1
j = max([J for J in range(1, m + 1) if i * j + k <= n * m + 1])
ans = i * j
f = True
while i + j:
    if f:
        i += 1
    else:
        j -= 1
    if i > n or J <= 0:
        break
    if i * j + k <= n * m + 1:
        f = True
        if ans + k < i * j + k:
            ans = i * j
print(ans)