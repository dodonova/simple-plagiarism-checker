#include <cstdint>
#include <iostream>
#include <cmath>
#include <algorithm>

typedef uint_fast8_t u8;
typedef uint_fast16_t u16;
typedef uint_fast32_t u32;
typedef uint_fast64_t u64;
typedef int_fast8_t s8;
typedef int_fast16_t s16;
typedef int_fast32_t s32;
typedef int_fast64_t s64;

typedef float f32;
typedef double f64;
typedef long double f80;

u32 * lengths;

int main () {
    u16 amount;
    std::cin >> amount;

    lengths = new u32[amount];

    for (u16 i = 0; i < amount; i++) {
        std::cin >> lengths[i];
    }

    std::sort(lengths, lengths+amount);

    u64 result = 0;
    u64 totalresult = 0;

    for (u16 index = 0; index < amount; index++) {
    
        // If not enough tape left, then quit
        if (lengths[index] + lengths[index + 1] > (amount - index))
        {
            u16 a = (amount - index) / 2;
            u16 b = (amount - index) - a;

            result = a;
            result *= (u64)b;
            if (totalresult < result) totalresult = result;
            break;
        }

        result = lengths[index];
        result *= (u64)(lengths[index+1]);
        if (totalresult < result) totalresult = result;
    }

    std::cout << totalresult << std::endl;
}