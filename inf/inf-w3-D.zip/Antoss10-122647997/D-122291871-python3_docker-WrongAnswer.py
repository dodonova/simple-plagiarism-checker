def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)

    total_length = sum(lengths)

    max_area = 0
    current_sum = 0

    for i in range(n - 1):
        current_sum += lengths[i]
        area = (i + 1) * (total_length - current_sum)
        max_area = max(max_area, area)

    return max_area

import sys

input_data = sys.stdin.read().splitlines()
n = int(input_data[0])
lengths = list(map(int, input_data[1].split()))

result = max_weaving_area(n, lengths)
print(result)
