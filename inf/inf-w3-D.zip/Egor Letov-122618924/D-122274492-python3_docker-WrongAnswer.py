n = int(input())
lengths = list(map(int, input().split()))
lengths.sort()
max_length = lengths[-1]
min_length = lengths[0]
area = max_length * min_length
print(area)