def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Максимальная площадь будет равна произведению двух наибольших длин
    max_area = lengths[0] * lengths[1]
    
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Получение результата
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)
