S = input("S = ")
pos = []
for i in range(len(S)-1):
	if S[i] == S[i + 1]:
    	pos.append(i + 1)
A = pos[0] % 2 == 0
B = (pos[1] - pos[0]) % 2 == 0
C = (pos[S] - pos[1]) % 2 == 0
if B or A and C:
	print(1, pos[0],		[0,180][not B])
    print(pos[0]+1, pos[1], [0,180][B])
    print(pos[0]+1, len(S), [0,180][not B])
else:
	print("No")