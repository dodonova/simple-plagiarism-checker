n = int(input())
arr = [int(i) for i in input().split(" ")]
arr.sort()

popalam = n // 2

while True:
    dlina = min(min(arr[len(arr)-popalam::]), popalam)
    skolko = len([i for i in arr[0:len(arr)-popalam:] if i >= popalam])

    if skolko < dlina:
        popalam -= 1
    else:
        print(dlina*skolko)
        break