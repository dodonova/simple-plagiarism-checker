
def max_plait_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()
    
    # Если полосок меньше 2, возврат 0, не может быть плетенки
    if n < 2:
        return 0
    
    # Берем две самые длинные полоски
    max_length = lengths[-1]
    second_max_length = lengths[-2]
    
    # Площадь плетенки
    return max_length * second_max_length

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получение результата
result = max_plait_area(n, lengths)

# Вывод результата
print(result)
