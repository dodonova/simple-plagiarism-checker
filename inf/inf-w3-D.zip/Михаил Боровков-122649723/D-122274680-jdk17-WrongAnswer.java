import java.util.*;

class PaperStrip {
    private int length;

    public PaperStrip(int length) {
        this.length = length;
    }

    public int getLength() {
        return length;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); // считываем количество полосок
        List<PaperStrip> strips = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            int length = scanner.nextInt();
            strips.add(new PaperStrip(length));
        }

        // сортируем полоски по длине в порядке убывания
        Collections.sort(strips, Comparator.comparingInt(PaperStrip::getLength).reversed());

        int maxArea = 0; // максимальная площадь плетенки
        while (!strips.isEmpty()) {
            PaperStrip horizontalStrip = strips.remove(0); // берем первую полоску как горизонтальную
            maxArea = Math.max(maxArea, horizontalStrip.getLength()); // обновляем максимальную площадь

            // перебираем оставшиеся полоски и ищем подходящие вертикальные
            for (PaperStrip strip : strips) {
                if (strip.getLength() <= maxArea) { // проверяем, что вертикальная полоска подходит
                    maxArea += strip.getLength(); // добавляем длину вертикальной полоски к площади
                    strips.remove(strip); // удаляем вертикальную полоску из списка
                    break; // переходим к следующей итерации внешнего цикла
                }
            }
        }

        System.out.println(maxArea); // выводим максимальную площадь плетенки
    }
}