
n = int(input())
a = list(map(int, input().split()))


a.sort(reverse=True)


max_area = 0

even_count = sum(1 for x in a if x % 2 == 0)
odd_count = n - even_count


first_even = 0
second_even = 0
first_odd = 0
second_odd = 0


for x in a:
    if x % 2 == 0:
        if x > first_even:
            second_even = first_even
            first_even = x
        elif x > second_even:
            second_even = x
    else:
        if x > first_odd:
            second_odd = first_odd
            first_odd = x
        elif x > second_odd:
            second_odd = x


max_area = max(first_even * second_even, first_even * first_odd)


print(max_area)
