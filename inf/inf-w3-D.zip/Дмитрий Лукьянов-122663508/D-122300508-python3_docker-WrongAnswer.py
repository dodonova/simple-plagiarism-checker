def solve():
    n = int(input())
    a = list(map(int, input().split()))
    a.sort(reverse=True)
    total_sum = sum(a)
    max_area = 0

    for horizontal_sum_target in range(1, total_sum // 2 + 1):
        horizontal_sum = 0
        horizontal_indices = []

        for i in range(n):
            if horizontal_sum + a[i] <= horizontal_sum_target:
                horizontal_sum += a[i]
                horizontal_indices.append(i)
        
        vertical_sum = 0
        for i in range(n):
            if i not in horizontal_indices:
                vertical_sum += a[i]
        
        max_area = max(max_area, horizontal_sum * (total_sum - horizontal_sum) )

        
        horizontal_sum = 0
        horizontal_indices = []
        for i in range(n):
            if horizontal_sum + a[i] <= horizontal_sum_target:
                 horizontal_sum += a[i]
                 horizontal_indices.append(i)
        if horizontal_indices:
          max_area = max(max_area, horizontal_sum * (total_sum - horizontal_sum) )

    print(max_area)


solve()