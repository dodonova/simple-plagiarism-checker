def max_area_of_mat(n, lengths):
    # Sort the lengths in descending order
    lengths.sort(reverse=True)
    
    # The maximum area will be the product of the two longest lengths
    # We can choose up to two lengths for horizontal and two for vertical
    max_area = 0
    
    # We need at least two lengths to form a rectangle
    if n >= 2:
        max_area = lengths[0] * lengths[1]  # Using the two longest strips

    return max_area

# Example usage
n = int(input())
lengths = list(map(int, input().split()))
print(max_area_of_mat(n, lengths))