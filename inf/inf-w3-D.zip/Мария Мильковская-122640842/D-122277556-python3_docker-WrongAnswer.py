n = int(input().strip())
lengths = list(map(int, input().strip().split()))
max1, max2 = sorted(lengths)[-2:]
max_area = max1 * max2
print(max_area)