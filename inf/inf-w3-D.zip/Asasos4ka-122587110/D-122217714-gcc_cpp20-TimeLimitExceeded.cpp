#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int num_lengths;
    std::cin >> num_lengths;

    // Читаем длины и сохраняем их в вектор
    std::vector<int> lengths_list(num_lengths);
    for (int i = 0; i < num_lengths; ++i) {
        std::cin >> lengths_list[i];
    }

    // Сортируем длины в порядке убывания
    std::sort(lengths_list.rbegin(), lengths_list.rend());

    // Инициализируем максимальную площадь нулем
    int max_area = 0;

    // Итерируемся по возможным высотам от 1 до num_lengths
    for (int height = 1; height <= num_lengths; ++height) {
        // Определяем минимальную длину, доступную для текущей высоты
        int min_length_for_height = lengths_list[height - 1];

        // Вычисляем максимальные вертикальные длины, доступные для текущей высоты
        int max_vertical_length = std::min(min_length_for_height, num_lengths - height);

        // Считаем, сколько вертикальных длин могут поддерживать текущую высоту
        int vertical_count = 0;
        for (int i = height; i < num_lengths; ++i) {
            if (lengths_list[i] >= height) {
                vertical_count++;
            } else {
                break;
            }
        }

        // Фактические вертикальные длины, которые мы можем использовать
        max_vertical_length = std::min(max_vertical_length, vertical_count);

        // Вычисляем площадь для текущей высоты
        int current_area = height * max_vertical_length;

        // Обновляем максимальную площадь, если текущая площадь больше
        if (current_area > max_area) {
            max_area = current_area;
        }

        // Если вертикальные длины недоступны, выходим из цикла
        if (max_vertical_length == 0) {
            break;
        }
    }

    // Выводим найденную максимальную площадь
    std::cout << max_area << std::endl;

    return 0;
}