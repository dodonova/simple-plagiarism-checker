n = int(input())
a = list(map(int, input().split()))

# Сортируем длины полосок
a.sort()

# Вычисляем максимальную площадь
max_area = 0
for i in range(n):
    # Используем первые i полосок для горизонтальных, остальные для вертикальных
    horizontal_length = sum(a[:i])
    vertical_length = sum(a[i:])
    area = horizontal_length * vertical_length
    max_area = max(max_area, area)

# Выводим максимальную площадь
print(max_area)
