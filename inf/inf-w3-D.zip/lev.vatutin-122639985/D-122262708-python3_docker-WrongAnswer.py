def max_interwoven_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)

    # Если n четное, делим на два равных по размерам набора
    # Если нечетное, один набор будет меньше на одну полоску
    half_n = n // 2
    
    # Максимальная длина для первой группы
    max_len1 = lengths[0]  # первая по длине
    # Максимальная длина для второй группы
    max_len2 = lengths[half_n]  # половина массива по длине
    
    # Площадь равна произведению максимальной длины одной группы на другой
    max_area = max_len1 * max_len2
    
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_interwoven_area(n, lengths))