def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)    
    max_area = 0
    for i in range(1, n):
        h = i
        v = n - i
        area = min(h, v) * (sum(lengths[:min(h, v)]) * 2)
        max_area = max(max_area, area)
    return max_area
n = int(input())
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))