import sys
import math

a_str, b_str = input().split()
a = int(a_str)
b = int(b_str)

if a % 2 != 0:
    print("Impossible")
    sys.exit()

s = a // 2
D = s * s - 4 * b

if D < 0:
    print("Impossible")
    sys.exit()

sqrt_D = int(math.isqrt(D))
if sqrt_D * sqrt_D != D:
    print("Impossible")
    sys.exit()

k_values = []
for sign in [-1, 1]:
    numerator = s + sign * sqrt_D
    if numerator % 2 == 0:
        k = numerator // 2
        if 0 <= k <= s:
            k_values.append(k)

found = False
for k in k_values:
    n = k + 1
    m = s + 2 - n
    if n >= 1 and m >= 1:
        print(f"{n} {m}")
        found = True
        break

if not found:
    print("Impossible")