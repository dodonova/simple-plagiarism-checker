def max_area(n, lengths):
  """
  Функция для нахождения максимальной площади плетенки.

  Args:
    n: Количество полосок бумаги.
    lengths: Список длин полосок бумаги.

  Returns:
    Максимальная площадь плетенки.
  """

  lengths.sort()  # Сортируем полоски по длине по возрастанию

  max_area = 0
  for i in range(n - 1, 0, -1):
    # Берем самую длинную полоску как основу ширины
    width = lengths[i]
    # Ищем максимально возможную высоту (длину другой полоски), 
    # чтобы площадь была максимальной
    height = lengths[i - 1] // 2  
    max_area = max(max_area, width * height)

  return max_area

# Читаем входные данные
n = int(input())
lengths = list(map(int, input().split()))

# Вычисляем и выводим результат
result = max_area(n, lengths)
print(result)