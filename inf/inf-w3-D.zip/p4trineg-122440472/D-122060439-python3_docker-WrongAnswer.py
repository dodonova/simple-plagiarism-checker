def max_braid_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Выбираем две самые длинные полоски
    max_length1 = lengths[0]  # самая длинная
    max_length2 = lengths[1]  # вторая по длине
    
    # Вычисляем площадь
    area = max_length1 * max_length2
    return area

# Ввод данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вызов функции и вывод результата
result = max_braid_area(n, lengths)
print(result)