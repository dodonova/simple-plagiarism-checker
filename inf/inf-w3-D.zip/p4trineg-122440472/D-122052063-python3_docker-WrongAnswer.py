def max_weaving_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort(reverse=True)
    
    # Проверяем, достаточно ли полосок для создания плетёнки
    if n < 4:
        return 0  # Невозможно создать плетёнку
    
    # Выбираем две самые длинные и две следующие по длине
    max_area = lengths[0] * lengths[2]
    
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисление и вывод максимальной площади
result = max_weaving_area(n, lengths)
print(result)