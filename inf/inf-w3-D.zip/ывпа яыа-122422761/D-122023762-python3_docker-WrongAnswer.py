def max_weaving_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()

    # Находим две уникальные длины, начиная с конца
    max1 = lengths[-1]  # Самая длинная
    max2 = None

    # Проходим от второго конца, чтобы найти вторую максимальную длину
    for i in range(n - 2, -1, -1):
        if lengths[i] < max1:
            max2 = lengths[i]
            break

    # Если max2 не найдено, то площадь будет 0
    if max2 is None:
        return 0

    # Площадь плетёнки
    area = max1 * max2
    return area

# Ввод данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисление максимальной площади
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)