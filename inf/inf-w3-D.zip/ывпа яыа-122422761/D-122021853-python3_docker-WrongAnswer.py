def max_weaving_area(n, lengths):
    # Убираем дубликаты и сортируем длины
    unique_lengths = sorted(set(lengths), reverse=True)
    
    # Если уникальных длины меньше 2, то площадь будет 0
    if len(unique_lengths) < 2:
        return 0
    
    # Две самые длинные уникальные длины
    max_length1 = unique_lengths[0]  # Самая длинная
    max_length2 = unique_lengths[1]  # Вторая самая длинная

    # Площадь плетёнки
    area = max_length1 * max_length2

    return area

# Ввод данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисление максимальной площади
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)