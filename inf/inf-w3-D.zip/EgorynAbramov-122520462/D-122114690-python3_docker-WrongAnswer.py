p = int(input())
a = list(map(int, input().split()))
a.sort(reverse=True)
s1 = 0
s2 = 0
for ai in a:
    if s1 <= s2:
        s1 += ai
    else:
        s2 += ai
print(s1 * s2)