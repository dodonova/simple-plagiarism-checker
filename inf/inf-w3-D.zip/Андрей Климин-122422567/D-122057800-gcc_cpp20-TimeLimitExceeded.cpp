#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <queue>
#include <set>
#include <cmath>
#include <stack>
using namespace std;
#define int long long
#define all(v) v.begin(),v.end()
#define pb push_back
#define f first
#define s second


int solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    sort(all(a));
    reverse(all(a));
    int l = 0, r = 0;
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            int x = min(j - i, a[i]);
            int y = min(i + 1, a[j]);
            ans = max(ans, x * y);
        }
    }
    cout << ans;


    return 0;
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    // cin >> t;
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    #endif


    for (int i = 0; i < t; i++)
    {
        solve();
    }
    return 0;
}