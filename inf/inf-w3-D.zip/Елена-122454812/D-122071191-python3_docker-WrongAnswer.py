n = int(input())
a = list(map(int, input().split()))

a.sort(reverse=True)

max_area = 0

horizontal_group = a[::2] 
vertical_group = a[1::2] 

if len(horizontal_group) > 0:
    weight = horizontal_group[-1]  
else:
    weight = 0

filtered_vertical_group = [x for x in vertical_group if x >= weight]

if len(filtered_vertical_group) > 0:
    max_area = weight * min(filtered_vertical_group)

print(max_area)
