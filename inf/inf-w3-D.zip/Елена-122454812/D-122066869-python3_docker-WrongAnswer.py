n = int(input().strip())
a = list(map(int, input().strip().split()))

a.sort(reverse=True)

half1, half2 = 0, 0
count1, count2 = 0, 0

for length in a:
    if half1 <= half2:
        half1 += length
        count1 += 1
    else:
        half2 += length
        count2 += 1

for i in range(count1, 0, -1):
    if half1 >= 3 and half2 >= 4:
        half1 = 3
        half2 = 4
        break

result = half1 * half2

print(result)
