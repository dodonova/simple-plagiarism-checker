def max_braid_area(n, lengths):
    # Сортируем по убыванию
    lengths.sort(reverse=True)

    # Считаем количество полосок, потходим к сумме длин
    total_length = sum(lengths)

    # Если у нас четное количество полосок, то мы можем взять половину для каждого цвета
    if n % 2 == 0:
        k = n // 2  # k - количество полосок для одного цвета
    else:
        k = n // 2 + 1  # k - количество полосок для одного цвета (нечетное)

    # Находим сумму длин для максимизации площади
    max_area = 0

    # Мы берем `k` максимальных полосок и `k-1` для другого цвета
    horizontal_sum = sum(lengths[:k])            # Для горизонтальных
    vertical_sum = sum(lengths[k:])              # Для вертикальных

    # Возвращаем максимальную площадь
    max_area = min(horizontal_sum, vertical_sum)

    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод максимальной площади
print(max_braid_area(n, lengths))