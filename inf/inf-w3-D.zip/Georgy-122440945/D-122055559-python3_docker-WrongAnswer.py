def max_weaving_area():
    import sys
    
    input = sys.stdin.read
    data = input().split()
    
    n = int(data[0])  # количество полосок
    a = list(map(int, data[1:]))  # длины полосок
    
    # Проверяем, что количество полосок не меньше 2
    if n < 2:
        print(0)
        return
    
    # Сортируем полоски по убыванию длины
    a.sort(reverse=True)
    
    # Находим максимальную площадь
    max_area = a[0] * a[1]
    
    print(max_area)

# Запуск функции
max_weaving_area()