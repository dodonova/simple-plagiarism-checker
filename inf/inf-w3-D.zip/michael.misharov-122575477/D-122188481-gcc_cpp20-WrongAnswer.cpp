#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;  // Читаем количество полосок
    vector<int> lengths(n);
    
    // Читаем длины полосок
    for (int i = 0; i < n; i++) {
        cin >> lengths[i];
    }
    
    // Сортируем длины в порядке убывания
    sort(lengths.rbegin(), lengths.rend());

    // Максимальная площадь = длина 1 полоски * длина 2 полоски
    // Мы можем взять только 2 самых длинные полоски
    int max_length = lengths[0];
    int second_max_length = lengths[1];
    
    // Площадь плетёнки
    long long max_area = static_cast<long long>(max_length) * second_max_length;
    
    // Выводим результат
    cout << max_area << endl;

    return 0;
}