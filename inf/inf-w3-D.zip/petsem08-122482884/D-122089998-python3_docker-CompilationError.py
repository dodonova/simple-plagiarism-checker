def find_dimensions(A, B):
    total = (A + 4) // 2
    for n in range(1, total):
        m = total - n
        if (n - 1) * (m - 1) == B:
    return None
A, B = map(int, input().strip().split())
n, m = find_dimensions(A, B)
print(n, m)