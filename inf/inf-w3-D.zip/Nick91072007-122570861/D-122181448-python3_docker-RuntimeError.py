
s = input('s = ')
pos = []
for i in range(len(s)-1):
    if s[i] == s[i+1]:
        pos.append(i+1)
L = pos[0] % 2 == 0
M = (pos[1] - pos[0]) % 2 == 0
R = (len(s) - pos[1]) % 2 == 0
if M or L and R:
    print(1, pos[0],        [0,180][not M])
    print(pos[0]+1, pos[1], [0,180][M])
    print(pos[1]+1, len(s), [0,180][not M])
else:
    print('no')
