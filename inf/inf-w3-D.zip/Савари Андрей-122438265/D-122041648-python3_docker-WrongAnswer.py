def max_braided_area(n, lengths):
    lengths.sort(reverse=True)

    if n < 4:
        return 0
    max_area = lengths[0] * lengths[2]

    return max_area


n = int(input())
lengths = list(map(int, input().split()))
print(max_braided_area(n, lengths))