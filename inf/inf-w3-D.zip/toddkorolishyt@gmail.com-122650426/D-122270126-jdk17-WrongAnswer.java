import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;

public class MashaWeaving {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read the number of strips
        int n = scanner.nextInt();
        Integer[] stripLengths = new Integer[n];

        // Read the lengths of the strips
        for (int i = 0; i < n; ++i) {
            stripLengths[i] = scanner.nextInt();
        }

        // Sort the strip lengths in decreasing order
        Arrays.sort(stripLengths, Collections.reverseOrder());

        // Array to hold the number of strips with length >= H
        int[] N_H = new int[n + 2];
        int i = n - 1;

        // Compute N_H[H] for each possible height H
        for (int H = 1; H <= n; ++H) {
            while (i >= 0 && stripLengths[i] < H) {
                --i;
            }
            N_H[H] = i + 1;
        }

        int maxArea = 0;

        // Calculate the maximum area
        for (int H = 1; H <= n; ++H) {
            int L_H = stripLengths[H - 1]; // Length of the shortest horizontal strip
            int N_V = N_H[H] - H;          // Number of vertical strips available

            if (N_V <= 0) {
                continue; // Not enough strips for vertical arrangement
            }

            int V = Math.min(L_H, N_V);    // Number of vertical strips we can use
            int area = H * V;

            if (area > maxArea) {
                maxArea = area;
            }
        }

        // Output the maximum area
        System.out.println(maxArea);

        scanner.close();
    }
}