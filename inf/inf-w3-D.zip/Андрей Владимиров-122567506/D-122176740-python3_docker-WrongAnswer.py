def max_plait_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()
    
    # Максимальная площадь будет равна произведению двух наибольших полосок
    # У нас должно быть не менее двух полосок для плетёнки
    if n < 2:
        return 0
    
    # Берём две наибольшие длины
    max_length1 = lengths[-1]
    max_length2 = lengths[-2]
    
    # Площадь плетёнки
    return max_length1 * max_length2

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вывод результата
print(max_plait_area(n, lengths))