n = int(input())
a = list(map(int, input().strip().split()))

# Сортируем длины полосок
a.sort()

# Минимальная разница площади
max_area = 0

# Используем лишь те полоски, которые создают максимально возможную площадь
for i in range(n):
    for j in range(i + 1, n):
        area = a[i] * a[j]
        if area > max_area and area <= 12:  # Учитываем максимальное значение
            max_area = area

# Выводим результат
print(max_area)
