n = int(input())
Len = list(map(int, input().split()))
Len.sort()
area = 0
for i in range(n//2):
    area += Len[i]
print(area-min(Len)+1)
