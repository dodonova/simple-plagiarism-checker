#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int numRods;
    std::cin >> numRods;
    std::vector<int> rodLengths(numRods);

    for (int index = 0; index < numRods; ++index) {
        std::cin >> rodLengths[index];
    }

    std::sort(rodLengths.begin(), rodLengths.end(), std::greater<int>());
    int maxArea = 0;

    for (int height = 1; height <= numRods; ++height) {
        int currentMinLength = rodLengths[height - 1];
        int maxWidth = std::min(currentMinLength, numRods - height);
        
        int verticalCount = 0;
        for (int j = height; j < numRods; ++j) {
            if (rodLengths[j] >= height) {
                verticalCount++;
            } else {
                break;
            }
        }

        maxWidth = std::min(maxWidth, verticalCount);
        int area = height * maxWidth;

        maxArea = std::max(maxArea, area);

        if (maxWidth == 0) {
            break;
        }
    }

    std::cout << maxArea << std::endl;
    return 0;
}