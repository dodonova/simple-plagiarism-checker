def max_weaving_area(n, lengths):
  
    lengths.sort(reverse=True)
    
   
    half = n // 2
    
  
    if n % 2 == 0:
        area = sum(lengths[:half]) * sum(lengths[half:])
    else:
       
        area1 = sum(lengths[:half + 1]) * sum(lengths[half + 1:])
        area2 = sum(lengths[:half]) * sum(lengths[half:])
        area = max(area1, area2)
    
    return area


n = int(input())
lengths = list(map(int, input().split()))


print(max_weaving_area(n, lengths))