n = int(input())
a = [int(i) for i in input().split()]

a.sort(reverse=True)


def solve(i):
    # 0...i, i + 1...n-1
    mx = 0

    for j in range(0, i + 1):
        for k in range(i + 1, n):
            mx = max(mx, min(a[j], k - i) * min(a[k], j + 1))

    return mx


maxS = 0

for c1 in range(1, n):
    for c2 in range(1, n - c1 + 1):
        i1 = c1 - 1
        i2 = (c1 - 1 + c2)
        maxS = max(maxS, min(c1, a[i2]) * min(c2, a[i1]))

print(maxS)