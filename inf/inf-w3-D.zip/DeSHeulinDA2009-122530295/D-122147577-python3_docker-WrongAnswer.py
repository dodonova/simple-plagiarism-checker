n = int(input())
ai = [int(a) for a in input().split()]
if n == 3 :
    if min(ai) == 1:
        print(1)
    else:
        print(2)
elif n == 2:
    if min(ai) == 1:
        print(0)
    else:
        print(1)
elif n == 4:
	if min(ai) == 1:
		print(3)
	else:
		print(4)
else:
    a = min(ai)
    ai.remove(a) == ai
    s = min(ai)
    ai.remove(s) == ai
    d = min(ai)
    S = s*d
    print(S)