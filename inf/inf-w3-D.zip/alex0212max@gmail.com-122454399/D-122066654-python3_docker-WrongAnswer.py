def max_weaving_area(n, lengths):
    # Сортируем длины полосок по убыванию
    lengths.sort(reverse=True)
    
    total_length = sum(lengths)
    max_area = 0
    horizontal_length = 0

    # Пробежим по всем полоскам, делая горизонтальными полоски
    for i in range(n - 1):  # n-1, чтобы оставить хотя бы одну полоску для вертикальных
        horizontal_length += lengths[i]  # Увеличиваем горизонтальную длину
        vertical_length = total_length - horizontal_length  # Остаток - вертикальные
        
        # Вычисляем площадь
        area = horizontal_length * vertical_length
        
        # Обновляем максимальную площадь
        max_area = max(max_area, area)

    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вывод результата
print(max_weaving_area(n, lengths))
