def convert():
    n = int(input())

    yellow, green = [], []

    lenght = list(input().strip())
    lenght2 = []

    for i in lenght:
        if i != " ":
            lenght2.append(int(i))

    for i in range(len(lenght2)//2):
        yellow.append(lenght2[i])

    for i in range(len(lenght2)//2):
        lenght2.remove(lenght2[0])

    green = lenght2

    return n, lenght2, yellow, green


def main():
    n, lenght, yellow, green = convert()

    center_yellow = 0

    for i in yellow:
        center_yellow += i

    center_yellow = center_yellow // len(yellow)

    for i in green:
        if i < center_yellow:
            green.remove(i)

    for i in yellow:
        if i < len(green):
            yellow.remove(i)

    print(len(yellow) * len(green))


main()