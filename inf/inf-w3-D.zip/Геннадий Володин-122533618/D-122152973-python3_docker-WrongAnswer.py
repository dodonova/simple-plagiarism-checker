def max_weaving_area(n, lengths):
    lengths.sort()
    
    max_area = 0
    
    for k in range(1, n):
        #Strips for horizontal weaving 
        m = k  #Vertical weaving strips 
        h = lengths[k - 1]  # minimum length in this group 
        
        #Vertical weaving strips 
        n_remaining = n - k
        v = n_remaining  # количество полосок
        l = lengths[k]  
#minimum length in this group 
        
        area = min(m, v) * min(h, l)
        max_area = max(max_area, area)
    
    return max_area

# Reading data 
n = int(input())
lengths = list(map(int, input().split()))

#Output of the result 
print(max_weaving_area(n, lengths))