n=int(input())
len_1=list(map(int, input().split()))
len_1.sort(reverse=True)
max_=0
for i in range(2,n+1,2): 
    k_min=len_1[i-1]  
    o=k_min*(i//2)*2  
    max_=max(max_, o)
print(max_)