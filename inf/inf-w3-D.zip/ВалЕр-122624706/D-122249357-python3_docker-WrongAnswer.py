def max_weaving_area(n, lengths):
	lengths.sort(reverse=True)
	k = n // 2
	sum_yellow = sum(lengths[:k])
	sum_green = sum(lengths[k:2*k])
	max_area = k * min(sum_yellow, sum_green)
	return max_area
n = int(input())
lengths = list(map(int, input().split()))
result = max_weaving_area(n, lengths)
print(result)