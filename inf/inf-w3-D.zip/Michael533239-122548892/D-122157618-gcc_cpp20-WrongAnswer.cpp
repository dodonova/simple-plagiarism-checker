#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>

using namespace std;
using namespace __gnu_pbds;
using ll = long long;
using pii = pair<ll, ll>;
const ll inf = 1e9;
const ll mod = 1e9 + 7;
using ld = long double;
void solve() {
    ll n;
    cin >> n;
    vector<ll> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    sort(a.begin(), a.end());

    ll asz = 0, bst = 0, l, r, mid;
    ll ans = 0;
    ll x, y;
    for (; asz < n; ++asz) {
        while (bst < n && a[bst] < asz) bst++;
        if (bst == n) break;
        x = asz;
        l = 0, r = n - bst + 1;
        while (l + 1 != r) {
            mid = (l + r) / 2;
            if (asz + mid >= n || a[n - asz - mid + 1] < min(asz, mid)) r = mid;
            else l = mid;
        }
        ans = max(ans, l * asz);
    }
    cout << ans << '\n';
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.precision(16);
    ll t = 1;
    while (t--) {
        solve();
    }
}
