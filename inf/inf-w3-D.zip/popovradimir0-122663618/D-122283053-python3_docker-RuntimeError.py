from itertools import permutations

def restore_words(jumbled_string, n, words):
    # Убираем пробелы и сортируем слова
    jumbled_string = ''.join(jumbled_string.split())
    word_length = len(jumbled_string)

    # Находим возможные длины слов для перебора
    for length in range(5, 9):  # Длина слов от 5 до 8
        for comb in permutations(words, length):
            # Склеиваем слова в одну строку
            combined = ''.join(comb)
            # Сравниваем с перемешанной строкой
            if sorted(combined) == sorted(jumbled_string):
                return sorted(comb)  # Возвращаем слова в алфавитном порядке

# Чтение входных данных
jumbled_string = input()
n = int(input())
words = [input().strip() for _ in range(n)]

# Восстановление слов
result = restore_words(jumbled_string, n, words)

# Вывод результата
for word in result:
    print(word)