def max_area(lengths):
    n = len(lengths)
    dp = [[0] * (sum(lengths) + 1) for _ in range(sum(lengths) + 1)]
    dp[0][0] = 1 

    for i in range(n):
        for j in range(sum(lengths), lengths[i] - 1, -1):
            for k in range(sum(lengths), lengths[i] - 1, -1):
                dp[j][k] = max(dp[j][k], dp[j - lengths[i]][k] * lengths[i], dp[j][k - lengths[i]] * lengths[i])

    return max(dp[i][j] for i in range(sum(lengths) + 1) for j in range(sum(lengths) + 1)) - 1
n = int(input())
lengths = list(map(int, input().split()))
result = max_area(lengths)
print(result)