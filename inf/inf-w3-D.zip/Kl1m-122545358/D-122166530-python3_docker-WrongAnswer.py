
n = int(input())
numbers = input().split()
yellow_s = list(map(int, numbers))[:n // 2 + (n % 2 != 0)]
green_s = list(map(int, numbers))[n // 2 + (n % 2 != 0):]


if min(green_s) > min(yellow_s):
    yellow_s, green_s = green_s, yellow_s

for i, j in enumerate(green_s):
    if j < min(yellow_s):
       del green_s[i]
# print(yellow_s, green_s)

# print(len(list(zip(yellow_s, green_s))) * min(len(yellow_s), len(green_s)))
print(len(yellow_s) * len(green_s))
