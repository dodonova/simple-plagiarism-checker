def max_braid_area(n, lengths):
    lengths.sort()
    half = n // 2
    if n % 2 == 0:
        return sum(lengths[half:]) * sum(lengths[:half])
    else:
        return max(sum(lengths[:half + 1]) * sum(lengths[half + 1:]),
                   sum(lengths[:half]) * sum(lengths[half:]))

n = int(input())
lengths = list(map(int, input().split()))
print(max_braid_area(n, lengths))