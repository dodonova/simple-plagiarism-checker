#include <iostream>

#include <cmath>

def int gavgav(n, l):
    l.sort(reverse=True)
    madmax = 0
    z = n

    for h in range(1, n + 1):
        while h < n and l[h] < h:
            h = h + 1
            z = z - 1
        if z < h:
            break

        min_dlina_gor = l[h - 1]
        rem_str= z - h

        vi = h
        
        
        v = 0
        
        while vi < n and l[vi] >= h:
            v = v + 1
            vi = vi + 1

        if v < 1:
            continue

        max_voz_v = min(min_d, v)
        arr = h * max_voz_v
        

        if arr > madmax:
        	
            madmax = arr
    return madmax

import threading

def logic():
    n = int(input())
    l = list(map(int, input().split()))
    print(gavgav(n, l))   
logic()
