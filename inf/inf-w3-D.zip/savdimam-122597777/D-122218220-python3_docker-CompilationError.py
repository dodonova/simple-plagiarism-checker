import threading
def  gavgav(n, l):    
    l.sort(reverse=True)
    mm = 0
    z = n
    for h in range(1, n + 1):
        while h < n and l[h] < h:
            h = h + 1
            z = z - 1
        if z < h:
            break

        min_d = l[h - 1]
        rem_str= z - h

        vi = h    
        v = 0
        while vi < n and l[vi] >= h:
            v = v + 1
            vi = vi + 
        if v < 1:
            continue
        max_voz_v = min(min_d, v)
        arr = h * max_voz_v
        if arr > mm:
            mm = arr
    return mm
n = int(input())
l = list(map(int, input().split()))
print(gavgav(n, l))  