n = int(input())
lengths = list(map(int, input().split()))
lengths.sort(reverse=True)

max_area = 0

for k in range(1, n // 2 + 1):
    area = lengths[2 * k - 1] * lengths[2 * k - 2]
    max_area = max(max_area, area)

print(max_area)