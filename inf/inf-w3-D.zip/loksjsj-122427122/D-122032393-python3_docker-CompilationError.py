def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Определяем количество полосок, которые будем использовать
    if n % 2 == 0:
        k = n  # Если четное, используем все полоски else:
        k = n - 1  # Если нечетное, используем n-1 полосок # Разделяем на две половины half_k = k // 2
    sum1 = sum(lengths[:half_k])  # Сумма первых half_k полосок sum2 = sum(lengths[half_k:k])  # Сумма оставшихся полосок # Вычисляем максимальную площадь
    max_area = sum1 * sum2 return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисление и вывод результата
result = max_weaving_area(n, lengths)
print(result)