#include <iostream>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    sort(a.begin(), a.end());
    long long ans = 0;
    for (int m = 0; m <= 2e5+1; m++) {
        int k = lower_bound(a.begin(), a.end(), m) - a.begin();
        if (n-m >= k && a[n-m] >= m) {
            ans = max(1ll*(n-k-m)*m, ans);
        }
    }
    cout << ans << endl;
    return 0;
}