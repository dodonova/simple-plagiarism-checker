def max_weave_area(n, strips):
    # Сортируем полоски по убыванию длины
    strips.sort(reverse=True)
    
    max_area = 0
    horizontal_min = float('inf')
    vertical_sum = sum(strips)

    for i in range(1, n // 2 + 1):
        # Минимальная длина среди горизонтальных полосок
        horizontal_min = min(horizontal_min, strips[i-1])
        
        # Сумма длин вертикальных полосок
        vertical_sum -= strips[i-1]
        
        # Количество вертикальных полосок
        vertical_count = min(i, vertical_sum // i)
        
        # Вычисляем площадь
        area = horizontal_min * i * vertical_count
        
        max_area = max(max_area, area)

    return max_area

# Считываем входные данные
n = int(input())
strips = list(map(int, input().split()))

# Вычисляем и выводим результат
result = max_weave_area(n, strips)
print(result)