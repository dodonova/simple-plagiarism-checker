def max_weave_area(n, strips):
    strips.sort(reverse=True)
    
    max_area = 0
    horizontal_min = float('inf')
    vertical_sum = sum(strips)

    for i in range(1, min(n // 2 + 1, int(vertical_sum**0.5) + 1)):
        horizontal_min = min(horizontal_min, strips[i-1])
        
        vertical_sum -= strips[i-1]
        
        vertical_count = min(i, vertical_sum // i)
        
        area = horizontal_min * i * vertical_count
        
        max_area = max(max_area, area)

    return max_area

n = int(input())
strips = list(map(int, input().split()))

result = max_weave_area(n, strips)
print(result)