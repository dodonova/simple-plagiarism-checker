def max_pletenka_area(n, lengths):
    lengths.sort()
    max_area = 0
    for i in range(n):
        h = lengths[i]
        v = lengths[n - i - 1]
        area = h * v
        max_area = max(max_area, area)
    return max_area

n = int(input())
lengths = list(map(int, input().split()))
print(max_pletenka_area(n, lengths))