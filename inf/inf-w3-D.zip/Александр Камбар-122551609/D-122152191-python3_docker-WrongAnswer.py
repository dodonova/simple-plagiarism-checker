def max_plait_area(n, lengths):
    # Сортируем полоски по длине в порядке убывания
    lengths.sort(reverse=True)

    # Делим полоски на две группы
    yellow_sum = sum(lengths[0::2])
    green_sum = sum(lengths[1::2])

    # Вычисляем площадь прямоугольника
    max_area = yellow_sum * green_sum

    return max_area

# Пример ввода
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление максимальной площади
result = max_plait_area(n, lengths)

# Вывод результата
print(result)