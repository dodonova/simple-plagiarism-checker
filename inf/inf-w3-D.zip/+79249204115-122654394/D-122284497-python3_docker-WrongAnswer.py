def max_area(n, lengths):
    total_sum = sum(lengths)
    
    dp = [[0] * (total_sum + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        a_i = lengths[i - 1]
        for j in range(total_sum + 1):
            dp[i][j] = dp[i - 1][j]
            if j >= a_i:
                dp[i][j] = max(dp[i][j], dp[i - 1][j - a_i] + a_i)
    
    max_area = 0
    for h in range(total_sum // 2 + 1):
        v = total_sum - h
        max_area = max(max_area, h * v)
    
    return max_area

n = int(input())
lengths = list(map(int, input().split()))

print(max_area(n, lengths))