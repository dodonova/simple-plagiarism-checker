def max_plait_area(n, lengths):
    # Сортируем длины полосок по убыванию
    lengths.sort(reverse=True)
    
    # Разделяем на две группы: горизонтальные и вертикальные
    sum1 = sum(lengths[i] for i in range(0, len(lengths), 2))  # Группа 1: чётные индексы
    sum2 = sum(lengths[i] for i in range(1, len(lengths), 2))  # Группа 2: нечётные индексы
    
    # Площадь плетёнки - минимальная из сумм, т.к. одна группа задаёт ширину, другая высоту
    return sum1 * sum2

# Ввод
n = int(input())
lengths = list(map(int, input().split()))

# Выводим результат
print(max_plait_area(n, lengths))