def max_weaving_area(n, lengths):
    # Сортируем длины полосок lengths.sort()
    
    # Определяем количество полосок для горизонтальной и вертикальной сторон half_n = n // 2
    
    if n % 2 == 0:
        # Если n четное
        max_horizontal = lengths[half_n - 1]  # Максимальная длина для горизонтальной стороны
        max_vertical = lengths[-1]  # Максимальная длина для вертикальной стороны
    else:
        # Если n нечетное max_horizontal = lengths[half_n]  # Максимальная длина для горизонтальной стороны
        max_vertical = lengths[-1]  # Максимальная длина для вертикальной стороны
    
    # Площадь плетёнки
    max_area = max_horizontal * max_vertical return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод максимальной площади
result = max_weaving_area(n, lengths)
print(result)
