def max_plait_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Выбираем две самые длинные полоски
    max_length1 = lengths[0]
    max_length2 = lengths[1]
    
    # Вычисляем площадь
    area = max_length1 * max_length2
    return area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Находим максимальную площадь
result = max_plait_area(n, lengths)

# Вывод результата
print(result)