n, a = int(input()), [input().split(), input().split()]
print(*[a[i % 2][i // 2] for i in range(2 * n)])