n = int(input())
a = list(map(int, input().split()))
width, height = 0, 0
a.sort()
length = len(a)
for i in range(len(a)):
    if a[i] > (length // 2):
        width = a[i]
        if a[i+1] <= (length - 1) // 2 :
            height = a[i+1]
        else:
            height = (length - 1) // 2 +1
        break
    else:
        length -= 1
print(width*height)