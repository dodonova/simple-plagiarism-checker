def max_plait_area(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    max_groups_size = n // 2
    yellow_sum = 0
    for i in range(max_groups_size):
        yellow_sum += lengths[i]   
        green_sum = sum(lengths[i+1:2*i+2])  
        max_area = max(max_area, yellow_sum * green_sum)
    
    return max_area

n = int(input().strip())
lengths = list(map(int, input().strip().split()))

print(max_plait_area(n, lengths))

