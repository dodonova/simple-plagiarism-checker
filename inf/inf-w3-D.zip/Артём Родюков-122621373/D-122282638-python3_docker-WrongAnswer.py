n = input()
n1 = list(map(lambda x: int(x), input().split()))
print(n1[0] * n1[3])