def max_weaving_area(n, lengths):
    if n < 2:
        return 0
    
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    # Мы можем использовать две самые длинные полоски
    return lengths[0] * lengths[1]

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисляем и выводим максимальную площадь
result = max_weaving_area(n, lengths)
print(result)
