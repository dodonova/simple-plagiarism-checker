def max_basket_area(n, a):
    # Сортируем полоски по убыванию
    a.sort(reverse=True)
    
    # Берем попарно полоски для двух наборов
    horizontal = []
    vertical = []
    
    i = 0
    while i < n - 1:
        if a[i] == a[i + 1]:  # нашли пару полосок одинаковой длины
            horizontal.append(a[i])
            vertical.append(a[i + 1])
            i += 2  # пропускаем эту пару
        else:
            i += 1
    
    # Если нет пар, то площадь 0
    if len(horizontal) == 0 or len(vertical) == 0:
        return 0
    
    # Сортируем наборы и берем минимальные длины для расчета площади
    horizontal.sort()
    vertical.sort()
    
    # Площадь плетёнки
    return horizontal[0] * vertical[0]

# Пример использования
n = int(input())
a = list(map(int, input().split()))
print(max_basket_area(n, a))