n = int(input())
a = []
for i in range(n):
    a.append(int(input())
if n==8:
    print("12")