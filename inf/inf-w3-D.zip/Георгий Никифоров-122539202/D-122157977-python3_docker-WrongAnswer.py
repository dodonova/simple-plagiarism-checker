line_ct = int(input())
line_len = sorted(map(int, input().split()))

horis_line = line_len[::2]
vert_line = line_len[1::2]

min_horis = min(horis_line)
min_vert = min(vert_line)

for i in range(line_ct):
    minLen = int(min(horis_line[0], vert_line[0]))
    if minLen == horis_line[0]:
        if minLen < len(vert_line):
            horis_line.pop(0)
    else:
        if minLen < len(horis_line):
            horis_line.pop(0)
print(len(vert_line)*len(horis_line))