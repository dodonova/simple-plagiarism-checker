n=int(input())
mas1 = list(map(int, input().split()))
i=-1
K=0
S=0
M=0
mas2=[]
while i < (n-1) and K < (n-1):
    i = i+1 
    while i < n and K < n:
        sum = mas1[i]+mas1[K]
        K=K+1
        
        if sum <= n:
            S=mas1[i]*mas1[K]
            mas2.append(S)
M = max(mas2)            
print (M)