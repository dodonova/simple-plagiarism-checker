n, *rest = map(int, """8
3 6 5 4 4 5 5 2""".split())
ai = rest
ai.sort(reverse=True)

max_area = 0
n = len(ai)

# Prefix sums of counts of lengths >= i
cnt_len_geq = [0] * (n + 2)
for i in range(n):
    cnt_len_geq[i + 1] = cnt_len_geq[i] + 1

for H in range(1, n + 1):
    # Length of the H-th longest strip
    min_len_h = ai[H - 1]
    # Maximum possible V
    V_max = min(min_len_h, n - H)
    if V_max < 1:
        continue
    # Number of strips with length >= H
    cnt_len_geq_H = 0
    for i in range(H, n):
        if ai[i] >= H:
            cnt_len_geq_H += 1
        else:
            break
    cnt_vertical = cnt_len_geq_H
    V = min(V_max, cnt_vertical)
    area = H * V
    if area > max_area:
        max_area = area

print(max_area)