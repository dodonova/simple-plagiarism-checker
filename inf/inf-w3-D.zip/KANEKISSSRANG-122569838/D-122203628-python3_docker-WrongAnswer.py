def max_beb(b):
    b.pop
    for i in range(a):
        if i>=a/2:
            l1.append(b[i])
        else:
            l2.append(b[i])
    mina=min(l1)* min(l2)
    return(mina)
a=int(input())
a=a-1
l1=[]
l2=[]
b = list(map(int, input().split()))
f = max_beb(b)
print(f)