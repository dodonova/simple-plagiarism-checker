def max_braiding_area(n, lengths):
    lengths.sort(reverse=True)
    
    if n % 2 == 0:
        area = lengths[n // 2 - 1] * lengths[n // 2]
    else:
    
    return area

n = int(input().strip())
lengths = list(map(int, input().strip().split()))

result = max_braiding_area(n, lengths)
print(result)