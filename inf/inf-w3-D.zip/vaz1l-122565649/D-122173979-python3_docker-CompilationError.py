def max_area(n, lengths):

    lengths.sort()

    horizontal_lengths = lengths[:n//2]
    vertical_lengths = lengths[n//2:]

    horizontal_sum = sum(horizontal_lengths)
    vertical_sum = sum(vertical_lengths)

return horizontal_sum * vertical_sum

n = int(input())
lengths = list(map(int, input().split()))

print(max_area(n, lengths))