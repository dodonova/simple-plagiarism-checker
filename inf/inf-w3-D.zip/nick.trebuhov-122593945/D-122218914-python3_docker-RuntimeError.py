n = int(input())
ai = map(int, input().split())
def max_plaited_mat_area(n, ai):
 
    ai.sort(reverse=True)
    max_area = 0

    for m in range(1, n + 1):
        
        min_length_horizontal = ai[m - 1]

        
        left = m  
        right = n  

        while left < right:
            mid = (left + right) // 2
            if ai[mid] >= m:
                left = mid + 1
            else:
                right = mid
        
        cnt_v = left - m

        n_v = min(cnt_v, min_length_horizontal)

        if n_v >= 1:
            area = m * n_v
            if area > max_area:
                max_area = area
print(max_area)