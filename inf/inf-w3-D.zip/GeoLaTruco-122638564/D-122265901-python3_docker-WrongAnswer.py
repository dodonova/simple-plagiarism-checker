def max_palet(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Полоски для желтого и зеленого
    half_n = n // 2

    # Максимальная площадь
    if n % 2 == 0:
        max_length_horizontal = lengths[0]
        max_length_vertical = lengths[half_n]
    else:
        max_length_horizontal = lengths[0]
        max_length_vertical = lengths[half_n + 1]
    
    # Возвращаем площадь
    return max_length_horizontal * max_length_vertical

# Ввод данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вывод результата
print(max_palet(n, lengths))