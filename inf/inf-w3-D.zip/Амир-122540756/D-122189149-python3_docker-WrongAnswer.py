n = int(input())
lengths = list(map(int, input().split()))

# Сортировка списка длин по убыванию
lengths.sort(reverse=True)

# Переменные для хранения двух максимальных сторон
first_pair = None
second_pair = None

# Поиск двух наибольших пар длин
i = 0
while i < n - 1:
    # Проверяем, соответствуют ли текущая полоска и следующая критерию пары
    if lengths[i] == lengths[i + 1] or lengths[i] - 1 == lengths[i + 1]:
        # Если первая пара ещё не найдена, заносим текущую
        if first_pair is None:
            first_pair = lengths[i + 1]
            i += 1  # Пропустим следующую полоску, так как она уже в паре
        # Иначе, это вторая пара
        elif second_pair is None:
            second_pair = lengths[i + 1]
            break  # После нахождения второй пары - выходим из цикла
    i += 1

# Если обе пары найдены, можем вычислить максимальную площадь
max_area = 0
if first_pair is not None and second_pair is not None:
    max_area = first_pair * second_pair

print(max_area)
