n = int(input())
lengths = list(map(int, input().split()))

# Сортировка списка длин по убыванию
lengths.sort(reverse=True)

# Инициализация переменных для хранения максимальной возможной ширины и высоты
max_width = 0
max_height = 0

# Поиск двух наибольших пар длин
i = 0
while i < len(lengths) - 1:
    if lengths[i] == lengths[i+1] or lengths[i] == lengths[i+1] + 1:
        if max_width == 0:
            max_width = lengths[i+1]
        else:
            max_height = lengths[i+1]
            break
    i += 1

# Вычисление максимальной площади прямоугольника
max_area = max_width * max_height
print(max_area)
