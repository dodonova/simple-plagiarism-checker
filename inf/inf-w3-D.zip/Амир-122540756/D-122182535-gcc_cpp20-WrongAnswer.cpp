#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }

    // Сортируем длины полосок
    sort(a.begin(), a.end());

    // Суммы для двух групп полосок
    long long sum1 = 0, sum2 = 0;

    // Суммируем половину массива для одной группы, оставшуюся для другой
    for (int i = 0; i < n / 2; ++i) {
        sum1 += a[i];
    }
    for (int i = n / 2; i < n; ++i) {
        sum2 += a[i];
    }

    // Максимальная площадь
    long long maxArea = sum1 * sum2;

    cout << maxArea << endl;

    return 0;
}
