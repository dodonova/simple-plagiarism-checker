#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<long long> lengths(n);
    
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }

    // Сортировка полосок в порядке убывания
    sort(lengths.rbegin(), lengths.rend());

    // Переменные для хранения двух наибольших пар
    long long max_width = 0, max_height = 0;

    // Поиск двух наибольших длин, которые могут выступать сторонами
    for (int i = 0; i < n - 1; ++i) {
        if (lengths[i] == lengths[i + 1]) {
            if (max_width == 0) {
                max_width = lengths[i];
                ++i; // пропускаем следующую полоску, так как она уже вошла в пару
            } else {
                max_height = lengths[i];
                break;
            }
        }
    }

    // Вычисление площади прямоугольника
    long long max_area = max_width * max_height;
    cout << max_area << endl;

    return 0;
}
