#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<long long> lengths(n);

    for (int i = 0; i < n; i++) {
        cin >> lengths[i];
    }

    // Сортируем длины в порядке убывания
    sort(lengths.begin(), lengths.end(), greater<long long>());

    long long width = 0, height = 0;

    // Ищем две наибольшие длины, которые встречаются хотя бы дважды.
    // Эти две длины будут использованы для расчета площади плетёнки.
    for (int i = 1; i < n; i++) {
        if (lengths[i] == lengths[i - 1] || lengths[i] == lengths[i - 1] - 1) {
            if (width == 0) {
                width = lengths[i];
            } else {
                height = lengths[i];
                break;
            }
            i++; // Пропускаем следующее число, чтобы не использовать его дважды
        }
    }
    
    // Вычисляем площадь плетёнки
    cout << width * height << endl;

    return 0;
}
