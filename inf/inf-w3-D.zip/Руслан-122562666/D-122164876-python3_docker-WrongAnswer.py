def max_braided_area(n, lengths):
    # Инициализируем две максимальные длины
    max1 = max2 = 0
    
    for length in lengths:
        if length > max1:
            max2 = max1
            max1 = length
        elif length > max2:
            max2 = length
    
    # Площадь максимальной плетёнки
    max_area = max1 * max2
    return max_area

# Ввод данных
import sys

input = sys.stdin.read
data = input().split()

n = int(data[0])
lengths = list(map(int, data[1:n+1]))

# Получение результата и вывод его
result = max_braided_area(n, lengths)
print(result)