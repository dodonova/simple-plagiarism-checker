n = int(input())
a = list(map(int, input().strip().split(' ')))
a.sort()
ans = 0
for i in range(n, 0, -1):
    if i == 1:
        print(1)
        break
    width = i // 2
    height = i - width
    if all(map(lambda x: x >= min(width, height), a[i-1:-1:-1])):
        print(width * height)
        break

