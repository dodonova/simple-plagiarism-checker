n = int(input())
dl = list(map(int, input().split()))

dl.sort()

pl = 0

for i in range(len(dl) - 1):
    if len(dl) - (i + 2) >= dl[i] + dl[i + 1] - 2 and dl[i] * dl[i + 1] > pl:
        pl = dl[i] * dl[i + 1]
    if len(dl) - (i + 2) < dl[i] + dl[i + 1] - 2:
        if len(dl) - (i + 2) % 2 == 1 and ((len(dl) - (i + 2)) // 2 + 2) * (len(dl) - (i + 2) // 2 + 1) > pl:
            pl = (len(dl) - (i + 2) // 2 + 2) * ((len(dl) - (i + 2)) // 2 + 1)
        elif len(dl) - (i + 2) // 2 != 0 and ((len(dl) - (i + 2)) / 2 + 1) ** 2 > pl:
            pl = ((len(dl) - (i + 2)) / 2 + 1) ** 2

print(int(pl))