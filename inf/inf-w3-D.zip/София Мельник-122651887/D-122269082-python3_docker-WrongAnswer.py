n = int(input())

stripes = list(map(int, input().split()))
stripes.sort()

best = 0
for i in range(1,n-1):
    if (n-i+1) >= (stripes[i]+stripes[i-1]):
        best = max(best, stripes[i]*stripes[i-1])
print(best)

