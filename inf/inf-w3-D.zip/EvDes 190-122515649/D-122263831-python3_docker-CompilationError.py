n = int(input())
a = list(map(int, input().split()))
a.sort()

i = len(a)

maxs = []

for y in range(1, int(i/2)):
	b = a
    
	g = i - y
    while min(b) < y: b.remove(min(b))
    miny = b[0]
    ming = b[y]
    
    maxs.append(miny * miny)
print(max(maxs))