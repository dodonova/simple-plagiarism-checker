n = int(input())
a = list(map(int, input().split()))

s = 0

while a:
	s1 = min(a) * len(a) - min(a)

	if s< s1:
		s = s1
	a.remove(min(a))
print(s)