def area(x1, y1, x2, y2, x3, y3):
    return abs(x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0

def min_area_difference(n, m, x, y):
    # Площадь всего пирога
    total_area = n * m

    # Разрезы:
    # 1. Из (0, 0) в (x, y)
    A1 = area(0, 0, x, y, x, 0)  # Area 1
    B1 = total_area - A1         # Area 2
    diff1 = abs(A1 - B1)

    # 2. Из (n, 0) в (x, y)
    A2 = area(n, 0, x, y, x, 0)  # Area 1
    B2 = total_area - A2         # Area 2
    diff2 = abs(A2 - B2)

    # 3. Из (0, m) в (x, y)
    A3 = area(0, m, x, y, x, m)  # Area 1
    B3 = total_area - A3         # Area 2
    diff3 = abs(A3 - B3)

    # 4. Из (n, m) в (x, y)
    A4 = area(n, m, x, y, x, m)  # Area 1
    B4 = total_area - A4         # Area 2
    diff4 = abs(A4 - B4)

    # Минимальная разница
    return min(diff1, diff2, diff3, diff4)

# Считываем входные данные
n, m = map(int, input().split())
x, y = map(int, input().split())

# Находим минимальную разницу
result = min_area_difference(n, m, x, y)
print(f"{result:.6f}")
