 
def max_area(lengths):
    lengths.sort(reverse=True)
    total_area = 0
    for i in range(len(lengths)):
        total_area += lengths[i]
        if total_area > lengths[i]:
            return total_area
    return total_area

# Пример ввода
n = 11
lengths = [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

# Вычисление максимальной площади
max_area = max_area(lengths)

# Вывод результата
print(max_area)
 

