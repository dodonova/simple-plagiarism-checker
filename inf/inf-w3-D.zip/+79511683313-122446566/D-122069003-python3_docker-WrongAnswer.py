def max_braid_area(n, lengths):
  lengths.sort(reverse=True)

  yellow_lengths = lengths[::2] # Взять элементы с четными индексами (0, 2, 4, ...)
  green_lengths = lengths[1::2] # Взять элементы с нечетными индексами (1, 3, 5, ...)

  
  max_area = sum(yellow_lengths) * sum(green_lengths)

  return max_area

n = int(input())
lengths = list(map(int, input().split()))

max_area = max_braid_area(n, lengths)
print(max_area)
