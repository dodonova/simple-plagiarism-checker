def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)
    
   
    first_max = lengths[0]  
    second_max = lengths[1]  
    area = first_max * second_max
    return area
n = int(input())
lengths = list(map(int, input().split()))
result = max_weaving_area(n, lengths)
print(result)
