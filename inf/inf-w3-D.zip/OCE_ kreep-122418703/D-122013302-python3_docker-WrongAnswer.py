def max_plenka_area(n, lengths):
    lengths.sort()
    
    half = n // 2
    horizontal = sum(lengths[:half])
    vertical = sum(lengths[half:])
    return horizontal * vertical
n = int(input())
lengths = list(map(int, input().split()))
print(max_plenka_area(n, lengths))
