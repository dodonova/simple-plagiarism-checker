n = int(input())
lengths = list(map(int, input().split()))

# Сортируем полоски по возрастанию
lengths.sort()

# Находим наибольшую длину для ширины
max_width = lengths[-1]  # последняя полоска - самая длинная

# Находим наибольшую длину для высоты
max_height = lengths[0]  # первая полоска - самая короткая

# Выводим результат
print(max_width * max_height)