#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<int> strips(n);
    for (int i = 0; i < n; i++) {
        cin >> strips[i];
    }

    sort(strips.begin(), strips.end());

    int maxArea = 0;
    for (int i = 0; i < n / 2; i++) {
        maxArea = max(maxArea, strips[i] * strips[n - i - 1]);
    }

    cout << maxArea << endl;

    return 0;
}