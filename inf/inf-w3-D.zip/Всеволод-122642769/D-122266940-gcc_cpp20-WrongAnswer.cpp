#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<int> lengths(n);
    for (int i = 0; i < n; i++) {
        cin >> lengths[i];
    }

    // Сортируем вектор длин в порядке убывания
    sort(lengths.begin(), lengths.end(), greater<int>());

    long long maxArea = 0;
    long long sum1 = 0, sum2 = 0;

    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            sum1 += lengths[i];
        } else {
            sum2 += lengths[i];
        }
    }

    // Находим максимальную площадь
    maxArea = sum1 * sum2;

    cout << maxArea << endl;

    return 0;
}