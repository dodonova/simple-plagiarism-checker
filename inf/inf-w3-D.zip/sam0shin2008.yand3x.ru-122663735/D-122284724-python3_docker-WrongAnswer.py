n=int(input())
b=list(map(int,input().split()))
b.sort()
smax=0
for i in range(n):
    for j in range(i,n):
        s=min(b[i],n-j)*min(b[j],j-i)
        print(i,j,"-",b[i],j-i,"-",n-j,b[j],"-",s)
        if s>smax:
            smax=s
print(smax)