x = int(input())
numbers = list(map(int, input().split()))
threshold = x // 2
numbers.sort()
for i in numbers:
    if i < threshold:
        numbers.remove(i)
        x += -1
        threshold = x // 2
result = numbers[0] * numbers[1]
print(result)
