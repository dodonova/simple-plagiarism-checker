n = int(input())
a = list(map(int, input().split()))
from collections import Counter

length_counts = Counter(a)
unique_lengths = sorted(length_counts.keys(), reverse=True)

cumulative_counts = []
total = 0
length_to_cumulative_count = {}
for length in unique_lengths:
    count = length_counts[length]
    total += count
    cumulative_counts.append((length, total))
    length_to_cumulative_count[length] = total

max_area = 0
for length, cnt_H in cumulative_counts:
    H = length
    V_max = cnt_H - H 
    if V_max > 0:
        area = H * V_max
        if area > max_area:
            max_area = area

print(max_area)