import sys

def main():
    import threading
    def solve():
        n_and_rest = sys.stdin.read().split()
        n = int(n_and_rest[0])
        lengths = list(map(int, n_and_rest[1:]))

        # Отсортируем длины в порядке убывания
        lengths.sort(reverse=True)

        max_area = 0
        h = 0  # Количество горизонтальных полосок
        j = 0  # Индекс для вертикальных полосок

        for i in range(n):
            h += 1  # Предполагаемое количество горизонтальных полосок
            min_length_h = lengths[i]  # Минимальная длина среди выбранных горизонтальных полосок

            # Ищем максимальное количество вертикальных полосок v,
            # таких что длина каждой >= h
            while j < n and lengths[j] >= h:
                j += 1

            v = min(min_length_h, j - h)
            if v < 0:
                continue

            area = h * v
            if area > max_area:
                max_area = area

        print(max_area)

    threading.Thread(target=solve).start()

if __name__ == "__main__":
    main()