def max_weaving_area(lengths):
    unique_lengths = sorted(set(lengths), reverse=True)  # Уникальные длины, сортируем
    if len(unique_lengths) < 2:
        return 0  # Невозможно создать плетенку, если меньше двух уникальных длин
    # Две максимально возможные длины
    max_length1 = unique_lengths[0]
    max_length2 = unique_lengths[1]
    return max_length1 * max_length2  # Площадь

# Чтение входных данных
n = int(input("Введите количество длин: "))  # Подсказка для пользователя
lengths = list(map(int, input("Введите длины, разделенные пробелами: ").split()))

# Проверяем правильность ввода
if len(lengths) != n:
    print("Ошибка: количество введенных длин не соответствует указанному.")
else:
    # Вычисление и вывод максимальной площади
    print(max_weaving_area(lengths))