import numpy as np

def max_weaving_area(n, lengths):
    lengths = np.sort(lengths)[::-1]  # Сортировка в порядке убывания
    total_length = np.sum(lengths)  # Общая длина
    max_area = 0

    for i in range(1, n):  # i - количество полосок для высоты 
        height = lengths[i - 1]  # высота
        width = total_length - np.sum(lengths[:i])  # ширина
        area = height * (n - i)  # площадь
        max_area = max(max_area, area)

    return max_area 

# Чтение данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление максимальной площади
result = max_weaving_area(n, np.array(lengths))

# Вывод результата
print(result)