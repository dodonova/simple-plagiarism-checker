def max_weaving_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()
    
    # Поскольку мы хотим максимизировать площадь, мы берем две половины
    mid = n // 2
    
    # Определяем длины для горизонтальных и вертикальных полосок
    if n % 2 == 0:
        horizontal = sum(lengths[mid:])
        vertical = sum(lengths[:mid])
    else:
        horizontal = sum(lengths[mid+1:])
        vertical = sum(lengths[:mid+1])
    
    # Площадь плетенки равна произведению длин горизонтальных и вертикальных полосок
    return min(horizontal, vertical) * 2

# Чтение входных данных
import sys
input = sys.stdin.read
data = input().split()

n = int(data[0])
lengths = list(map(int, data[1:]))

# Вычисление и вывод результата
result = max_weaving_area(n, lengths)
print(result)