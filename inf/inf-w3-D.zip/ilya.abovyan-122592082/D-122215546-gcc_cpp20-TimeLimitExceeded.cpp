#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int total_lengths;
    std::cin >> total_lengths;
    std::vector<int> lengths_array(total_lengths);

    for (int i = 0; i < total_lengths; ++i) {
        std::cin >> lengths_array[i];
    }

    std::sort(lengths_array.begin(), lengths_array.end(), std::greater<int>());
    int maximum_area = 0;

    for (int height = 1; height <= total_lengths; ++height) {
        int min_length_for_current_height = lengths_array[height - 1];
        int available_count = std::min(min_length_for_current_height, total_lengths - height);
        
        int vertical_count = 0;
        for (int j = height; j < total_lengths; ++j) {
            if (lengths_array[j] >= height) {
                vertical_count++;
            } else {
                break;
            }
        }

        available_count = std::min(available_count, vertical_count);
        int current_area = height * available_count;

        maximum_area = std::max(maximum_area, current_area);

        if (available_count == 0) {
            break;
        }
    }

    std::cout << maximum_area << std::endl;
    return 0;
}