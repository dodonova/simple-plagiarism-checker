def max_rectangle_area(n, a):
    sums = [0] * len(a) + [0]
    
    for x in range(len(a)):
        for y in range(x, len(sums)):
            sums[y] += a[x]
            
    result = min(sums)
    
    return result ** 2

n = int(input())
a = list(map(int, input().split()))

print(max_rectangle_area(n, a))