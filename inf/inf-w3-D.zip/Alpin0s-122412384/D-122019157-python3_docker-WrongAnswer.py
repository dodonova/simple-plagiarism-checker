def max_weaving_area(n, a):
    a.sort()  # Сортируем полоски по длине
    max_area = 0

    # Перебираем все возможные точки разделения
    for i in range(1, n):
        horizontal_length = a[i - 1]  # Длина горизонтальной полоски (максимальная из первой группы)
        vertical_length = a[n - i]  # Длина вертикальной полоски (максимальная из второй группы)

        current_area = horizontal_length * vertical_length  # Площадь плетёнки
        max_area = max(max_area, current_area)  # Обновляем максимальную площадь

    return max_area

# Чтение входных данных
n = int(input())
a = list(map(int, input().split()))

# Вывод максимальной площади
print(max_weaving_area(n, a))
