n = int(input())
a = list(map(int, input().split()))
from collections import Counter

# Count the frequencies of each length
length_counts = Counter(a)
unique_lengths = sorted(length_counts.keys(), reverse=True)

# Calculate cumulative counts
cumulative_counts = []
total = 0
for length in unique_lengths:
    total += length_counts[length]
    cumulative_counts.append((length, total))

max_area = 0
for idx, (L, N_L) in enumerate(cumulative_counts):
    s = N_L
    h = min(s // 2, L)
    v = min(s - h, L)
    area = h * v
    if area > max_area:
        max_area = area

print(max_area)