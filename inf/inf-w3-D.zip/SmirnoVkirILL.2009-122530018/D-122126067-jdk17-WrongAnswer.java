import java.util.Arrays;

public class Plenka {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4}; // Пример длины полосок
        System.out.println(maxArea(a));
    }

    public static int maxArea(int[] a) {
        int n = a.length;
        int maxArea = 0;

        for (int mask = 1; mask < (1 << n); mask++) {
            int length1 = 0, length2 = 0, count1 = 0, count2 = 0;

            for (int i = 0; i < n; i++) {
                if ((mask & (1 << i)) > 0) {
                    length1 += a[i];
                    count1++;
                } else {
                    length2 += a[i];
                    count2++;
                }
            }

            if (count1 > 0 && count2 > 0) {
                int area = Math.min(count1, count2) * Math.min(length1, length2);
                maxArea = Math.max(maxArea, area);
            }
        }
        return maxArea;
    }
}