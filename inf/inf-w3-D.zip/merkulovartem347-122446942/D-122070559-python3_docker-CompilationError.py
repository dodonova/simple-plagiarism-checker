mport numpy as np

def f(a, b, c):
    if len(c) == 0:
        n = 0  
        k = 0  
    
        i, j = 0, 0  
    
        while i < len(a) or j < len(b):
     
            if i < len(a) and a[i] >= k:
                n += 1
            i += 1
            if j < len(b) and b[j] >= n:
                k += 1
            j += 1
    
        return n*k
    else:
        print(a,b,c)
        return max(f(np.append(a, c[0]), b,np.delete(c, 0)), f(a,np.append(b, c[0]),np.delete(c, 0)))

n = int(input())
c = np.array(list(map(int, input().split())))
c = np.sort(c)[::-1]

a = np.array([])
b = np.array([])
print(f(a,b,c))