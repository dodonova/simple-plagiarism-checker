def max_plait_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)

    # Поскольку необходимо разбить полоски на 2 группы, 
    # нам нужно как минимум 2 полоски.
    if n < 2:
        return 0

    # Используем 2 наибольшие длины
    max_length1 = lengths[0]
    max_length2 = lengths[1]

    # Площадь будет равна произведению
    return max_length1 * max_length2

if __name__ == "__main__":
    import sys
    
    # Чтение входных данных
    input_data = sys.stdin.read().strip().split()
    n = int(input_data[0])  # количество полосок
    lengths = list(map(int, input_data[1:n+1]))  # длины полосок

    # Вычисление максимальной площади плетёнки
    result = max_plait_area(n, lengths)
    
    # Вывод результата
    print(result)