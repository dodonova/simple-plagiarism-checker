def p(arr):
    min_block = min(arr)
    max_block = max(arr)
    width = max_block - min_block + 1
    height = len(arr)
    
    perimeter = 2 * (width + height)
    return perimeter
n = int(input())
arr = list(map(int, input().split()))
print(p(arr))
