from itertools import combinations

def max_weave_area(strips):
    max_area = 0

    for horizontal in range(1, len(strips)//2 + 1):
        for hor_comb in combinations(strips, horizontal):
            remaining_strips = [strip for strip in strips if strip not in hor_comb]
            for ver_comb in combinations(remaining_strips, horizontal):
                area = sum(hor_comb) * sum(ver_comb)
                max_area = max(max_area, area)

    return max_area

n = int(input())
strips = list(map(int, input().split()))

print(max_weave_area(strips))