def our_max_area(n,lengths):
	lengths.sort(reverse=True)
	max_area = 0
	for i in range(1,n):
	yellow = sum(lengths[:i])
	green = sum(lengths[i:])
	area = i * min(yellow, green)
	max_area = max(max_area, area)
return max_area
n = int(input(()
lengths = list(map(int, input().split()))
print(our_max_area(n, lengths))