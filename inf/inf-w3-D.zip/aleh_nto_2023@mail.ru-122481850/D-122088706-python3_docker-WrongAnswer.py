n = int(input())
a = sorted(map(int, input().split()))
r = []
for i in range(1, n):
    if a[i-1] + a[i] <= n:
        r.append(a[i-1] * a[i])
        n -= 1
        continue
    print(max(r))
    break