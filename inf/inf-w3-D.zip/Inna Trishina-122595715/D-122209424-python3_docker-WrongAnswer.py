def max_plait_area(n, lengths):  
    # Сортируем длины полосок  
    lengths.sort()  
    
    # Общая сумма всех полосок  
    total_sum = sum(lengths)  
    
    max_area = 0  
    
    # Считаем нужные суммы и максимальную площадь  
    current_sum = 0  
    for i in range(n - 1):  # Не включая последний элемент для разбивки  
        current_sum += lengths[i]  
        remaining_sum = total_sum - current_sum  
        area = current_sum * remaining_sum  
        if area > max_area:  
            max_area = area  
    
    return max_area  

# Чтение входных данных  
n = int(input().strip())  
lengths = list(map(int, input().strip().split()))  

# Вызов функции и вывод результата  
result = max_plait_area(n, lengths)  
print(result)