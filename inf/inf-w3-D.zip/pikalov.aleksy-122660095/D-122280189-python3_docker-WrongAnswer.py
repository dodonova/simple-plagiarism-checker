n = int(input())
a = sorted(map(int, input().split()), reverse=True)

l = []
x, y = (a[0], 1), (a[1], 1)

for i in range(2, len(a)):
    if i % 2 == 0:
        x = (a[i], x[1] + 1)
    else:
        y = (a[i], y[1] + 1)
    l += [min(x[0], y[0]) * min(x[1], y[1])]
    
print(max(l))