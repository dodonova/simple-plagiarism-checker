def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    for k in range(1, n // 2 + 1):
        max_area = max(max_area, 2 * k * lengths[k - 1])
    return max_area

n = int(input().strip())
lengths = list(map(int, input().strip().split()))
result = max_weaving_area(n, lengths)
print(result)
