def max_area(lengths):
    lengths.sort(reverse=True)
    
   
    max_area = 0
    for i in range(0, len(lengths) - 1, 2):
        if i + 1 < len(lengths):
            area = lengths[i] * lengths[i + 1]
            max_area = max(max_area, area)

    return max_area


n = int(input("Введите количество полосок: "))
lengths = list(map(int, input("Введите длины полосок через пробел: ").split()))

result = max_area(lengths)


print(f"Максимальная площадь плетёнки: {result}")
