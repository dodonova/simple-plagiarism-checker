def max_weaving_area(n, lengths):
 
    lengths.sort(reverse=True)
    
    max_area = 0
    

    for i in range(n):
        
        count = i + 1
   
        length = lengths[i]
        
      
        area = count * length
        
     
        max_area = max(max_area, area)
    
    return max_area

def main():
    
    n = int(input().strip())
    lengths = list(map(int, input().strip().split()))
    
 
    result = max_weaving_area(n, lengths)
    
  
    print(result // 2)  

if __name__ == "__main__":
    main()