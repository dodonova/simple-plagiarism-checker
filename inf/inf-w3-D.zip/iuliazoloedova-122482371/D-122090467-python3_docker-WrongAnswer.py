def count_matrices(n, m, a, b):
    # Инициализация таблицы для динамического программирования
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    dp[a][b] = 1

    # Заполнение таблицы
    for i in range(a, n + 1):
        for j in range(b, m + 1):
            if i > a:
                dp[i][j] += dp[i - 1][j]
            if j > b:
                dp[i][j] += dp[i][j - 1]

    return dp[n][m]

# Пример использования
n, m = 5, 3
a, b = 2, 2

result = count_matrices(n, m, a, b)
print("Количество способов достроить матрицу:", result)

