def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)
    k = n // 2 * 2
    if k == 0:
        return 0
    sum_horizontal = sum(lengths[:k // 2])
    sum_vertical = sum(lengths[k // 2:k])
    area = sum_horizontal * sum_vertical
    return area
n = int(input())
lengths = list(map(int, input().strip().split()))
print(max_weaving_area(n, lengths))