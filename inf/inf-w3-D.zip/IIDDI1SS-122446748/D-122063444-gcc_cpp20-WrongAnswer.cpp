#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }

    // Сортируем длины полосок по убыванию
    sort(lengths.rbegin(), lengths.rend());

    // Площадь плетёнки будет максимальной, если мы возьмём две самыя длинные полоски
    // Для получения площади, мы умножаем их длины
    long long maxArea = static_cast<long long>(lengths[0]) * lengths[1];

    cout << maxArea << endl;
    return 0;
}