n = int(input())
a = list(map(int, input().split()))
a.sort(reverse=True)


max_area = 0
for i in range(n):
    for j in range(i + 1, n):
        area = a[i] * a[j]
        if area > max_area:
            max_area = area

print(max_area)