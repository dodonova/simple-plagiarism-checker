n = int(input())
a = list(map(int, input().split()))a.sort(reverse=True)
# Ищем пары одинаковой длины
pairs = []
i = 0
while i < n - 1:
    if a[i] == a[i + 1]:        
        pairs.append(a[i])
        i += 2    
    else:
        i += 1
# Берём две максимальные парыif len(pairs) < 2:
print(0)else:
print(pairs[0] * pairs[1])