def max_plait_area(n, a):
    a.sort()

    horizontal = sum(a[n // 2:])

    vertical = sum(a[:n // 2])

    max_area = horizontal * vertical

    return max_area


n = int(input())
a = list(map(int, input().split()))

print("Максимальная площадь плетёнки:", max_plait_area(n, a))

