def max_rectangle_area(n, lengths):    # Сортируем длины полос по убыванию
    lengths.sort(reverse=True)    
    side1 = min(lengths[0], lengths[1])  # Берем минимум из двух самых длинных    
	side2 = min(lengths[2], lengths[3])  # Берем минимум из следующих двух самых длинных
        # Возвращаем площадь прямоугольника
    return side1 * side2
n = int(input())  # Количество полос
lengths = list(map(int, input().split()))  # Длины полос
print(max_rectangle_area(n, lengths))