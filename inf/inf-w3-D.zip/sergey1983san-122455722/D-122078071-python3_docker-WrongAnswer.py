def max_plait_area(n, a):
    a.sort(reverse=True)

    horizontal = a[0] // 2
    vertical = a[1] // 2

    for i in range(2, n):
        horizontal += a[i] // 2
        vertical += a[i] // 2

    area = min(horizontal, vertical) * 2

    return area


n = int(input())
a = list(map(int, input().split()))
print(int(max_plait_area(n, a)/2))
