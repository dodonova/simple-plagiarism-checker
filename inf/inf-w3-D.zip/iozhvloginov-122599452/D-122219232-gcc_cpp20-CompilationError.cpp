#include <iostream>
#include <cmath>
#include <algorithm> // Для min и max
#include <tuple>
#include <fstream> //для работы с файлами как потоками
#include <vector>

using namespace std;

// DEBUG
#define DEBUG
#ifdef DEBUG
ifstream fin("input.txt");
ofstream fout("output.txt");
#define cin fin
#define cout fout
#endif // DEBUG


int main() {
    int k;
    cin >> k; 

    vector<int> l(k);
    for (int i = 0; i < k; ++i) {
        cin >> l[i]; 
    }

    sort(l.begin(), l.end()); 
    int last_i=0;
    int a,b;

    for (int i = 1; i < k; ++i) {
        a = l[i - 1];
        b = l[i];
        if (k - (i + 1) >= a + b - 2) {
            last_i=i;
        } else {
            break; 
        }
    }

    if (last_i>0) {
        a = l[last_i - 1];
        b = l[last_i];
        cout << a * b << endl; 
    } else {
        cout << 0 << endl; 

    return 0;
}
