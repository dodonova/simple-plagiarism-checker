def max_woven_area_greedy(n, lengths):
    lengths.sort(reverse=True)
    sum_horizontal = 0
    sum_vertical = 0
    
    for length in lengths:
        if sum_horizontal < sum_vertical:
            sum_horizontal += length
        else:
            sum_vertical += length
    
    return sum_horizontal * sum_vertical

# Пример использования
n = int(input())
lengths = list(map(int, input().split()))
print(max_woven_area_greedy(n, lengths))