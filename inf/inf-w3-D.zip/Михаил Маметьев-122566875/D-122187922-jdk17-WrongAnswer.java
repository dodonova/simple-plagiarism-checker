import java.util.Arrays;
import java.util.Scanner;

public class MaxAreaSorting {
    public static long maxArea(int n, int[] a) {
        // Сортируем массив по убыванию
        Arrays.sort(a);
        
        long horizontalSum = 0;
        long verticalSum = 0;
        
        // Чередуем четные и нечетные индексы
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                horizontalSum += a[n - 1 - i];
            } else {
                verticalSum += a[n - 1 - i];
            }
        }
        
        // Возвращаем произведение сумм
        return horizontalSum * verticalSum;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Чтение входных данных
        int n = scanner.nextInt();
        int[] a = new int[n];
        
        for (int i = 0; i < n; i++) {
            a[i] = scanner.nextInt();
        }
        
        // Вывод результата
        System.out.println(maxArea(n, a));
    }
}