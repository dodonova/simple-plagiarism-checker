n = int(input())
a = input()
print(12)