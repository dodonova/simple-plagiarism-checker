import statistics

n = int(input())
papers_long = list(map(int, input().split()))
papers_long.sort()
x = n // 2
y = n - x
x = min(papers_long, key=lambda el: abs(el - x))
x_position = papers_long.index(x)
y_position = x_position + 1
y = papers_long[y_position]
while True:
    if x_position == 0 and len(papers_long[x_position:]) >= x + y:
        print(x * y)
        break
    elif x_position == 0:
        print(x_position * y_position)
    else:
        flag = False
        median = statistics.median(papers_long)
        if x <= median:
            check_areas = papers_long[:x_position]
            for i in range(len(check_areas) - 1, -1, -1):
                if check_areas[i] + y <= len(papers_long[i:]):
                    print(check_areas[i] * y)
                    flag = True
                    break
        if flag:
            break
        y_position = x_position
        x_position -= - 1
        x = papers_long[x_position]
        y = papers_long[y_position]
