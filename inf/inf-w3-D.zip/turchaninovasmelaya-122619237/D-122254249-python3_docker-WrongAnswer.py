def max_plaiting_area(n, lengths):
    # Сортируем полоски по убыванию длины
    lengths.sort(reverse=True)
    
    # Инициализируем суммы и максимальную площадь
    left_sum = 0
    right_sum = sum(lengths)
    max_area = 0
    
    # Используем два указателя
    for i in range(n):
        # Добавляем текущую полоску к левой сумме
        left_sum += lengths[i]
        # Убираем текущую полоску из правой суммы
        right_sum -= lengths[i]
        
        # Вычисляем площадь прямоугольника
        area = left_sum * (n - i - 1)
        
        # Обновляем максимальную площадь
        max_area = max(max_area, area)
    
    return max_area

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
result = max_plaiting_area(n, lengths)
print(result)