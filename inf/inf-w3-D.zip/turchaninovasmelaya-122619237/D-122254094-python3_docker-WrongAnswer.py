def max_plaiting_area(n, lengths):
    # Сортируем полоски по убыванию длины
    lengths.sort(reverse=True)
    
    # Инициализируем максимальную площадь
    max_area = 0
    
    # Перебираем все возможные разделения полосок на две группы
    for i in range(1, n):
        # Сумма длин горизонтальных полосок
        horizontal_sum = sum(lengths[:i])
        # Сумма длин вертикальных полосок
        vertical_sum = sum(lengths[i:])
        
        # Вычисляем площадь прямоугольника
        area = horizontal_sum * vertical_sum
        
        # Обновляем максимальную площадь
        max_area = max(max_area, area)
    
    return max_area

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
result = max_plaiting_area(n, lengths)
print(result)