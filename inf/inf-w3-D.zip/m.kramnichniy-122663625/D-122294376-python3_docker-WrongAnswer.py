def main():
    n = int(input())
    lst = list(map(int, input().split()))
    green = []
    yellow = []
    lst.sort()
    for i in range(n):
        if i%2 == 0:
            green.append(lst[i])
        else:
            yellow.append(lst[i])
    maximum = 0
    for i in range(len(yellow)):
        nofi = 0
        for j in green:
            if j >= i+1:
                nofi += 1
        maximum = max(maximum, nofi*(i+1))
    print(maximum)
main()