def max_plait_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Если n нечётное, уменьшаем его на 1
    if n % 2 == 1:
        n -= 1
    
    # Максимальная длина для горизонтальных и вертикальных полосок
    horizontal = lengths[:n//2]
    vertical = lengths[n//2:n]
    
    # Площадь = минимальная длина из горизонтальных * минимальная длина из вертикальных
    area = min(horizontal) * min(vertical)
    
    return area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вывод результата
print(max_plait_area(n, lengths))

