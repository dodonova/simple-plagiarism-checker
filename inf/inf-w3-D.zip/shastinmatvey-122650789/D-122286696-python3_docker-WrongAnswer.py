import itertools as it
import math

def max_weaving_area(n, lengths):
    n = int(n)
    lengths = list(map(int, lengths))

    # Сортируем длины полосок по убыванию
    lengths.sort()
    
    # Используем комбинации для определения размеров плетенок
    max_lengths = [math.comb(n, i) for i in range(1, n//2 + 1)]
    max_shorts = []

    # Сохраняем длину из наибольшего элемента
    max_len = lengths[-1]
    
    for comb in it.combinations(lengths, len(max_lengths)):
        total_sum = sum([l * r for l, r in zip(comb, reversed(max_lengths))])
        
        # Добавляем комбинацию в максимальные плетёнки, если она больше всех предыдущих
        max_shorts.append(abs((sum(comb)/max_len)**2 - total_sum))

    # Возвращаем минимальное значение из наибольших длин, максимальную по длине короткую, и длину наибольшего элемента
    return min(max_lengths + max_shorts + [max_len * len(lengths)])
