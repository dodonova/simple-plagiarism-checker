import sys

def get_maximal_braid(n, lengths):
    # Сортируем полоски по длине в порядке убывания
    lengths.sort(reverse=True)

    # Создаем два массива для горизонтальных и вертикальных полосок
    horizontal = []
    vertical = []

    # Жадный алгоритм - выбираем максимально возможные длины для каждого направления
    max_horizontal = 0
    max_vertical = 0
    for i in range(n):
        if lengths[i] > max_horizontal:
            horizontal.append(lengths[i])
            max_horizontal = lengths[i]
        elif lengths[i] > max_vertical:
            vertical.append(lengths[i])
            max_vertical = lengths[i]

    # Вычисляем площадь
    max_braid = sum(horizontal) * sum(vertical)

    return max_braid

# Тест
n = int(input())
lengths = list(map(int, sys.stdin.readline().split()))
print(get_maximal_braid(n, lengths))

