def max_braid_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Берем максимум два самых длинных отрезка
    # Для формирования базы плетенки
    # Если мы используем эти отрезки, нам нужно, чтобы они были минимум по одной длине
    max_length_1 = lengths[0]
    max_length_2 = lengths[1]

    # Площадь будет равна произведению двух самых длинных полосок
    # Так как мы знаем, что минимальное количество полосок для формирования прямоугольника - это две
    max_area = max_length_1 * max_length_2

    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление максимальной площади
result = max_braid_area(n, lengths)

# Вывод результата
print(result)