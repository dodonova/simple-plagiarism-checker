def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Если у нас есть 2 или более полоски, можем вычислить площадь
    if n >= 2:
        # Две самые длинные полоски
        first = lengths[0]
        second = lengths[1]

        # Затем необходимо подобрать два следующих по длине
        if n > 2:
            third = lengths[2]
            if n > 3:
                fourth = lengths[3]
            else:
                fourth = 0  # Если меньше 4 полосок, оставшиеся будут 0
        else:
            third = fourth = 0  # В случае, если только 2 полоски всего

        # У нас есть две группы полосок:
        # Группа 1: 2 первых длинных полоски, Группа 2: следующие 2
        area1 = max(first * second, first * third, second * third)

        # Поскольку мы можем выбрать полоски по-разному, учтем наиболее высокие из нескольких вариантов
        return max(area1, first * max(second, third, fourth))

# Чтение входных данных
import sys

input = sys.stdin.read
data = input().split()
n = int(data[0])
lengths = list(map(int, data[1:n+1]))

# Вычисление максимальной площади плетёнки
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)
