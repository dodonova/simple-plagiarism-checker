n=int(input())
q=list(map(int,input().split()))
q.sort()
print(q)
smax=0
for i in range(n):
    for j in range(i,n):
        s=min(q[i],n-j)*min(q[j],j-i)
        print(i,j,"-",q[i],j-i,"-",n-j,q[j],"-",s)
        if s>smax:
            smax=s
print(smax)