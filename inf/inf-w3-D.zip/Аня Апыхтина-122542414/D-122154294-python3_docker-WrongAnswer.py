def max_pletenka_area(n, lengths):
    # Сортируем полоски по длине
    lengths.sort()
    
    # Делим полоски на две части
    half = n // 2
    sum_first_half = sum(lengths[:half])
    sum_second_half = sum(lengths[half:])
    
    # Площадь плетёнки — произведение сумм длин
    return sum_first_half * sum_second_half

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод максимальной площади плетёнки
print(max_pletenka_area(n, lengths))