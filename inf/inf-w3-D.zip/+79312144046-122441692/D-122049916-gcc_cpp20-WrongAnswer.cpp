#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main() {
    int n;
    cin >> n;
    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }
    sort(lengths.begin(), lengths.end(), greater<int>());
    vector<long long> pairs;
    int i = 0;
    while (i < n - 1) {
        if (lengths[i] == lengths[i + 1]) {
            pairs.push_back(lengths[i]);
            i += 2;
        } else {
            ++i;
        }
    }
    if (pairs.size() < 2) {
        cout << 0 << endl;
        return 0;
    }
    long long side1 = pairs[0];
    long long side2 = pairs[1];
    cout << side1 * side2 << endl;
    return 0;
}