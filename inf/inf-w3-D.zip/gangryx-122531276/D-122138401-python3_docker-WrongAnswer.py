def max_plait_area(n, lengths):
    lengths.sort(reverse = True)
    
    max_area = 0
    
    current_sum_yellow = 0
    current_sum_green = sum(lengths)
    
    for i in range(n):
        current_sum_yellow += lengths[i]
        current_sum_green -= lengths[i]
        
        yellow_count = i + 1
        green_count = n - yellow_count
        
        if green_count > 0:
            area = yellow_count * current_sum_yellow * green_count * current_sum_green
            max_area = max(max_area, area)
            
    return max_area // 2
            
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

result = max_plait_area(n, lengths)

print(result)