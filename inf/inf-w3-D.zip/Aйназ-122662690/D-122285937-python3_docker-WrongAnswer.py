def max_area(n, lengths):
    lengths.sort(reverse=True)
    half_n = n // 2
    
    return lengths[0] * lengths[half_n]

n = int(input())
lengths = list(map(int, input().split()))
result = max_area(n, lengths)
print(result)