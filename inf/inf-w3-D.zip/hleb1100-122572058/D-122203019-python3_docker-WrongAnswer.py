def max_beb(a):
    a.pop
    for i in range(n):
        if i>=n/2:
            l1.append(a[i])
        else:
            l2.append(a[i])
    mina=min(l1)* min(l2)
    return(mina)
n=int(input())
n=n-1
l1=[]
l2=[]
a = list(map(int, input().split()))
asd = max_beb(a)
print(a)