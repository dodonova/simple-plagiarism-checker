n = int(input())
t = 0
ln = list(map(int, input().split())).sort(reverse=True)

for i in range(1, n):
    ploshad = min(i, n - i) * ln[i - 1]
    maximum = max(maximum, ploshad)
print(maximum(n, lg))