


def max_plait_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)

    # Считаем количество полосок для двух цветовых групп
    horizontal_count = (n + 1) // 2  # Максимум для горизонтальных
    vertical_count = n // 2          # Максимум для вертикальных

    # Длина полосок для максимальной группы
    max_horizontal_length = lengths[0] if horizontal_count > 0 else 0
    max_vertical_length = lengths[horizontal_count] if vertical_count > 0 else 0

    # Площадь плетенки
    max_area = horizontal_count * max_vertical_length  # учитывая, что длины могут отличаться или совпадать

    return max_area

# Пример использования
n = 8
lengths = [3, 6, 5, 4, 4, 5, 5, 2]

result = max_plait_area(n, lengths)
print(result)  # Вывод: 12


