a = int(input())  
b = int(input())  
c = int(input())  
a, b = (reversed(sorted([a, b])))  
x = 1  
y = max([y for y in range(1, b + 1) if x * y + c <= a * b + 1])  
r = x * y  
t = True  

while x + y:  
    if t:  
        x += 1  
        t = False  
    else:  
        y -= 1  
    if x > a or y <= 0:  
        break  
    if x * y + c <= a * b + 1:  
        t = True  
        if r + c < x * y + c:  
            r = x * y  

print(r)