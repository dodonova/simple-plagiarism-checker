def max_plait_area(n, lengths):
    # Сортируем длины полосок lengths.sort()
    k = n // 2
    # Определяем количество полосок в каждой группе k = n // 2 # Минимальные длины для горизонтальных и вертикальных полосок min_length_horizontal = lengths[k - 1]  # k-ая по величине
    min_length_vertical = lengths[n - k]     # (n-k)-ая по величине
    
    # Площадь плетёнки max_area = 2 * k * min(min_length_horizontal, min_length_vertical)
    
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вывод результата
print(max_plait_area(n, lengths))
