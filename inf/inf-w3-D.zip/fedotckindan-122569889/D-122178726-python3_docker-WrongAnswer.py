def max_area(a):
    # Сортируем полоски по длинне
    a.sort()
    n = len(a)

    max_area = 0

    # Перебираем длину одной группы полосок
    for i in range(n):
        height = a[i]
        # Бинарный поиск для нахождения подходящей ширины полосок
        width = 0
        for j in range(n):
            if a[j] >= height:
                width += 1
        # Площадь = высота * ширина
        max_area = max(max_area, height * width)

    return max_area

# Пример использования
strip_lengths = [5, 3, 6, 2]
print(max_area(strip_lengths))