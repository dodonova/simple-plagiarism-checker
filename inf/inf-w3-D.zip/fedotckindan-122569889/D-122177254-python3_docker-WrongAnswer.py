def max_braid_area(n, lengths):
    lengths.sort(reverse=True)

    usable_strips = n // 2 * 2  

    if usable_strips == 0:
        return 0

    max_area = lengths[0] * lengths[usable_strips // 2]
    return max_area

n = int(input())
lengths = list(map(int, input().split()))

print(max_braid_area(n, lengths))