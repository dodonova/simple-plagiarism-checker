def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Инициализируем максимальную площадь
    max_area = 0
    
    # Перебираем возможные точки разделения
    for i in range(1, n):
        sum_yellow = sum(lengths[:i])  # Сумма желтых полос
        sum_green = sum(lengths[i:])   # Сумма зеленых полос
        max_area = max(max_area, sum_yellow * sum_green)
    
    return max_area

# Чтение входных данных
if __name__ == "__main__":
    n = int(input("Введите количество полосок бумаги: "))
    lengths = list(map(int, input("Введите длины полосок через пробел: ").split()))

    # Вычисление максимальной площади
    result = max_weaving_area(n, lengths)

    # Вывод результата
    print(result)