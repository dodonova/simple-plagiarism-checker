import java.util.Arrays;
import java.util.Scanner;

public class MaxWeavingArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Чтение количества полосок
        int n = scanner.nextInt();
        int[] lengths = new int[n];
        
        // Чтение длин полосок
        for (int i = 0; i < n; i++) {
            lengths[i] = scanner.nextInt();
        }
        
        // Сортировка длин полосок
        Arrays.sort(lengths);
        
        // Определение максимальных длин
        int max1 = lengths[n - 1]; // максимальная длина
        int max2 = lengths[n - 2]; // вторая по величине длина
        
        // Вычисление площади
        int maxArea = max1 * max2;
        
        // Вывод результата
        System.out.println(maxArea);
        
        scanner.close();
    }
}