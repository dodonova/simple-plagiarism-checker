def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Площадь = длина самой длинной полоски * длина второй по длине полоски
    max_area = lengths[0] * lengths[1]
    
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление максимальной площади
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)