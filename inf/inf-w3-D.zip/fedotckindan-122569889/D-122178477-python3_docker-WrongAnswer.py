def max_weave_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort(reverse=True)

    # Объявляем переменные для горизонтальных и вертикальных полосок
    horizontal = 0
    vertical = 0

    # Перебираем полоски, чтобы разделить их на два цвета
    for i in range(n):
        # Чередуем добавление в горизонтальные и вертикальные длины
        if i % 2 == 0:
            horizontal += lengths[i]
        else:
            vertical += lengths[i]

    # Площадь плетенки будет равна произведению горизонтальных и вертикальных полосок
    return horizontal * vertical

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
result = max_weave_area(n, lengths)
print(result)
