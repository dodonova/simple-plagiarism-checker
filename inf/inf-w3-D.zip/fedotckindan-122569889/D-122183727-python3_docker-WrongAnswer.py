def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Префиксные суммы
    prefix_sum = [0] * (n + 1)
    
    for i in range(1, n + 1):
        prefix_sum[i] = prefix_sum[i - 1] + lengths[i - 1]
    
    max_area = 0
    
    # Перебираем возможные точки разделения
    for i in range(1, n):
        sum_yellow = prefix_sum[i]  # Сумма желтых полос
        sum_green = prefix_sum[n] - sum_yellow  # Сумма зеленых полос
        max_area = max(max_area, sum_yellow * sum_green)
    
    return max_area

# Чтение входных данных
if __name__ == "__main__":
    n = int(input())
    lengths = list(map(int, input().split()))

    # Вычисление максимальной площади
    result = max_weaving_area(n, lengths)

    # Вывод результата
    print(result)