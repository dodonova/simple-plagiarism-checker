def max_plait_area(n, lengths):  
    # Сортируем длины полосок в порядке убывания  
    lengths.sort(reverse=True)  
    
    # Проверяем, достаточно ли полосок  
    if n < 2:  
        return 0  # Если полосок меньше 2, площадь не может быть вычислена  
    
    # Находим две самые длинные полоски  
    max_height = lengths[0]  # Первая самая длинная  
    max_width = lengths[1]   # Вторая самая длинная  
    
    # Вычисляем площадь  
    return max_height * max_width  

# Чтение входных данных  
input_data = input().strip()  # Считываем вход  
input_list = list(map(int, input_data.split(',')))  # Преобразуем в список  

n = input_list[0]  # Первое число - количество полосок  
lengths = input_list[1:]  # Остальные числа - это длины полосок  

# Проверяем, что количество длин соответствует n  
if len(lengths) != n:  
    raise ValueError(f"Количество длин ({len(lengths)}) не соответствует n ({n}).")  

# Вычисляем максимальную площадь плетёнки  
result = max_plait_area(n, lengths)  

# Выводим результат  
print(result)