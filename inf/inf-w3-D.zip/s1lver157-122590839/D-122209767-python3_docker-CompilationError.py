def max_area(x, y):     
 
    if x < 2: 
        return 0 
    y.sort(reverse=True)    horizontal_sum = 0 
    vertical_sum = 0 
    for i in range(n):        if i % 2 == 0: 
            horizontal_sum += y[i]
			else: 
            vertical_sum += y[i] 
    return horizontal_sum * vertical_sum 
 
x = int(input())y = list(map(int, input().split())) 
if len(y) != x: 
    printelse: 
    print(max_area(x, y))