def max_weaving_area(n, lengths):
   
    max2 = lengths[-2]
    
import sys
input = sys.stdin.read
data = input().strip().split()

n = int(data[0])
lengths = list(map(int, data[1:n+1]))

result = max_weaving_area(n, lengths)

print(result)
