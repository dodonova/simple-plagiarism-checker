def max_weaving_area(n, lengths):
    lengths.sort()
    max_area = 0
    for i in range(n // 2 + 1):
        horizontal_length = lengths[n - 1 - i]
        vertical_length = lengths[i] 
        area = horizontal_length * vertical_length
        return area
n = int(input())
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))