n = int(input())
lengths = list(map(int, input().split()))
lengths.sort(reverse=True)
m = 0
for h in range(1, n + 1):
    min_length_h = lengths[h - 1] if h <= n else 0
    v = min(min_length_h, n - h)
    vertical_lengths = lengths[h:]
    count_v = 0
    for l in vertical_lengths:
        if l >= h:
            count_v += 1
        else:
            break
    v = min(v, count_v)
    a = h * v
    if a > m:
        m = a
    if v == 0:
        break
print(m)