#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;
    std::vector<int> lengths(n);

    for (int i = 0; i < n; ++i) {
        std::cin >> lengths[i];
    }

    std::sort(lengths.rbegin(), lengths.rend());
    int max_area = 0;

    for (int h = 1; h <= n; ++h) {
        int min_length_h = lengths[h - 1];
        int v = std::min(min_length_h, n - h);
        
        int count_v = 0;
        for (int j = h; j < n; ++j) {
            if (lengths[j] >= h) {
                count_v++;
            } else {
                break;
            }
        }

        v = std::min(v, count_v);
        int area = h * v;

        max_area = std::max(max_area, area);

        if (v == 0) {
            break;
        }
    }

    std::cout << max_area << std::endl;
    return 0;
}
