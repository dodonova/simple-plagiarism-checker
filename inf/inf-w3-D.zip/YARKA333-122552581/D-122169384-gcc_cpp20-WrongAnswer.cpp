#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;

    std::vector<int> f(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> f[i];
    }

    std::sort(f.begin(), f.end(), std::greater<int>());

    int max_product = 0;

    for (int d = 1; d < n; ++d) {
        int ma = *std::min_element(f.begin(), f.begin() + d);
        int mb = *std::min_element(f.begin() + d, f.end());

        if (d > mb || (n - d) > ma) {
            continue;
        }

        int product = d * (n - d);
        max_product = std::max(max_product, product);
    }

    std::cout << max_product << std::endl;

    return 0;
}