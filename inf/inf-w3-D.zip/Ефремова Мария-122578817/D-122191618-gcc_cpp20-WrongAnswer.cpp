#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    
    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }
    
    // Сортируем длины в порядке убывания
    sort(lengths.rbegin(), lengths.rend());
    
    long long max_area = 0;

    // Перебираем возможные разделения
    for (int i = 1; i < n; ++i) {
        long long horizontal_length = lengths[i - 1]; // Длина горизонтальной полоски
        long long vertical_length = lengths[i]; // Длина вертикальной полоски
        long long area = horizontal_length * vertical_length;
        max_area = max(max_area, area);
    }

    cout << max_area << endl;

    return 0;
}
