a = []

for i in range(int(input())):
    a.append(int(input()))

middle = sum(a)/len(a)

b = []
c = []

for i in a:
    if i > middle:
        b.append(i)
    else:
        c.append(i)

print(b)
print(c)
