n = int(input().strip())
lengths = list(map(int, input().strip().split()))
def max_plait_area(n, lengths):
    lengths.sort(reverse=True)

half = n // 2
    sum1 = sum(lengths[:half])
    sum2 = sum(lengths[half:])

return min(half, n - half) * min(sum1, sum2)

print(max_plait_area(n, lengths))