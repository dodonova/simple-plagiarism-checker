def max_area_plet(val):
    n = len(val)
    val.sort()
    
    max_area = 0
    
    for i in range(1, n):
        h = i
        v = n - i
        
        min_length_h = val[i - 1]  
        min_length_v = val[i]     

        area = h * v * min(min_length_h, min_length_v)
        max_area = max(max_area, area)

    return max_area
n = int(input())
a = list(map(int, input().split()))
print(max_area_plet(a))