n = int(input())
arr = list(map(int, input().split()))
arr.sort(reverse=True)

distinct_lengths = []
num_counts = []
count = 0
previous_length = None
for i, length in enumerate(arr):
    if length != previous_length:
        distinct_lengths.append(length)
        num_counts.append(n - i)
        previous_length = length

length_to_num = dict(zip(distinct_lengths, num_counts))

max_surface_area = 0
m = len(arr)
for height in range(1, m + 1):
    length_height = arr[height - 1]
    N_height = m - height + 1

    max_value = min(length_height, N_height)

    left = 0
    right = len(distinct_lengths) - 1
    best_value = 0
    while left <= right:
        mid = (left + right) // 2
        value = distinct_lengths[mid]
        if value > max_value:
            left = mid + 1
            continue
        N_value = length_to_num[value]
        if N_value >= height:
            best_value = value
            right = mid - 1
        else:
            left = mid + 1

    if best_value > 0:
        surface_area = height * best_value
        if surface_area > max_surface_area:
            max_surface_area = surface_area

print(max_surface_area)