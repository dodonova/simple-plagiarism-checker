import random
random_list = [random.randint(10, 20) for i in range(1)]

print(random_list) 