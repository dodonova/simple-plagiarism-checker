#include <iostream> 
#include <vector> 
#include <string> 
#include <map> 
#include <set> 
#include <algorithm> 
#include <queue> 
#include <cmath> 
#include <ctime> 
#include <numeric> 
 
using ll = long long; 
using dl = long double; 
 
using namespace std;

int main() {
    ll n;
    cin >> n;
    vector<ll> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    sort(a.rbegin(), a.rend());
    vector<ll> f, s;
    for (int i = 0; i < n; i++) {
        if (i % 2 == 0) {
            f.push_back(a[i]);
        }
        else {
            s.push_back(a[i]);
        }
    }
    ll ans = 0;
    for (int i = 0; i < f.size(); i++) {
        ll l = 0, r = s.size();
        while (r - l > 1) {
            ll mid = (r + l) / 2;
            if (s[mid] >= i + 1) {
                l = mid;
            }
            else {
                r = mid;
            }
        }
        if (s[l] >= i + 1) {
            ans = max(ans, (i + 1) * (l + 1));
        }
    }
    cout << ans;
}