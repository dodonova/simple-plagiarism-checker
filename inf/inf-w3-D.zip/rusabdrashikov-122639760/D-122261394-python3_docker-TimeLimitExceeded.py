import sys
import bisect

def main():
    input = sys.stdin.read().split()
    n = int(input[0])
    ai_sorted = sorted(map(int, input[1:n+1]))
    
    count = [0] * (n + 2)
    for k in range(1, n + 1):
        count[k] = n - bisect.bisect_left(ai_sorted, k)
    
    max_area = 0
    for h in range(1, n + 1):
        w_max = min(count[h] - h, n - h)
        if w_max < 1:
            continue
        
        best_w = max((mid for mid in range(1, w_max + 1) if count[mid] >= h), default=0)
        if best_w > 0:
            max_area = max(max_area, h * best_w)
    
    print(max_area)

if __name__ == "__main__":
    main()