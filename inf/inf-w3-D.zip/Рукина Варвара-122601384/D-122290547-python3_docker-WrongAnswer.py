n = int(input())
a = map(int, input().split())

def summa(n, a):
    a = sorted(a)
    min_a = min(a)

    for i in range(n - 1):
        if min_a in a:
            a.remove(min_a)
    g = n // 2
    ver = a[:g]
    print(min(ver) * len(ver))


summa(n, a)
