#include <iostream>
#include <vector>
#include <algorithm>

int main() {
	int n;
	std::cin >> n;

	std::vector<int> a(n);
	for (int i = 0; i < n; ++i) {
		std::cin >> a[i];
	}
	
	// Сортировка в порядке убывания
	std::sort(a.begin(), a.end(), std::greater<int>());

	std::vector<int> N_H(n + 2, 0);
	int i = n - 1;

	// Заполнение массива N_H
	for (int H = 1; H <= n; ++H) {
		while (i >= 0 && a[i] < H) {
		--i;
		}
		N_H[H] = i + 1;
	}

	int max_area = 0;

	// Вычисление максимальной площади
	for (int H = 1; H <= n; ++H) {
		int L_H = a[H - 1];
		int N_V = N_H[H] - H;
		if (N_V <= 0) {
			continue;
		}
		int V = std::min(L_H, N_V);
		int area = H * V;
		if (area > max_area) {
			max_area = area;
		}
	}

	std::cout << max_area << std::endl;

	return 0;
	}