# Чтение данных из файла input.txt
with open('input.txt', 'r') as f:
    n = int(f.readline())  # Читаем количество полосок
    a = list(map(int, f.readline().split()))  # Читаем длины полосок

# Разделяем полоски на четные и нечетные
even = []
odd = []

for x in a:
    if x % 2 == 0:
        even.append(x)
    else:
        odd.append(x)

# Находим максимальную плетёнку
even_sum = sum(even)
odd.sort(reverse=True)
odd_sum = sum(odd[:len(odd) - len(odd) % 2])

# Выводим результат в файл output.txt
with open('output.txt', 'w') as f:
    f.write(str((even_sum + odd_sum) // 2) + '\n')
