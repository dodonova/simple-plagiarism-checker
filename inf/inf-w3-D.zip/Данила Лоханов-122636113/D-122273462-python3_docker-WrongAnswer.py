def max_weaving_area(n, lengths):
    # Сортируем массив длин в порядке убывания
    lengths.sort(reverse=True)

    # Две самые длинные полоски для горизонтальной группы
    horizontal = lengths[0] + lengths[1]
    # Две следующие по длине полоски для вертикальной группы
    vertical = lengths[2] + lengths[3]

    # Площадь прямоугольной плетёнки
    area = horizontal * vertical
    return area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получаем результат
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)
