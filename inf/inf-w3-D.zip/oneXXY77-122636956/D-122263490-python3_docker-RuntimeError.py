def solve_puzzle(a, b):
    # Перебираем возможные значения n
    n = 2
    while n <= b + 1:  # Нет смысла проверять n больше чем b + 1
        if (b % (n - 1)) == 0:
            m = b // (n - 1) + 1
            # Проверяем условие для t-образных фигур
            if 2 * (n + m - 2) == a:
                print(n, m)
                return
        n += 1

def main():
    # Чтение данных из файла input.txt
    with open('input.txt', 'r') as file:
        a, b = map(int, file.readline().split())

    # Решение задачи
    solve_puzzle(a, b)

if name == "__main__":
    main()