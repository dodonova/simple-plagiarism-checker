def max_weaving_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort(reverse=True)

    max_area = 0
    
    # Перебираем возможные количества полосок от 1 до n//2
    for k in range(1, n // 2 + 1):
        # Площадь = k-ая длина в отсортированном массиве * k-ая длина в отсортированном массиве
        area = lengths[k - 1] * lengths[k - 1]
        max_area = max(max_area, area)

    return max_area

def main():
    # Чтение данных из файла input.txt
    with open('input.txt', 'r') as file:
        n = int(file.readline().strip())
        lengths = list(map(int, file.readline().strip().split()))

    # Вычисление максимальной площади
    result = max_weaving_area(n, lengths)

    # Запись результата в файл output.txt
    with open('output.txt', 'w') as file:
        file.write(str(result) + '\n')

if name == "__main__":
    main()