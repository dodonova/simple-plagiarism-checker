def max_plait_area(n, lengths):
    lengths.sort(reverse=True)  # Сортируем длины в порядке убывания

    if n % 2 == 0:
        color1_lengths = lengths[:n // 2]  # Длины для первого цвета
        color2_lengths = lengths[n // 2:n]  # Длины для второго цвета
    else:
        color1_lengths = lengths[:n // 2 + 1]  # Длины для первого цвета
        color2_lengths = lengths[n // 2 + 1:n]  # Длины для второго цвета

    max_length1 = color1_lengths[0] if color1_lengths else 0  # Максимальная длина для первого цвета
    max_length2 = color2_lengths[0] if color2_lengths else 0  # Максимальная длина для второго цвета

    return max_length1 * max_length2  # Площадь косы

n = int(input())
lengths = list(map(int, input().split()))

print(max_plait_area(n, lengths))


