def max_plait_area(n, lengths):
    if not (2 <= n <= 2 * 10 ** 5):
        raise ValueError("n must be between 2 and 2 * 10^5")

    for length in lengths:
        if not (1 <= length <= 10 ** 9):
            raise ValueError("lengths must be between 1 and 10^9")

    lengths.sort(reverse=True)
    if n % 2 == 0:
        return lengths[n // 2 - 1] * lengths[n // 2] if n // 2 - 1 >= 0 and n // 2 < len(lengths) else 0
    else:
        return lengths[n // 2] * lengths[n // 2 + 1] if n // 2 >= 0 and n // 2 + 1 < len(lengths) else 0

n = int(input())
lengths = list(map(int, input().split()))

try:
    print(max_plait_area(n, lengths))
except ValueError as e:
    print(e)


