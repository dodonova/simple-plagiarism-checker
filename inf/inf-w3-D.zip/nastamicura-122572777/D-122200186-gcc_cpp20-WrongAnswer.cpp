#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>

using std::cin;
using std::cout;

int main() {
  int n, a;
  int maxx = 0;
  std::vector<int> vec;
  std::vector<int> vec_time1;
  cin >> n;
  for (int i = 0; i < n; ++i){
    cin >> a;
    vec.push_back(a);
  }
  std::sort(vec.begin(), vec.end());
  int i = 0;
  while(vec[i] < (n - i - 1)){
    if(std::min(vec[n - vec[i]], n - i - vec[i]) + vec[i] > n - i){
      break;
    }
    maxx = std::max(maxx, vec[i] * std::min(vec[n - vec[i]], n - i - vec[i]));
    i++;
  }
  cout << maxx;
}