line_ct = int(input())
line_len = []
horis_line = []
vert_line = []

line_len = sorted(input().split())
print(line_len)

for i in range(line_ct):
    if i % 2 == 0:
        horis_line.append(line_len[i])
    else:
        vert_line.append(line_len[i])

for i in range(line_ct):
    minLen = int(min(horis_line[0], vert_line[0]))
    if minLen == horis_line[0]:
        if minLen < len(vert_line):
            horis_line.pop(0)
    else:
        if minLen < len(horis_line):
            horis_line.pop(0)
print(len(vert_line)*len(horis_line))