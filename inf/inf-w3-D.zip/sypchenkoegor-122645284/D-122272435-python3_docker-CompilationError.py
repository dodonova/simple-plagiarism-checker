def max_plait_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
 # Чтобы сплести плетёнку, нам нужны как минимум две полоски
    # Площадь будет максимальной при использовании двух самых длинных полосок
    max_area = lengths[0] * lengths[1]
 return max_area

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление максимальной площади плетёнки
result = max_plait_area(n, lengths)

# Вывод результата
print(result)