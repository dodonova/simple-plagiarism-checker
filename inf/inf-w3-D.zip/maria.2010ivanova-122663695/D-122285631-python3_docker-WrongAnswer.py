def max_plait_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    max_area = 0
    
    # Перебираем количество полосок одного цвета
    for k in range(1, n // 2 + 1):
        # Количество полосок другого цвета
        m = n - k
        
        # Минимальная длина среди первых k и m полосок
        min_length = min(lengths[k - 1], lengths[m - 1])
        
        # Вычисляем площадь
        area = k * m * min_length
        max_area = max(max_area, area)
    
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получаем максимальную площадь плетёнки
result = max_plait_area(n, lengths)

# Выводим результат
print(result)
