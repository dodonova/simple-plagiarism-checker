import sys
import bisect

def main():
    import sys
    import bisect

    def solve():
        import sys
        data = sys.stdin.read().split()
        idx = 0
        n = int(data[idx])
        idx +=1
        ai = list(map(int, data[idx:idx +n]))
        idx +=n
        ai_sorted = sorted(ai)
        C = [0]*(n +2)

        ptr =0
        for k in range(1,n+1):
            ptr = bisect.bisect_left(ai_sorted, k, ptr)
            C[k]=n - ptr

        max_area =0

        for h in range(1, n +1):
            v_max = min(C[h], n -h)
            if v_max <1:
            for v in range(v_max, 0, -1):
                if C[v] >=h:
                    max_hv = max(h, v)
                    if C[v] + C[h] - C[max_hv] >= h +v:
                        area = h * v
                        if area > max_area:
                            max_area = area
                        break
        print(max_area)