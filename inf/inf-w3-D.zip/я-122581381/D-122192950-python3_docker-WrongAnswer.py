def max_braiding_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    # Определяем количество полосок для каждой группы
    half_n = n // 2
    
    # Длина для горизонтальных и вертикальных полосок
    max_horizontal_length = lengths[0] if half_n > 0 else 0
    max_vertical_length = lengths[half_n] if n > half_n else 0
    
    # Площадь плетёнки
    return max_horizontal_length * max_vertical_length

# Чтение входных данных
import sys

input_data = sys.stdin.read().strip().split()
n = int(input_data[0])
lengths = list(map(int, input_data[1:]))

# Вычисление максимальной площади плетёнки
result = max_braiding_area(n, lengths)

# Вывод результата
print(result)