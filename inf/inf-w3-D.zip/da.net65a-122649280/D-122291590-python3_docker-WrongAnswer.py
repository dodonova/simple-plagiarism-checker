def max_braid_area(n, lengths):
    from collections import Counter


    counter = Counter(lengths)

    sorted_lengths = sorted(counter.keys(), reverse=True)

    if len(sorted_lengths) < 2:
        # Если нет двух разных длин (что маловероятно по условиям задачи)
        return 0


    length_1 = sorted_lengths[0]
    length_2 = sorted_lengths[1]


    count_length_1 = counter[length_1]
    count_length_2 = counter[length_2]

    max_area = min(count_length_1, count_length_2) * length_1 * length_2

    return max_area



n = int(input().strip())
lengths = list(map(int, input().strip().split()))

result = max_braid_area(n, lengths)
print(result)