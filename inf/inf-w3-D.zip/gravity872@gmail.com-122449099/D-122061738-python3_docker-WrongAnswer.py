def max_weaving_area(n, lengths):
    lengths.sort()
    max_area = 0

    for h in range(1, n):  # от 1 до n-1
        v = n - h  # количество вертикальных полосок
        min_length_vertical = lengths[v - 1]  # минимальная длина среди вертикальных полосок
        area = h * min_length_vertical  # вычисляем площадь
        max_area = max(max_area, area)  # обновляем максимальную площадь

    return max_area

n = int(input())
lengths = list(map(int, input().split()))
result = max_weaving_area(n, lengths)
print(result)

