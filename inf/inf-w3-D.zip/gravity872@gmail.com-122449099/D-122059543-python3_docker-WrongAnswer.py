def max_weaving_area(n, lengths):
    lengths.sort()
    max_area = 0
    for k in range(1, n):
        min_length_vertical = lengths[n - k]
        area = k * min_length_vertical
        max_area = max(max_area, area)
    return max_area
n = int(input())
lengths = list(map(int, input().split()))
result = max_weaving_area(n, lengths)
print(result)
