def calculate_max_plait_area(strip_lengths):
    # Сортируем длины в порядке убывания
    sorted_lengths = sorted(strip_lengths, reverse=True)

    # Разделяем на две группы
    mid_index = len(sorted_lengths) // 2
    horizontal_strips = sorted_lengths[:mid_index]
    vertical_strips = sorted_lengths[mid_index:]

    # Находим минимальные длины в каждой группе
    min_horizontal = min(horizontal_strips)
    min_vertical = min(vertical_strips)

    # Рассчитываем максимальную площадь
    max_area = min_horizontal * min_vertical
    return max_area

def main():
    # Ввод данных
    n = int(input("Введите количество полосок: "))
    lengths_input = input("Введите длины полосок через пробел: ")
    
    # Преобразуем входные данные в список целых чисел
    strip_lengths = list(map(int, lengths_input.split()))

    if len(strip_lengths) != n:
        print("Ошибка: количество введенных длин не соответствует указанному количеству полосок.")
        return

    # Вычисляем максимальную площадь плетёнки
    result = calculate_max_plait_area(strip_lengths)

    # Вывод результата
    print("Максимальная площадь плетёнки:", result)

if __name__ == "__main__":
    main()

