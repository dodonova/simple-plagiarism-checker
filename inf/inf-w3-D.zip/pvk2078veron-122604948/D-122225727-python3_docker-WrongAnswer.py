n = int(input())
lengths = list(map(int, input().split()))
def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)  
    if n % 2 == 0:
        horizontal = max(lengths[:n // 2])
        vertical = min(lengths[n // 2:])
    else:
        horizontal = max(lengths[:n // 2 + 1])
        vertical = min(lengths[n // 2 + 1:])

    return horizontal * vertical

max_area = max_weaving_area(n, lengths)
print(max_area)