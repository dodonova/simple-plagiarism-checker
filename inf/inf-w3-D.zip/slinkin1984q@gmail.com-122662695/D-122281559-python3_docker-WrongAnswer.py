n = int(input())
lengths = list(map(int, input().split()))

# Сортируем длины полосок
lengths.sort()

# Максимальная площадь = длина второго по величине элемента * длина самого большого элемента
max_area = lengths[-1] * lengths[-2]

print(max_area)