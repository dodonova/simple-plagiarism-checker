#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

long long max_weaving_area(int n, vector<int>& lengths) {
    // Сортируем длины полосок
    sort(lengths.begin(), lengths.end());
    
    // Определяем середину
    int half = n / 2;
    
    // Максимальная площадь = минимальная длина в первой половине * минимальная длина во второй половине
    long long max_area = static_cast<long long>(lengths[half - 1]) * lengths[half];
    
    return max_area;
}

int main() {
    int n;
    cin >> n;
    vector<int> lengths(n);
    
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }
    
    long long result = max_weaving_area(n, lengths);
    
    cout << result << endl;
    
    return 0;
}
