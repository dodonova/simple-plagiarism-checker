def max_plait_area(n, lengths):
    lengths.sort()
    half_n = n // 2
    max_length_horizontal = lengths[-half_n]  
    max_length_vertical = lengths[-(half_n + 1)]  
    max_area = max_length_horizontal * max_length_vertical
    return max_area
n = int(input())
lengths = list(map(int, input().split()))
print(max_plait_area(n, lengths))
