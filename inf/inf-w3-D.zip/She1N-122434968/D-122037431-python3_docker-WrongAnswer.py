def max_weaving_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    # Если количество полосок четное, берем две группы по n // 2
    half = n // 2
    width = lengths[half - 1]  # Длина самой короткой полоски в группе 1
    height = lengths[0]         # Длина самой длинной полоски в группе 2
    
    # Площадь плетёнки
    return width * height

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
result = max_weaving_area(n, lengths)
print(result)
