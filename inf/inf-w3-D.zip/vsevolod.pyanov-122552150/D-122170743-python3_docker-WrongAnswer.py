def max_weaving_area(n, lengths):
    lengths.sort()
    height = 0
    width = 0

    for i in range(n - 1):
        if lengths[i] >= 4 and lengths[i + 1] >= 4:
            height = 4
            break
    for j in range(n):
        if lengths[j] >= 3:
            width = 3
            break
    if height and width:
        return height * width
    return 0
n = int(input())
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))
