
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int max_area(int n, vector<int>& lengths) {
    sort(lengths.rbegin(), lengths.rend()); // Сортировка в обратном порядке

    int max_length_1 = lengths[0];
    int max_length_2 = 0;

    for (int i = 1; i < n; ++i) {
        if (lengths[i] < max_length_1) {
            max_length_2 = lengths[i];
            break;
        }
    }

    if (max_length_2 == 0) {
        return 0; // Если подходящая длина не найдена, возвращаем 0
    }

    return max_length_1 * max_length_2;
}

int main() {
    int n;
    cin >> n; // Чтение количества сторон
    vector<int> lengths(n);
    
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i]; // Чтение длин
    }

    cout << max_area(n, lengths) << endl; // Вывод максимальной площади
    return 0;
}