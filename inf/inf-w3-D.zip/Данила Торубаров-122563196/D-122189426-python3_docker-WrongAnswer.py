n = int(input())
a = list(map(int, input().split()))

a.sort(reverse=True)

mx = 0
for i in range(n // 2):
    if a[i] * a[n - i - 1] <= mx:
        break
    mx = a[i] * a[n - i - 1]
print(mx)