def f(n, m):
    m.sort()
    t = sum(m)
    x = 0
    y = 0
    for i in range(n - 1):
        y += m[i]
        a = t - y
        b = y * a
        x = max(x, b)

    return x

n = int(input())
x = list(map(int, input().split()))
print(f(n, x))
