def max_braided_area(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    for k in range(1, n // 2 + 1):
        area = k * (lengths[2 * k - 1] + lengths[2 * k - 2]) 
        max_area = max(max_area, area)
    return max_area
n = int(input())
lengths = list(map(int, input().strip().split()))
result = max_braided_area(n, lengths)
print(result)
