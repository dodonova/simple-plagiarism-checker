def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    for k in range(1, (n // 2) + 1):
        horizontal_length = lengths[k - 1]
        vertical_length = lengths[k]
        area = horizontal_length * vertical_length
        max_area = max(max_area, area)
    return max_area
print(return)