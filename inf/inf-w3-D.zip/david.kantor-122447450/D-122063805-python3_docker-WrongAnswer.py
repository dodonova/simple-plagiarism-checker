import sys
import bisect

def main():
    import sys

    def solve():
        import sys
        from bisect import bisect_left

        # Read all input at once
        data = sys.stdin.read().split()
        idx = 0

        # Read number of strips
        n = int(data[idx])
        idx +=1

        # Read lengths of strips
        ai = list(map(int, data[idx:idx +n]))
        idx +=n

        # Sort the lengths in ascending order
        ai_sorted = sorted(ai)

        # Precompute C(k) = number of strips with length >= k for k from 1 to n
        C = [0] * (n + 2)  # 1-based indexing, C[1] to C[n]
        for k in range(1, n +1):
            pos = bisect_left(ai_sorted, k)
            C[k] = n - pos

        max_area = 0

        for h in range(1, n +1):
            C_h = C[h]
            v_max = min(C_h, n - h)
            if v_max <1:
                continue

            # Binary search to find the largest v <= v_max with C(v) >= h
            left =1
            right =v_max
            best_v =0
            while left <=right:
                mid = (left +right)//2
                if C[mid] >=h:
                    best_v =mid
                    left = mid +1
                else:
                    right = mid -1

            if best_v >0:
                C_v = C[best_v]
                C_max_hv = C[max(h, best_v)]
                if h + best_v <= C_v + C_h - C_max_hv:
                    area =h * best_v
                    if area > max_area:
                        max_area =area

        print(max_area)

    solve()


main()