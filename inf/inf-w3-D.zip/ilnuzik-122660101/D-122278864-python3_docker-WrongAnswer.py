from collections import Counter 
 
def max_weaving_area(n, lengths): 
    # Посчитаем количество каждой длины 
    count = Counter(lengths) 
     
    # Список для хранения доступных пар 
    pairs = [] 
     
    # Ищем пары 
    for length, cnt in count.items(): 
        # Мы можем сделать пару, если длина встречается хотя бы дважды 
        while cnt >= 2: 
            pairs.append(length) 
            cnt -= 2 
     
    # Рассортируем пары по убыванию 
    pairs.sort(reverse=True) 
     
    # Если найдено меньше двух пар, то площадь плетенки 0 
    if len(pairs) < 2: 
        return 0 
     
    # Для вычисления площади берем две наибольшие длины 
    return pairs[0] * pairs[1] 
 
# Чтение входных данных 
n = int(input())  # Количество полос 
lengths = list(map(int, input().split()))  # Длины полос 
 
# Выводим результат 
print(max_weaving_area(n, lengths))