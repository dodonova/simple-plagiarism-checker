def calculate_max_area():
    strip_count = int(input())
    lengths_list = list(map(int, input().split()))
    lengths_list.sort()

    maximum_area = 0

    for i in range(1, strip_count // 2 + 1):
        current_area = i * min(lengths_list[i - 1], lengths_list[strip_count - i])
        if current_area > maximum_area:
            maximum_area = current_area

    print(maximum_area)

calculate_max_area()
