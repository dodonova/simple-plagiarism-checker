def max_plait_area(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    
    for k in range(1, n // 2 + 1):
        min_length = min(lengths[k - 1], lengths[n - k])
        area = k * min_length
        max_area = max(max_area, area)
    
    return max_area

n = int(input())
lengths = list(map(int, input().split()))
print(max_plait_area(n, lengths))
