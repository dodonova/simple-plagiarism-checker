def max_area_strips(n, a):
    max_area = 0
    # Сортируем длины полосок по возрастанию
    a.sort()
    
    for h in range(1, n + 1):  # количество горизонтальных полосок
        v = n - h  # количество вертикальных полосок
        # сумма h самых длинных полосок
        h_length = sum(a[-h:])  
        # сумма v самых коротких полосок
        v_length = sum(a[:v]) if v > 0 else 0 
        # обновляем максимальную площадь
        max_area = max(max_area, h_length * v_length) 
    
    return max_area

import sys

# считывание входных данных
input_data = sys.stdin.read().strip().split()
n = int(input_data[0])  # количество полосок
a = list(map(int, input_data[1:n + 1]))  # длины полосок

# выводим результат
print(max_area_strips(n, a))