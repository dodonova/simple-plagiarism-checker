def max_braid_area(n, lengths):
    
    lengths.sort(reverse=True)

    
    half = n // 2
    sum1 = sum(lengths[:half]) 
    sum2 = sum(lengths[half:])  

    area = sum1 * sum2
    return area


n = int(input())
lengths = list(map(int, input().split()))


result = max_braid_area(n, lengths)
print(result)