#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; ++i){
        cin >> a[i];
    }
    sort(a, a + n);
    for (int i = 0; i + 1 < n; ++i){
        if (a[i] - 1 + a[n - 1] - 1 > n - 1 - i - 1){
            cout << a[i - 1] * a[n - 1] << endl;
            return 0;
        }
    }
}