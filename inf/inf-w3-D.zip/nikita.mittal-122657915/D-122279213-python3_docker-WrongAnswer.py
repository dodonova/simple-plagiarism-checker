
n = int(input())
inp = input()
inp = inp.split()
sp = list(map(int, inp))
mid = (n // 2)
start = 0
maxkol = -1
moda = 0
mv1 = 1
mv = 1000000
save = 0
Flag = True
for i in sp:
    if Flag == False:
        break
    if sp.count(i) != 1:
        Flag = False
if maxkol == -1:
    for i in range(0, 10000):
        if sp[start] >= n // 2 and sp[mid] >= (n // 2 + n % 2):
            save = n // 2 * (n // 2 + n % 2)
            break
        if mv % 2 == 0:
            start += 1
            n -= 1
            mv -= 1
            continue
        if mv % 2 != 0:
            mid += 1
            n -= 1
            mv -= 1
            continue
for i in range(0,len(sp)):
    if sp.count(sp[i]) >= n // 2 + n %2 and  sp.count(sp[i]) != len(sp):
        maxkol = i
        break
if Flag == True :
    save = sp[(sum(sp)//len(sp))] * ( n -sp[(sum(sp)//len(sp))] )

if maxkol > -1 :
    sp1 = sp
    indexend = -1
    for i in range(0,len(sp1)):
        end=sp1[indexend]
        if end >= n  and move1 <= sp[maxkol] and end >= sp.count(sp[maxkol]) :
            if save <(n - sp[maxkol]) * move1:
                save = (n - sp[maxkol]) * move1
        elif end < n  and move1 <= sp[maxkol]:
            if save < end * move1:
                save = end * move1
        move1 +=1
        indexend +=1

print(save)
