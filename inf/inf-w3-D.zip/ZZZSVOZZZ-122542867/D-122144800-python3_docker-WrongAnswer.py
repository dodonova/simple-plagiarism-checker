def max_area(lengths):
  """
  Функция для вычисления максимальной площади плетенки.

  Args:
    lengths: Список длин полосок бумаги.

  Returns:
    Максимальная площадь плетенки.
  """
  lengths.sort()  # Сортировка длин по возрастанию
  n = len(lengths)
  max_area = 0
  for i in range(n):
    for j in range(i + 1, n):
      area = lengths[i] * lengths[j]  # Вычисление площади
      max_area = max(max_area, area)  # Обновление максимальной площади
  return max_area

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод максимальной площади
max_area = max_area(lengths)
print(max_area)