def max_braiding_area(n, lengths): 
    # Сортируем длины полосок по убыванию 
    lengths.sort(reverse=True) 
 
    # Количество полосок для каждой группы 
    half = n // 2 
 
    # Горизонтальные полоски 
    if half > 0: 
        horizontal_length = lengths[half - 1] 
    else: 
        horizontal_length = 0 
 
    # Вертикальные полоски 
    if half < n: 
        vertical_length = lengths[n - half - 1] 
    else: 
        vertical_length = 0 
 
    # Площадь плетёнки 
    return horizontal_length * vertical_length 
print(max_braiding_area(n, lengths))