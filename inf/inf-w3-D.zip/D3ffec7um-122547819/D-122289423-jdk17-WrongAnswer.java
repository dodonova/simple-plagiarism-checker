
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class MashaWeaving {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read the number of strips
        int numberOfStrips = scanner.nextInt();
        Integer[] stripLengths = new Integer[numberOfStrips];

        // Read the lengths of the strips
        for (int i = 0; i < numberOfStrips; ++i) {
            stripLengths[i] = scanner.nextInt();
        }

        // Sort the strip lengths in decreasing order
        Arrays.sort(stripLengths, Collections.reverseOrder());

        // Compute the number of strips with length >= H
        int[] stripsAtHeight = computeStripsAtHeight(stripLengths, numberOfStrips);

        // Calculate the maximum area
        int maxArea = calculateMaxArea(stripLengths, stripsAtHeight, numberOfStrips);

        // Output the maximum area
        System.out.println(maxArea);

        scanner.close();
    }

    private static int[] computeStripsAtHeight(Integer[] stripLengths, int numberOfStrips) {
        int[] stripsAtHeight = new int[numberOfStrips + 1];
        int index = numberOfStrips - 1;

        for (int height = 1; height <= numberOfStrips; ++height) {
            while (index >= 0 && stripLengths[index] < height) {
                index--;
            }
            stripsAtHeight[height] = index + 1; // Counts strips with height >= height
        }

        return stripsAtHeight;
    }

    private static int calculateMaxArea(Integer[] stripLengths, int[] stripsAtHeight, int numberOfStrips) {
        int maxArea = 0;

        for (int height = 1; height <= numberOfStrips; ++height) {
            int shortestStripLength = stripLengths[height - 1]; // Length of the shortest horizontal strip
            int availableVerticalStrips = stripsAtHeight[height] - height; // Available vertical strips after allocating horizontal ones

            if (availableVerticalStrips > 0) {
                int verticalStripsUsed = Math.min(shortestStripLength, availableVerticalStrips); // Limit vertical strips to available count
                int area = height * verticalStripsUsed; // Calculate the area

                maxArea = Math.max(maxArea, area); // Update max area if current area is greater
            }
        }

        return maxArea;
    }
}