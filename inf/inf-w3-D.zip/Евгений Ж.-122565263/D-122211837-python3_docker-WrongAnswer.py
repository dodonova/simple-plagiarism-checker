n = int(input())
mas = list(map(int, input().split()))
masy = []
masz = []
mas.sort()
o = (n - 1) // 2 / 2
for i in range(len(mas)):
    if (i <= (0 + o+1) or i >= len(mas)-o-1) and i != 0:
        masy.append(mas[i])
    elif i != 0:
        masz.append(mas[i])
miny = min(masy)
minz = min(masz)
print(minz*miny)