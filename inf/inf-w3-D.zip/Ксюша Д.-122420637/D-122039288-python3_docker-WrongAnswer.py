n = int(input())
lengths = list(map(int, input().split()))

max1 = max(lengths)
lengths.remove(max1)
max2 = max(lengths)

print(max1 * max2)