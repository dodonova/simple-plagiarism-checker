#include <iostream>
#include <vector>
#include <algorithm>

typedef long long ll;

int main() {
    ll n;
    std::cin >> n;
    std::vector<ll> a(n);
    for(ll i = 0; i < n; ++i)
        std::cin >> a[i];
    std::sort(a.begin(), a.end(), std::greater<ll>());
    ll max_area = 0;
    ll idx_v = 0; // Индекс для вертикальных полосок
    for(ll h = 1; h <= n; ++h) {
        // Находим количество полосок длиной >= h
        while(idx_v < n && a[idx_v] >= h)
            idx_v++;
        ll cnt_len_ge_h = idx_v;
        if(cnt_len_ge_h < h)
            break; // Недостаточно полосок длиной >= h
        // Теперь ищем максимальное v такое, что есть не менее h полосок длиной >= v
        ll idx_h = h - 1; // Индекс последней горизонтальной полоски
        if(a[idx_h] < h)
            continue; // Длина горизонтальной полоски меньше требуемой
        ll v = a[idx_h]; // Длина вертикальных полосок (число вертикальных полосок)
        // Проверяем количество полосок длиной >= v
        ll cnt_len_ge_v = 0;
        while(cnt_len_ge_v < n && a[cnt_len_ge_v] >= v)
            cnt_len_ge_v++;
        if(cnt_len_ge_v < h)
            continue; // Недостаточно полосок длиной >= v для горизонтальных полосок
        // Проверяем, что общее число использованных полосок не превышает n
        if(h + v > n)
            continue;
        ll area = h * v;
        if(area > max_area)
            max_area = area;
    }
    std::cout << max_area << std::endl;
    return 0;
}
