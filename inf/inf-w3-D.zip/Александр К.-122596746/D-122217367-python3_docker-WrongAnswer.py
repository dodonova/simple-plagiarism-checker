def max_woven_area(n, lengths):
    # Sort lengths in descending order
    lengths.sort(reverse=True)
    
    # Split lengths into two sets: horizontal and vertical
    horizontal = []
    vertical = []
    
    for i in range(n):
        if i % 2 == 0:
            horizontal.append(lengths[i])
        else:
            vertical.append(lengths[i])
    
    # Calculate the sum of the two sets, ensuring even count for maximum area
    h_sum = sum(horizontal[:len(horizontal) // 2 * 2])
    v_sum = sum(vertical[:len(vertical) // 2 * 2])
    
    # Return the maximum possible area
    return h_sum * v_sum

# Input
n = int(input())
lengths = list(map(int, input().split()))

# Output
print(max_woven_area(n, lengths))

