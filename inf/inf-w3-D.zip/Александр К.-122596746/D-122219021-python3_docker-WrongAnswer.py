def main():
    import sys
    import threading
    def solve():
        n_and_rest = sys.stdin.read().split()
        n = int(n_and_rest[0])
        ai = list(map(int, n_and_rest[1:n+1]))
        n = len(ai)
        ai.sort(reverse=True)
        
        # Создаем список уникальных длин и соответствующих количеств
        lengths = []
        counts = []
        prev_len = None
        for length in ai:
            if length != prev_len:
                lengths.append(length)
                counts.append(1)
                prev_len = length
            else:
                counts[-1] += 1
        
        # Преобразуем counts в накопительное количество полосок длиной >= L
        total_counts = []
        total = 0
        for count in counts:
            total += count
            total_counts.append(total)
        
        max_area = 0
        total_strips = len(ai)
        for i in range(len(lengths)):
            L = lengths[i]
            cnt_L = total_counts[i]
            h = cnt_L
            # Ищем максимальное v, такое что есть не менее v полосок длиной >= h
            # Это полоски с длиной >= h
            # Найдем индекс, где длина < h
            import bisect
            idx = bisect.bisect_left(lengths, h, lo=0, hi=len(lengths))
            if idx < len(lengths) and lengths[idx] >= h:
                v = total_counts[idx]
            else:
                v = 0
            v = min(v, h)
            if h + v > total_strips:
                v = total_strips - h
            if v <= 0:
                continue
            area = h * v
            if area > max_area:
                max_area = area
        print(max_area)
    threading.Thread(target=solve).start()


