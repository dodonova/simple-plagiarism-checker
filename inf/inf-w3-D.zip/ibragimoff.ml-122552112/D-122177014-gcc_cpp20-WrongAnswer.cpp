#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
using namespace std;


int main()
{
    vector <unsigned int> ar;
    int l=0;
    string sa;
    cin>>l;
    cin.ignore();
    getline(cin,sa);
    int n;
    stringstream s(sa);
    while(s>>n){
        ar.push_back(n);
    }
    sort(ar.begin(),ar.end());
    unsigned long iznr=ar.size();
    while(ar.size()-1<=*(ar.end()-1)){
        if(*ar.begin()<iznr-ar.size()) {
            iznr--;
            ar.erase(ar.begin());
        }
        if(ar.size()-1<*(ar.end()-1)){
            ar.pop_back();
        }
    }
    
    //for(auto i :ar) cout<<i<<" ";
    cout<<ar.size()*(iznr-ar.size());
}