 n = len(lengths)
    lengths.sort()  # Сортируем длины по возрастанию

    # Двух указателей для нахождения оптимального разбиения
    left = 0
    right = n - 1

    max_area = 0
    while left < right:
        # Вычисляем площадь прямоугольника
        area = lengths[left] * lengths[right]
        max_area = max(max_area, area)

        # Перемещаем указатели
        if lengths[left] < lengths[right]:
            left += 1
        else:
            right -= 1

    return max_area

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_area(lengths))

