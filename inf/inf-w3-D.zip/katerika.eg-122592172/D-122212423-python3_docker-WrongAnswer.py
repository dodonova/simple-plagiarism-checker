def max_plenka_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    # Для плетёнки используется каждая из двух самых длинных полосок:
    # n // 2 для одной стороны
    # n // 2 для другой стороны
    half_n = n // 2
    
    # Площадь = минимальная длина * минимальная длина
    area = lengths[half_n - 1] * lengths[half_n]
    
    return area

if __name__ == "__main__":
    n = int(input().strip())
    lengths = list(map(int, input().strip().split()))
    
    max_area = max_plenka_area(n, lengths)
    print(max_area)