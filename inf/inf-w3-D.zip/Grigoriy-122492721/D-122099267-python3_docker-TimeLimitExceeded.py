n, *rest = list(map(int, input().split()))
if len(rest) < n:
    rest.extend(map(int, input().split()))
a = rest[:n]
a.sort(reverse=True)

max_length = a[0]
length_counts = {}
for length in a:
    length_counts[length] = length_counts.get(length, 0) + 1

unique_lengths = sorted(set(a), reverse=True)
cnt = []
cumulative = 0
length_to_cnt = {}
for length in unique_lengths:
    cumulative += length_counts[length]
    cnt.append((length, cumulative))
    length_to_cnt[length] = cumulative

def get_N(L):
    if L > unique_lengths[0]:
        return 0
    if L <= unique_lengths[-1]:
        return length_to_cnt[unique_lengths[-1]]
    left = 0
    right = len(unique_lengths) -1
    while left <= right:
        mid = (left + right) // 2
        if unique_lengths[mid] >= L:
            left = mid +1
        else:
            right = mid -1
    return length_to_cnt[unique_lengths[right]]

max_area = 0
n = len(a)
for h in range(1, n+1):
    L_h = a[h-1]
    cnt_h = get_N(h)
    v_max = min(L_h, cnt_h)
    left = 1
    right = v_max
    best_v = 0
    while left <= right:
        mid = (left + right) // 2
        min_hv = min(h, mid)
        N_min_hv = get_N(min_hv)
        if N_min_hv >= h + mid:
            left = mid +1
            best_v = mid
        else:
            right = mid -1
    if best_v > 0:
        area = h * best_v
        if area > max_area:
            max_area = area

print(max_area)

