import sys

n = int(sys.stdin.readline().strip())
a = list(map(int, sys.stdin.readline().strip().split()))

a.sort(reverse=True)
max_area = 0

for i in range(1, n):
    area = a[i - 1] * a[i]
    if area > max_area:
        max_area = area

print(max_area)