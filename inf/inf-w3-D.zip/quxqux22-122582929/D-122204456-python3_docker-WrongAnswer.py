import sys

n = int(sys.stdin.readline().strip())
a = list(map(int, sys.stdin.readline().strip().split()))

a.sort()
max_length = a[-1]
second_max_length = a[-2]

print(max_length * second_max_length)