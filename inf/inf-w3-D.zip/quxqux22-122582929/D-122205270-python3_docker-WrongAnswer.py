def solve():
    import sys
    def main():
        n_and_rest = sys.stdin.read().split()
        n = int(n_and_rest[0])
        a_list = list(map(int, n_and_rest[1:n+1]))
        a_list.sort(reverse=True)
        max_area = 0
        total_strips = n
        for i in range(n):
            length = a_list[i]
            c = i + 1
            max_k = min(length, c // 2, total_strips // 2)
            if max_k > 0:
                area = max_k * max_k
                if area > max_area:
                    max_area = area
        print(max_area)
    main()
solve()