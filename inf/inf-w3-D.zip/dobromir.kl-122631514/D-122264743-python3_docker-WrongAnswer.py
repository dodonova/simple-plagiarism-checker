from collections import Counter
def max_weaving_area(n, lengths):
    count = Counter(lengths)   
    pairs = []    
    for length, cnt in count.items():
        while cnt >= 2:
            pairs.append(length)
            cnt -= 2
    pairs.sort(reverse=True)
    if len(pairs) < 2:
        return 0
    return pairs[0] * pairs[1]
n = int(input())  
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))