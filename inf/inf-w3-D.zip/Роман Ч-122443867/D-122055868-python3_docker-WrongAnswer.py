n = int(input())
a = list(map(int, input().split()))

a.sort()
result = max(a[a[0]] * a[0], a[1] * a[a[1]])
print(result)