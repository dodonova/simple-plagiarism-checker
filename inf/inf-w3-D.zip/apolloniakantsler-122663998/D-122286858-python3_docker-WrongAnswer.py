def max_weaving_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)

    # Подсчет максимальной площади
    max_area = 0
    
    # Нам нужно как минимум 2 полоски, чтобы создать прямоугольник
    for i in range(1, n):
        # Пара полосок, чтобы они могли образовать прямоугольник
        width = lengths[i-1]
        height = lengths[i]
        area = width * height
        max_area = max(max_area, area)
    
    return max_area

# Главная функция для обработки ввода и вывода
def main():
    import sys
    input = sys.stdin.read
    data = input().strip().split()
    
    n = int(data[0])
    lengths = list(map(int, data[1:n + 1]))
    
    result = max_weaving_area(n, lengths)
    print(result)

if __name__ == "__main__":
    main()