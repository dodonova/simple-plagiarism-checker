#include <iostream>
#include <iomanip>
using namespace std;

int arr[100000], brr[100000];
int main() {
    int n, t=0;
    cin>>n;
    for(int i=0;i<n;++i){
        cin>>arr[i];
        brr[i]=arr[i];
        t++;
    }
    int t1=t, i=0;
    while(i<t){
        if(arr[i]<(t1/2){
            brr[i]=0;
            t1--;
            i++;
        }
    }
    int mn1=1000000001, mn2=1000000001;
    for(int i=0;i<t;++i){
        if(brr[i]<mn1 and brr[i]!=0){
            mn1=brr[i];
        }
    }
    for(int i=0;i<t;++i){
        if(brr[i]<mn2 and brr[i]!=0 and brr[i]>mn1){
            mn2=brr[i];
        }
    }
    cout<<mn1*mn2;
}
