#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int64_t max_weaving_area(int n, vector<int>& lengths) {
    // Сортируем полоски по длине
    sort(lengths.begin(), lengths.end());

    // Находим сумму первой половины полосок (меньшие)
    int64_t sum_first_group = accumulate(lengths.begin(), lengths.begin() + n / 2, 0LL);
    
    // Находим сумму второй половины полосок (большие)
    int64_t sum_second_group = accumulate(lengths.begin() + n / 2, lengths.end(), 0LL);

    // Площадь плетёнки
    return sum_first_group * sum_second_group;
}

int main() {
    int n;
    cin >> n; // Читаем количество полосок

    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i]; // Читаем длины полосок
    }

    // Вычисляем максимальную площадь плетёнки
    cout << max_weaving_area(n, lengths) << endl;

    return 0;
}
