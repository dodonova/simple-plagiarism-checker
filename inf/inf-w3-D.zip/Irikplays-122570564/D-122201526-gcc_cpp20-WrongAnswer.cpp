#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int64_t max_weaving_area(int n, vector<int>& lengths) {
    // Сортируем полоски по длине
    sort(lengths.begin(), lengths.end());

    // Считаем сумму всех полосок
    int64_t total_sum = accumulate(lengths.begin(), lengths.end(), 0LL);
    int64_t max_area = 0;
    int64_t current_sum = 0;

    // Перебираем возможные разбиения
    for (int i = 0; i < n - 1; ++i) {
        current_sum += lengths[i]; // Сумма первой группы
        int64_t second_group_sum = total_sum - current_sum; // Сумма второй группы

        // Вычисляем площадь
        max_area = max(max_area, current_sum * second_group_sum);
    }

    return max_area;
}

int main() {
    int n;
    cin >> n;  // Читаем количество полосок

    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];  // Читаем длины полосок
    }

    // Вычисляем максимальную площадь плетёнки
    cout << max_weaving_area(n, lengths) << endl;

    return 0;
}
