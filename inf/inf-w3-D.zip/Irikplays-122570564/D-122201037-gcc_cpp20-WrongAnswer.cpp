#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int64_t max_weaving_area(int n, vector<int>& lengths) {
    // Сортируем полоски по длине
    sort(lengths.begin(), lengths.end());

    // Объявляем переменные для хранения максимальной площади
    int64_t max_area = 0;

    // Перебираем возможные разбиения
    for (int k = 1; k < n; ++k) {
        // Сумма первой группы (1 до k)
        int64_t sum_first_group = accumulate(lengths.begin(), lengths.begin() + k, 0LL);
        // Сумма второй группы (k до n)
        int64_t sum_second_group = accumulate(lengths.begin() + k, lengths.end(), 0LL);
        
        // Вычисляем площадь
        max_area = max(max_area, sum_first_group * sum_second_group);
    }

    return max_area;
}

int main() {
    int n;
    cin >> n;  // Читаем количество полосок

    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];  // Читаем длины полосок
    }

    // Вычисляем максимальную площадь плетёнки
    cout << max_weaving_area(n, lengths) << endl;

    return 0;
}
