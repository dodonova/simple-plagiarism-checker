#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int n;
    std::cin >> n;

    std::vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> lengths[i];
    }

    // Сортировка полосок по длине в порядке убывания
    std::sort(lengths.rbegin(), lengths.rend());

    long long maxArea = 0;

    // Проверяем все возможные комбинации горизонтальных и вертикальных полосок
    for (int i = 1; i <= n; ++i) {
        int j = n - i;
        if (j < i) break; // Symmetry check

        // Рассчитываем максимальную длину и ширину
        long long width = 0, height = 0;
        for (int k = 0; k < i; ++k) {
            width += lengths[k];
        }
        for (int k = i; k < n; ++k) {