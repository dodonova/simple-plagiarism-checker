def max_braid_area(strip_lengths):
    # Сортировка длины полосок в порядке убывания
    strip_lengths.sort(reverse=True)

    # Инициализация максимальной площади
    max_area = 0

    # Проверяем все возможные комбинации разделения полосок
    for split_index in range(len(strip_lengths) + 1):
        # Разделение полосок на две группы
        yellow_lengths = [length / 2 for length in strip_lengths[:split_index]]
        green_lengths = [length / 2 for length in strip_lengths[split_index:]]

        # Вычисляем суммы длин и количества полосок для каждой группы
        yellow_sum = sum(yellow_lengths)
        green_sum = sum(green_lengths)
        yellow_count = len(yellow_lengths)
        green_count = len(green_lengths)

        # Вычисляем максимальную площадь плетёнки для текущей комбинации
        area = min(yellow_sum, green_sum) * min(yellow_count, green_count)

        # Обновляем максимальную площадь
        max_area = max(max_area, area)

    return max_area

def main():
    # Ввод количества полосок
    while True:
        try:
            n = int(input())
            if n <= 0:
                print()
                continue
            break
        except ValueError:
            print()

    # Ввод длин полосок
    strip_lengths = []
    for i in range(n):
        while True:
            try:
                length = float(input())
                if length <= 0:
                    continue
                break
            except ValueError:
        strip_lengths.append(length)

    # Вычисление и вывод максимальной площади плетёнки
    max_area = max_braid_area(strip_lengths)
    print(max_area)

if __name__ == "__main__":
    main()