 def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)  # Сортируем по убыванию
    max_area = 0

    for i in range(1, n):
        h = i  # Количество полосок одного цвета
        v = n - i  # Количество полосок другого цвета
        current_length = min(lengths[i-1], lengths[v-1])  # Минимальная длина среди выбранных
        area = 2 * h * v * current_length
        max_area = max(max_area, area)

    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
print(max_weaving_area(n, lengths))