#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<int> strips(n);
    for (int i = 0; i < n; ++i) {
        cin >> strips[i];
    }

    // Сортируем полоски по убыванию
    sort(strips.begin(), strips.end(), greater<int>());

    // Массив для хранения длин двух наибольших пар
    vector<int> pairs;

    // Проходим по отсортированному списку и ищем возможные пары
    for (int i = 0; i < n - 1; ++i) {
        if (strips[i] == strips[i + 1]) {
            pairs.push_back(strips[i]);  // Нашли пару
            i++;  // Пропускаем следующий элемент, так как он уже использован в паре
        }
    }

    // Для построения плетёнки нужны минимум две пары
    if (pairs.size() < 2) {
        cout << 0 << endl;
        return 0;
    }

    // Нам нужны две наибольшие пары для максимальной площади
    cout << static_cast<long long>(pairs[0]) * pairs[1] << endl;

    return 0;
}
