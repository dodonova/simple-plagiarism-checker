from itertools import combinations

def max_rectangle_area(n, lengths):
    max_area = 0
    
    # Сортируем длины полосок по убыванию
    sorted_lengths = sorted(lengths, reverse=True)
    
    for i in range(len(sorted_lengths)):
        for j in range(i, len(sorted_lengths)):
            # Выбираем две группы полосок: горизонтальные и вертикальные
            horizontal = sorted_lengths[:i]
            vertical = sorted_lengths[j:]
            
            # Вычисляем площадь прямоугольника
            area = sum(horizontal) * sum(vertical)
            
            # Обновляем максимальную площадь
            max_area = max(max_area, area)
    
    return max_area

# Пример использования
n = int(input())
lengths = list(map(int, input().split()))
result = max_rectangle_area(n, lengths)
print(result)
