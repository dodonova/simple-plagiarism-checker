def max_woven_area(n, a):
    # Сортируем массив длин полосок
    a.sort(reverse=True)
    
    # Разделяем на две группы по парности индексов
    horizontal = []
    vertical = []
    
    for i in range(0, n - 1, 2):
        if a[i] == a[i + 1]:
            horizontal.append(a[i])
            vertical.append(a[i + 1])
    
    # Если удалось выбрать хотя бы 2 полоски для каждой стороны
    if len(horizontal) >= 2 and len(vertical) >= 2:
        # Берем две наибольшие полоски из каждой группы
        max_area = horizontal[0] * vertical[1]
        print(max_area)
    else:
        print(0)

# Пример использования
if __name__ == "__main__":
    n = int(input())
    a = list(map(int, input().split()))
    max_woven_area(n, a)
