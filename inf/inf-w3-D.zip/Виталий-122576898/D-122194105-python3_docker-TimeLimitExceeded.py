n = int(input())
strps = list(map(int,input().split()))
strps.sort()
M = 1
j = 1
if n > 5:
    for i in range(n-1, n-6, -1):
        cnt = 0
        for el in strps[i-1::-1]:
            if el >= j:
                cnt+=1
        M = max(min(cnt, strps[i])*j, M)
        j+=1
        
for i in range(n-1):
    if sum(strps[:2])>=len(strps):
        break
    strps=strps[1:]
    
x=strps[0]
y=strps[1]
xlen = 1
ylen = 1
for i in range(2,len(strps)):
    if ylen>=xlen and xlen<y:
        xlen+=1
    elif ylen<x:
        ylen+=1
        
print(max(ylen*xlen, M))
