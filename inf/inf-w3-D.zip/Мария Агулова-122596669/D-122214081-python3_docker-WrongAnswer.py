def calculate_max_area(n, a):
    max_area = 0
    for h in range(n + 1):
        for v in range(h + 1, n + 1):
            if h * v > max_area:
                max_area = h * v
    return max_area

n = int(input())
a = list(map(int, input().split()))
max_area = calculate_max_area(n, a)
print(max_area)