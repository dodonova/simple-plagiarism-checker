import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();
        int[] lengths = new int[n];

        for (int i = 0; i < n; i++) {
            lengths[i] = scanner.nextInt();
        }

        Arrays.sort(lengths);

        int mA = lengths[2] * lengths[1];

        System.out.println(mA);
    }
}