nu = input().split()
a1 = int(nu[0])
b1 = int(nu[1])
a2 = int(nu[2])
b2 = int(nu[3])

nu = input().split()
x = int(nu[0])
y = int(nu[1])

koo = x * y

maxa = max(a1, a2)
mina = min(a1, a2)

maxb = max(b1, b2)
minb = min(b1, b2)

cho = x * y

par1 = mina
par2 = minb

osta = maxa - mina
ostb = maxb - minb

svob = cho - (par1 + par2)
if svob < 0:
    print(cho*2)
elif svob - osta < 0 or svob - ostb < 0 or svob - ostb - osta < 0:
    print(par1 * 2 + par2 * 2 + svob)
elif svob - osta -ostb >= 0:
    print(par1 * 2 + par2 * 2+ osta + ostb)