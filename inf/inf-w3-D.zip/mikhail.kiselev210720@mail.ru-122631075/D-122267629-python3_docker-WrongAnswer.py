n = int(input())
l = list(map(int, input().split()))    
l.sort()
m = (n + 1) // 2 
print(l[n - m] * l[m - 1] - n)