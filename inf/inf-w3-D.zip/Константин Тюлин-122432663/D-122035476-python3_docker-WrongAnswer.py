n = int(input())
a = list(map(int, input().split()))

# Создаём список возможных частей (не больше 2n штук)
pieces = []
for ai in a:
    if ai >= 2:
        l1 = ai // 2
        l2 = ai - l1
        pieces.append(l1)
        pieces.append(l2)
    else:
        pieces.append(ai)

# Сортируем части по убыванию длины
pieces.sort(reverse=True)
total_pieces = len(pieces)
prefix_sums = [0]
for length in pieces:
    prefix_sums.append(prefix_sums[-1] + length)

max_area = 0

# Итерируемся по k от 1 до числа частей
for k in range(1, total_pieces + 1):
    if pieces[k - 1] < k:
        continue
    total_length_needed = 2 * k * k
    if prefix_sums[min(2 * k, total_pieces)] >= total_length_needed:
        max_area = k * k

# Выводим максимальную найденную площадь
print(max_area)
