def max_plait_area(n, lengths):
    from collections import Counter

    # Считаем количество каждой длины
    count = Counter(lengths)
    # Создаем список возможных сторон (длины, которые встречаются не менее 2 раз)
    sides = []
    for length in sorted(count.keys(), reverse=True):
        while count[length] >= 2:
            sides.append(length)
            count[length] -= 2
            if len(sides) >= 2:
                break
        if len(sides) >= 2:
            break

    if len(sides) < 2:
        return 0  # Невозможно сформировать плетёнку
    else:
        # Площадь равна произведению двух наибольших сторон
        return sides[0] * sides[1]

# Чтение ввода
n = int(input())
lengths = list(map(int, input().split()))

# Вычисление и вывод результата
result = max_plait_area(n, lengths)
print(result)
