def max_pletenka_area(n, a):
    a.sort(reverse=True)
    
    max_area = 0
    for i in range(0, n - 1, 2):
        max_area += a[i + 1]
    
    return max_area

n = int(input())
a = list(map(int, input().split()))

print(max_pletenka_area(n, a))
