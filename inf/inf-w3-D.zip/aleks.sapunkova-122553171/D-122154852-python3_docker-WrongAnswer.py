def max_pletenka_area(n, lengths):
    # Сортируем массив длин
    lengths.sort(reverse=True)

    # Вычисляем префиксные суммы
    prefix_sum = [0] * (n + 1)
    for i in range(1, n + 1):
        prefix_sum[i] = prefix_sum[i - 1] + lengths[i - 1]

    max_area = 0

    # Проходим по всем возможным разделениям
    for h in range(1, n):  # h - количество полосок для одного цвета
        width = prefix_sum[h]  # Sумма длин h полосок
        height = prefix_sum[n] - width  # Sумма длин оставшихся полосок
        area = width * height  # Вычисляем площадь
        if area > max_area:
            max_area = area  # Обновляем максимальную площадь

    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Получение максимальной площади плетёнки
result = max_pletenka_area(n, lengths)

# Вывод результата
print(result)