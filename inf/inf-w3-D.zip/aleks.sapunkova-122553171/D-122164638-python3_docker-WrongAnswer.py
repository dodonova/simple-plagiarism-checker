def main():
    import sys
    input = sys.stdin.read
    data = input().splitlines()
    
    n = int(data[0].strip())
    a = list(map(int, data[1].strip().split()))
    
    # Сортируем длины по убыванию
    a.sort(reverse=True)
    
    # Сумма всех длин
    total_length = sum(a)
    
    max_area = 0
    sum_vertical = 0
    
    # Проходим по всем возможным количествам горизонтальных полосок
    for h in range(1, n):
        sum_vertical += a[h-1]  # Добавляем текущую длину в вертикальные
        horizontal_count = h     # Количество горизонтальных полосок
        vertical_count = n - h   # Количество вертикальных полосок
        
        # Площадь = количество горизонтальных * сумма длин вертикальных
        area = horizontal_count * (total_length - sum_vertical)
        
        max_area = max(max_area, area)
    
    print(max_area)

if __name__ == "__main__":
    main()