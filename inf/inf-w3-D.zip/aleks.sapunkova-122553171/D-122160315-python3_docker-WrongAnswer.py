def max_plait_area(n, lengths):
    lengths.sort()
    # Если количество полосок четное, берем n//2
    # Если нечетное, то (n//2, n//2 + 1)
    half_n = n // 2
    # Максимальная площадь
    max_area = lengths[half_n - 1] * lengths[n - half_n]
    return max_area

# Чтение входных данных
n = int(input())
a = list(map(int, input().split()))

# Вычисление и вывод результата
print(max_plait_area(n, a))