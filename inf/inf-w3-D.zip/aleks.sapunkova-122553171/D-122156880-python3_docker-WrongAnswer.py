def max_weaving_area(n, lengths):
    if n < 2:
        return 0  # Если полосок меньше 2, площадь не может быть посчитана.
    
    # Сортируем длины полосок
    lengths.sort()
    
    # Берем две самые длинные полоски
    longest = lengths[-1]
    second_longest = lengths[-2]
    
    # Площадь плетенки
    max_area = longest * second_longest
    return max_area

# Считывание входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Печатаем результат
result = max_weaving_area(n, lengths)
print(result)