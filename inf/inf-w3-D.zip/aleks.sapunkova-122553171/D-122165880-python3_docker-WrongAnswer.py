def max_weaving_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()
    
    max_area = 0
    
    # Перебираем количество полосок в одной из групп
    for k in range(1, n):
        # Полоски для одной группы: k
        # Полоски для другой группы: n - k
        min_length_group1 = lengths[k - 1]  # Минимальная длина в первой группе
        min_length_group2 = lengths[n - k]  # Минимальная длина во второй группе
        
        area1 = min_length_group1 * k
        area2 = min_length_group2 * (n - k)
        
        max_area = max(max_area, area1, area2)
    
    return max_area

if __name__ == "__main__":
    import sys
    input = sys.stdin.read
    data = input().splitlines()
    
    n = int(data[0])
    lengths = list(map(int, data[1].split()))
    
    result = max_weaving_area(n, lengths)
    print(result)