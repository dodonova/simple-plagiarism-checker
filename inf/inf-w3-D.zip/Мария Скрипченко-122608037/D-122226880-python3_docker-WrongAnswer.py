def maximum_weaving_area(n, lengths):
    lengths.sort(reverse=True)  # Сортируем длины в порядке убывания
    max_area = 0
    
    # Учитываем, что нам нужно взять хотя бы 2 полоски для каждого цвета
    for k in range(1, (n // 2) + 1):  # k полосок для одного цвета
        # Используем полоски от 0 до 2*k-1 для проверки площади
        if 2*k <= n:  # Нужно, чтобы можно было взять 2*k полоски
            min_length = lengths[k - 1]  # Длина самой короткой полоски в этой группе
            area = min_length * k  # Площадь (min * count)
            max_area = max(max_area, area)
    
    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисление и вывод результата
print(maximum_weaving_area(n, lengths))