def max_braided_area(n, lengths):
    lengths.sort()
    max_area = 0
    for k in range(1, n // 2 + 1):
        sum_first_k = sum(lengths[-k:]) 
        sum_second_k = sum(lengths[-(2*k):-k])
        area = sum_first_k * sum_second_k
        max_area = max(max_area, area)
    return max_area
n = int(input())
lengths = list(map(int, input().split()))
result = max_braided_area(n, lengths)
print(result)