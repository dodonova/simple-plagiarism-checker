# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))


lengths.sort(reverse=True)


max_area = lengths[0] * lengths[1]


print(max_area)
