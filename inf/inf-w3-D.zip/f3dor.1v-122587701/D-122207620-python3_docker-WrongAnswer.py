def max_area(lengths):
    n = len(lengths)
    total_length = sum(lengths)
    dp = [[0] * (total_length + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(1, total_length + 1):
            
            dp[i][j] = dp[i - 1][j]

            
            if j >= lengths[i - 1]:
                dp[i][j] = max(dp[i][j], min(j, total_length - j) * lengths[i - 1])

    return max(dp[n])


n = int(input())
lengths = list(map(int, input().split()))


print(max_area(lengths))