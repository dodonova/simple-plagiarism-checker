f = int(input())l = list(map(int, input().split()))
l.sort()l = l[round(len(l) * 0.1):]
print(l[0] * l[1])
#KimberlyClark