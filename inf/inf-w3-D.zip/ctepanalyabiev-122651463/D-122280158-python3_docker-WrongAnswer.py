def max_weaving_area(n, lengths):
    lengths.sort()
    max_area=0
    for i in range(len(lengths)):
       area=(i+1)*lengths[i]
       if area > max_area:
           max_area = area
    return max_area

n = int(input())
lengths = list(map(int, input().split()))

result = max_weaving_area(n, lengths)
print(result)