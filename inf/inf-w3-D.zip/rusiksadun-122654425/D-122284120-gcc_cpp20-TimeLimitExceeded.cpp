#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int a;
    std::cin >> a;
    std::vector<int> lengths(a);

    for (int i = 0; i < a; ++i) {
        std::cin >> lengths[i];
    }

    std::sort(lengths.rbegin(), lengths.rend());

    int max_area = 0;

    for (int h = 1; h <= a; ++h) {
        int min_length_h = (h <= a) ? lengths[h - 1] : 0;
        int v = std::min(min_length_h, a - h);

        int count_v = 0;
        for (int j = h; j < a; ++j) {
            if (lengths[j] >= h) {
                count_v++;
            } else {
                break;
            }
        }

        v = std::min(v, count_v);
        int area = h * v;

        if (area > max_area) {
            max_area = area;
        }

        if (v == 0) {
            break;
        }
    }

    std::cout << max_area << std::endl;
}