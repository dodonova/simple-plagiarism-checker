t=int(input())
tis=[int(x) for x in input().split()]
s=0
len1=0
len2=0
nn1=0
nn2=0
for i in range(0,int(len(tis)/2)):
    len1+=tis[i]
for i in range(int(len(tis)/2),len(tis)):
    len2+=tis[i]
len1=int(len1/int(len(tis)/2))
len2=int(len2/int(len(tis)/2))
for i in range(0,int(len(tis)/2)):
    if tis[i]<len1:
        nn1+=1
for i in range(int(len(tis)/2),len(tis)):
    if tis[i]<len2:
        nn2+=1
if len1>int((len(tis)-nn1)/2):
    len1=(len(tis)-nn1)/2
if len2>int((len(tis)-nn2)/2):
    len2=(len(tis)-nn2)/2
print(int(len1*len2))

