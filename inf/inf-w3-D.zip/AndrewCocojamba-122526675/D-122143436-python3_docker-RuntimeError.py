m = int(input())   
n = int(input())   
k = int(input())   

max_deli = m * n // k   
if (m * n) % k == 0:   
    print(max_deli)   
else:     
    for i in range(max_deli, 0, -1):   
        if (m * n) % i == 0 and (m * n) // i >= k:   
            print(i)   
            break