n = int(input())
widths = list(map(int, input().split()))

widths.sort()
max_area = 0

for i in range(n // 2):
    area = widths[i] * widths[n - i - 1]
    max_area = max(max_area, area)

print(max_area)