k = int(input().strip())
l = list(map(int, input().strip().split()))
def kl(k, l):
    l.sort(reverse=True)

    nm = 0


    for k in range(1, k):
        op = k * l[k]
        nm = max(nm, op)

    return nm


print(kl(k, l))