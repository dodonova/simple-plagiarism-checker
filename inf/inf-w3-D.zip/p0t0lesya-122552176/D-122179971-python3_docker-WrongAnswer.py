n = int(input())
m = list(map(int, input().split()))
m.sort()

m_k = 0
m_zn = 0
for i in range(len(m)):
    if m.count(m[i]) > m_k:
        m_k = m.count(m[i])
        m_zn = m[i]



m_k2 = 0
m_zn2 = 0
for i in range(len(m)):
    if m[i] == m_k:
        m_k2 = m.count(m[i])
        for j in range(1, m[i]):
            m_k2 += m.count(m[i])
        m_z2 = m[i]
if m_k2 >= m_zn:
    print(m_k * m_zn)
else:
    print(m_k * m_z2)