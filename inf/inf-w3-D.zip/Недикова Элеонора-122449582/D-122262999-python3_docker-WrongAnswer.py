def max_plait_area(n, lengths):
    lengths.sort()
    max_area = 0
    for i in range(1, n):  
        h = i  
        v = n - i
        min_h = lengths[i - 1]
        min_v = lengths[n - 1]
        area = min_h * min_v * min(h, v)
        max_area = max(max_area, area)
    return max_area
import sys
input = sys.stdin.read
data = input().split()
n = int(data[0])
lengths = list(map(int, data[1:n + 1]))
result = max_plait_area(n, lengths)
print(result)
