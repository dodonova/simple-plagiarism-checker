def max_weaving_area(n, a):
    a.sort(reverse=True)
    max_area = 0
    
    for i in range(n + 1):
        for j in range(i + 1, n + 1):
            width = min(i, j)
            height = sum(a[:width])
            max_area = max(max_area, width * height)
    
    return max_area

n = int(input())
a = list(map(int, input().split()))
print(max_weaving_area(n, a))