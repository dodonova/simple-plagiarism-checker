eyud getij 
dykge
dunde
eyjfd
dukn
murd
krdv
ueevn
fdeyn