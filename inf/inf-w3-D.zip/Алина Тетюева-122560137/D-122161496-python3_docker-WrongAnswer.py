def max_plait_area(n, a):
    a.sort(reverse=True)

    vertical_count = n // 2
    horizontal_count = n - vertical_count

    max_area = horizontal_count * a[vertical_count - 1]

    return max_area

n = int(input().strip())
a = list(map(int, input().strip().split()))

print(max_plait_area(n, a))