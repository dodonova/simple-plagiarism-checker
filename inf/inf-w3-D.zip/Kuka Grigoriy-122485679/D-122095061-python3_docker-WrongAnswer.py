def max_braid_area(n, lengths):
    # Сортируем длины в порядке убывания
    lengths.sort(reverse=True)
    
    # Находим количество полосок для групп
    k = n // 2
    
    # Суммируем длины для первой группы
    sum_horizontal = sum(lengths[i] for i in range(k))
    sum_vertical = sum(lengths[i] for i in range(k, n))
    
    # Максимальная площадь плетенки
    max_area = 2 * min(sum_horizontal, sum_vertical)
    
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод максимальной площади
print(max_braid_area(n, lengths))