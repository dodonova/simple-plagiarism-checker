#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
using ll = long long;

int main() {
    ll n;
    cin >> n;
    vector <ll> arr;
    arr.resize(n);
    for (ll i = 0; i < n; ++i) {
        cin >> arr[i];
    }
    sort(arr.begin(), arr.end());
    ll s = 0;
    for (ll i = 0; i < n; ++i) {
        s = max(s, arr[i] * (n - i));
    }
    cout << s / 2;
    return 0;
}
