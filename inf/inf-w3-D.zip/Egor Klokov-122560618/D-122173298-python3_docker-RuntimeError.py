def max_area(widths, lengths):
    """
    Функция для вычисления максимальной площади плетенки.

    Args:
        widths: Список ширин полосок бумаги.
        lengths: Список длин полосок бумаги.

    Returns:
        Максимальная площадь плетенки.
    """

    widths.sort()
    lengths.sort()

    max_area = 0
    i = 0
    j = len(lengths) - 1

    while i < len(widths) and j >= 0:
        current_area = widths[i] * lengths[j]
        max_area = max(max_area, current_area) # Исправлено!

        if widths[i] < lengths[j]:
            i += 1
        else:
            j -= 1

    return max_area


# Ввод данных
n = int(input())
widths = list(map(int, input().split()))
lengths = list(map(int, input().split()))

# Вычисление максимальной площади
max_area = max_area(widths, lengths)

# Вывод результата
print(max_area)