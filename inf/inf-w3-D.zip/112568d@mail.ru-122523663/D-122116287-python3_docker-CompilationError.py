def max_braiding_area(n, lengths):
   
    lengths.sort(reverse=True)
    
    max_area = 0
   
    for k in range(1, n // 2 + 1):
        
        horizontal_length = min(lengths[i] for i in range(k))
        vertical_length = min(lengths[i] for i in range(k, 2 * k))
         area = horizontal_length * vertical_length * k
        max_area = max(max_area, area)
    
    return max_area = 0
n = int(input())
lengths = list(map(int, input().split()))
result = max_braiding_area(n, lengths)
print(result)