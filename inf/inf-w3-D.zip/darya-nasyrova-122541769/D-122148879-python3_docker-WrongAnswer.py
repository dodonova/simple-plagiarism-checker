def max_weaving_area(n, lengths):
    max2 = lengths[-2]  # Вторая по величине длина # Площадь прямоугольника area = max1 * max2
    return n
n = int(input())
lengths = list(map(int, input().split()))
result = max_weaving_area(n, lengths)
print(result)