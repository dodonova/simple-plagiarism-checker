
def max_weaving_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort()
    
    max_area = 0
    
    # Обойдем все возможные k от 1 до n-1
    for k in range(1, n):
        # Количество в первой группе (k)
        # Количество во второй группе (n - k)
        
        # Длина максимальной полоски в первой группе
        max_length_group_1 = lengths[k - 1]
        
        # Длина максимальной полоски во второй группе
        max_length_group_2 = lengths[n - k]
        
        # Площадь = min(k, n - k) * max_length
        area = min(k, n - k) * max(max_length_group_1, max_length_group_2)
        
        # Обновляем максимальную площадь
        max_area = max(max_area, area)
    
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_weaving_area(n, lengths))
