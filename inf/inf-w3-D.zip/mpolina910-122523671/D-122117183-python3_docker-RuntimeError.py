n=int(input())
s=""
for _ in range(n):
   a=input()
   if a.find('лук')==-1:
       s=s+","+a if len(s)>0 else s+a
print(s)