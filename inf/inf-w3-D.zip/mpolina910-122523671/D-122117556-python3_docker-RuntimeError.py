s = input('s = ')
pos = []
for i in range(len(s)-1):
    if s[i] == s[i+1]:
        pos.append(i+1)
if pos[0]%2 != pos[1]%2:
    print('no')
else:
    print(1, pos[0], 0)
    print(pos[0]+1, pos[1], 180)
    print(pos[1]+1, len(s), 0)