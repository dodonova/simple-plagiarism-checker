n = int(input())
lengths = list(map(int, input().split()))

lengths.sort(reverse=True)

yellow_lengths = []
green_lengths = []

for i in range(n):
  if i % 2 == 0:
    yellow_lengths.append(lengths[i])
  else:
    green_lengths.append(lengths[i])

max_area = 0
for i in range(len(yellow_lengths)):
  for j in range(len(green_lengths)):
    area = yellow_lengths[i] * green_lengths[j]
    max_area = max(max_area, area)

print(max_area)