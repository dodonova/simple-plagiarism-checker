n = int(input())
lengths = list(map(int, input().split()))

length_counts = {}
for length in lengths:
    length_counts[length] = length_counts.get(length, 0) + 1

top_two_lengths = sorted(length_counts, key=length_counts.get, reverse=True)[:2]

max_area = 0
if len(top_two_lengths) == 2:
    max_area = top_two_lengths[0] * top_two_lengths[1]
elif len(top_two_lengths) == 1 and length_counts[top_two_lengths[0]] >= 2:
    max_area = top_two_lengths[0] * top_two_lengths[0]

print("Максимальная площадь плетёнки:", max_area)