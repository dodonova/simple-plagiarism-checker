n = int(input())
lengths = list(map(int, input().split()))
lengths.sort(reverse=True)
max_area = 0
for i in range(n):
    for j in range(i + 1, n):
       if lengths.count(lengths[i]) >= i + 1 and lengths.count(lengths[j]) >= j + 1:
            max_area = max(max_area, lengths[i] * lengths[j])
print(max_area)