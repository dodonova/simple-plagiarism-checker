n = int(input())
lengths = list(map(int, input().split()))
lengths.sort(reverse=True)
max_area = 0
length_counts = {}
for length in lengths:
    length_counts[length] = length_counts.get(length, 0) + 1

for i in range(n):
    for j in range(i + 1, n):
        if length_counts[lengths[i]] >= i + 1 and length_counts[lengths[j]] >= j + 1:
            max_area = max(max_area, lengths[i] * lengths[j])
print(max_area)