def max_plait_area(n, lengths):
    lengths.sort()

    half = n // 2
    min_length_yellow = lengths[half - 1]
    min_length_green = lengths[n - 1]


    area = min_length_yellow * min_length_green
    return area



n = int(input())
lengths = list(map(int, input().split()))


result = max_plait_area(n, lengths)
print(result//2)
