#include <iostream>
#include <vector>
#include <algorithm>
#inclede <cmath>
using namespace std;

int main() {
    long long n;
    cin >> n;
    vector<long long> l(n);

    for (long long i = 0; i < n; ++i) {
        cin >> l[i];
    }

    sort(l.begin(), l.end(), greater<long long>());

    long long maxArea = 0;
    long long mx, my;
    for (long long i = 0; i < n - 1; ++i) {
        if (l[i] == l[i + 1]) {
            mx = i / 2 + 1;
            maxArea = max(maxArea, (long long int)(pow(min(mx, l[i]),2)));
        }
        else {
            if (i % 2 == 0) {
                mx = i / 2 + 1;
                maxArea = max(maxArea, (long long int)(pow(min(mx, l[i+1]), 2)));
            }
            else {
                mx = i / 2 + 1;
                maxArea = max(maxArea, min(mx+1, l[i])*min(mx, l[i+1]));
            }

        }
    }

    cout << maxArea ;
    
}
