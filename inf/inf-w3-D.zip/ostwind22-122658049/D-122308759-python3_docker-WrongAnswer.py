n = int(input())
ai = list(map(int, input().split()))
ai.sort()
print(ai)
S_max = 0
count = 1
for i in range(len(ai)):
    if ai[i] * (len(ai) - (i+1) - ai[i]) > S_max and (len(ai) - i-1 - ai[i]) >= ai[-ai[i]]:
        print(len(ai) - (i+1) - ai[i])
        S_max = ai[i] * (len(ai) - i-1 - ai[i])

print(S_max)