def max_weaving_area(n, lengths):
    lengths.sort(reverse=True)
    return (lengths[0] * lengths[1]) // 2
n = int(input())
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))