def max_plait_area(n, lengths):
    # Сортируем длины полосок по убыванию
    lengths.sort(reverse=True)

    # Максимальная площадь плетёнки
    max_area = 0
    
    # Проходим по всем возможным k (число полосок в каждой группе)
    for k in range(1, n // 2 + 1):
        # Длина k-й самой длинной полоски (для горизонтальных)
        L_max = lengths[k - 1]
        # Длина k-й самой длинной полоски (для вертикальных)
        W_max = lengths[k - 1]
        
        # Площадь плетёнки
        area = 2 * k * L_max * W_max
        
        # Обновляем максимальную площадь
        max_area = max(max_area, area)

    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Получаем и выводим результат
result = max_plait_area(n, lengths)
print(result)
