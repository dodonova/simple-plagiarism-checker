nikolay, maxim, metro = int(input()), 0, list(map(int, input().split()))
metro.sort(reverse=True)
for goool in range(1, nikolay + 1):
    if goool <= nikolay:
        minimalny = metro[goool - 1]
    else:
        minimalny = 0
    hot = min(minimalny, nikolay - goool)
    gif = metro[goool:]
    yogurt = 0
    for l in gif:
        if l >= goool:
            yogurt += 1
        else:
            break
    hot = min(hot, yogurt)
    area = goool * hot
    if area > maxim:
        maxim = area
    if hot == 0:
        break
print(maxim)