def max_braiding_area(n, a):
    a.sort(reverse=True)
    half_n = n // 2
    return a[half_n - 1] * a[half_n] 

n = int(input().strip())
a = list(map(int, input().strip().split()))

print(max_braiding_area(n, a))
