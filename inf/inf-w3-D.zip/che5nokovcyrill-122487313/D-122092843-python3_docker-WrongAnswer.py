def max_braiding_area(n, lengths):
    # Сортируем список длин полосок
    lengths.sort()
    
    # Инициализируем максимальную площадь
    max_area = 0
    
    # Перебираем все возможные разделения на горизонтальные и вертикальные
    for i in range(1, n):  # i — количество полосок для горизонтальных
        # Горизонтальные полоски — lengths[:i]
        # Вертикальные полоски — lengths[i:]
        horizontal_min = lengths[i - 1]
        vertical_min = lengths[n - 1]
        
        # Площадь плетёнки
        current_area = horizontal_min * vertical_min
        max_area = max(max_area, current_area)
    
    return max_area

# Читаем данные (можно использовать input())
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Выводим результат
print(max_braiding_area(n, lengths))
