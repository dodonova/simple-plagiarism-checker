n = int(input())
a = list(map(int, input().split()))
a.sort(reverse = True)
max1 = a[0] * a[1]
print(max1)