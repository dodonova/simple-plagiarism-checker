import sys

def read_ints():
    return list(map(int, sys.stdin.readline().split()))

n = int(sys.stdin.readline())
a = read_ints()

# Отсортируем полоски по длине в порядке невозрастания
a.sort(reverse=True)

# Префиксные суммы для количества полосок с длиной >= длины
lengths = []
counts = []
prev_length = None
count = 0

for length in a:
    if length != prev_length:
        lengths.append(length)
        counts.append(1)
        prev_length = length
    else:
        counts[-1] += 1

cumulative_counts = []
cumulative = 0
for c in counts:
    cumulative += c
    cumulative_counts.append(cumulative)

# Функция для поиска количества полосок с длиной >= L
def get_count(L):
    left, right = 0, len(lengths) - 1
    result = 0
    while left <= right:
        mid = (left + right) // 2
        if lengths[mid] >= L:
            result = cumulative_counts[mid]
            left = mid + 1
        else:
            right = mid - 1
    return result

max_area = 0

# Перебираем возможные значения h (число горизонтальных полосок)
for i in range(len(lengths)):
    h = cumulative_counts[i]
    min_length_for_h = lengths[i]

    # Количество полосок, которые можно использовать для вертикальных полосок
    remaining_strips = n - h

    # Максимальное возможное значение v
    v = min(get_count(min_length_for_h), remaining_strips)

    # Условия из задачи
    if v > 0 and get_count(v) >= h and min_length_for_h >= v:
        area = h * v
        if area > max_area:
            max_area = area

print(max_area)
