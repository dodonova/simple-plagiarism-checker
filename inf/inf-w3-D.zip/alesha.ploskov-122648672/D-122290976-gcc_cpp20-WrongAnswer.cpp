#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

typedef long long ll;

int main() {
    int n;
    cin >> n;
    vector<int> ai(n);
    for (int i = 0; i < n; ++i) {
        cin >> ai[i];
    }

    // Sort the strips in decreasing order
    sort(ai.begin(), ai.end(), greater<int>());

    // Count the frequency of each unique length
    map<int, int> counts;
    for (int length : ai) {
        counts[length]++;
    }

    // Get the unique lengths in decreasing order and cumulative counts
    vector<int> lengths;
    vector<int> cumulative_counts;
    int cumulative = 0;
    for (auto it = counts.rbegin(); it != counts.rend(); ++it) {
        lengths.push_back(it->first);
        cumulative += it->second;
        cumulative_counts.push_back(cumulative);
    }

    ll max_area = 0;
    int m = lengths.size();

    // Iterate over possible values of h (horizontal strips)
    for (int i = 0; i < m; ++i) {
        int length_h = lengths[i];
        int total_h = cumulative_counts[i];

        // Check if we have at least total_h strips of length >= length_h
        if (total_h < length_h) {
            continue;
        }

        int h = length_h; // Number of horizontal strips
        if (h > n) {
            continue;
        }

        // Remaining strips
        int strips_remaining = n - h;

        // Find number of strips with length >= h for vertical strips
        // Use binary search to find the index where length >= h
        int idx_v = -1;
        int left = 0, right = m - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (lengths[mid] >= h) {
                idx_v = mid;
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        if (idx_v == -1) {
            continue; // No strips of length >= h for vertical strips
        }

        int total_strips_length_ge_h = cumulative_counts[idx_v];
        int strips_available_for_v = total_strips_length_ge_h - h;

        if (strips_available_for_v <= 0) {
            continue; // No strips left for vertical strips
        }

        int v = min(strips_available_for_v, strips_remaining);
        if (v <= 0) {
            continue; // No strips available for vertical strips
        }

        ll area = (ll)h * v;
        if (area > max_area) {
            max_area = area;
        }
    }

    cout << max_area << endl;
    return 0;
}
