n = int(input())
a = list(map(int, input().split()))

a.sort(reverse=True)

max_area = 0

for i in range(n):
    width = i + 1
    length = a[i]

    area = width * length
    max_area = max(max_area, area)

print(max_area)