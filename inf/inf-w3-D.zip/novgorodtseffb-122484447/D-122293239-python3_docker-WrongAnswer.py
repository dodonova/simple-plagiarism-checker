def max_basket_area(n, lengths):
    # Сортируем длины полосок
    lengths.sort(reverse=True)

    # Массив для хранения возможных длин двух сторон плетёнки
    pairs = []
    i = 0

    # Проходим по отсортированным длинам и находим пары
    while i < n - 1:
        if lengths[i] == lengths[i + 1]:
            pairs.append(lengths[i])
            i += 2  # Пропускаем оба элемента, так как они уже образуют пару
        else:
            i += 1  # Переходим к следующему элементу

    # Если нашли хотя бы две пары
    if len(pairs) < 2:
        return 0  # Невозможно составить плетёнку

    # Сортируем найденные пары
    pairs.sort(reverse=True)

    # Максимальная площадь будет произведением двух наибольших значений
    return pairs[0] * pairs[1]

# Входные данные
n = int(input())  # количество полосок
lengths = list(map(int, input().split()))  # длины полосок

# Выводим результат
print(max_basket_area(n, lengths))