n = int(input())
lengths = list(map(int, input().split()))

lengths.sort(reverse=True)

max_area = 0
for i in range(n):
    if i % 2 == 0:
        area = lengths[i] * lengths[n - i - 1]
        max_area = max(max_area, area)

print(max_area)