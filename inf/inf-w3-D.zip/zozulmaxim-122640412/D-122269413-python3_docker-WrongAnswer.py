import sys
import bisect
from collections import Counter

def main():
    sys.setrecursionlimit(1000000)

    data = sys.stdin.read().split()
    scrambled = data[0]
    n = int(data[1])
    words = data[2:2+n]

    assert len(words) == n

    scrambled_counter = Counter(scrambled)

    candidates = []
    word_counters = []
    for word in words:
        wc = Counter(word)
        if all(wc[c] <= scrambled_counter.get(c, 0) for c in wc):
            candidates.append(word)
            word_counters.append(wc)

    sorted_candidates = sorted(zip(candidates, word_counters), key=lambda x: (-len(x[0]), x[0]))
    candidates = [x[0] for x in sorted_candidates]
    word_counters = [x[1] for x in sorted_candidates]

    total_length = len(scrambled)
    min_k = 5
    max_k = 8

    memo = {}

    def backtrack(start, selected, remaining_counter, k):
        if k == 0:
            return selected if not remaining_counter else None
        if (start, tuple(remaining_counter.elements()), k) in memo:
            return None
        
        rem_len = sum(remaining_counter.values())
        if rem_len < 5 * k or rem_len > 8 * k:
            return None
        
        for i in range(start, len(candidates)):
            word = candidates[i]
            wc = word_counters[i]
            if all(wc[c] <= remaining_counter.get(c, 0) for c in wc):
                new_selected = selected + [word]
                new_remaining = remaining_counter.copy()
                new_remaining.subtract(wc)
                new_remaining += Counter() 
                
                result = backtrack(i + 1, new_selected, new_remaining, k - 1)
                if result:
                    return result
        
        memo[(start, tuple(remaining_counter.elements()), k)] = None
        return None

    for k in range(min_k, max_k + 1):
        if 5 * k <= total_length <= 8 * k:
            result = backtrack(0, [], scrambled_counter, k)
            if result:
                for word in sorted(result):
                    print(word)
                return
    
    print()

if __name__ == "__main__":
    main()