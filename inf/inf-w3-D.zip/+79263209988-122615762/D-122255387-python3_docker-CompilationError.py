осз n, *rest = map(int, open(0).read().split())
lengths = rest[:n]
 
# Сортируем полоски в порядке убывания
lengths.sort(reverse=True)
 
def max_area(lengths):
    n = len(lengths)
    max_area = 0
    left, right = 1, n // 2
 
    # Бинарный поиск для квадрата
    while left <= right:
        mid = (left + right) // 2
        if lengths[mid - 1] >= mid and lengths[2 * mid - 1] >= mid:
            max_area = max(max_area, mid * mid)
            left = mid + 1
        else:
            right = mid - 1
 
    # Проверка для прямоугольника
    limit = min(2000, n)
    cnt_len_ge = [0] * (limit + 2)
    for length in lengths:
        if length <= limit:
            cnt_len_ge[length] += 1
 
    for i in range(limit, 0, -1):
        cnt_len_ge[i] += cnt_len_ge[i + 1]
 
    for h in range(1, limit + 1):
        v = cnt_len_ge[h]
        if v >= h:
            max_area = max(max_area, h * v)
 
    return max_area
 
print(max_area(lengths)) 