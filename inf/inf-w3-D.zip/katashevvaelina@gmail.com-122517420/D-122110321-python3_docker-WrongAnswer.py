n = int(input())
a = sorted(map(int, input().split()))
for i in range(1, n):
    if a[i-1] + a[i] <= n:
        n -= 1
        continue
    print(a[i-2] * a[i-1])
    break