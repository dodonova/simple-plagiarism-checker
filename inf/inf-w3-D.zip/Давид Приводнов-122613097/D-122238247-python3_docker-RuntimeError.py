def get_dict(string):
    data = {}
    for char in string:
        if char not in data:
            data[char] = 1
        else: 
            data[char] += 1
    return data

string = input()
string_len = len(string)
string_dict = get_dict(string)

def is_consist(string_list):
    data = get_dict(string)
    for word in string_list:
        for char in word:
            if data[char] == 0:
                return False
            else:
                data[char] -= 1
    for char in data:
        if data[char] != 0:
            return False
    return True
 
def is_include(word, str):
    for char in word:
        if char not in str:
            return False
        elif str[char] < word.count(char):
            return False
    return True

def next_word(words, new_string, char_size):    
    if len(new_string) > 8:
        return False
    
    if char_size == string_len:
        if is_consist(new_string):
            return new_string
        else:
            return False
    elif string_len - char_size < 5:
        return False
    
    last_word = min(string_len - char_size, 8)

    for i, word in enumerate(words):
        if len(word) > last_word:
            continue
        if word in new_string:   
            continue
        new_string.append(word)
        res = next_word(words[i:], new_string, char_size + len(word))
        if res != False:
            return res
        new_string.pop()
    return False

N = int(input())
words = []
for i in range(N):
    word = input()
    if is_include(word, string_dict):
        words.append(word)
        
answer = next_word(words, [], 0)

for i in answer:   
    print(i)