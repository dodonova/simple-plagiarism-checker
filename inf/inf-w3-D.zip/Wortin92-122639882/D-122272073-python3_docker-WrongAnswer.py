n = int(input())
leng = list(map(int, input().split()))

leng.sort()

h = leng[::2]
v = leng[1::2]

print(min(h)*min(v))