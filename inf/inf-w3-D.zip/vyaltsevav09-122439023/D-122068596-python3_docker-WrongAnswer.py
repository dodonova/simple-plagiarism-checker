def max_plait_area(n, lengths):
    lengths.sort()
    
    max_area = 0
    
    # Суммируем длины, начиная с конца
    sum_vertical = sum(lengths)
    sum_horizontal = 0

    # Мы можем делить на h и v полосок
    for h in range(1, n):  # h = количество горизонтальных полосок
        sum_horizontal += lengths[h - 1]  # добавляем длину очередной горизонтальной полоски
        sum_vertical -= lengths[h - 1]    # убираем из вертикальных полосок

        area = sum_horizontal * sum_vertical
        max_area = max(max_area, area)

    return max_area

# Чтение входных данных
n = int(input().strip())
lengths = list(map(int, input().strip().split()))

# Вычисление максимальной площади
result = max_plait_area(n, lengths)

# Вывод результата
print(result)