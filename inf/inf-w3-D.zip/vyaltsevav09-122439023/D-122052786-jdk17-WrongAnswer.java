import java.util.Arrays;
import java.util.Scanner;

public class MaxWeavingArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] lengths = new int[n];

        // Read the lengths of the paper strips
        for (int i = 0; i < n; i++) {
            lengths[i] = scanner.nextInt();
        }

        // Sort the lengths in descending order
        Arrays.sort(lengths);
        int maxArea = 0;

        // Try all possible combinations of yellow and green strips
        for (int i = 0; i <= n; i++) {
            int yellowLength = 0;
            int greenLength = 0;

            // Calculate the total length of yellow and green strips
            for (int j = 0; j < i; j++) {
                yellowLength += lengths[j];
            }
            for (int j = i; j < n; j++) {
                greenLength += lengths[j];
            }

            // Calculate the area of the woven rectangle
            int area = Math.min(yellowLength, greenLength) * 2;
            maxArea = Math.max(maxArea, area);
        }

        System.out.println(maxArea);
    }
}