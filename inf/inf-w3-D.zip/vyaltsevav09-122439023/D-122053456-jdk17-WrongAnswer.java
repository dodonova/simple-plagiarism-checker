import java.util.Arrays;
import java.util.Scanner;

public class MashaWeaving {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Чтение количества полосок
        int n = scanner.nextInt();
        int[] lengths = new int[n];
        
        // Чтение длин полосок
        for (int i = 0; i < n; i++) {
            lengths[i] = scanner.nextInt();
        }
        
        // Сортировка длин полосок
        Arrays.sort(lengths);
        
        // Инициализация переменной для хранения максимальной площади
        long maxArea = 0;
        
        // Проходим по возможным разделениям
        for (int i = 1; i <= n / 2; i++) {
            long horizontalLength = lengths[n - i]; // Длина для горизонтальных полосок
            long verticalLength = lengths[n - i - 1]; // Длина для вертикальных полосок
            long area = horizontalLength * verticalLength;
            maxArea = Math.max(maxArea, area);
        }
        
        // Вывод максимальной площади
        System.out.println(maxArea);
    }
}