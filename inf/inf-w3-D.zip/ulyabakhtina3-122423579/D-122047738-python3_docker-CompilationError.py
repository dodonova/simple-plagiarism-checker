def max_weaving_area(n, lengths): 
    lengths.sort(reverse=True)       
	max_pairs = n // 2 * 2  
    total_length = sum(lengths[:max_pairs])        
	max_area = total_length // 2
    return max_area
n = int(input())lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))