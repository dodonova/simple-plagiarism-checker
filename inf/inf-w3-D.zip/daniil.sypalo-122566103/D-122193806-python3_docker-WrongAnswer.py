def max_weaving_area(n, lengths):
    # Сортируем длины полосок по убыванию
    lengths.sort(reverse=True)
    
    # Находим максимальную площадь плетёнки
    max_area = 0
    for k in range(1, n // 2 + 1):
        # Длина плетёнки по горизонтали и вертикали
        S_h = sum(lengths[:k])
        S_v = sum(lengths[k:k*2])
        # Площадь для текущего k
        max_area = max(max_area, min(S_h, S_v) * 2)
    
    return max_area

# Пример ввода
n = int(input())
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))
