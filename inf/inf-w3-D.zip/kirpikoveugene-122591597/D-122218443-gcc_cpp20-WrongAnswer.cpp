#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<long long> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }

    sort(lengths.begin(), lengths.end());

    long long sum1 = 0, sum2 = 0;
    for (int i = n - 1; i >= 0; --i) {
        if (sum1 < sum2) {
            sum1 += lengths[i];
        } else {
            sum2 += lengths[i];
        }
    }

    cout << sum1 * sum2 << endl;
    return 0;
}

