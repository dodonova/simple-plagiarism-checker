#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

long long максимальная_плетёнка(int n, vector<long long>& a) {
    sort(a.begin(), a.end());
    long long sum1 = 0, sum2 = 0;
    for (int i = 0; i < n / 2; ++i) {
        sum1 += a[i];
    }
    for (int i = n / 2; i < n; ++i) {
        sum2 += a[i];
    }
    return sum1 * sum2;
}

int main() {
    int n;
    cin >> n;
    vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    cout << максимальная_плетёнка(n, a) << endl;
    return 0;
}
