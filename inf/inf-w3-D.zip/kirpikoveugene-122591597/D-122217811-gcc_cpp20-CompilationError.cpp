#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int n;
    cin >> n;
    vector<long long> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }

    sort(lengths.begin(), lengths.end());

    long long sumOdd = 0, sumEven = 0;
    for (int i = 0; i < n; ++i) {
        if (i % 2 == 0) {
            sumOdd += lengths[i];
        } else {
            sumEven += lengths[i];
        }
    }

    cout << max(sumOdd, sumEven) * (accumulate(lengths.begin(), lengths.end(), 0LL) - min(sumOdd, sumEven)) << endl;
    return 0;
}

