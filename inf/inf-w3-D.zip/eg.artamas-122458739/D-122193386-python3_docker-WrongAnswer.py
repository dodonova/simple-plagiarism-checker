def max_mat_area(n, lengths):
    # Сортируем полоски по убыванию
    lengths.sort(reverse=True)

    # Нам нужно по крайней мере по две полоски для каждой стороны
    horizontal = []
    vertical = []
    
    # Будем выбирать пары одинаковой длины для создания сторон
    i = 0
    while i < n - 1:
        if lengths[i] == lengths[i + 1]:  # если находим пару одинаковых полосок
            if len(horizontal) <= len(vertical):
                horizontal.append(lengths[i])
            else:
                vertical.append(lengths[i])
            i += 2
        else:
            i += 1

    # Теперь у нас есть списки horizontal и vertical с парами полосок
    if len(horizontal) < 1 or len(vertical) < 1:
        return 0  # если не удалось собрать хотя бы по две полоски
    
    # Считаем максимальную площадь
    return horizontal[0] * vertical[0]

if __name__ == "__main__":
    n = int(input())
    lengths = list(map(int, input().split()))
    print(max_mat_area(n, lengths))
