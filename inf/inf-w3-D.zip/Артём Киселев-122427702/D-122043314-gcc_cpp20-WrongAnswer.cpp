#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n; // Считываем количество полосок
    vector<int> lengths(n);
    
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i]; // Считываем длины полосок
    }
    
    // Сортируем длины полосок
    sort(lengths.begin(), lengths.end());
    
    // Максимальная площадь будет равна произведению двух самых длинных полосок
    // и двух самых коротких полосок
    int maxArea = lengths[n - 1] * lengths[n - 2]; // Две самые длинные
    int minArea = lengths[0] * lengths[1]; // Две самые короткие
    
    // Площадь плетёнки будет равна минимуму из maxArea и minArea
    cout << min(maxArea, minArea) * 2 << endl;

    return 0;
}