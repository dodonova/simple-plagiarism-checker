#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    long n;
    cin >> n;

    vector<long> lengths(n);
    
    // Считываем длины полосок
    for (long i = 0; i < n; i++) {
        cin >> lengths[i];
    }

    // Сортируем длины в порядке убывания
    sort(lengths.begin(), lengths.end());

    long maxArea = 0;

    // Перебираем все возможные группы для нахождения максимальной площади
    for (long i = 1; i < n; i++) {
        long yellowCount = i;              // Количество желтых полосок
        long greenCount = n - yellowCount; // Количество зеленых полосок

        long h = lengths[yellowCount - 1]; // Длина самой короткой желтой полоски
        long w = lengths[n - greenCount];   // Длина самой короткой зеленой полоски

        long area = h * w;
        maxArea = max(maxArea, area);
    }

    cout << maxArea << endl;

    return 0;
}
