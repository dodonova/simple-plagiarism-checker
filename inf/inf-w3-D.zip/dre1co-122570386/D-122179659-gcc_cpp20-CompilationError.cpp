def max_weaving_area(n, lengths):

    lengths.sort(reverse=True)

    total_sum = sum(lengths)
    max_area = 0
    current_sum = 0
    

    for i in range(n - 1):  # n-1
        current_sum += lengths[i]
        remaining_sum = total_sum - current_sum area = current_sum * remaining_sum
        max_area = max(max_area, area)
    
    return max_area

n = int(input())
lengths = list(map(int, input().split()))

result = max_weaving_area(n, lengths)

print(result)
