def max_rectangle_area(n, a):
    sum_ai = sum(a)
    min_ai = min(a)
    max_ai = max(a)
    
    # Calculate the maximum area possible
    area_horizontal = sum_ai * min_ai
    area_vertical = max_ai * (sum_ai - min_ai)
    
    return max(area_horizontal, area_vertical)

# Reading input
n = int(input())
a = list(map(int, input().split()))

# Calculating the maximum rectangle area
max_area = max_rectangle_area(n, a)

# Output the result
print(max_area)
