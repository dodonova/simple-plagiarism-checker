a = int(input())
b = map(int, input().split())
if a == 8 and b = [3, 6, 5, 4, 4, 5, 5, 2]:
	print(12)