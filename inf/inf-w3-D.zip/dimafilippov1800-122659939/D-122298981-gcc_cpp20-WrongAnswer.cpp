#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    
    vector<int> lengths(n);
    for (int i = 0; i < n; ++i) {
        cin >> lengths[i];
    }
    
    // Инициализация указателей
    int left = 0;
    int right = n - 1;
    
    // Инициализация максимальной площади
    long long max_area = 0;
    
    // Пока указатели не встретятся
    while (left <= right) {
        // Выбираем более короткую сторону
        int min_length = min(lengths[left], lengths[right]);
        
        // Вычисляем текущую площадь
        long long current_area = 1LL * min_length * (right - left + 1);
        
        // Обновляем максимальную площадь
        if (current_area > max_area) {
            max_area = current_area;
        }
        
        // Сдвигаем указатель с более короткой стороной
        if (lengths[left] < lengths[right]) {
            ++left;
        } else {
            --right;
        }
    }
    
    // Выводим максимальную площадь
    cout << max_area << endl;
    
    return 0;
}
