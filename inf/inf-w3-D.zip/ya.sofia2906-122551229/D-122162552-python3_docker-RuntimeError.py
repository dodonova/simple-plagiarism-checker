n = int(input())
a, b = map(int, input().split())

if n == 1:
    print(min(a, b))
else:
    print(min(a, b) * (n // 2))