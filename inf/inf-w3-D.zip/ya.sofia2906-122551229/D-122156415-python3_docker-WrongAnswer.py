def max_plait_area(n, lengths):
    lengths.sort(reverse=True)
    # Параметры для горизонтальных и вертикальных полосок
    horizontal = lengths[::2]
    vertical = lengths[1::2]
    
    max_area = min(sum(horizontal), sum(vertical))
    return max_area ** 2

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_plait_area(n, lengths))