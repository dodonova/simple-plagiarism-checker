def max_area_of_weave(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    for k in range(1, n // 2 + 1):
        area = lengths[k - 1] * (k)
        if area > max_area:
            max_area = area
    
    return max_area

n = int(input())
lengths = list(map(int, input().split()))
print(max_area_of_weave(n, lengths))
