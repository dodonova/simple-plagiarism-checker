import functools


class Group(object):
    def __init__(self, min_value: int|float = float('inf'), cnt: int = 0) -> None:
        self.min_value = min_value
        self.cnt = cnt

    def create_from(group, value: int):
        return Group(min(group.min_value, value), group.cnt+1)

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.min_value == other.min_value and self.cnt == other.cnt
        else:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self.min_value, self.cnt))


def read() -> list:
    return list(map(int, input().split()))


def main():
    n, a = int(input()), read()

    def largest_rectangle_area(heights):
        n = len(heights)
        left = [0] * n
        right = [0] * n
        stack = []

        for i in range(n):
            while stack and heights[stack[-1]] >= heights[i]:
                stack.pop()

            left[i] = stack[-1] if stack else -1
            stack.append(i)

        stack = []
        for i in range(n-1, -1, -1):
            while stack and heights[stack[-1]] >= heights[i]:
                stack.pop()

            right[i] = stack[-1] if stack else n
            stack.append(i)

        max_area = 0
        for i in range(n):
            max_area = max(max_area, heights[i] * (right[i] - left[i] - 1))

        return max_area

    print(largest_rectangle_area(a)//2)


if __name__ == '__main__':
    main()