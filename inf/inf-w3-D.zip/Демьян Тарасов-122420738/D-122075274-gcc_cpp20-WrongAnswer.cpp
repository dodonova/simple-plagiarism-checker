
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;


int main() {
  int n;
  long long maxS = 0;
  cin >> n;
  vector<int> v(n);
  vector<int> x;
  vector<int> y;
  
  for(int i=0; i<n; i++)
    cin >> v[i];
  
  sort(v.begin(), v.end());
  
  bool fl = true;
  for(int i = n-1; i >= 0; i--){
    if(fl)
      x.push_back(v[i]);
    else
      y.push_back(v[i]);
    fl=!fl;
  }
  for(int i = 1; i <= y.size(); i++){
    int l=0;
    for(int j = min(y[i-1], int(x.size())); j > 0; j--){
      if(x[j-1] >= i) {
        l = j;
        break;
      }
    }
    maxS = max(maxS, 1ll*l*i);
  }
  
  cout << maxS;
  return 0;
}