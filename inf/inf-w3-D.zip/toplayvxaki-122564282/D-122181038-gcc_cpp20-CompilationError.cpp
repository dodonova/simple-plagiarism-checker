#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <unordered_set>

using namespace std;


int main() {
    int n;
    cin >> n;
    vector <string> a;
    for(int i = 0; i < n/2; i++){
        string b;
        cin >> b;
        a.push_back(b);
    }

    vector <string> q;
    for(int i = n/2; i < n; i++){
        string b;
        cin >> b;
        q.push_back(b);
    }
    sort(a.begin(), a.end());
    sort(q.begin(), q.end());

    cout << a[0] * q[1];


    return 0;
}
