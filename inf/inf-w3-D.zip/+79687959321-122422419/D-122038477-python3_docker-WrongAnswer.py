def max_braided_area(n, lengths):
    # Сортировка длин полосок в порядке убывания
    lengths.sort(reverse=True)
    # Вычисление суммы двух наибольших длин
    sum_lengths = sum(lengths[:2])
    # Вычисление площади плетенки
    braided_area = sum_lengths * min(lengths[2:])
    return braided_area

# Ввод количества полосок
n = int(input("Введите количество полосок: "))
# Ввод длин полосок
lengths = list(map(int, input("Введите длины полосок: ").split()))

# Получаем результат
result = max_braided_area(n, lengths)
print(result)