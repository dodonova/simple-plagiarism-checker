n = int(input()) 
a = list(map(int, input().split())) 
a.sort(reverse=True) 
 
left = 0 
right = n - 1 
max_area = 0 
 
while left < right: 
    max_area = max(max_area, min(a[left], a[right]) * (right - left + 1)) 
    if a[left] < a[right]: 
        left += 1 
    else: 
        right -= 1 
 
print(max_area)