n = int(input())
lines = sorted(map(int, input().split()))

max_area = min(lines[-1], len(lines) - 1)

for i in range(len(lines)):
    if len(lines) > lines[i] + 1:
        mx = lines[-lines[i]]
    else:
        break
    count = min(mx, len(lines) - lines[i] - i)

    max_area = max(max_area, count * lines[i])

print(max_area)
