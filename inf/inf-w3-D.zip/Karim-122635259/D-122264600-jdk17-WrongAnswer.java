

import java.io.*;
import java.util.*;


public class Main {
    public static void main(String[] args) throws IOException {
        int n = nextInt();
        List<Integer> lengths = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            lengths.add(nextInt());
        }

        lengths.sort(Comparator.comparingInt(i -> i));

        long maxS = 0;
        for (int i = 0; i < lengths.size()-1; i++) {
            List<Integer> l1 = lengths.subList(0, i+1);
            List<Integer> l2 = lengths.subList(i+1, lengths.size());

            int min1 = Integer.MAX_VALUE;
            for (int e:l1) {
                min1 = Math.min(e, min1);
            }
            min1 = Math.min(l2.size()*2+1, min1);

            int min2 = Integer.MAX_VALUE;
            for (int e:l2) {
                min2 = Math.min(e, min2);
            }
            min2 = Math.min(l1.size()*2+1, min2);

            maxS = Math.max(maxS, (long) min1 *min2);
        }

        out.println(maxS);
        out.close();
    }

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter out = new PrintWriter(System.out);
    static StringTokenizer in = new StringTokenizer("");


    public static boolean hasNext() throws IOException {
        if (in.hasMoreTokens()) return true;
        String s;
        while ((s = br.readLine()) != null) {
            in = new StringTokenizer(s);
            if (in.hasMoreTokens()) return true;
        }
        return false;
    }

    public static String nextToken() throws IOException {
        while (!in.hasMoreTokens()) {
            in = new StringTokenizer(br.readLine());
        }
        return in.nextToken();
    }

    public static int nextInt() throws IOException {
        return Integer.parseInt(nextToken());
    }

    public static double nextDouble() throws IOException {
        return Double.parseDouble(nextToken());
    }

    public static long nextLong() throws IOException {
        return Long.parseLong(nextToken());
    }
}