def max_weaving_area(n, lengths):
    lengths.sort(reverse=True) 
    max_area = 0

    for m in range(1, n // 2 + 1):
        S = sum(lengths[:m]) 
        area = m * min(S, sum(lengths[m:])) 
        max_area = max(max_area, area)

    return max_area

n = int(input())
lengths = list(map(int, input().split()))
print(max_weaving_area(n, lengths))