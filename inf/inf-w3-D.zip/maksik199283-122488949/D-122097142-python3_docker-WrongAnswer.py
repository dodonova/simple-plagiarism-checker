def max_area(n, a):
    a.sort()  
    max_h = a[-2]  
    max_v = a[-1]  
    return max_h * max_v
n = int(input())
a = list(map(int, input().split()))
result = max_area(n, a)
print(result)