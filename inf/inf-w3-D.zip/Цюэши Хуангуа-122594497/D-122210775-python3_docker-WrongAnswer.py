def calculate_max_area(count, strip_lengths):
    # Упорядочиваем длины полосок
    strip_lengths.sort()
    
    # Находим середину для разделения на две части
    midpoint = count // 2
    
    # Вычисляем длины для горизонтальных и вертикальных полос
    if count % 2 == 0:
        horizontal_length = sum(strip_lengths[midpoint:])
        vertical_length = sum(strip_lengths[:midpoint])
    else:
        horizontal_length = sum(strip_lengths[midpoint+1:])
        vertical_length = sum(strip_lengths[:midpoint+1])
    
    # Площадь плетенки является произведением длин горизонтальных и вертикальных полос
    return min(horizontal_length, vertical_length) * 2

# Считывание входных данных
import sys
input_data = sys.stdin.read
input_values = input_data().split()

n = int(input_values[0])
lengths = list(map(int, input_values[1:]))

# Вычисляем результат и выводим его
result_value = calculate_max_area(n, lengths)
print(result_value)