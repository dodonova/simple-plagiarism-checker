gas = int(input())
assol = list(map(int, input().split()))

for i in range(0, len(assol)):
    for j in range(i+1, len(assol)):
        if assol[i] >= assol[j]:
            assol[i], assol[j] = assol[j],assol[i]
print(assol[0] * assol[gas // 2])