import sys
import bisect

def calculate_max_area(n, ai):
    ai_sorted = sorted(ai)
    
    
    count = [0] * (n + 2)  
    for k in range(1, n + 1):
        idx = bisect.bisect_left(ai_sorted, k)
        count[k] = n - idx  
    
    max_area = 0 
    
    
    for h in range(1, n + 1):
        
        w_max = min(count[h] - h, n - h)
        if w_max < 1:
            continue  
        
        
        left, right = 1, w_max
        best_w = 0
        while left <= right:
            mid = (left + right) // 2
            if count[mid] >= h:
                best_w = mid
                left = mid + 1  
            else:
                right = mid - 1  
        
        if best_w > 0:
            area = h * best_w
            max_area = max(max_area, area)  
    
    return max_area

def main():
    
    input_data = sys.stdin.read().split()
    n = int(input_data[0])
    ai = list(map(int, input_data[1:n + 1]))
    
    
    max_area = calculate_max_area(n, ai)
    print(max_area)

if __name__ == "__main__":
    main()