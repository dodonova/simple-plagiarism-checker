def amogus(n, lengths):
    lengths.sort()
    
    imposter = n // 2
    
    if n % 2 == 0:
        sus = sum(lengths[imposter:]) #тут мне стало лень я решил делать как судьба велит
        ses = sum(lengths[:imposter])
    else:
        sus = sum(lengths[imposter+1:])
        ses = sum(lengths[:imposter+1])
    
    return min(sus, ses) * 2

import sys
mashka = sys.stdin.read #помогите у меня 2 ночи у меня пробник завтра
yummy = mashka().split()

n = int(yummy[0])
lengths = list(map(int, yummy[1:]))


niko_pro = amogus(n, lengths)
print(niko_pro)