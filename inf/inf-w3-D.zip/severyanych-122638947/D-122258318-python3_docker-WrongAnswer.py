def max_weaving_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Определяем количество полосок, которые можно использовать
    k = n // 2  # максимальное количество полосок одного цвета
    
    # Если n нечетное, используем только k полосок
    # Площадь будет равна произведению первых k длин полосок
    # Для горизонтальных и вертикальных полосок
    max_area = lengths[k - 1] * lengths[0]
    
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Получение максимальной площади
result = max_weaving_area(n, lengths)

# Вывод результата
print(result)
