n = int(input())
lengths = list(map(int, input().split()))

total_length = 0
for length in lengths:
    total_length += length

print(total_length)