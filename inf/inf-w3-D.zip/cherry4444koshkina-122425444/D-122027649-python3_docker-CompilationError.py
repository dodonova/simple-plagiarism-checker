def max_plait_length(n, lengths):
yellow = []
green = []

for i in range(n):
if i % 2 == 0:
yellow.append(lengths[i])
else:
green.append(lengths[i])

total_length = sum(yellow) + sum(green)
return total_length
n = int(input())
lengths = list(map(int, input().split()))
result = max_plait_length(n, lengths)
print(result)