from math import floor
n = int(input())
a = sorted(map(int, input().split()), reverse=True)
s = floor(sum(a) / len(a))
aw = sum(1 for i in a if i > s)
al = [i for i in a if i <= s]
m = 10**5
res = []
for i in range(len(al)):
    if al[i] <= m:
        m = al[i]
    res.append(m * (i+1))
w, l = (a[0], 1), (a[1], 1)
for i in range(2, len(a)):
    if i % 2 == 0:
        w = (a[i], w[1] + 1)
    else:
        l = (a[i], l[1] + 1)
    res.append(min(w[0], l[0]) * min(w[1], l[1]))
print(max(res))