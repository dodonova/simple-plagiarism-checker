n = int(input())
a = sorted(map(int, input().split()), reverse=True)
w, l = (a[0], 1), (a[1], 1)
res = []
for i in range(2, len(a)):
    if i % 2 == 0:
        w = (a[i], w[1] + 1)
    else:
        l = (a[i], l[1] + 1)
    res.append(min(w[0], l[0]) * min(w[1], l[1]))
print(max(res))