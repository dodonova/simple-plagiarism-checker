# Считываем количество полосок
n = int(input())

# Функция для удаления минимального элемента из списка
def remove_min_element(lst):
    lst.remove(min(lst))

# Считываем длины полосок и преобразуем их в список целых чисел
paper_lengths = list(map(int, input().split()))

# Проверяем, что количество длин соответствует заданному n
if len(paper_lengths) == n:
    # Сортируем список длин по возрастанию
    paper_lengths.sort()
    
    # Находим минимальную длину и сохраняем её
    first_min = paper_lengths[0]
    
    # Удаляем минимальный элемент
    remove_min_element(paper_lengths)
    
    # Находим следующий минимальный элемент
    second_min = paper_lengths[0]
    
    # Печатаем максимальную площадь плетёнки с учётом двух минимальных длин, умноженной на 2
    print(first_min * second_min * 2)

