n = int(input())
a = list(map(int, input().split()))
a.sort(reverse=True)
max_area = 0
for i in range(n):
    for j in range(i + 1, n):
        max_area = max(max_area, a[i] * a[j])

print(max_area)
