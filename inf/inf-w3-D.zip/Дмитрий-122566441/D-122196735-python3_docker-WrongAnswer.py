def max_area(n, a):
    a.sort(reverse=True)

    sum1 = sum(a[i] for i in range(0, n, 2))
    sum2 = sum(a[i] for i in range(1, n, 2))

    return 2 * min(sum1, sum2)

n = int(input())
a = list(map(int, input().split()))
print(max_area(n, a))