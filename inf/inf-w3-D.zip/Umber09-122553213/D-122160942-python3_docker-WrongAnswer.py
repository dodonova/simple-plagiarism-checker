def max_plait_area(n, lengths):
    lengths.sort(reverse=True)

    horizontal = lengths[::2]
    vertical = lengths[1::2]
    
    max_area = min(sum(horizontal), sum(vertical))
    return max_area ** 2


n = int(input())
lengths = list(map(int, input().split()))


print(max_plait_area(n, lengths))