def max_plait_area(n, lengths):
    # Сортируем длинны полосок по убыванию
    lengths.sort(reverse=True)

    # Чтобы получить максимальную площадь, берем длины двух самых длинных полосок
    if n < 2:
        return 0

    # Извлекаем две самые длинные полоски
    l1 = lengths[0]
    l2 = lengths[1]

    # Площадь плетенки
    return l1 * l2

# Ввод данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод максимальной площади
print(max_plait_area(n, lengths))