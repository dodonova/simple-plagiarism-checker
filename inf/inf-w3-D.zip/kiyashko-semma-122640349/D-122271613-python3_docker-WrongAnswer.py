n = int(input())
str = []*n
str = map(int, input().split())
str = sorted(str)
if n-2 >= str[3]:
    print(str[2] * str[3])
elif n-1 >= str[2]:
    print(str[1]*str[2])
else:
    print(str[0]*str[1])