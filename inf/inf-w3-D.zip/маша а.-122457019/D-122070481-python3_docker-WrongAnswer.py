def max_basket_area(n, lengths):

    # Сортируем полоски по длинам по убыванию для дальнейшей эффктивной проверки

    lengths.sort(reverse=True)

    # Переменные для подсчета суммарной длины горизонтальных и вертикальных полосок

    horizontal_sum = 0

    vertical_sum = 0

    # В цикле проходим по всем полоскам

    for i in range(n):

        # Выбираем, какой сумме (горизонтальной или вертикальной) добавить текущую полоску

        # На каждом шаге выбираем ту, которая меньше, чтобы обе суммы были максимально сбалансированы

        if horizontal_sum <= vertical_sum:

            horizontal_sum += lengths[i]

        else:

            vertical_sum += lengths[i]

    # Площадь плетёнки будет равна произведению минимальной из двух сумм и количества полосок в меньшей сумме

    # Это потому что одна сторона плетёнки будет длиной равна меньшей из сумм, 

    # другая - количеству полосок в меньшей сумме

    width = min(horizontal_sum, vertical_sum)

    height = len([l for l in lengths if l <= width])

    # Возвращаем максимальную возможную площадь

    return width * height

# Считываем входные данные

n = int(input().strip())

lengths = list(map(int, input().strip().split()))

# Вычисляем и выводим максимальную площадь плетёнки

print(max_basket_area(n, lengths))

