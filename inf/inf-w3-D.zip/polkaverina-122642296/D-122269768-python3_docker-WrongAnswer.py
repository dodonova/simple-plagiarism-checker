def max_braid_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    max_area = 0
    area_sum = 0
    
    # Вычисляем максимальную площадь
    for k in range(1, n + 1):
        area_sum += lengths[k - 1]  # добавляем длину текущей полоски
        # Площадь = количество полосок * сумма длин полосок другой группы
        max_area = max(max_area, area_sum * k)

    return max_area

# Чтение данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_braid_area(n, lengths))
