x = int(input())
while x != 0:
    z = int(input())
while x == 0:
    print(z)
    exit()