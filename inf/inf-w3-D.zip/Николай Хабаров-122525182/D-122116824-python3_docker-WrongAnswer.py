def max_plait(n, lengths):
  lengths.sort(reverse=True)
  max_area = 0

  for i in range(1, n + 1):
    x = min(n - i, n)
    if x > 0:
      area = i * x
      max_area = max(max_area, area)
  return max_area

n = int(input())
lenghts = list(map(int, input().split()))

result = max_plait(n, lenghts)
print(result)