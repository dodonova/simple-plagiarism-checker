def max_braided_area(q, len):

    max_len = lengths[-k]  # Длина k-й самой длинной полоски
    
    # Площадь плетёнки
    area = max_len * k
    return area

# Чтение входных данных
q = int(input())
len = list(map(int, input().split()))

# Вычисление максимальной площади
result = max_braided_area(q, len)

# Вывод результата
print(result)
