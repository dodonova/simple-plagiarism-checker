g = int(input())
b = sorted(map(int, input().split()), reverse=True)
w, l = (b[0], 1), (b[1], 1)
r = []
for j in range(2, len(b)):
    if j % 2 == 0:
        w = (b[j], w[j] + 1)
    else:
        l = (b[j], l[1] + 1)
    r.append(min(w[0], l[0]) * min(w[1], l[1]))
print(max(r))