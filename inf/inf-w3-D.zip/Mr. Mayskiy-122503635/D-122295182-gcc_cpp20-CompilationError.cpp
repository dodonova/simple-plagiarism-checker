#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int calculateMaxArea(int numStrips, vector<int> stripLengths) {
    sort(stripLengths.begin(), stripLengths.end(), greater<int>());
    
    vector<int> horizontalStrips;
    vector<int> verticalStrips;
    for (int i = 0; i < numStrips; i++) {
        if (i % 2 == 0) {
            horizontalStrips.push_back(stripLengths[i]);
        } else {
            verticalStrips.push_back(stripLengths[i]);
        }
    }
    
    int maxWidth = min(horizontalStrips.size(), verticalStrips.size());
    
    int maxArea = 0;
    for (int i = 1; i <= maxWidth; i++) {
        for (int j = i; j <= maxWidth; j++) {
            int totalLength = 0;
            int minLength = INT_MAX;
            for (int k = 0; k < i; k++) {
                totalLength += min(horizontalStrips[k], verticalStrips[k]);
                minLength = min(minLength, min(horizontalStrips[k], verticalStrips[k]));
            }
            int maxLength = min(totalLength / i, minLength);
            int area = maxLength * i;
            maxArea = max(maxArea, area);
        }
    }
    
    return maxArea;
}

int main() {
    int numStrips;
    cin >> numStrips;
    vector<int> stripLengths(numStrips);
    for (int i = 0; i < numStrips; i++) {
        cin >> stripLengths[i];
    }
    
    cout << calculateMaxArea(numStrips, stripLengths) << endl;
    
    return 0;
}