def max_braid_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
    
    # Если полосок четное количество, берем их все, иначе теряем одну
    if n % 2 != 0:
        n -= 1
    
    # Максимальная площадь равна произведению двух наибольших длин
    max_area = lengths[0] * lengths[1]
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Проверка, что количество полосок соответствует введенному n
if len(lengths) != n:
    print("Ошибка: Количество введенных длин не соответствует заявленному количеству полосок.")
else:
    # Вывод результата
    print(max_braid_area(n, lengths))

