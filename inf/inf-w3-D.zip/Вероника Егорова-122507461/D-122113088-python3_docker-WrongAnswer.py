a=int(input())
k=0
b=list(map(int, input().split()))
d=[]
d=b
e=0
f=0
while True:
  if a%2==0:
    for i in b:
      if i>=a/2:
        k+=1
    if k==a:
      k=2
      break
    else:
      a-=1
      k=0
      
  else:
    for i in b:
      if min(d)>=(a-1)//2:
        k+=1
        d.remove(min(d))
      else:
        d.remove(min(d))
    if k>=(a-1)//2:
      k=1
      break   
    else:
      a-=1
      k=0
      d=b
  if k==2 or k==1:
      break
      
if k==2:
  print((a//2)*(a//2))

else:
  e=(a-1)//2
  print(e*(a-e))