def max_basket_area(n, lengths):
    lengths.sort(reverse=True)
    max_area = 0
    for i in range(1, n // 2 + 1):
        horizontal_length = sum(lengths[:i])  
        vertical_length = sum(lengths[i:i+i])  
        area = horizontal_length * vertical_length
        max_area = max(max_area, area)
    return max_area
n = int(input())
lengths = list(map(int, input().split()))
result = max_basket_area(n, lengths)
print(result)
