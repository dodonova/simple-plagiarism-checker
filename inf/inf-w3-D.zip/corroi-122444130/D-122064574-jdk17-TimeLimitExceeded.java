// Framework: Java Standard Library
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    static int arraySize;

    static boolean isValid(int x, int y, long[] array) {
        int index1 = lowerBound(array, x);
        int index2 = lowerBound(array, y);
        return arraySize - index1 >= y && arraySize - index2 >= x && arraySize - Math.min(index1, index2) >= x + y;
    }

    static int lowerBound(long[] array, int value) {
        int left = 0, right = array.length;
        while (left < right) {
            int mid = (left + right) / 2;
            if (array[mid] < value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }
        return left;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        arraySize = scanner.nextInt();
        long[] array = new long[arraySize];
        for (int i = 0; i < arraySize; ++i) {
            array[i] = scanner.nextLong();
        }
        Arrays.sort(array);
        long result = 0;
        for (int i = 1; i <= arraySize; ++i) {
            int left = 0, right = arraySize + 1 - i;
            while (right - left > 1) {
                int mid = (right + left) / 2;
                if (isValid(i, mid, array)) {
                    left = mid;
                } else {
                    right = mid;
                }
            }
            result = Math.max(result, (long) i * left);
        }
        System.out.println(result);
    }
}