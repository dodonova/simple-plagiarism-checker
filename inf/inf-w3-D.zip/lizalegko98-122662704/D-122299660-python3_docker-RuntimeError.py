def max_braid_area(n, lengths):
    # Сортируем длины полосок в порядке убывания
    lengths.sort(reverse=True)
 # Количество полосок, которые можно использовать в каждой группе k = n // 2 # Длина k самых длинных полосок для горизонтальных и вертикальных
    horizontal_length = lengths[:k]  # k самых длинных полосок vertical_length = lengths[k:2*k]  # следующие k самых длинных полосок # Площадь плетёнки max_area = max(horizontal_length) * max(vertical_length)
    return max_area

# Чтение входных данных
n = int(input())
lengths = list(map(int, input().split()))

# Вывод результата
print(max_braid_area(n, lengths))