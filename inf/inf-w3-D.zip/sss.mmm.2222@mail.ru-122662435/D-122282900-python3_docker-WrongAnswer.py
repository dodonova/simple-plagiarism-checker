def max_plait_area(n, lengths):
    lengths.sort(reverse=True)
    horizontal_count = (n + 1) // 2
    vertical_count = n // 2
    max_length_horizontal = sum(lengths[:horizontal_count])
    max_length_vertical = sum(lengths[horizontal_count:horizontal_count + vertical_count])
    return max_length_horizontal * max_length_vertical
n = int(input())
lengths = list(map(int, input().split()))
result = max_plait_area(n, lengths)
print(result)