n, *rest = list(map(int, input().split())) #ввод числе из первой и второй строки
if len(rest) < n: #отвечает за правильность ввода
    rest.extend(map(int, input().split())) 
a = rest[:n] # присваеваем переменной a rest от начала до n
a.sort(reverse=True) #сортеруем и переворачиваем

max_length = a[0] #максимальный элемент a
length_counts = {} #множество
for length in a: #присваеваем множеству length_counts элементам length ключи
    length_counts[length] = length_counts.get(length, 0) + 1

general_length = sorted(set(a), reverse=True)
cnt = [] #список
cumulative = 0 #создаём переменную равную 0
length_to_cnt = {} #ещё множество
for length in general_length: 
    cumulative += length_counts[length] #переворачиваем уже словарь с помощью нового множества
    cnt.append((length, cumulative)) #в списк добавляем элементы(временно) из length и cumulative
    length_to_cnt[length] = cumulative #теперь их добавляем сюда

def get_N(L): #функция правой и левой ленты
    if L > general_length[0]:
        return 0
    if L <= general_length[-1]:
        return length_to_cnt[general_length[-1]]
    left = 0 #
    right = len(general_length) -1
    while left <= right:
        center = (left + right) // 2
        if general_length[center] >= L:
            left = center +1
        else:
            right = center -1
    return length_to_cnt[general_length[right]]

max_area = 0 #создаём переменную равную 0
n = len(a) #n приравниваем к длинне списка a
for h in range(1, n+1): #цикл для нахождения минимального и максимального участка
    L_h = a[h-1]
    cnt_h = get_N(h)
    v_max = min(L_h, cnt_h)
    left = 1 #создаём переменную равную 0
    right = v_max
    v1 = 0 #создаём переменную равную 0
    while left <= right: #цикл в цикле для
        center = (left + right) // 2
        min_hv = min(h, center) 
        N_min_hv = get_N(min_hv)
        if N_min_hv >= h + center:
            left = center +1
            v1 = center
        else:
            right = center -1
    if v1 > 0:
        area = h * v1 #area равняется произведение
        if area > max_area: #Если area > max_area, делаем area равной max_area
            max_area = area

print(max_area) #вывод