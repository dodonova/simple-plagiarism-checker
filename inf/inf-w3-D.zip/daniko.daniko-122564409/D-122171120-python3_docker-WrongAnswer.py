def max_rectangle_area(n, lengths):
    # Сортируем длины полос
    lengths.sort()

    # Разделяем полосы на две группы
    half = n // 2

    # Находим максимальные площади, используя половину полос из каждой группы
    max_area = lengths[half - 1] * lengths[half - 1]

    return max_area

#Galdis
n = int(input())
lengths = list(map(int, input().split()))
print(max_rectangle_area(n, lengths))