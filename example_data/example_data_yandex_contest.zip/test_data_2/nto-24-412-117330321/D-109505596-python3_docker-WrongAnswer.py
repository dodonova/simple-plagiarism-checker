n, k = map(int, input().split())

a = [[0] * n] * n


def f(xs, ys, size, k1):
    global a
    if k1 < 3 or size == 1:
        # print(s1, e, size, k1)
        for yi in range(ys, ys + size):
            for xi in range(xs, xs + size):
                a[yi][xi] = k1
                # print(a[y][x])
    else:
        f(xs+0, ys+0, size // 2, k1 - 1)
        f(xs + size // 2, ys+0, size // 2, k1 - 2)
        f(xs+0, ys + size // 2, size // 2, k1 - 2)
        f(xs+size // 2, ys+size // 2, size // 2, k1 - 3)


f(0, 0, n, k)
for y in range(n):
    s = ''
    for x in range(n):
        s += str(a[y][x])+' '
    print(s)
