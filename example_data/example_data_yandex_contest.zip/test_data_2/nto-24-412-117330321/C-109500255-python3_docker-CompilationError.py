k=int(input())
b = []
for i in range(1, 10):
    for j in range(10):
        for k1 in range(10):
			if (i+1)*(j+1)*(k1+1)==k:
				b.append((2**i)*(3**j)*(5**k1))
print(min(b))