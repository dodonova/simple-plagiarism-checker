k=int(input())
b = []
for i in range(1, 10):
    for j in range(10):
        for k1 in range(10):
            for k2 in range(10):
                for k3 in range(10):
                    if (i+1)*(j+1)*(k1+1)*(k2+1)*(k2+1)*(k3+1)==k:
                        b.append(2**i*3**j*5**k1*7**k2*11**k2*13**k3)
print(min(b))