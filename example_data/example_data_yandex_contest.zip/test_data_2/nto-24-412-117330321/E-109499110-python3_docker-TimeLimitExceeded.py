s,x=map(int,input().split())

ans = 0

n=int(input())

a=[int(i) for i in input().split()]

b=[0]*n

b[0] = a[0]

for i in range(1, n):
    b[i] = b[i-1]+a[i]

for l in range(n):
    for r in range(l, n):
        p = a[l:r+1]
        sum1 = sum(p)

        if sum1 == s:
            if x in p:
                ans+=1
print(ans)