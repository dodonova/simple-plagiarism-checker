s,x = map(int, input().split(" "))
n = int(input())
a = list(map(int, input().split(" ")))
otv = 0
x1 = a.index(x)
if x in a:
    for l in range(0,n):
        for r in range(l,n):
            b = []
            if l <= x1 <= (r+1):
                for i in range(l,r+1):
                    b.append(a[i])
                #print(l, r, b)
                if sum(b) == s and x in b:
                    otv += 1
print(otv)