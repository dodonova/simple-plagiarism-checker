def pole(n1, k1, massiv0):
    if n1 == 1 or k1 < 3:
        for i in range(n1):
            massiv0[i] = [k1]*n1
        return massiv0
    else:
        massiv1 = []
        massiv2 = []
        massiv4 = []
        massiv5 = []
        for i in range(int(n1 // 2)):
            massiv1.append([0] * (int(n1 // 2)))
            massiv2.append([0] * (int(n1 // 2)))
            massiv4.append([0] * (int(n1 // 2)))
        for i in range(n1):
            massiv5.append([0] * n1)
        massiv1 = pole(int(n1 // 2), k1 - 1, massiv1)
        massiv2 = pole(int(n1 / 2), k1 - 1, massiv2)
        massiv4 = pole(int(n1 / 2), k1 - 1, massiv4)
        for i in range(int(n1//2)):
            for j in range(int(n1//2)):
                massiv5[i][j] = massiv1[i][j]
        for i in range(int(n1//2),n1):
            for j in range(int(n1//2)):
                massiv5[i][j] = massiv1[i-(int(n1//2))][j]
        for i in range(int(n1//2)):
            for j in range(int(n1//2),n1):
                massiv5[i][j] = massiv1[i][j-(int(n1//2))]
        for i in range(int(n1//2),n1):
            for j in range(int(n1//2),n1):
                massiv5[i][j] = massiv1[i-(int(n1//2))][j-(int(n1//2))]
        return massiv5

n,k = map(int, input().split(" "))
massiv = []
for i in range(n):
    massiv.append([0]*n)

massiv_otv = pole(n,k,massiv)

for i in range(n):
    print(*massiv_otv[i])