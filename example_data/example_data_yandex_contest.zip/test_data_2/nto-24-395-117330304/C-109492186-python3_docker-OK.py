n = int(input())
max1 = 2**n
for i in range(2,max1):
    dels = 1
    for j in range(1,i//2+1):
        if i//j == i/j:
            dels += 1
        if dels > n:
            break
    if dels == n:
        print(i)
        break