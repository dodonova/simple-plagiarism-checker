s,x = map(int, input().split(" "))
n = int(input())
a = list(map(int, input().split(" ")))
otv = 0
for l in range(0,n):
    for r in range(l,n):
        b = []
        sum1 = 0
        for i in range(l,r+1):
            b.append(a[i])
            sum1 += a[i]
            if sum1 > s:
                break
        if sum(b) == s and x in b:
            otv += 1
print(otv)