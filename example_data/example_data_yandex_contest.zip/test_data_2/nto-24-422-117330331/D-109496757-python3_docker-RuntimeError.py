def b1(n, k):
    a = []
    for i in range(n):
        a.append((str(k) + ' ') * n)
    return('\n'.join(a))

def b2(n, k):
    return(k)

def b3(n, k):
    for i in range(n // 2):
        b6((str(b4(n // 2,k - 1)) + " " + str(b4(n // 2,k - 2))), 0)
    for i in range(n // 2):
        b6(str(b4(n // 2,k - 2)) + " " + str(b4(n // 2,k - 3)), 0)
def b4(n, k):
    if k < 3:
        return(b1(n, k))
    elif n == 1:
        return(b2(n, k))
    else:
        return(b3(n, k))
def b5(n, k):
    b4(n,k)
    return('\n'.join(b6(0, 1)))
def b6(n, k):
    if k == 3:
        b = []
    if k == 0:
        b.append(n)
    if k == 1:
        return b


n = int(input())
k = int(input())

b = []
print(b5(n, k))