#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int s, x, ans = 0;
    cin >> s >> x;
    int n;
    cin >> n;
    vector<int> arr(n + 1);
    vector<int> original(n + 1);
    cin >> arr[1];
    for (int i = 2; i <= n; i++) {
        int temp;
        cin >> temp;
        arr[i] = arr[i - 1] + temp;
        original[i] = temp;
    }
    vector<int> next_x(n + 1);
    int last = -1;
    int last_good = -1;
    int sm = original[n];
    vector<int> last_ok(n + 1);
    if (original[n] > 0 && s > 0) {
        last_good = n;
    }
    if (original[n] < 0 && s < 0) {
        last_good = n;
    }
    for (int i = n; i >= 0; i--) {
        if (original[i] == x) {
            last = i;
        }
        //last_good += original[i];
        next_x[i] = last;
        if (s < 0 && original[i] < 0) {
            last_good = i;
        }
        if (s > 0 && original[i] > 0) {
            last_good = i;
        }
        last_ok[i] = last_good;
    }
    for (int i = 1; i <= n; i++) {
        if (next_x[i] == -1) {
            break;
        }
        for (int j = next_x[i]; j <= n; j++) {
            if (arr[j] - arr[i - 1] == s) {
                ans += 1;
            }
            if (s < 0 && arr[j] - arr[i - 1] > 0) {
                if (last_ok[j] == -1) {
                    break;
                }
                j = last_ok[j] - 1;
            }
            if (s > 0 && arr[j] - arr[i - 1] < 0) {
                if (last_ok[j] == -1) {
                    break;
                }
                j = last_ok[j] - 1;
            }
        }
    }
    cout << ans;
}
