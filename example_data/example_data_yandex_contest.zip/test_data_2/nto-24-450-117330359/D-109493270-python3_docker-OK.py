def fill(starti, startj, n, k, arr):

    if k < 3:
        for i in range(starti, starti + n):
            for j in range(startj, startj + n):
                arr[i][j] = k
    elif n == 1:
        for i in range(starti, starti + n):
            for j in range(startj, startj + n):
                arr[i][j] = k
    else:
        n //= 2
        fill(starti, startj, n, k - 1, arr)
        fill(starti, startj + n, n, k - 2, arr)
        fill(starti + n, startj, n, k - 2, arr)
        fill(starti + n, startj + n, n, k - 3, arr)


n, k = map(int, input().split())

arr = [[0] * n for i in range(n)]
fill(0, 0, n, k, arr)
for i in range(n):
    print(*arr[i])