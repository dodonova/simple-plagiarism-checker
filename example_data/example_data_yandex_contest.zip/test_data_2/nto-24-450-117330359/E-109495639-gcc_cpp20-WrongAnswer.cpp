#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int s, x, ans = 0;
    cin >> s >> x;
    int n;
    cin >> n;
    vector<int> arr(n + 1);
    vector<int> original(n + 1);
    cin >> arr[1];
    for (int i = 2; i <= n; i++) {
        int temp;
        cin >> temp;
        arr[i] = arr[i - 1] + temp;
        original[i] = temp;
    }
    vector<int> next_x(n + 1);
    int last = -1;
    for (int i = n; i >= 0; i--) {
        if (original[i] == x) {
            last = i;
        }
        next_x[i] = last;
    }
    for (int i = 1; i <= n; i++) {
        if (next_x[i] == -1) {
            break;
        }
        for (int j = next_x[i]; j <= n; j++) {
            if (arr[j] - arr[i - 1] == s) {
                ans += 1;
            }
        }
    }
    cout << ans;
}