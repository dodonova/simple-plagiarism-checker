#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int s, x, ans = 0;
    cin >> s >> x;
    int n;
    cin >> n;
    vector<int> arr(n);
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
    for (int i = 0; i < n; i++) {
        int s_1 = 0;
        int has_x = false;
        for (int j = i; j < n; j++) {
            s_1 += arr[j];
            if (arr[j] == x) {
                has_x = true;
            }
            if (s_1 == s && has_x) {
                ans += 1;
            }
        }
    }
    cout << ans;
}