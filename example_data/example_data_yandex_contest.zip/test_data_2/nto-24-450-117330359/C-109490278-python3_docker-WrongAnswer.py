k = int(input())
d = [0,0,0,0]
primes = []
for i in range(2, k + 1):
    while k % i == 0:
        primes.append(i)
        k //= i
primes_unique = list(set(primes))
primes = sorted(primes)
for i in range(len(primes)):
    d[i] = primes[i] - 1
ans = 1
for i in range(len(d)):
    if d[i] != 0:
        if i == 0:
            ans *= 2 ** d[i]
        if i == 1:
            ans *= 3 ** d[i]
        if i == 2:
            ans *= 5 ** d[i]
        if i == 3:
            ans *= 7 ** d[i]
print(ans)