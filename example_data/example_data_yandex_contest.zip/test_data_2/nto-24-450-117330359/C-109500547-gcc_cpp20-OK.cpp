#include <iostream>
int ans = 1000000000;
int primes[] = {2,3,5,7,11,13,17,19};
using namespace std;
void helper(int k, int cur, int prev, int i) {
    if (k == cur) {
        ans = min(ans, prev);
        return;
    }
    int counter = 2;
    cur *= 2;
    while (cur <= k) {
        prev *= primes[i];
        helper(k, cur, prev, i + 1);
        cur /= counter;
        counter++;
        cur *= counter;
    }
}
int main()
{
    int k = 0;
    cin >> k;
    helper(k, 1, 1, 0);
    cout << ans;
}