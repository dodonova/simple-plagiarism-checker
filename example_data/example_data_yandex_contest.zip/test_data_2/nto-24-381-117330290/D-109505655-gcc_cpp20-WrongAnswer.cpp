#include <iostream>
#include <vector>

using namespace std;

struct vault {
	bool last = false;
	vector<vault> rf;
	int im = 0;
};

vault fill(int n, int k){
	if (k < 3 && n>1) {
		vault a = { true, {}, k };
		vault b = { false, {a,a,a,a}, 0 };
		return b;
	}
	if (n > 1) {
		vault a = { false, {fill(n / 2, k - 1),fill(n / 2, k - 2), fill(n / 2, k - 2), fill(n / 2, k - 3)},0};
		return a;
	}
	else {
		return { true, {}, k };
	}
}

void print_v(const vault& v, const int n, vector<int>& answ) {
	if (v.last) {
		answ.push_back(v.im);
		return;
	}
	for (auto i : v.rf) {
		print_v(i, n/2, answ);
	}
}

int main()
{
	int n, k;
	cin >> n >> k;
	vault answ = fill(n, k);
	vector<int> answer;
	print_v(answ, n, answer);
	for (int i = 0; i < n*n; ++i) {
		cout << answer[i];
	}
}
