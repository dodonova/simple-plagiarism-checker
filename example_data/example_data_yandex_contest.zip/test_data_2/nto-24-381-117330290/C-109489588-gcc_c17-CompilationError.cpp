#include <vector>
#include <math.h>
#include <iostream>

using namespace std;

int del_count(int num) {
	int counter = 1;
	
	for (int i = 1; i < sqrt(num); ++i) {
		if (num % i == 0) {
			++counter;
		}
	}
	return counter;
}


int get_min(int del) {
	int num = 1;
	while (true) {
		if (del_count(num) == del) {
			return num;
		}
		++num;
	}
}

int main()
{
	int num=0;
	cin >> num;
	cout << get_min(num);
}
