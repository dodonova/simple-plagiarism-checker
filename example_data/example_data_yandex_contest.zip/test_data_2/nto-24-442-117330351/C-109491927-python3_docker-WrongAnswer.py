de = int(input())
def d(x):
    k = 0
    for i in range(1, x+1):
        if x % i == 0:
            k += 1
    return k
for x in range(1, 10*8):
    if d(x) == de:
        print(x)
        break