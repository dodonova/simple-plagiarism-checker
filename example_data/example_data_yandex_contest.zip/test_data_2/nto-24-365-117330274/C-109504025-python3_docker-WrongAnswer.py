k = int(input())

L = []
res = 1


while k != 1:
    if k % 2 == 0:
        k = k//2
        L.append(2)
    elif k % 3 == 0:
        k = k // 3
        L.append(3)
    elif k % 5 == 0:
        k = k // 5
        L.append(5)
    elif k % 7 == 0:
        k = k // 7
        L.append(7)

for i in range(len(L)):
    if i == 0:
        res *= 2**(L[i]-1)
    elif i == 1:
        res *= 3**(L[i]-1)
    elif i == 2:
        res *= 5**(L[i]-1)
    elif i == 3:
        res *= 7**(L[i]-1)

print(res)