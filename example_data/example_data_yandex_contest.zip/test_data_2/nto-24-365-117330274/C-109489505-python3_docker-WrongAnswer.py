k = int(input())
res = 2 if k == 2 else 2**(k-1)
print(res)