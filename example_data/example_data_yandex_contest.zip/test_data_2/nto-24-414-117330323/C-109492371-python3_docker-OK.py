res = {1: 1, }
i = 1

while i < 2**12:
    i += 1
    c = 0
    for j in range(1, i+1):
        if not i % j:
            c += 1

    res[c] = min(res.get(c, 10**20), i)

print(res[int(input())])