def trying(mass, left, right, target_x, target_s):
    flag = False
    s = 0
    for num in mass[left:right+1]:
        s += num
        if num == target_x:
            flag=True
        if s > target_s:
            break

    else:
        if flag and s == target_s:
            return True

    return False


def main():
    target_s, target_x = map(int, input().split())
    input()
    mass = list(map(int, input().split()))

    answer = left = 0
    
    for right in range(len(mass)):
        for left in range(0, right):
            answer += int(trying(mass, left, right, target_x, target_s))
    
    print(answer)

main()