def drow(matrix, k, n, start_row, last_row, start_column, last_column):
    if k < 3 or n == 1:
        # print(k, n, start_row, last_row, start_column, last_column)
        for row in range(start_row, last_row):
            for column in range(start_column, last_column):
                matrix[column][row] = k
    else:
        matrix = drow(
            matrix,
            k=1,
            n=n//2,
            start_row=start_row + 1,
            start_column=start_column + 1,
            last_row=start_row + n // 2,
            last_column=start_column + n // 2
        )
        matrix = drow(
            matrix,
            k=2,
            n=n//2,
            start_row=start_row + 1,
            start_column=start_column + n // 2 + 1,
            last_row=start_row + n // 2,
            last_column=last_column
        )
        matrix = drow(
            matrix,
            k=2,
            n=n//2,
            start_row=start_row + n // 2 + 1,
            start_column=start_column + 1,
            last_row=last_row,
            last_column=start_column + n // 2
        )
        matrix = drow(
            matrix,
            k=3,
            n=n//2,
            start_row=start_row + n // 2 + 1,
            start_column=start_column + n // 2 + 1,
            last_row=last_row,
            last_column=last_column
        )
    return matrix


def main():
    n, k = map(int, input().split())

    matrix = [[0]*n]*n

    matrix = drow(
        matrix, k, n,
        0,
        n,
        0,
        n
    )

    for line in matrix:
        print(*line)


main()