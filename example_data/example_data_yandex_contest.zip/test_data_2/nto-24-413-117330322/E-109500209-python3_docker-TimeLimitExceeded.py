s, x = map(int,input().split())
n = int(input())
m = list(map(int,input().split()))
k = 0
for i in range(n):
    fl = 0
    r = 0
    for j in range(i,n):
        if m[j] == x:
            fl = 1
        r += m[j]
        if fl and (r == s):
            k += 1
print(k)