def f(a):
    r = 1
    i = 2
    while a >= i:
        sh = 0
        while a % i == 0:
            a //= i
            sh += 1
        r *= sh+1
        i += 1
    return r
k = int(input())
for j in range(2,10**10):
    if f(j) == k:
        print(j)
        break