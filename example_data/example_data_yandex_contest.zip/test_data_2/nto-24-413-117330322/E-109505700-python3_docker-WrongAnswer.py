s, x = map(int,input().split())
n = int(input())
m = list(map(int,input().split()))
k = 0
fl = 0
for i in m:
    for j in range(m.index(i)+1):
        r = 0
        fl = 0
        for h in range(j, m.index(i)+1):
            if m[h] == x:
                fl = 1
            r += m[h]
            if (r == s) and fl:
                k += 1
print(k)