n, k = map(int,input().split())
def f(n, k):
    if k < 3:
        for i in range(n):
            for j in range(n):
                print(k,end = ' ')
            print()
        return
    if n == 1:
        print(k, end = ' ')
        return
    else:
        a = n // 2
        for i in range(n):
            for j in range(n):
                if (i < a) and (j < a):
                    f(n//2,k-1)
                elif (i > a) and (j > a):
                    f(n//2,k-3)
                else:
                    f(n//2,k-2)
            print()
        return
f(n,k)