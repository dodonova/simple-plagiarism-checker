s, x = map(int,input().split())
n = int(input())
m = list(map(int,input().split()))
k = 0
fl = 0
for i in m:
    if i == x:
        fl = 1
    if fl:

        for j in range(m.index(i)):
            r = 0
            for h in range(j, m.index(i)):
                r += m[h]
                if r == s:
                    k += 1
print(k)