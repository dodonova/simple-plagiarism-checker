n, k = map(int,input().split())

if k < 3:
    for i in range(n):
        for j in range(n):
            print(k,end = ' ')
        print()

if n == 1:
    print(k, end = ' ')

else:
    a = n // 2
    for i in range(n):
        for j in range(n):
            if (i < a) and (j < a):
             print(1)   
            elif (i > a) and (j > a):
                print(1)

            else:
                print(1)

        print()