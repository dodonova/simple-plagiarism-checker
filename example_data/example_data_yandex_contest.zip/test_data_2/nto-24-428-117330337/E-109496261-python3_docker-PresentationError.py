from itertools import combinations
f = input().split()
s = int(f[0])
x = int(f[1])
i = int(input())
arrStr = input()
arr = arrStr.split()
count = 0

for a in range(0, len(arr)):
    for b in range(1, len(arr)):
        n = arr[a:b]
        sum = 0
        flag = 0
        for i in n:
            sum += int(i)
            if int(i) == x:
                flag = 1
        if sum == s and flag == 1:
            count += 1
        print(n, sum, flag)
print(count*2)