def find(k):
    def divisors(n):
        divisors = 0
        for i in range(1, int(n ** 0.5) + 1):
            if n % i == 0:
                divisors += 1
                if n // i == i:
                    divisors += 1
        return divisors+1

    num = 1
    while True:
        if divisors(num) == k:
            return num
        num += 1

print(find(int(input())))