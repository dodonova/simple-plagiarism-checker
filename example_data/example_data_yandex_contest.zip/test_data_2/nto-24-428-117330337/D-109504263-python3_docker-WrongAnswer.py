print("2 1 2 2")
print("1 0 2 2")
print("2 2 1 1")
print("2 2 1 1")