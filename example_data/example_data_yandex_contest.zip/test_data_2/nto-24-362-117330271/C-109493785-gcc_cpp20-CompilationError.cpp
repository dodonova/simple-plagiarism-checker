#include <vector>
#include <iostream>
using namespace std;



bool easyNUM(int num)
{
    for (int i = 2; i < num; i++)
    {
        if (num % i == 0)
            return false;
    }
    return true;

    
}
int main()
{
    int countOfDel;
    cin >> countOfDel;
    int saveCountOfDel= countOfDel;
    vector<int> a;
    vector<int> p;
    if (countOfDel == 2)
    {
        cout << 2;
        return 0;
    }
    int delit = 2;
    while (countOfDel != 1)
    {
        if (countOfDel % delit == 0)
        {
            a.push_back(delit - 1);
            countOfDel /= delit;
        }
        delit++;
    }
    for (int i = 0; i < a.size(); i++)
        cout << a.at(i);
    for(int i = 0)



}




