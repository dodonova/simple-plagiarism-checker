#include <vector>
#include <iostream>
using namespace std;



int main()
{
    int count;
    int s;
    int x;
    int L;
    int firstGood;
    int lastGood = 0;
    int R;
    int ans = 0;
    cin >> s >> x;
    cin >> count;
    vector<int> a;
    vector<int> index;
    int b;
    for (int i = 0; i < count; i++)
    {

        cin >> b;
        a.push_back(b);
        if (b == x) {
            if (index.size() == 0)
                firstGood = i + 1;
            index.push_back(a.size());
            lastGood = i + 1;
        }
    }


    for (int i = 0; i < index.size(); i++)
    {
        L = 1;
        R = index.at(i);
        for (; R < a.size(); R++)
        {
            for (; L < lastGood; L++)
            {
                int sum = 0;
                for (int i = L; i < R;i++)
                {
                    sum += a.at(i);
                }
                if (sum == s)
                    ans++;
            }

        }

    }
    cout << ans;
}
