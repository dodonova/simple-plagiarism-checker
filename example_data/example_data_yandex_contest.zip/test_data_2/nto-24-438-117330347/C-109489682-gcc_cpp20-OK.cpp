#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <algorithm>

using namespace std;

map<int, int> prime (int n)
{
    int t = 2;
    map<int, int> cnt;
    while (t * t <= n)
    {
        while (n % t == 0)
        {
            cnt[t] += 1;
            n /= t;
        }
        t += 1;
    }
    if (n != 1)
        cnt[n] += 1;
    return cnt;
}

int main()
{
    int n;
    cin >> n;
    for (int i = 2; i < 1e9; i ++)
    {
        int reso = 1;
        map<int, int> res = prime(i);
        for (auto i:res)
        {

            reso *= i.second + 1;
            //cout << i.first << endl;
        }
        if (reso == n)
        {
            cout << i;
            return 0;
        }
    }




}

