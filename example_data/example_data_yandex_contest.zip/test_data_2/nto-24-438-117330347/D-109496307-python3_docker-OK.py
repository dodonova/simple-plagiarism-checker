n, m = map(int, input().split())


def concati_1(a, b):
    c = []
    for i in range(len(a)):
        c.append(a[i] + b[i])
    return c


def concati_2(a, b):
    a += b
    return a


def rec(n1, k1):
    if (k1 < 3 or n1 == 1):
        res = [[k1] * n1 for i in range(n1)]
        return res
    a = concati_1(rec(n1 // 2, k1 - 1), rec(n1 // 2, k1 - 2))
    b = concati_1(rec(n1 // 2, k1 - 2), rec(n1 // 2, k1 - 3))
    c = concati_2(a, b)
    return c


a = rec(n, m)
for i in a:
    print(*i)