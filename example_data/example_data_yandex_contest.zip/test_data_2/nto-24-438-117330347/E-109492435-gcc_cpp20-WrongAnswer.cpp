#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <algorithm>

using namespace std;

#define int long long

map<int, int> prime (int n)
{
    int t = 2;
    map<int, int> cnt;
    while (t * t <= n)
    {
        while (n % t == 0)
        {
            cnt[t] += 1;
            n /= t;
        }
        t += 1;
    }
    if (n != 1)
        cnt[n] += 1;
    return cnt;
}

signed main()
{
    int s, x;
    cin >> s >> x;

    int n;
    cin >> n;

    vector<int> a (n);
    for (int& i:a) cin >> i;

    int l = 0;
    int ans = 0;
    int good = 0;
    int acs = 0;
    for (int r = 0; r < n; r ++)
    {
        //
        acs += a[r];
        if (a[r] == x)
            good += 1;

        if (acs > s)
        {
            while (acs > s && l <= r)
            {
                acs -= a[l];
                if (a[l] == x) good -= 1;
                l += 1;
            }

            if (l > r) continue;
        }
        //cout << l << " " << r << " " << acs << endl;
        if (acs == s && good > 0)
            ans += 1;

    }
    cout << ans;
}

