s, x = map(int, input().split())
n = int(input())
a = list(map(int, input().split()))
k = 0
k1 = 0
if sum(a) == s and x in a:
    if sum(a) == s:
        k += 1
    if x in a:
        k1 += 1
print(k + k1)