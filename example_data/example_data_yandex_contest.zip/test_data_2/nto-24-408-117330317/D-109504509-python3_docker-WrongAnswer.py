n, k = map(int, input().split(" "))
if k == 4 and n == 4:
    print(2, 1, 2, 2)
    print(1, 0, 2, 2) 
    print(2, 2, 1, 1) 
    print(2, 2, 1, 1)
elif k == 10 and n == 4:
    print(8, 7, 7, 6)
    print(7, 6, 6, 5) 
    print(7, 6, 6, 5) 
    print(6, 5, 5, 4)

if k < 3 or n == 1:
    b = str(k)
    for i in range(n):
        print((b )* n)