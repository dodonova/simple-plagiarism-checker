n, k = map(int, input().split(" ")
if k < 3 or n == 1:
    b = str(k)
    for i in range(n):
        print((b )* n)