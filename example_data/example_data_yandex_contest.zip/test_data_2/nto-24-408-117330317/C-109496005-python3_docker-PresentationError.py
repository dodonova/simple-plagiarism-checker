n = int(input())
k = n
if n == k:
    print('ok')
