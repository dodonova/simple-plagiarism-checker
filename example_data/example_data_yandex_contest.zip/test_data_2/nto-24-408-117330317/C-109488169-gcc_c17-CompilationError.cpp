k = int(input())
print(2**(k-1))k = int(input())
print(2**(k-1))