s, x = map(int, input().split(" "))
n = int(input())
summa = 0
good = 0
for i in range(n):
 summa += i
 if i == x:
     good += 1
if summa == s:
    good += 1
if good == 2 or good == 1 or good == 0:
    print(good)
else: 
    good += 1
    print(good)