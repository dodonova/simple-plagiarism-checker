k = int(input())
if k == 0 or k == 2 or k == 7:
    print(2**(k - 1))
else:
    print('ok')
