k = int(input())
if k >= 2 and k <= 16:
    print(2**(k-1))