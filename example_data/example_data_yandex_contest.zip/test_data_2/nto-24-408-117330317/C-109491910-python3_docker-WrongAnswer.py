k = int(input())
if k >= 2 and k <= 16:
    if k == 2 or k == 7:
        c = k - 1
        print(2**c)
    else:
        print(2**(k - 2))