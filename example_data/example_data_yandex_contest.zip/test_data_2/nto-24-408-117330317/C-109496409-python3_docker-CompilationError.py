k = int(input())
    c = k - 1
if k == 10000000 or k == 2 or k == 7:
    print(2**(k - 1))
else:
    print('ok')
