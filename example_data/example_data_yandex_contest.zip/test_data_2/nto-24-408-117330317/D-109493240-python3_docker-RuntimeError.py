n = int(input())
k = int(input())
if k < 3 or n == 1:
    for i in range(n):
        print((str(k) )* n)