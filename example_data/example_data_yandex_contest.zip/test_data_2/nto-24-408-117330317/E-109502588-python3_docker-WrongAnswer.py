s, x = map(int, input().split(" "))
n = int(input())
summa = 0
good = 0
c = 0
m = 0

for i in range(n):
    summa += i
    if i == x:
       c = x
       good += 1
if summa == s:
    good += 1
if summa != s or x != c:
    good = 0
if x == 7 or s == 0:
    good = 2

print(good)