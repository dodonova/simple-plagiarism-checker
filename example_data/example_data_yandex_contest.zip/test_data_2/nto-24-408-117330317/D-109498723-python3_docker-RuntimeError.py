n = int(input())
k = int(input())
if k < 3 or n == 1:
    b = str(k)
    for i in range(n):
        print((b )* n)