k = int(input())

def check(data):
    count = 0
    for j in range(1, 100000):
        if data%j==0 and data>=j:
            count += 1
        elif count > k:
            return 0
    return count

for i in range(1, 100000):
    if check(i) == k:
        print(i)
        break