k = int(input())

def check(data):
    count = 0
    for j in range(1, 10000):
        if data%j==0 and data>=j:
            count += 1
            if count > k:
                count = 0
                break
    return count

for i in range(1, 10000):
    if check(i) == k:
        print(i)
        break