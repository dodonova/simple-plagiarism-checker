a = input().split()
b = int(input())
c = [int(x) for x in input().split()]
d = 0
if sum(c) == int(a[0]) and int(a[1]) in c:
    print(2)