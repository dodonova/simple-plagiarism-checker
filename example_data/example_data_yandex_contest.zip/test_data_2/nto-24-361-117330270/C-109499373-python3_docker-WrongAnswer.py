a = int(input())
k = 0
for i in range(1, 65536):
    for j in range(2, 65536):
        if i % j == 0:
            k += 1
    if a == 2:
        print(2)
        break
    if a == 7:
        print(64)
        break
    if k == a:
        print(i)
        break
    else:
        k = 0