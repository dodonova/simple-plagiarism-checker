a = int(input())
k = 0
for i in range(1, 65536):
    for j in range(2, 65536):
        if i % j == 0:
            k += 1
    if k == a:
        print(i)
        break
    else:
        k = 0
