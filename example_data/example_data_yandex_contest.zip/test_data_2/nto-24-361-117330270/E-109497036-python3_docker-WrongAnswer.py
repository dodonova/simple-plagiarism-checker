a = input().split()
b = int(input())
c = [int(x) for x in input().split()]
d = 0
if sum(c) == int(a[0]):
    d += 1
if int(a[1]) in c:
    d += 1
print(d)