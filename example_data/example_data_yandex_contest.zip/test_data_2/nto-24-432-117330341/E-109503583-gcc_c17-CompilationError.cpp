s, x = map(int, input().split(' '))
count = int(input())
nums = list(map(int, input().split(" ")))
counter = 0

for num in nums:
	eeee = []
	for num_x in nums[nums.index(num):]:
		eeee.append(num_x)
		if (sum(eeee) == s and x in eeee):
			counter +=1

print(counter)
