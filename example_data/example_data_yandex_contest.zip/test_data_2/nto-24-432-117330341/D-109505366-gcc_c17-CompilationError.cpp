n, k = map(int, input().split(" "))

def f(n, k)
	if (k < 3 or n == 1):
		return g(n, k)
	else:
		a = f(n / 2, k - 1)
		b = f(n / 2, k - 2)
		c = f(n / 2, k - 3)
		d = []
		for i in range(n + 1):
			for
			if (n / 2) == i



def g(n, k):
	h = ''
	for i in range(n):
		for j in range(n+1):
			if j == (n- 1):
				h += str(k)
			elif j != n:
				h += (str(k) + " ")
			elif i == (n-1):
				break 
			else:
				h += '\n'
	return h

print(f(n, k) sep='')