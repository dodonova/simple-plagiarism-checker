k = int(input())


def count_dels(n):
    i = 1
    count_div = 0
    while i <= n:
        if n%i == 0:
            count_div += 1
        i += 1
    return count_div


i = 2
while True:
    if count_dels(i) == k:
        print(i)
        break
    i += 1
