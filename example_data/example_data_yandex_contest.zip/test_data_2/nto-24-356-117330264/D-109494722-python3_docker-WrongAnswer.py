N, K = map(int, input().split())


def risunok(n, k):
    if k < 3:
        return [*[k] * n] * n
    elif n == 1:
        return [k]
    else:
        return [*risunok(n//2, k-1), *risunok(n//2, k-2)] + [*risunok(n//2, k-2), *risunok(n//2, k-3)]


real_karta = ""
karta = risunok(N, K)
last_i = 0
for i in range(0, len(karta)+1, N):
    if i == 0: continue
    real_karta += " ".join(map(str, karta[last_i:i])) + "\n"
    last_i = i

print(real_karta.rstrip())
