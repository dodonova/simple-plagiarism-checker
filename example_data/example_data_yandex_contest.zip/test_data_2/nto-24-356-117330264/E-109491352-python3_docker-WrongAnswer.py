S, X = map(int, input().split())
n = int(input())
m = list(map(int, input().split()))

ans = 0
start = 0
for i in range(1, n+1):
    if sum(m[start:i]) == S and X in m[start:i]:
        ans += 1
        start = i

print(ans)
