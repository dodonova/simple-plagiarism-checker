N, K = map(int, input().split())

# [0, 0, 0, 0]
# N * N


def risunok(n, k):
    if k < 3:
        return [*[k] * n] * n
    elif n == 1:
        return [k]
    else:
        return [*risunok(n//2, k-1), *risunok(n//2, k-2)] + [*risunok(n//2, k-2), *risunok(n//2, k-3)]


if K<3:
    x = [[K] * N] * N
    x1 = [" ".join(map(str, i)) for i in x]
    print("\n".join(map(str, x1)))
elif N == 1:
    print(K)
else:
    part_1 = risunok(N//2, K-1)
    part_2 = risunok(N//2, K-2)
    part_3 = risunok(N//2, K-3)
    # ans = [[]]*N
    # print(ans)
    # print(part_1, part_2, part_2, part_3)
    #for i in range(N//2):
    #    ans[i] += part_1[0:N//2]
    real_karta = ""
    karta = risunok(N, K)
    print(karta)
    last_i = 0
    for i in range(0, len(karta)+1, N):
       if i == 0: continue
       real_karta += " ".join(map(str, karta[last_i:i])) + "\n"
       last_i = i

    print(real_karta.rstrip())