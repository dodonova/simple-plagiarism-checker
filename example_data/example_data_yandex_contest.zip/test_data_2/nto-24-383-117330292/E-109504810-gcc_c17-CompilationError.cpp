S,X = map(int, input().split())
n = int(input())
a = list(map(int,input().split()))
cnt = 0
for L in range(n):
    for R in range(L,n):
        if sum(a[L:R+1]) == S and X in a[L:R+1]:
            cnt+=1
print(cnt)