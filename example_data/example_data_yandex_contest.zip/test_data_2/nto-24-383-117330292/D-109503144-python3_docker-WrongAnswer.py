n, k = map(int,input().split())
global flag
flag = False
def f(n,k):
    global flag
    if k < 3:
        a = []
        for _ in range(n):
            b = []
            for _ in range(n):
                b.append(k)
            a.append((b))
        return a
    elif n == 1:
        return [k]
    else:
        return f(n//2,k-1) +f(n // 2, k - 2)  + f(n // 2, k - 2) + f(n // 2, k - 3)

a = f(n,k)
if len(a) == n*n:
    for i in range(n):
        for j in range(n):
            print(a[j], end=" ")
        for j in range(n):
            a.pop(0)
        print()
else:
    for i in range(n//2):
        print(a[0][0], end=" ")
        print(a[1][0], end=" ")
        print(a[4][0], end=" ")
        print(a[4][1], end=" ")
        a.pop((4))
        a.pop((0))
        a.pop((0))
        print()
    for i in range(n//2):
        a1 = a[0]
        for j in range(len(a1)):
            print(a1[j], end=" ")
        a1 = a[1]
        for j in range(len(a1)):
            print(a1[j], end=" ")
        a.pop(0)
        a.pop(0)
        print()
