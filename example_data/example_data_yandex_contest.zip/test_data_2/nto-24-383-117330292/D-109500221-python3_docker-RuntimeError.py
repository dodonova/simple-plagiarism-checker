n, k = map(int,input().split())
def f(n,k):
    if k < 3:
        a = []
        for _ in range(n):
            b = []
            for _ in range(n):
                b.append(k)
            a.append((b))
        return a
    elif n == 1:
        return [k]
    else:
        return f(n//2,k-1) + f(n // 2, k - 2) + f(n // 2, k - 2) + f(n // 2, k - 3)
a = f(n,k)
for i in range(n):
    for j in range(n):
        print(a[j],end=" ")
    for j in range(n):
        a.pop(0)
    print()