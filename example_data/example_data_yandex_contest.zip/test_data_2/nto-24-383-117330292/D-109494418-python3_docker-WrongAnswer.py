n, k = map(int,input().split())
if k < 3:
    for _ in range(n):
        for _ in range(n):
            print(k,end=" ")
elif n == 1:
    print(k)
else:
    for _ in range(n//2):
        c = 0
        for i in range(1, n // 2 + 1):
          c+=1
          for j in range(1, n // 2 + 1):
              print(k-c, end=" ")
        print()

    for _ in range(n // 2):
        c = 1
        for i in range(1, n // 2 + 1):
          c+=1
          for j in range(2, n // 2 + 2):
              print(k-c, end=" ")
        print()
