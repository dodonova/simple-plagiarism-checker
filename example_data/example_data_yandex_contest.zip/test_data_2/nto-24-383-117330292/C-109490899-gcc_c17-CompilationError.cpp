n = int(input())
def f(n):
    count = []
    for i in range(1,int(n**0.5)+1):
        if n % i == 0:
            count.append(i)
            if (n/i) not in count:
                count.append(n / i)
    return len(count)
d = {}
for i in range(49):
    d[i] = 10**10

for i in range(4097):
    d[f(i)] = min(d[f(i)],i)
print(d[n])