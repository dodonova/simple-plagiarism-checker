
# print(int(bin(4732)[2:],2))
# from random import randint
# from functools import lru_cache


def func(n,k, x0,x1,y0,y1):

    if k < 3 or n == 1:
        for i in range(x0,x1):
            for j in range(y0,y1):
                m[i][j] = k
    else:
        func(int(n / 2), k - 1, x0,   int(x1/2),  y0,   int(y1/2))
        func(int(n / 2), k - 2, int(x1/2), x1,    y0,   int(y1/2))
        func(int(n / 2), k - 2, x0,   int(x1/2),  int(y1/2), y1)
        func(int(n / 2), k - 3, int(x1/2), x1,    int(y1/2), y1)

n = int(input())
k = int(input())

m = []

for i in range(n):
    m.append([0]*n)

func(n,k,0,n,0,n)

for i in range(n):
    for j in range(n):
        print(m[i][j], end = " ")
    print()
