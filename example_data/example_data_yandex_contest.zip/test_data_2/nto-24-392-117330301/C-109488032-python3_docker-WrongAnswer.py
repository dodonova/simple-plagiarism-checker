def add(x):

    k = 0
    for i in range(2, int(x/2)):
        if x%i == 0:
            k += 1
    return k

n = int(input())

for i in range(10000000):
    if add(i) == n:
        print(i)
        break