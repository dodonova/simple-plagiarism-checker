
# print(int(bin(4732)[2:],2))
# from random import randint
# from functools import lru_cache

def prost(x):

    for i in range(2, int(x)):
        if x%i == 0:
            return 0
    return 1


def kol(a, b):
    k = 0
    while (a % b == 0):
        a = a / b
        k = k + 1
    return k


def add(x):
    p = 1
    m = []
    for i in range(1, x + 1):
        if x % i == 0 and i!=1:
            m.append(i)

    #print(x, m)

    for i in range(len(m)):
        if prost(m[i]):
            #print(m[i])
            p = p * (1 + kol(x, m[i]))

    return p


n = int(input())

for i in range(10000000):
    if add(i) == n:
        print(i)
        break