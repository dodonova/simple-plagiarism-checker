k = input
for k in range(2,16):
	n = 2^k-1
print(n)