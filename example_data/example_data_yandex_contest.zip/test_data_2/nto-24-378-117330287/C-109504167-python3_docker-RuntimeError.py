def de(num):
    col = 2
    for i in range(2, int(num ** 0.5) + 3):
        if num % i == 0:
            if num // i == i:
                col += 1
            else:
                col += 2
    return col
col = int(input())
for i in range(2, 1000000000):
    if de(i) == col:
        print(i)
        quit()