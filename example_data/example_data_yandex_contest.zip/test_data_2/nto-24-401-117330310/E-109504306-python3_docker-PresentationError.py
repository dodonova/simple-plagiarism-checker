signature, happynumber = map(int, input().split())
new_balance = int(input())
count = 0
nums = list(map(int, input().split()))
for l in range(new_balance):
    for r in range(l, new_balance):
        if sum(nums[l:r+1]) == signature and happynumber in nums[l:r + 1]:
            print(nums[l:r+1])
            count += 1
print(count)
