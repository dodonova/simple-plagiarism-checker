k = int(input())
singleton = 0
for i in range(2, 35536):
	for j in range(1, i+1):
		if j == 1 or j == i or i % j == 0:
			singleton += 1
	if singleton == k:
		print(i)
		break
	else:
		singleton = 0