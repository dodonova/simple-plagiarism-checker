s, x = map(int, input().split())
n = int(input())
n1 = input().split()
t = [int(n1[i]) for i in range(n)]
y = []
q = 0
u = []
ch = 0
for i in range(n):
    q += t[i]
    if t[i] == x:
        y.append(str(q))
        u.append(i)
    else:
        y.append(str(q))
for i in range(n):
    for j in range(len(u)):
        if i >= u[j] and s == int(y[i]):
            ch += 1
print(ch)
