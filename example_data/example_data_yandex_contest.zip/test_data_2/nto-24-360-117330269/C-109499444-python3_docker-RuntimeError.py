def r(a,b):
    if b!=0:
        if a%b==0:
            c.append(b)
        return r(a,b-1)
    else:
        return c
k = int(input())
for i in range(0,1000000):
    c=[]
    f=r(i,i)
    if len(f)==k:
        break
print(i)