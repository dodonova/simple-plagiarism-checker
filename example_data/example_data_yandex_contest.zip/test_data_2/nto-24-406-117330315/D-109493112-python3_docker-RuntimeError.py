n = int(input()).split(" ")

if n[2] < 3:
    print(n[1],n[1],n[1],n[1])
    print(n[1],n[1],n[1],n[1])
    print(n[1],n[1],n[1],n[1])
    print(n[1],n[1],n[1],n[1])
elif n[1] == 1:
    print(n[1])
else:
    print(n[1] - 1,n[1] - 1,n[1] - 2,n[1] - 2)
    print(n[1] - 1,n[1] - 1,n[1] - 2,n[1] - 2)
    print(n[1] - 2,n[1] - 2,n[1] - 3,n[1] - 3)
    print(n[1] - 2,n[1] - 2,n[1] - 3,n[1] - 3)