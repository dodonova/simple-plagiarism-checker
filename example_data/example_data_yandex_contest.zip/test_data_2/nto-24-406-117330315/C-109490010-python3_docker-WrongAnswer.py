k = int(input())

n = 2

for i in range(k - 2):
    n *= 2
print(n)