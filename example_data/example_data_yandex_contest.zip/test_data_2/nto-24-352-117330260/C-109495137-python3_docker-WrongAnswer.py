a = int(input())
print(2 ** (a-1))