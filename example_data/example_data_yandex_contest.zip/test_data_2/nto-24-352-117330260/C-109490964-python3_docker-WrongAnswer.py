a = int(input())
if 2 <= a <= 16:
    print(2 ** (a-1))