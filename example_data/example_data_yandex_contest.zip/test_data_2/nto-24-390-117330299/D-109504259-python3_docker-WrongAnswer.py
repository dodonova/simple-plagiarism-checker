nums = input().split(" ")


n = int(nums[0])
k = int(nums[1])

i = 0
if (k < 3 or n == 1):
    while i < n:
        print((" "+ str(k) +" ") * n)
        i += 1
else:
    pass
   

    
    


