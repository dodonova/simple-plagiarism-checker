nums = input().split(" ")


n = int(nums[0])
k = int(nums[1])

i = 0
if (k < 3 or n == 1):
    while i < n:
        print((" "+ str(k) +" ") * n)
        i += 1
else:
    firstLine = (" "+ str(k - 2) +" " + " "+ str(k - 3) +" ")
    secondLine = (" "+ str(k - 3) +" " + " "+ str(k - 4) +" ")

    
    print(firstLine)
    print(secondLine)
