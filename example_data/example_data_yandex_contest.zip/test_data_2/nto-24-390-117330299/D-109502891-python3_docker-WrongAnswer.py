nums = input().split(" ")


n = int(nums[0])
k = int(nums[1])

i = 0
if (k < 3 or n == 1):
    while i < n:
        print((" "+ str(k) +" ") * n)
        i += 1
else:
    print(str(k - (n//2)) + " " + str((k -1) - (n//2)) + " " + str((k - 1) - (n//2)) + " " + str((k -2) - (n//2)))
    print(str((k - 1) - (n//2)) + " " + str((k -2) - (n//2)) + " " + str((k - 2) - (n//2)) + " " + str((k -3) - (n//2)))

    print(str((k - 1) - (n//2)) + " " + str((k -2) - (n//2)) + " " + str((k - 2) - (n//2)) + " " + str((k -3) - (n//2)))
    print(str((k - 2) - (n//2)) + " " + str((k -3) - (n//2)) + " " + str((k - 3) - (n//2)) + " " + str((k -4) - (n//2)))
   

    
    


