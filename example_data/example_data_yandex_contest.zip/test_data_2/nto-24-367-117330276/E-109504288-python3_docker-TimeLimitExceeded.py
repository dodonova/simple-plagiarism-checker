SX = input().split()
S, X= int(SX[0]), int(SX[1])
n = int(input())
lst = list(map(int, input().split()))
c = 0

if X in lst:
    for i in range(n):
        for j in range(i + 1, n + 1):
            mas = lst[i:j]
            if sum(mas) == S and X in mas:
                c += 1
    print(c)
else:
    print(0)


