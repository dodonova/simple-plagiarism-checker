k = int(input())

def delit(n):
    c = 0
    for i in range(1, n + 1):
        if n % i == 0:
            c += 1
    return c

n = 1
while delit(n) != k:
    n += 1
print(n)