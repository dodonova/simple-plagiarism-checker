S, X = list(map(int, input().split()))
n = int(input())
lst = list(map(int, input().split()))
c = 0
for i in range(n):
    for j in range(i + 1, n + 1):
        mas = lst[i:j]
        if sum(mas) == S and X in mas:
            c += 1
print(c)
