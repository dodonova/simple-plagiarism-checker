S, X = map(int, input().split())
n = int(input())
lst = list(map(int, input().split()))
c = 0
i = 0
j = 1
while i != n:
    mas = lst[i:j]
    print(mas, i, j)
    if sum(mas) == S and X in mas:
        c += 1
    if j < n:
        j += 1
    else:
        i += 1
        j = i + 1
print(c)

