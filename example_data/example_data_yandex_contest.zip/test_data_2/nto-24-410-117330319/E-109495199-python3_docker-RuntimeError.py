s,x= map(int, input().split())
n = int(input())
a = list(input().split())
c=k=0
l=''
for i in range(n):
    c+=int(a[i])
    l=l+a[i]
    if c == s:
        if str(x) in l:
            k+=1
    if c>s:
        c=a[i]
        l=str(a[i])
print(k)