s,x= map(int, input().split())
n = int(input())
a = list(input().split())
c=k=0
l=''
m=0
for i in range(n):
    if c == s:
        if str(x) in l:
            k+=1
            if a[i]==l[0:(len(a[i]))]:
                if a[i]!=str(0):
                    c-=int(a[i])
                    l=l.replace(a[i],'',1)
    c += int(a[i])
    l = l + a[i]
    while c>s:
        c-=int(a[m])
        m+=1
        l=l.replace(a[m],'',1)


if c == s:
    if str(x) in l:
        k+=1
print(k)