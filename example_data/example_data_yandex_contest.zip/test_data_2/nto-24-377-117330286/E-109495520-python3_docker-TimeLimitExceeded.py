s, x = map(int, input().split())
n = int(input())
a = list(map(int, input().split()))
prev = [0, 0]
pr = [prev]
for i in range(n):
    prev = [prev[0]+a[i], prev[1]+int(a[i] == x)]
    pr.append(prev)
cnt = 0
for l in range(1, n+1):
    for r in range(l, n+1):
        if pr[r][0]-pr[l-1][0] == s and pr[r][1]-pr[l-1][1] > 0:
            cnt += 1
print(cnt)