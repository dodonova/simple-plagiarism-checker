s, x = map(int, input().split())
n = int(input())
a = list(map(int, input().split()))
pr = [0]
for i in range(n):
    pr.append(pr[-1]+a[i])
cnt = 0
for l in range(n):
    for r in range(l, n):
        if pr[r]-pr[l] == s and x in a[l:r+1]:
            cnt += 1
print(cnt)