#include <iostream>
int main(){
int n;
std::cin >> n;
cout << 2^(n-1);
return 0;
}