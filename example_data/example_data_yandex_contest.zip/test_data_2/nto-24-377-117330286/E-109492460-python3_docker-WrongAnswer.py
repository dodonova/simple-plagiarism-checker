s, x = map(int, input().split())
n = int(input())
a = list(map(int, input().split()))
pr = [0]
for i in range(n):
    pr.append(pr[-1]+a[i])
cnt = 0
for l in range(1, n+1):
    for r in range(l, n+1):
        if pr[r]-pr[l-1] == s and x in a[l:r+1]:
            cnt += 1
print(cnt)