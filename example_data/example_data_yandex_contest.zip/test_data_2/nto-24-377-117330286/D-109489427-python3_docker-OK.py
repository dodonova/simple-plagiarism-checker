N, K = map(int, input().split())
a = [[0] * N for i in range(N)]


def fill(n, k, y, x):
    if n == 1 or k < 3:
        for j in range(n):
            for i in range(n):
                a[y + j][x + i] = k
    else:
        fill(n // 2, k - 1, y, x)
        fill(n // 2, k - 2, y, x + n // 2)
        fill(n // 2, k - 2, y + n // 2, x)
        fill(n // 2, k - 3, y + n // 2, x + n // 2)


fill(N, K, 0, 0)
for item in a:
    print(*item)