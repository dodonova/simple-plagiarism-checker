mas2=[]
for i in range(l):
    l = []
    for i in mas:
        if sum(l)!=s and len(l)>=0 and (x not in l) and l not in mas2:
            l.append(i)
    if l not in mas2:
        mas2.append(l)
print(len(mas2))