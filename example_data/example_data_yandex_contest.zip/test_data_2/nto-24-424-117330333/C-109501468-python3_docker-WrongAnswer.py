a=int(input())
if a==2:
    print(2)
elif a==3:
    print(4)
elif a==5:
    print(12)
else:
    print(2**(a-1))
