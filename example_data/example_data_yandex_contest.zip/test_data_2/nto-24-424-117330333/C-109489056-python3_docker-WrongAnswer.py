a=int(input())
if a==2:
    print(2)
else:
    print(2**(a-1))