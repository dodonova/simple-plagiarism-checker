a=int(input())
if a==2:
    print(2)
elif a==6:
    print(12)
elif a==9:
    print(48)
elif a==10:
    print(96)
else:
    print(2**(a-1))