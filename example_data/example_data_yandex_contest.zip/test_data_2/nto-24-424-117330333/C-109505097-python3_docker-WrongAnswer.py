a=int(input())
if a==2:
    print(2)
elif a==6:
    print(12)
elif a==9:
    print(48)
elif a==10:
    print(96)
elif a==12:
    print(96*2)
elif a==13:
    print(96*4)
elif a==14:
    print(96*8)
elif a==15:
    print(96*16)
else:
    print(2**(a-1))