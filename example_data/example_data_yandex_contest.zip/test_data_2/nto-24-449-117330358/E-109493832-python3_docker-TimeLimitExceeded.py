sumg, numl = map(int, input().split())
colm = int(input())
mass = list(map(int, input().split()))
colgm = 0
for i in range(colm):
    for j in range(i+1, colm+1):
        if sum(mass[i:j]) == sumg and numl in mass[i:j]:
            colgm += 1
print(colgm)
