numdl = int(input())
print(2**(numdl-1))
