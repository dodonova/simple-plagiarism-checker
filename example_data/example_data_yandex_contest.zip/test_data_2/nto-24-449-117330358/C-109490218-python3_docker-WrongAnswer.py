numch = int(input())
print(2**numch)
