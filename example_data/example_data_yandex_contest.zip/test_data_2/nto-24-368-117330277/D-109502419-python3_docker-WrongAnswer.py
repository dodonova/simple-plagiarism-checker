N, K = map(int, input().split())
table = []

for i in range(N):
    table.append([0] * N)


def f(x1, x2, y1, y2, k):
    global table
    if k < 3 or (N - x2) == (N - y2)== N - 1:
        for i in range(x1, x2):
            for j in range(y1, y2):
                table[j][i] = k
    else:
        f(x1=x1, x2=x2//2, y1=y1,y2=y2//2, k=(k-1)) # lev verh
        f(x1=x2//2, x2=x2, y1=y1,y2=y2//2, k=(k-2)) # prav verh
        f(x1=x1, x2=x2//2, y1=y2//2,y2=y2, k=(k-2)) # lev niz
        f(x1=x2//2, x2=x2, y1=y2//2,y2=y2, k=(k-3)) # prav niz


f(x1=0, x2=N, y1=0, y2=N, k=K)

for m in range(N):
    print(*table[m])