S, X = map(int, input().split())
N = int(input())
l = list(map(int, input().split()))
L, R = 0, 0
prom_sum = l[0]
res = 0
while L < N:
    if R == N:
        break
    if S < prom_sum:
        prom_sum -= l[L]
        L += 1
    elif X in l[L:R + 1] and S == prom_sum:
        res += 1
        R += 1
        if R == N:
            break
        prom_sum += l[R]
    else:
        R += 1
        prom_sum += l[R]
print(res)