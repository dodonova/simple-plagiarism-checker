k = int(input())
res = k - 1
res = 2 ** res
print(res)
        