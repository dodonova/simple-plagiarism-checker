n = int(input()) - 1
print(2 ** n)