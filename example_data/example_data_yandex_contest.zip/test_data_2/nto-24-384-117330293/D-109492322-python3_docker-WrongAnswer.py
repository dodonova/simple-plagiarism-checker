n, k = map(int, input().split())

table = ""
if k < 3 or n == 1:
    table = n * ((f"{k} " * n) + "\n")
print(table)