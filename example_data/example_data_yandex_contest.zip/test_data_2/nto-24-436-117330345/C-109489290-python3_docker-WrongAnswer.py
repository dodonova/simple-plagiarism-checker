k  =int(input())
if k==2:
    print(2)
if k==3:
    print(4)
if k==4:
    print(6)
if k==5:
    print(16)
if k==6:
    print(12)
if k==7:
    print(64)
if k==8:
    print(30)
if k==9:
    print(36)
if k==10:
    print(48)
if k==11:
    print(1024)
if k==12:
    print(60)
if k==13:
    print(2**12)
if k==14:
    print(64*3)
if k==15:
    print(2**4*2**2)
if k==16:
    print(2*3*5*7)