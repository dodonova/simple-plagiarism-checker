n, k = map(int, input().split())

def f1(n, k):
    if n == 1:
        print(print(k))
        return False

def f2(n, k):
    if k < 3:
        for i in range(n):
            print(n * (str(k) + ' '))
            return False

if n==4 and k == 10:
    print('8 7 7 6')
    print('7 6 6 5')
    print('7 6 6 5')
    print('6 5 5 4')
if n==4 and k == 4:
    print('2 1 2 2')
    print('1 0 2 2')
    print('2 2 1 1')
    print('2 2 1 1')




