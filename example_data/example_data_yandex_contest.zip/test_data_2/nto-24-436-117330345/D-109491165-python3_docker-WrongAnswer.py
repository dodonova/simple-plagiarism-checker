n, k = map(int, input().split())

if n == 1:
    print(print(k))
if k < 3:
    for i in range(n):
        print(n * (str(k) + ' '))