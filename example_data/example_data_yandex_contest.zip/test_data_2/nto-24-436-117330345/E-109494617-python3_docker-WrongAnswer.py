s, x = map(int, input().split())
n = int(input())
data = [int(c) for c in input().split()]
d1 = data[::-1]
ans = 0

for i in range(n):
    for j in range(i, n):
        t = data[i:j]
        if sum(t) == s and x in t and len(t) > 1:
            ans+= 2
        elif sum(t) == s and x in t:
            ans += 1
print(ans)