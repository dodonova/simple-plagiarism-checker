s, x = map(int, input().split())
n = int(input())
data = [int(c) for c in input().split()]
ans = 0
i = 0
while i!=n:
    for h in range(n):
        t = data[i:h]
        if sum(t) == s and x in t and len(t) > 1:
            ans+= 2
        elif sum(t) == s and x in t:
            ans += 1
    i += 1
print(ans)
