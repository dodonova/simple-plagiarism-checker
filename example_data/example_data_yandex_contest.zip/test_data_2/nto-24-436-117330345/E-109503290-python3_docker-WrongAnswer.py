s, x = map(int, input().split())
n = int(input())
data = [int(c) for c in input().split()]
if data.count(x) == 0:
    print(0)
else:
    print(data.count(x)*2)
