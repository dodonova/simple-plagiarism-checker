k  =int(input())
def col(n):
    c = []
    for i in range(1, n+1):
        if n%i == 0:
            c.append(i)
    return len(c)

for j in range(20000):
    if col(j) == k:
        print(j)
        break   