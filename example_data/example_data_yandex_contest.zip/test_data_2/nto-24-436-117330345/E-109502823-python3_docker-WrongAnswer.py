s, x = map(int, input().split())
n = int(input())
data = [int(c) for c in input().split()]

print(data.count(x)*2)