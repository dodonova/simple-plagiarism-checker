

i = int(input())

p = [3, 5, 7]

if i <= 2 or i in p:
    print(2)
else:
    print(2**(i-1))