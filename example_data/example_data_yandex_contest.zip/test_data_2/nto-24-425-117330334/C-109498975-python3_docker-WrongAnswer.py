
i = int(input())

if i <= 2:
    print(i)
else:
    print(2**(i-1))