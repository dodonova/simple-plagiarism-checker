i = int(input())

if i <= 2:
    print(i)
    exit(0)

print(2**(i-1))