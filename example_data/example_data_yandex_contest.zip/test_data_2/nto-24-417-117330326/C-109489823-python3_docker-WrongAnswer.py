k = int(input())
b = k - 1
n = 2 ** b
print(n)