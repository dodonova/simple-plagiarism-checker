k = int(input())
if (k >= 2) and (k <= 16):
    b = k - 1
    c = 2 ** b
    print(c)