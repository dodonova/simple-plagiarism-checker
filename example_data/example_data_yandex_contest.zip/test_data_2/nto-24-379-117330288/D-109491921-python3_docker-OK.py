def vertical_merge(mat1: list[list], mat2: list):
    res = mat1.copy()
    for i in range(len(mat1)):
        res[i].extend(mat2[i])
    return res

def rec(n, k):
    if n == 1:
        return [[str(k)]]
    if k < 3:
        return [[str(k) for _ in range(n)] for i in range(n)]
    

    left_top = rec(n//2, k-1)
    right_top_left_bottom = rec(n//2, k-2)
    right_bottom = rec(n//2, k-3)

    mat = vertical_merge(left_top, right_top_left_bottom)
    mat.extend(vertical_merge(right_top_left_bottom, right_bottom))
    return mat

n, k = map(int, input().split())
res = rec(n, k)

print('\n'.join(list(map(lambda x: ' '.join(x), res))))
