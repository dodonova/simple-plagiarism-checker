S, X = map(int, input().split())
n = int(input())
arr = list(map(int, input().split()))

l = 0
r = 0

s = 0
count_x = 0

res = 0

while r < len(arr):
    s += arr[r]
    if arr[r] == X:
        count_x += 1
    while s > S:
        s -= arr[l]
        if arr[l] == X:
            count_x -= 1
        l += 1
        if r < l + 1: break
    if s == S and count_x >= 1:
        res += 1
    r += 1

print(res)