from math import sqrt
from collections import Counter

def fact(n):
    facs = []
    nn = n
    for i in range(2, int(sqrt(n))+1):
        while nn % i == 0:
            facs.append(i)
            nn = nn // i

    if nn != 1:
        facs.append(nn)
    return Counter(facs).most_common(len(set(facs)))


def count_dels(n):
    facs = fact(n)
    res = 1
    for i in facs:
        res *= i[1] + 1
    return res

n = int(input())

for i in range(1, int(1e6)):
    local_res = count_dels(i)
    if local_res == n:
        print(i)
        break