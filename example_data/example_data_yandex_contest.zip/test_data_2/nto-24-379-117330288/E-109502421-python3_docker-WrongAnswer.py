S, X = map(int, input().split())
n = int(input())
arr = list(map(int, input().split()))

l = 0
r = 0

s = 0
count_x = 0

res = 0

count_zeros = [0]
zs = 0
for i in arr:
    if i == 0:
        zs += 1
    count_zeros.append(zs)

while r < len(arr):
    #print(r, l, s, count_x, res)
    s += arr[r]
    if arr[r] == X:
        count_x += 1
    while s > S:
        s -= arr[l]
        if arr[l] == X:
            count_x -= 1
        l += 1
        if r < l + 1: break
    if s == S and count_x >= 1:
        res += 1 + count_zeros[r] - count_zeros[l]
    r += 1

print(res)