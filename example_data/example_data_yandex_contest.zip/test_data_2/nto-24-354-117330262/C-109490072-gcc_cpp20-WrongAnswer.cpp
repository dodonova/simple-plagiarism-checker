#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int k=0;
    cin >> k;
    cout << pow(2, (k-1)) << endl;
    return 0;
}