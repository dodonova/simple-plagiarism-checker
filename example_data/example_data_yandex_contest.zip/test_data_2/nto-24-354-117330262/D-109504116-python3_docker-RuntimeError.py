usr = input().split()
n2, k2 = int(usr[0]), int(usr[1])
arr = [['' for i in range(4)] for i in range(4)]
xo = 0

def f(n, k, x=0, y=0, c=1):
    global xo
    if k < 3    or n == 1:
        for i in range(n):
            for j in range(n):
                arr[y+i][x+j] = str(k)

    else:
        f(n // 2, k - 1, n - n // c,      n - n // c)
        f(n // 2, k - 2,    n // 2, n - n // c)
        f(n // 2, k - 2, n - n // c,         n // 2)
        f(n // 2, k - 3,    n // 2,    n // 2)
        c += 1


abc = (f(n2,k2))
for s in abc:
    print(' '.join(s))
