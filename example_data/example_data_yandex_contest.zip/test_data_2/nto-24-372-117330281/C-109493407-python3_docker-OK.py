def delit(k):
    ar = []
    k1 = k
    while k1 > 1:
        q = 2
        while k1 % q != 0:
            q += 1
        ar.append(q)
        k1 = k1 // q
    return ar


ch = int(input())
arr = sorted(delit(ch), reverse=True)
ar1 = [2, 3, 5, 7]
if len(arr) == 1:
    print(ar1[0] ** (arr[0] - 1))
elif len(arr) == 2:
    print(ar1[0] ** (arr[0] - 1) * ar1[1] ** (arr[1] - 1))
elif len(arr) == 3:
    if arr[0] > 2:
        print(ar1[0] ** (arr[0] - 1) * ar1[1] ** (arr[1] - 1) * ar1[2] ** (arr[2] - 1))
    else:
        print(ar1[0] ** (arr[0] + 1) * ar1[1] ** (arr[1] - 1))
else:
    if ar1[3] ** (arr[3] - 1) > ar1[0] ** (arr[3]):
        print(ar1[0] ** (arr[0] + 1) * ar1[1] ** (arr[1] - 1) * ar1[2] ** (arr[2] - 1))
    else:
        print(ar1[0] ** (arr[0] + 1) * ar1[1] ** (arr[1] - 1) * ar1[2] ** (arr[2] - 1) * ar1[3] ** (arr[3] - 1))
