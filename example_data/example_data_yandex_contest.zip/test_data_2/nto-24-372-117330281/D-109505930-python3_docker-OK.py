def rek(n, k, lp):
    global arr
    if n == 1:
        arr.append([lp, k])
        return k
    elif k < 3:
        return [rek(n // 2, k, lp * 2), rek(n // 2, k, lp * 2), rek(n // 2, k, lp * 2 + 1), rek(n // 2, k, lp * 2 + 1)]
    else:
        return [rek(n // 2, k - 1, lp * 2), rek(n // 2, k - 2, lp * 2), rek(n // 2, k - 2, lp * 2 + 1), rek(n // 2, k - 3, lp * 2 + 1)]


n, k = map(int, input().split())
arr = []
ar = rek(n, k, 0)
ar2 = [0] * n
for i in range(n):
    ar2[i] = []
for i in range(len(arr)):
    ar2[arr[i][0]].append(arr[i][1])
arr.sort()
for i in range(n):
    for j in range(n):
        print(ar2[i][j], end=' ')
    print()
