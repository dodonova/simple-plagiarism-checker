from math import ceil


print(210)