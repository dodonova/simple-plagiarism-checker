ch = int(input())
print(2 ** (ch - 1))