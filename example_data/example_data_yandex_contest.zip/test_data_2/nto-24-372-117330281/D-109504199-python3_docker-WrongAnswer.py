def rek(n, k, lp):
    global arr
    if n == 1:
        arr.append([lp, k])
        return k
    elif k < 3:
        return [rek(n // 2, k, lp * 2), rek(n // 2, k, lp * 2), rek(n // 2, k, lp * 2 + 1), rek(n // 2, k, lp * 2 + 1)]
    else:
        return [rek(n // 2, k - 1, lp * 2), rek(n // 2, k - 2, lp * 2), rek(n // 2, k - 2, lp * 2 + 1), rek(n // 2, k - 3, lp * 2 + 1)]


n, k = map(int, input().split())
arr = []
ar = rek(n, k, 0)
arr.sort()
for i in range(n):
    for j in range(n):
        if i < n // 2:
            if j < n // 2:
                print(arr[i * n + (n // 2 - 1 - j)][1], end=' ')
            else:
                print(arr[i * n + j][1], end=' ')
        else:
            print(arr[i * n + (n - 1 - j)][1], end=' ')
    print()
