print(2 ** (int(input()) - 1))def is_answer(num):
    answ = 0
    for i in lst:
        if num % i == 0:
            answ += 1
    if answ == n:
        return 1
    return 0


for i in range(1, 10000):
    if is_answer(i):
        print(i)
        break
