n = int(input())
for i in range(1, 100000):
    lst = []
    ans = 0
    for j in range(1, i + 1):
        if i % j == 0:
            lst.append(j)
            ans += 1
    if ans == n:
        print(i)
        break

