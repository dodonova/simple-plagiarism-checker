n, k = list(map(int, input().split()))

mx = []
if k < 3 or n == 1:
    for i in range(n):
        row = []
        for j in range(k):
            row.append(k)
        mx.append(row)
for i in range(n):
    print(*mx[i])