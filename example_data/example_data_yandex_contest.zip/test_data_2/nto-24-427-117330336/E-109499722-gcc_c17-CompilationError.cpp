s, x = list(map(int, input().split()))
n = int(input())
lst = list(map(int, input().split()))


def sub_lists(my_list):
    subs = [[]]
    for sub in my_list:
        subs += [i + [sub] for i in subs]
    return subs


answer = 0
subs = sub_lists(lst)
for i in subs:
    if sum(i) == s and x in i:
        answer += 1
print(answer)