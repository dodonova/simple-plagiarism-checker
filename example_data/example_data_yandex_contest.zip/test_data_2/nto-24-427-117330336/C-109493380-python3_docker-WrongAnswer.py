n = int(input())
for i in range(1, 1000):
    ans = 0
    for j in range(1, 1000):
        if i % j == 0:
            ans += 1
    if ans == n:
        print(i)
        break
