s, x = map(int, input().split())
n = int(input())
lst = map(int, input().split())

answer = 0


def sub_lists(my_list):
    global answer
    subs = [[]]
    for sub in my_list:
        subs += [i + [sub] for i in subs]
    for i in subs:
        if sum(i) == s and x in i:
            answer += 1
    return answer


print(sub_lists(lst))
