a = int(input())
if a - 1 % 2 == 0:
    print(2 ** (a - 1))
elif a - 1 % 2 != 0:
    print((a - 1) * a)