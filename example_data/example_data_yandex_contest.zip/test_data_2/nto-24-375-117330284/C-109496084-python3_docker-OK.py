a = int(input())
c = 0
f = False
for i in range(1, 10000):
    for j in range(1, i + 1):
        if i % j == 0:
            c += 1
    if c == a:
        f = True
        break
    else:
        c = 0
print(i)