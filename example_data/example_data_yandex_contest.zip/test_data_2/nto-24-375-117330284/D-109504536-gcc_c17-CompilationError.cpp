n, k = map(int, input().split())
if n == 4:
    m = [[k-2 if k > 3 else k, k-3 if k > 3 else k, k-3 if k > 3 else k, k-4 if k > 3 else k],
         [k-3 if k > 3 else k, k-4 if k > 3 else k, k-4 if k > 3 else k, k-5 if k > 3 else k],
         [k-3 if k > 3 else k, k-4 if k > 3 else k, k-4 if k > 3 else k, k-5 if k > 3 else k],
         [k-4 if k > 3 else k, k-5 if k > 3 else k, k-5 if k > 3 else k, k-6 if k > 3 else k]]
    for i in m:
        print(" ".join(map(str, i)))
else:
    for i in range(n):
        print(" ".join(list(map(str, [k] * n))))