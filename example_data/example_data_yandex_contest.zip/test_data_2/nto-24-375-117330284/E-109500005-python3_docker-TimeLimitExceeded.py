s, x = map(int, input().split())
n = int(input())
m = list(map(int, input().split()))
cnt = 0
snow = m[0]
for i in range(n):
    snow = m[i]
    for j in range(i + 1, n):
        snow += m[j]
        if snow == s and x in m[i:j + 1]:
            cnt += 1
print(cnt)