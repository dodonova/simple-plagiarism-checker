#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using ld = long double;
const ll INF = (ll) 1e18;
vector<vector<int>> a;
void req(int x1, int y1, int x2, int y2, int k) {
    int n = y2 - y1 + 1;
    if (n == 1 || k < 3) {
        for (int i = y1; i <= y2; ++i) {
            for (int j = x1; j <= x2; ++j) {
                a[i][j] = k;
            }
        }
    } else {
        req(x1, y1, (x1 + x2) / 2, (y1 + y2) / 2, k - 1);
        req((x1 + x2 + 1) / 2, (y1 + y2 + 1) / 2, x2, y2, k - 3);
        req((x1 + x2 + 1) / 2, y1, x2, (y1 + y2) / 2, k - 2);
        req(x1, (y1 + y2 + 1) / 2, (x1 + x2) / 2, y2, k - 2);
    }
}
int main() {
    int n, k;
    cin >> n >> k;
    a.resize(n, vector<int>(n));
    req(0, 0, n - 1, n - 1, k);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << a[i][j] << " ";
        }
        cout << "\n";
    }
    return 0;
}
