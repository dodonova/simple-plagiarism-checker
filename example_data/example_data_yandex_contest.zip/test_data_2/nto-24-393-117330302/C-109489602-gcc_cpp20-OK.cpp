#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using ld = long double;
const ll INF = (ll) 1e18;

int main() {
    int k;
    cin >> k;
    int n = (1 << 16);
    vector<bool> primes(n, true);
    vector<int> a;
    for (int i = 2; i < n; ++i) {
        if (!primes[i]) {
            continue;
        }
        a.push_back(i);
        for (int j = i + i; j < n; j += i) {
            primes[j] = false;
        }
    }
    int mini = 10000000;
    for (int i = 2; i <= (1 << 16); ++i) {
        int res = 1;
        for (int j = 0; j < (int) a.size(); ++j) {
            int cnt = 0;
            int copy = i;
            while (copy % a[j] == 0) {
                cnt++;
                copy /= a[j];
            }
            res *= (cnt + 1);
        }
        if (res == k) {
            mini = min(mini, i);
        }
    }
    cout << mini << endl;
    return 0;
}
