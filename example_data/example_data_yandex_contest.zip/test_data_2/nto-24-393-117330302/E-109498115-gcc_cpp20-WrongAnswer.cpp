#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using ld = long double;
const ll INF = (ll) 1e18;

int main() {
    ll s, x;
    cin >> s >> x;
    int n;
    cin >> n;
    vector<ll> a(n);
    bool flag = true;
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
        if (a[i] != a[0]) {
            flag = false;
        }
    }
    if (flag) {
        if (s == a[0] && s == 0) {
            if (x == a[0]) {
                cout << n * (n - 1) / 2 << endl;
            } else {
                cout << 0 << endl;
            }
            return 0;
        } else if (s == a[0] && s != 0) {
            if (x == a[0]) {
                cout << n << endl;
            } else {
                cout << 0 << endl;
            }
            return 0;
        }
        // if (s % a[0] == 0) {
        //     int get = s / a[0];
        //     if ()
        // }
    }
    vector<ll> pref_sums_check2(n + 1);
    pref_sums_check2[0] = 0;
    for (int i = 0; i < n; ++i) {
        pref_sums_check2[i + 1] = pref_sums_check2[i] + (a[i] == x);
    }
    // for (auto el : pref_sums_check2) {
    //     cout << el << " ";
    // }
    // cout << endl;
    map<ll, vector<int>> check; // {sums, {indexes}};
    ll now_sum = 0;
    ll res = 0;
    for (int i = 0; i < n; ++i) {
        now_sum += a[i];
        check[now_sum - a[i]].push_back(i);
        for (auto ind : check[now_sum - s]) {
            if (pref_sums_check2[i + 1] - pref_sums_check2[ind] > 0) {
                res++;
            }
            // cout << ind << " " << i << endl;
        }
    }
    cout << res << endl;
    return 0;
}
