#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using ld = long double;
const ll INF = (ll) 1e18;

int main() {
    ll s, x;
    cin >> s >> x;
    int n;
    cin >> n;
    vector<ll> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    vector<int> pref_sums_check2(n + 1);
    pref_sums_check2[0] = 0;
    for (int i = 0; i < n; ++i) {
        pref_sums_check2[i + 1] = pref_sums_check2[i] + (a[i] == x);
    }
    map<int, vector<int>> check; // {sums, {indexes}};
    ll now_sum = 0;
    ll res = 0;
    for (int i = 0; i < n; ++i) {
        now_sum += a[i];
        for (auto ind : check[s - now_sum]) {
            if (pref_sums_check2[i + 1] - pref_sums_check2[ind] > 0) {
                res++;
            }
            // cout << ind << " " << i << endl;
        }
        check[now_sum - a[i]].push_back(i);
    }
    cout << res << endl;
    return 0;
}
