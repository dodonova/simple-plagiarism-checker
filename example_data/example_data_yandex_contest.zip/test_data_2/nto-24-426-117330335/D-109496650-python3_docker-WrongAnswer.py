def zapolnenie(n, k):  # требуется передавать n/ 2, f показывает сколько раз вызывалась функция
    k1, n1 = k, n
    if k1 < 3:
        mass = [' '.join([str(k1) for j in range(n1)]) for i in range(n1)]
    else:
        mass = []
        k1 -= 1
        s = ''
        for i in range(n1):
            for j in range(n1):
                s += str(k1)
                if j != n1 - 1:
                    k1 -= 1
                    s += ' '
            mass.append(s)
            s = ''
    return mass


n, k = map(int, input().split())
if n == 1:
    print(k)
elif k < 3:
    for i in range(n):
        mass = [' '.join([str(k) for j in range(n)]) for i in range(n)]
        print(mass[i])
else:
    left_up = zapolnenie(n // 2, k - 1)
    r_up = zapolnenie(n // 2, k - 2)
    l_down = zapolnenie(n // 2, k - 2)
    r_down = zapolnenie(n // 2, k - 3)
    for i in range(n // 2):
        print(left_up[i], r_up[i])
    for i in range(n // 2):
        print(l_down[i], r_down[i])
