k = int(input())
if k == 2:
    print(2)
if k == 3:
    print(121)
if k == 4:
    print(65)
if k == 5:
    print(81)
if k == 6:
    print(68)
if k == 7:
    print(64)
if k == 8:
    print(66)
if k == 9:
    print(100)