def num_del(number):
    n = 0
    for i in range(1, number + 1):
        if number % i == 0:
            n += 1
    return n



k = int(input())
num = 2
while True:
    if num_del(num) == k:
        print(num)
        break
    num += 1