def is_good(data, s, x):
    return sum(data) == s and x in data


s, x = list(map(int, input().split()))
n = int(input())
lst = list(map(int, input().split()))

n_god = 0
len_under = 1
while len_under <= len(lst):
	if is_good(lst[:len_under], s, x):
            n_god += 1
    len_under += 1
print(n_god)