def is_good(data, s, x):
    return sum(data) == s and x in data


s, x = list(map(int, input().split()))
n = int(input())
lst = list(map(int, input().split()))

n_god = 0
len_under = 2
while len_under <= n:
    for i in range(n - len_under + 1):
        if is_good(lst[i:i + len_under], s, x):
            n_god += 1
    len_under += 1
print(n_god)