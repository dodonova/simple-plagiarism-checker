class Table():
    def __init__(self, n, k):
        self.n = n
        self.k = k

    def convert(self):
        if self.n == 1:
            return [[self.k]]
        if self.k < 3:
            return [[k for i in range(n)] for j in range(n)]
        return [[Table(n / 2, k - 1).convert(), Table(n / 2, k - 2).convert()], [Table(n / 2, k - 2).convert(), Table(n / 2, k - 3).convert()]]


def print_data(data):
    for i in data:
        print(' '.join(list(map(str, i))).replace('[', '').replace(']', ''))



n, k = list(map(int, input().split()))
if k < 3 or n == 1:
    data = [[k for i in range(n)] for j in range(n)]
    print_data(data)
else:
    data = Table(n, k)
    print_data(data.convert())