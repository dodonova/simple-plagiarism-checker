'''class Table():
    def __init__(self, ):

'''
def print_data(data):
    for i in data:
        print(*i)

'''
def transform(data, n, k):
'''


n, k = list(map(int, input().split()))
if k < 3 or n == 1:
    data = [[k for i in range(n)] for i in range(n)]
    print_data(data)
else:
    print(1)