n, k = map(int,input().split())
matrix = []
if k < 3 or n == 1:
    qer = []
    for i in range(n):
        qer.append(k)
    for i in range(n):
        matrix.append(qer)

for i in range(n):
    print()
    for j in range(n):
        print(matrix[i][j], end='')