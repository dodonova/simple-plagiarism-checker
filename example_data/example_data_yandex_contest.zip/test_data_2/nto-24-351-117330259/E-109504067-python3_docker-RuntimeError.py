s, x = map(int, input().split())
n = int(input())
mas = list(map(int, input().split()))
xin = mas.index(x)
cnt = 0
for i in range(len(mas)):
    res = []
    if i > xin:
        break
    for j in range(i, len(mas)):
        res.append(mas[j])
        if sum(res) == s and x in res:
            cnt += 1

print(cnt)
