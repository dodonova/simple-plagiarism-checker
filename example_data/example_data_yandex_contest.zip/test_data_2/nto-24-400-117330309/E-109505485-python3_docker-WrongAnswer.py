def main():
    subarrays_count = 0
    s, x = map(int, input().split())
    n = int(input())
    array = [int(i) for i in input().split()]
    len_array = len(array)

    for i in range(len_array):
        cursor = i
        subarray = []
        while cursor != len_array:
            subarray.append(array[cursor])
            if x in subarray and sum(subarray) == s:
                while sum(subarray) == s:
                    subarrays_count += 1
                    cursor += 1
                    if cursor != len_array:
                        subarray.append(array[cursor])
                        continue
                    break

                break
            cursor += 1

    return subarrays_count


main()
