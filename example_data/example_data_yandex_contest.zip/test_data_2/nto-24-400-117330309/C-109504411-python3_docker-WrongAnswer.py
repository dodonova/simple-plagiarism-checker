def main():
    k = int(input())
    deliters = 0
    counter = 1
    while True:
        counter += 1
        for i in range(1, counter + 1):
            if isDelitel(counter, i):
                deliters += 1
            if deliters == k:
                return counter
        deliters = 0


def isDelitel(a, b):
    return True if a / b == round(a / b) else False


print(main())