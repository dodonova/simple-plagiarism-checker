def func():
    n = int(input())
    print(2 ** (n - 1))


func()
