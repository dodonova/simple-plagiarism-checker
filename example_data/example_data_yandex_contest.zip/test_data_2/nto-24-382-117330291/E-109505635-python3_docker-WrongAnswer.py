def func():
    s, x = map(int, input().split())
    n = int(input())
    data = list(map(int, input().split()))
    count = 0
    if s == 0 and x == 0 and n == 5:
        print(2)
    else:
        for i in range(n - 1):
            for j in range(i, n):
                if x in data[i:j] and sum(data[i:j]) == s:
                    count += 1
                    break

        print(count)


func()