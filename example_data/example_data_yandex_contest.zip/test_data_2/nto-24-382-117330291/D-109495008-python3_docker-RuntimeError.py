def func(n, k):
    if k < 3:
        for i in range(n):
            print((f'{k} ' * n).strip())
    elif n == 1:
        print(k)
    else:
        f_sector = []
        s_sector = []
        qatr_sector = []
        if k - 1 < 3:
            for x in range(int(n / 2)):
                s_sector.append([k - 1] * int(n / 2))
        else:
            # обработка
            c = k - 1
            new_c = c
            for x in range(int(n / 2)):
                new_c = c
                lst = []
                for y in range(int(n / 2)):
                    lst.append(new_c - 1)
                    new_c -= 1
                f_sector.append(lst)
                c -= 1

        if k - 2 < 3:
            for x in range(int(n / 2)):
                s_sector.append([k - 2] * int(n / 2))
        else:
            c = k - 2
            new_c = c
            for x in range(int(n / 2)):
                new_c = c
                lst = []
                for y in range(int(n / 2)):
                    lst.append(new_c - 1)
                    new_c -= 1
                s_sector.append(lst)
                c -= 1
        if k - 3 < 3:
            for x in range(int(n / 2)):
                qatr_sector.append([k - 3] * int(n / 2))
        else:
            # обработка
            c = k - 3
            new_c = c
            for x in range(int(n / 2)):
                new_c = c
                lst = []
                for y in range(int(n / 2)):
                    lst.append(new_c - 1)
                    new_c -= 1
                qatr_sector.append(lst)
                c -= 1
    for x in range(int(n / 2)):
        print(*f_sector[x], *s_sector[x])
    for x in range(int(n / 2)):
        print(*s_sector[x], *qatr_sector[x])


n, k = map(int, input().split())
func(n, k)
