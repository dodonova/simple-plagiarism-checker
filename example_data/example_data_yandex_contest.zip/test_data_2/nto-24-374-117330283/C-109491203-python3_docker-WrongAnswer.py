a = int(input())
if a <= 7:
    print(2**(a-1))
else :
    print(2 ** (a+1))