s=int(input())
print(2**(s-1))