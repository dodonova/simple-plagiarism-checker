a=int(input())
for i in range(1,32769):
    k=1
    for j in range(1,i):
        if i%j==0:
            k+=1
    if k==a:
        print(i)
        break