def f(a, n, k):
    z = n // 2
    x = k - 1
    if x < 3 or z == 1:
        for i in range((z // 2) + 1):
            for j in range((z // 2) + 1):
                a[i][j] = x
    else:
        return f(a, z, x), g(a, z, x), h(a, z, x)
    return a


def g(a, n, k):
    z = n // 2
    x = k - 2
    if x < 3 or z == 1:
        for i in range(z, ((z // 2) - 1), -1):
            for j in range((z // 2) + 1):
                a[i][j] = x
        for i in range((z // 2) + 1):
            for j in range(z, (z // 2) - 1, -1):
                a[i][j] = x
    else:
        return f(a, z, x), g(a, z, x), h(a, z, x)
    return a


def h(a, n, k):
    z = n // 2
    x = k - 3
    if x < 3 or z == 1:
        for i in range(z, (z // 2) - 1, -1):
            for j in range(z, (z // 2) - 1, -1):
                a[i][j] = x
    else:
        return f(a, z, x), g(a, z, x), h(a, z, x)
    return a



n, k = map(int, input().split())
a = [[0] * n] * n
if k < 3 or n == 1:
    for i in range(n):
        for j in range(n):
            a[i][j] = k
else:
    f(a, n, k)
    g(a, n, k)
    h(a, n, k)

for i in range(n):
    for j in range(n):
        print(a[i][j], end=' ')
    print('')