n, k = map(int, input().split())
a = [[0] * n] * n

if k < 3 or n==1:
    for i in range(n):
        for j in range(n):
            a[i][j] = k

for i in range(n):
    for j in range(n):
        print(a[i][j],end=' ')
    print('')