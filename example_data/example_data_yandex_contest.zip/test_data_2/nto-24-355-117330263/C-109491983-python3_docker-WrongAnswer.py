k=int(input())
for n in range (1, 1000):
    count=0
    for d in range (1, 1000):
        if n%d == 0: count +=1
    if count == k:
        print (n)
        break