s, x = map(int, input().split())
input()
nums = list(map(int, input().split()))
lucky = list(map(lambda n: n == x, nums))
counter = 0
for w in range(1, len(nums) + 1):
    for i in range(len(nums) - w + 1):
        if any(lucky[i:i+w]) and sum(nums[i:i+w]) == s:
            counter += 1
print(counter)