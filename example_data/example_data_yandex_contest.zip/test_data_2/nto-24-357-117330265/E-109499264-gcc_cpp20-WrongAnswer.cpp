#include <stdio.h>
#include <stdlib.h>
#define ll long long int

using namespace std;

bool is_lucky(ll *lucky_arr, ll lucky, ll start, ll end)
{
    for (ll i = start; i <= end; ++i)
        if (lucky_arr[i] == lucky) return true;
    return false;
}

ll sum(ll *arr, ll start, ll end)
{
    ll s = 0;
    for (ll i = start; i <= end; ++i)
        s += arr[i];
    return s;
}

int main()
{
    ll S, X;
    scanf("%lld %lld", &S, &X);
    ll len;
    scanf("%lld", &len);
    ll *arr = (ll *)malloc(sizeof(ll) * len);
    for (ll i = 0; i < len; ++i) {
        scanf(" %lld", arr + i);
    }
    ll counter = 0;
    for (ll w = 1; w <= len; ++w) {
        for (ll i = 0; i <= len - w; ++i) {
            if (is_lucky(arr, X, i, i + w) && sum(arr, i, i + w) == S) {
                counter++;
            }
        }
    }
    printf("%lld\n", counter);
    return 0;
}