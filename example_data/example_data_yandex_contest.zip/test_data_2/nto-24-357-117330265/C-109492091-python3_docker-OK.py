def dividers(n: int) -> int:
    counter = 2
    for i in range(2, n):
        if n % i == 0:
            counter += 1
    return counter
        

target = int(input())
n = 2
while True:
    if dividers(n) == target:
        print(n, end=" ")
        break
    n += 1