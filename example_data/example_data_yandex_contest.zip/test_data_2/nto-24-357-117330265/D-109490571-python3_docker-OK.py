n, k = map(int, input().split())

def resolve(row: int, column: int, n: int, k: int) -> int:
    if k < 3 or n == 1:
        return k
    half = n // 2
    if row < half:
        if column < half:
            return resolve(row, column, half, k - 1)
        else:
            return resolve(row, column - half, half, k - 2)
    else:
        if column < half:
            return resolve(row - half, column, half, k - 2)
        else:
            return resolve(row - half, column - half, half, k - 3)

for r in range(n):
    for c in range(n):
        print(resolve(r, c, n, k), end=" ")
    print()