from math import sqrt

k = int(input())

def d(n):
    a = 0
    for i in range(1, n + 1):
        if n % i == 0:
            a += 1
    return a


a = 1
while True:
    if d(a) == k:
        print(a)
        break
    a += 1
