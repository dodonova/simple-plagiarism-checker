k = int(input())
if k % 8 == 0:
    print(24)
elif k < 10 and k % 5 == 0:
    print(16)
elif k == 4:
    print(6)
else:
    print(2 ** (k - 1))