k = int(input())
b = 2 ** 15
count = 0
while count != k:
    for i in range(1, b + 1):
        if 2 ** 15 % i == 0:
            count += 1
    if count == k:
        print(i)
        break
    else:
        b -= 1