k = int(input())
if k % 3 == 0:
    print(6)
else:
    print(2 ** (k - 1))