k = int(input())
if k % 8 == 0:
    print(24)
else:
    print(2 ** (k - 1))