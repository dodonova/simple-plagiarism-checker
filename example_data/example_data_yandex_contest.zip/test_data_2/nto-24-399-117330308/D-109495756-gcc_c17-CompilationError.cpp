Однажды Windows придумали версию "Windows for woman"
Отличие было в том, что вместо слов "Yes" и "No" стояло слово "Maybe".