k = int(input())


def count_primes(n):
    cout = 1

    for j in range(2, n + 1):
        while n % j == 0:
            n //= j
            cout += 1
        if n == 1:
            break

    return cout


for i in range(2 ** k):
    if count_primes(i) == k:
        print(i)
        break
