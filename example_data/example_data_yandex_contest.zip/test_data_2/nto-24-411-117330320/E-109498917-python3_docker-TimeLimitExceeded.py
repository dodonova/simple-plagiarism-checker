s, x = map(int, input().split())
n = int(input())
arr = map(int, input().split())

prefixes = []
nums = []
for idx, num in enumerate(arr):
    prefixes.append((prefixes[-1] if prefixes else 0) + num)
    if num == x:
        nums.append(idx)


def get_prefix_sum(left, right):
    return prefixes[right] if left == 0 else prefixes[right] - prefixes[left - 1]


cout = 0
for li in range(n):
    for ri in range(n):
        if get_prefix_sum(li, ri) == s and any(li <= ln <= ri for ln in nums):
            cout += 1

print(cout)
