import itertools


def fill_matrix(n, k):
    if n == 1:
        return [[k]]
    if k < 3:
        return [[k] * n for _ in range(n)]

    left_top = fill_matrix(n // 2, k - 1)
    middle = fill_matrix(n // 2, k - 2)
    right_bottom = fill_matrix(n // 2, k - 3)

    lst1 = []
    for arr in itertools.chain(zip(left_top, middle), zip(middle, right_bottom)):
        t = []
        for sarr in arr:
            t += sarr
        lst1.append(t)

    return lst1


for line in fill_matrix(*map(int, input().split())):
    print(*line)
