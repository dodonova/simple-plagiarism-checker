k = int(input())
print(2 ** (k - 1))
