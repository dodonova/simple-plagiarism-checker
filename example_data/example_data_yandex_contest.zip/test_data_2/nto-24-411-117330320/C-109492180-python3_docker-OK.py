k = int(input())


def count_primes(n):
    cout = 0

    for j in range(1, n + 1):
        if n % j == 0:
            cout += 1

    return cout


for i in range(2 ** k):
    if count_primes(i) == k:
        print(i)
        break
