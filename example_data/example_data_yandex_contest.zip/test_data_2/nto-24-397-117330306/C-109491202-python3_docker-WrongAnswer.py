n = int(input())
rez = 0
for i in range(1, 999):
    for j in range(1, i + 1):
        if i % j == 0:
            rez = rez + 1
            print(rez)
    print("xam")

    if rez == n:
        print(i)
        break
    rez = 0