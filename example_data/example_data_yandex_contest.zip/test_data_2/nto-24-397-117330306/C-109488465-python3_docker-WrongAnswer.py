import math
n = int(input())
print(pow(2,(n-1)))
