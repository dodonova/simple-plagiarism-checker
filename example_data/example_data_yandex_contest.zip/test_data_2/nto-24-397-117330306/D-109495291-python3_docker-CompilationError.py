int main()
{
    int n,k;
    cin >> n >> k;
    int** a = new int*[n];
    for (int i = 0; i < n; i++){
        a[i] = new int[n];
    }

    if (k < 3) or (n == 1){
        for (int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cout << k << " ";
            }
            cout << endl;
        }
    } else {
        
    }
    

    for (int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){

        }
    }
    return 0;
}