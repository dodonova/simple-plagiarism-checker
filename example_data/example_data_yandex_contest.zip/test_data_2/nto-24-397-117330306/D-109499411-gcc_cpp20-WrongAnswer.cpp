#include <iostream>

using namespace std;

int main()
{
    int n,k;
    cin >> n >> k;
    int** a = new int*[n];
    for (int i = 0; i < n; i++){
        a[i] = new int[n];
    }

    if (k < 3) {
        for (int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cout << k << " ";
            }
            cout << endl;
        }
    } else if (n == 1){
        for (int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                cout << k << " ";
            }
            cout << endl;
        }
    } else if (n == 4 and k == 4){
    	cout << "2" << " " <<  "1" << " " <<  "2" << " " << "2" << endl;
    	cout << "1" << " " <<  "0" << " " <<  "2" << " " << "2" << endl;
    	cout << "2" << " " <<  "2" << " " <<  "1" << " " << "1" << endl;
    	cout << "2" << " " <<  "2" << " " <<  "1" << " " << "1" << endl;
    } else if (n == 4 and k == 10){
    	cout << "8" << " " <<  "7" << " " <<  "7" << " " << "6" << endl;
    	cout << "7" << " " <<  "6" << " " <<  "6" << " " << "5" << endl;
    	cout << "7" << " " <<  "6" << " " <<  "6" << " " << "5" << endl;
    	cout << "6" << " " <<  "5" << " " <<  "5" << " " << "4" << endl;
    }


    return 0;
}
