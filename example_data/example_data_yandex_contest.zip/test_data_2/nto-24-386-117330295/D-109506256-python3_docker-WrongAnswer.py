from math import log2
# from functools import lru_cache
# @lru_cache(None)

# class Tree:
# 	def __init__(self, left, right):
# 		self.left = left
# 		self.right = right
# t = Tree(Tree("a", "b"), Tree("c", "d"))
# t.right.left
# n = 4
# d = [1] * (n+1)
 
# for x in range(2, len(d)):
#   for y in range(x, len(d), x):
#     d[y] += x
 
# i = next(i for i,x in enumerate(d) if x >= n)
# print(i)
n = 4
k = 4
def main(n, k):
    n = int(n)
    if n == 1:
        return k
    if k<3:
        return [[main(n/2, k),  main(n/2, k)],
                [main(n/2, k),  main(n/2, k)]]
    
    
    return [
        [main(n/2, k-1),  main(n/2, k-2)],
        [main(n/2, k-2),  main(n/2, k-3)],
    ]
a = main(n, k)

# def prrr(l):
#     if type(l) == int:
#         print(l)
#     if 

# print(len(a))
ans = []
for i in range(n):
    ans.append([])
h = 0
def print_row(r, p):
    global h

    if type(r) == int:
        if len(ans[h]) == n:
            h += 2
            if h+1 > n:
                return
        if p == 0:
            ans[h].append(r)
        else:
            print(h, len(ans))
            ans[h+1].append(r)
        return
    print_row(r[0], 0)
    print_row(r[1], 1 or p)


def pr(l, s, p):
    global ans
    if int(s) == 1:
        print_row(l, p)
        return

    pr(l[0], s//2, 0)
    pr(l[1], s//2, 1)
pr(a, n, 0)

for i in range(n- 1):
    for g in range(len(ans[i])):
        if i == n:
            print(ans[i][g])
        else:
            print(ans[i][g], end='')