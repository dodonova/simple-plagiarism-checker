k = int(input())

n = 2 + (k-3)
print(2**n)