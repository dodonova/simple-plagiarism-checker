s, x = map(int, input().split())
n = int(input())
a = [int(i) for i in input().split()]
su = 0
new = []
k = 0

for l in range(len(a)):
    for r in range(len(a)):
        
        if sum(a[l:r+1]) == s and x in a[l:r+1]:
            k+= 1
print(k)