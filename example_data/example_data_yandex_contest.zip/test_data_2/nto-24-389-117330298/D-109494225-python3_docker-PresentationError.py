n, k = map(int, input().split())
matrix = []
# for i in range(n):
#     matrix.append(list(map(int, input().split())))
# print(matrix)
if k < 3 or n == 1:
    matrix = [[k for i in range(n)] for j in range(n)]
# else:
#     for i in range(n):
#         for j in range(n):
#             

print(matrix)