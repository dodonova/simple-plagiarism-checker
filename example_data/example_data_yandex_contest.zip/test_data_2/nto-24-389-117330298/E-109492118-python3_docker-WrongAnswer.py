s, x = map(int, input().split())
n = int(input())
mass = list(map(int, input().split()))
c = 0
for i in range(n-1):
    for j in range(i+1, n):
        if sum(mass[i:j+1]) == s and (x in mass[i:j+1]):
            c += 1
        if sum(mass[i:j+1]) > s:
            break
print(c)