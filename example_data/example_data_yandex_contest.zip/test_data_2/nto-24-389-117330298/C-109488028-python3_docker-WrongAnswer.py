t = int(input())
print(2 ** (t - 1))