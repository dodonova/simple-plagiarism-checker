t = int(input())
def f(n):
    s = set()
    for i in range(1, int(n**0.5)+1):
        if n % i == 0:
            s.add(i)
            s.add(n // i)
    return len(s)
for i in range(1, 100000):
    if f(i) == t:
        print(i)
        break