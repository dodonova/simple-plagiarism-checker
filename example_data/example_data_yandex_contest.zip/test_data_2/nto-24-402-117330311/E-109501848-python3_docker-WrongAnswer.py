s, x = map(int, input().split())
n = int(input())
a = list(map(int, input().split()))

luck = []
for i, j in enumerate(a):
    if j == x:
        luck.append(i)

count = 0

for start in range(n):
    for end in range(start, n + 1):
        for i in luck:
            if start > i or end <= i or sum(a[start:end]) != s:
                continue
            count += 1

print(count)