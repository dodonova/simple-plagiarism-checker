s, x = map(int, input().split())
n = int(input())
a = list(map(int, input().split()))

luck = []
for i, j in enumerate(a):
    if j == x:
        luck.append(i)

count = 0

for start in range(n):
    for end in range(start, n):
        lucky = False
        for i in luck:
            if start <= i <= end:
                lucky = True
                break
        if sum(a[start:end]) != s or not lucky:
            continue
        count += 1

print(count)