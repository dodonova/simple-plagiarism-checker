n, k = map(int, input().split())
grid = [[0 for _ in range(n)] for _ in range(n)]


def f(subgrid, n, k):
    if n == 1 or k < 3:
        return [[k for _ in range(n)] for _ in range(n)]
    top_left = f([row[:n // 2] for row in subgrid[:n // 2]], n // 2, k - 1)
    top_right = f([row[n // 2:] for row in subgrid[:n // 2]], n // 2, k - 2)
    bot_left = f([row[:n // 2] for row in subgrid[n // 2:]], n // 2, k - 2)
    bot_right = f([row[n // 2:] for row in subgrid[n // 2:]], n // 2, k - 3)
    grid = []
    for y in range(n):
        if y < n // 2:
            grid.append(top_left[y] + top_right[y])
        else:
            grid.append(bot_left[y - n // 2] + bot_right[y - n // 2])
    return grid


print("\n".join(" ".join(map(str, x)) for x in f(grid, n, k)))
