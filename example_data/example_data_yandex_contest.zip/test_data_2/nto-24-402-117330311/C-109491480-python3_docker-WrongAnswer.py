import math


def primes(n):
    for i in range(2, n):
        is_prim = True
        for j in range(2, math.floor(math.sqrt(i)) + 1):
            if i % j == 0:
                is_prim = False
                break
        if is_prim:
            yield i


primes = list(primes(100))


def factor(x):
    while x > 1:
        for i in primes:
            if x % i == 0:
                x //= i
                yield i
                break


k = int(input())
n = 1
for i, x in enumerate(reversed(list(factor(k)))):
    n *= primes[i] ** (x - 1)

print(n)