n = int(input())
ni = n - 1
k = 2 * n - 1
mas = input()
mas = mas.split(' ')
sum = 0
for l in range(n):
    for r in range(n):
        if 0 <= l <= r <= ni:
            razn = r - l
            if razn == 0 and int(mas[l]) == s and int(mas[l]) == x:
                sum += 1
            else:
                stri = ''
                si = 0
                for i in range(l, r + 1):
                    stri += mas[i]
                    si += int(mas[i])
                if si == s and str(x) in stri:
                    sum += 1

print(sum)