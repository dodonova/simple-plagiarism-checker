k = int(input())
if 2 <= k <= 16:
    n = k - 1
    print(2 ** n)