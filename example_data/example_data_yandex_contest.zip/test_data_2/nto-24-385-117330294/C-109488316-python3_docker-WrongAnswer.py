k = int(input())
n = k-1
print(2**n)