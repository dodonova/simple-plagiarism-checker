s, x = map(int, input().split(' '))
n = int(input())
ni = n - 1
mas = input()
mas = mas.split(' ')
sumi = 0
for li in range(1,n+1):
    for r in range(n):
        if 1 <= li <= r <= n:
            razn = r - li
            if razn == 0 and int(mas[li-1]) == s and int(mas[li-1]) == x:
                sumi += 1
            else:
                stri = ''
                si = 0
                for i in range(li-1, r):
                    stri += mas[i]
                    si += int(mas[i])
                if si == s and str(x) in stri:
                    sumi += 1

print(sumi)