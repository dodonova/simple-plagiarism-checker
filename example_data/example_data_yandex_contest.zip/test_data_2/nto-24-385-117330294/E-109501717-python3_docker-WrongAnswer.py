s, x = map(int, input().split(' '))
n = int(input())
ni = n - 1
mas = input()
mas = mas.split(' ')
sumi = 0
for li in range(n):
    for r in range(n):
        if 0 <= li <= r <= ni:
            razn = r - li
            if razn == 0 and int(mas[li]) == s and int(mas[li]) == x:
                sumi += 1
            else:
                stri = ''
                si = 0
                for i in range(li, r + 1):
                    stri += mas[i]
                    si += int(mas[i])
                if si == s and str(x) in stri:
                    sumi += 1

print(sumi)