#include <iostream>
#include <vector>

#define ll long long

using namespace std;

int main() {

	ll k; cin >> k;

	for (ll u = 2; u < 100000; u++) {
		ll num = u;
		ll i = 2;
		ll ans = 1;
		while (num != 1) {
			if (num % i == 0) {
				ans++;
				num = num / i;
				continue;
			}
			i++;
		}
		if (ans == k) {
			cout << u;
			return 0;
		}
	}
	
	return -1;
}

