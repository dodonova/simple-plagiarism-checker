#include <iostream>
#include <vector>

#define ll long long

using namespace std;

int main() {
	vector<ll> vec(1e5, 1);

	int k; cin >> k;

	for (ll u = 2; u < vec.size(); u++) {
		ll num = u;
		ll i = 2;
		ll ans = 1;
		while (num != 1) {
			if (num % i == 0) {
				ans++;
				num = num / i;
				continue;
			}
			i++;
		}
		if (ans == k) {
			cout << u;
			return 0;
		}
	}
	
	return -1;
}

