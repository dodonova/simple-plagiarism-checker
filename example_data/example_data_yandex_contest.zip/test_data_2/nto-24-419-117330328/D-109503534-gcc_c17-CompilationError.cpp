#include <iostream>
#include <deque>
#include <vector>
#include <cmath>

#define ll long long

using namespace std;

void sol(ll n, ll k, ll stx, ll sty, ll wig, ll hei, vector<vector<ll>>&vec) {
	if (k < 3) {
		for (ll i = sty; i <= hei; i++) {
			for (ll j = stx; j <= wig; j++) {
				vec[i][j] = k;
			}
		}
	}
	else if (n == 1) {
		vec[sty][stx] = k;
	}
	else {
		sol(n / 2, k - 1, stx, sty, wig / 2, hei / 2, vec);

		sol(n / 2, k - 2, wig/2+1, sty, wig, hei / 2, vec);

		sol(n / 2, k - 2, stx, hei/2+1, wig / 2, hei, vec);

		sol(n / 2, k - 3, wig/2+1, hei/2+1, wig, hei, vec);
	}
}

int main() {
	ll n, k; cin >> n >> k;

	vector<vector<ll>> vec(n, vector<ll>(n, 0));

	sol(n, k, 0, 0, n - 1, n - 1, vec);



	for (auto x : vec) {
		for (auto y : x) {
			cout << y << " ";
		}
		cout << "\n";
	}
	return 0;
}
