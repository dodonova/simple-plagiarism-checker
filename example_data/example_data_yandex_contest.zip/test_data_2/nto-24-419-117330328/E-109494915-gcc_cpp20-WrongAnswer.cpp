#include <iostream>
#include <deque>
#include <vector>

#define ll long long

using namespace std;

int main() {
	
	ll s, x;
	cin >> s >> x;

	ll n; cin >> n;

	vector<ll> vec;
	for (ll i = 0; i < n; i++) {
		ll k; cin >> k;
		vec.push_back(k);
	}

	ll ans = 0;

	for (int i = 1; i < n + 1; i++) {
		deque<ll> dq;
		ll u = 0;
		ll sum = 0;
		ll fl = false;
		while (dq.size() < i) {
			dq.push_back(vec[u]);
			sum += vec[u];
			if (vec[u] == x) {
				fl = true;
			}
			u++;
		}

		if (i == n) {
			if (sum == s && fl == true) {
				ans++;
			}
		}

		while (u < n) {
			if (sum == s && fl == true) {
				ans++;
			}

			sum -= dq.front();
			if (dq.front() == x) {
				fl = false;
			}

			dq.pop_front();

			dq.push_back(vec[u]);
			u++;

			sum += dq.back();

			if (dq.back() == x) {
				fl = true;
			}
		}
	}

	cout << ans;

	return 0;
}
