#include <iostream>
#include <deque>
#include <vector>

#define ll long long

using namespace std;

int main() {

	ll s, x;
	cin >> s >> x;

	ll n; cin >> n;

	vector<ll> vec;
	for (ll i = 0; i < n; i++) {
		ll k; cin >> k;
		vec.push_back(k);
	}

	ll ans = 0;

	for (int i = 0; i < n + 1; i++) {
		//deque<ll> dq;
		ll l, r; l = 0; r = 0;
		ll u = 0;
		ll sum = 0;
		ll fl = false;
		while (r-l+1 < i) {
			sum += vec[r];
			if (vec[r] == x) {
				fl = true;
			}
			r++;
		}

		if (i == n) {
			if (sum == s && fl == true) {
				ans++;
			}
		}

		while (r+1 < n) {
			if (sum == s && fl == true) {
				ans++;
			}

			sum -= vec[l];
			if (vec[l] == x) {
				fl = false;
			}
			l++;
			r++;
			sum += vec[r];

			if (vec[r] == x) {
				fl = true;
			}
		}
		if (sum == s && fl == true) {
			ans++;
		}
	}

	cout << ans;

	return 0;
}
