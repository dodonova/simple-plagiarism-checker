#include <iostream>
#include <deque>
#include <vector>
#include <cmath>

#define ll long long

using namespace std;

int main() {
	ll k;
	cin >> k;

	cout << pow(2, k - 1);

	return 0;
}
