k = int(input())
n = int(input())
if k < 3 or n == 1:
    print(k)
else:
    print("Не могу решить:(")