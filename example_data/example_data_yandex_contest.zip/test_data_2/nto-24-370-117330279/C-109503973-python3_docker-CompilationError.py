k = int(input())
if k < 3:
	print(k, k, k, k, /n)
elif k == 7:
	print("))")