S, X = int(input()), int(input())
n = int(input())
n1, n2, n2, n4 = int(input()), int(input()), int(input()), int(input())
