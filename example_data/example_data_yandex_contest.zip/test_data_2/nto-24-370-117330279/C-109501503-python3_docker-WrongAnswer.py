k = int(input())
a = 2**k-1
print(a)