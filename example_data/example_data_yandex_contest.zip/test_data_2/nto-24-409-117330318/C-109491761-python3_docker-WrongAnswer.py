k = int(input())
b = 1
for i in range(k - 1):
    b *= 2
print(b)