n, k = list(map(int, input().split()))
if n == 1:
    print(k)
elif k < 3:
    for column in range(n):
        for row in range(n):
            print(k, end="")
        print("\n", end="")
else:
    print("")