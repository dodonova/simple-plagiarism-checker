n = int(input())
k = int(input())
if k < 3 or n == 1:
    for i in range(n):
        st = ""
        for i in range(n):
            st += str(k) + " "
        print(st)
