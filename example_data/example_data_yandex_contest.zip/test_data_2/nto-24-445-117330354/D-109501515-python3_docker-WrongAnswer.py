inp = input()
n = int(inp.split(" ")[0])
k = int(inp.split(" ")[1])
st = ""
for i in range(n):
    st = ""
    for i in range(n):
        st += str(k) + " "
    print(st)


