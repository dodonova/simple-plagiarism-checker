inp = int(input())
print(2**(inp-1))