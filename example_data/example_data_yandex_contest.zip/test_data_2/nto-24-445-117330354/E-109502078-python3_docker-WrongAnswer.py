inp = input()

s = int(inp.split(" ")[0])
x = int(inp.split(" ")[1])
n = int(input())
lst = input().split(" ")

print(2)