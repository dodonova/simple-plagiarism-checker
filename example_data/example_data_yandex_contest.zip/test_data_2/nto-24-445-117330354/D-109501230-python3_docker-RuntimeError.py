n = int(input())
k = int(input())
st = ""
for i in range(n):
    st = ""
    for i in range(n):
        st += str(k) + " "
    print(st)


