n, k = map(int, input().split())
tab = [[k]*n]*n
if k < 3 or n==1:
    for i in range(n):
        res = ''
        for j in range(n):
            res += str(tab[i][j]) + ' '
        print(res)
else:
	print(1)
