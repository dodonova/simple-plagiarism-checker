s, x = map(int, input().split())
n = int(input())
A = [int(x) for x in input().split()]
c = 0

for l in range(len(A)):
    for r in range(l, len(A)):
        if (sum(A[l:r+1]) == s) and (x in A[l:r+1]):
            c += 1
print(c)
