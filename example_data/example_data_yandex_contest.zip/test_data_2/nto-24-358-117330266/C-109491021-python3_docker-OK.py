a = int(input())
def razl(a):
    res = 1
    b = [0, 0] + [0]*a
    for i in range(2, a+1):
        if a % i == 0:
            while a % i == 0:
                b[i] += 1
                a //= i

    for y in b:
        res *= (y+1)
    return res

for i in range(10**9):
    if razl(i) == a:
        print(i)
        break
