s, x = map(int, input().split())
n = int(input())
A = [int(x) for x in input().split()]
c = 0
b = []
for l in range(len(A)):
    for r in range(len(A)-l+4):
        if (sum(A[l:r+1]) == s) and (x in A[l:r+1]) and (A[l:r+1] not in b):
            c += 1
            b.append(A[l:r + 1])
print(c)
