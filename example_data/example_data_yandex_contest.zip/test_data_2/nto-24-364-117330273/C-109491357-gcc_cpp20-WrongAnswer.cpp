#include <iostream>

using namespace std;

int main()
{
    int k, n;
    cin >> k;
        if(n % k >= 0){}
    cout << n;
    return 0;
}