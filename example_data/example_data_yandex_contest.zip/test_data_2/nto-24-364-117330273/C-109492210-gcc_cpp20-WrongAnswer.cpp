#include <iostream>

using namespace std;

int main()
{
    int k, n;
    cin >> k;
        if(n % k >= 0){
        k = k - 1;}
    cout << n;
    return 0;
}