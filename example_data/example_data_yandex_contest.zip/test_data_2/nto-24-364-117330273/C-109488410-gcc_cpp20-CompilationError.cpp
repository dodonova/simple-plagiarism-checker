#include <iostream>

using namespace std;

int main()
{
    int k, n, d;
    cout >> k
    if(n % k == 0) and (n <= d){
        d += 1
    }
    cout << d << endl;
    return 0;
}