#include <iostream>

using namespace std;

int main()
{
    int k, d, n;
    cin >> d;
        if(n % k >= 0){}
    cout << k;
    return 0;
}