a = int(input())
if a == 2:
    print(2)
elif a > 2:
    c = 2 ** a
    print(c)
    