a = int(input())
b = a - 1
if a == 2:
    print(2)
elif a > 2:
    c = 2 ** b
    print(c)