#include<iostream>
#include<math.h>

using namespace std;

int main() {
    int st;

    cin >> st;

    cout << pow(2, st-1);
}