#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main() {
    int s;
    int x;
    int n;
    int result = 0;
    vector<int> massive;

    cin >> s >> x >> n;

    for (int i = 0; i < n; ++i) {
        int k;
        cin >> k;

        massive.push_back(k);
    }

    for (int i = 0; i < n; ++i) {
        int curren_sum = 0;
        bool flag = false;
        for (int k = i; k < n; ++k) {
            //curren_sum += massive[k];

            if (massive[k] == x or flag) {
                flag = true;
                curren_sum += massive[k];
            }
            if (curren_sum == s && flag) {
                result += 1;
            }
        }
    }

    cout << result;
}
