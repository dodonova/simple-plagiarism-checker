sums, x = map(int, input().split())
n = int(input())
mas = list(map(int, input().split()))
count = 0
for i in range(n):
    flag = False
    s = 0
    if mas[i] == x:
        flag = True
    for j in range(i, n):
        s += mas[j]
        if flag:
            if sums == s:
                count += 1
        elif mas[j] == x:
            flag = True
print(count)