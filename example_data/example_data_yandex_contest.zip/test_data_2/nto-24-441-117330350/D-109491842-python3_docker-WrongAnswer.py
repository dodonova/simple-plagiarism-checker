n, k = map(int, input().split())

#def solve(n, k):
if k < 3 or n == 1:
    for i in range(n):
        for j in range(n):
            print(k, end=' ')
        print()