sums, x = map(int, input().split())
n = int(input())
mas = list(map(int, input().split()))
count = 0
flag = False
for i in range(n):
    flag = False
    s = mas[i]
    if mas[i] == x:
        flag = True
    for j in range(i+1, n):
        s += mas[j]
        if flag and sums == s:
            count += 1
        elif mas[j] == x:
            flag = True
print(count)