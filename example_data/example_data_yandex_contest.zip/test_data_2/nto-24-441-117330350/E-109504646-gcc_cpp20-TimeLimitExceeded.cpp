#include <iostream>

using namespace std;

int main()
{
    int sums, x;
    cin >> sums >> x;
    int n;
    cin >> n;
    int mas[n];
    for (int i = 0; i < n; i++){
        cin >> mas[i];
    }
    int counts = 0;
    for (int i = 0; i < n; i++){
        bool flag = false;
        int s = 0;
        if (mas[i] == x)
            flag = true;
        for (int j = i; j < n; j ++){
            s += mas[j];
            if (mas[j] == x)
                flag = true;
            if (flag && sums == s)
                counts ++;
        }
    }
    cout << counts << endl;
    return 0;
}
