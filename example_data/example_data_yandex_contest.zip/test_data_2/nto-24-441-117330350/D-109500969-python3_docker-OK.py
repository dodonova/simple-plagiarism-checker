n, k = map(int, input().split())


def solve(n, k):
    if k < 3 or n == 1:
        ans = [[] for _ in range(n)]
        for i in range(n):
            ans[i] = [k] * n
        return ans
    else:
        one = solve(n // 2, k - 1)
        two_three = solve(n // 2, k - 2)
        four = solve(n // 2, k - 3)
        ans = [[] for _ in range(n)]
        for i in range(n // 2):
            ans[i] = one[i] + two_three[i]
        for i in range(n // 2):
            ans[n // 2 + i] = two_three[i] + four[i]
        return ans
ans = solve(n, k)
for i in ans:
    print(*i, sep=' ')