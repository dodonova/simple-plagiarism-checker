a  = int(input())
c  =[0] * 4
i = 0
h  = [2,3,5,7,11]
ans  = 1
while a != 1:
    b = 2
    while a % b != 0:
        b += 1
    a = a / b
    c[i] = b - 1
    i += 1
c.sort()
   
for i in range(4):
    ans = ans * h[i] ** c[-(i + 1)]
print(int(ans))
