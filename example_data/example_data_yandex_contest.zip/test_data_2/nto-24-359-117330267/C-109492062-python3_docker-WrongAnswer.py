a  = int(input())
d = 1
for i in range(a - 1 ):
    d = d * 2
print(d)