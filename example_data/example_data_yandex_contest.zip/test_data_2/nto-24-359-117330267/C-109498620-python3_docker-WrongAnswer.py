a  = int(input())
c  =[0] * 4
i = 0
h  = [2,3,5,7]
ans  = 0
while a != 1:
    b = 2
    while a % b != 0:
        b += 1
    a = a / b
    c[i] = b
    i += 1
    c.sort()
for i in range(3):
    ans += h[i] ** c[-(i + 1)]
print(ans)
