a  = int(input())
d = 1
for i in range(a ):
    d = d * 2
print(d)