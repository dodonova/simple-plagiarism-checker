n = int(input())
n = int(input())
t = 0
m = []
def f(n):
    k = 0
    for i in range(1, n+1):
        if n % i == 0:
            k += 1
    return k
for i in range(n * 200):
    t = 0
    t = f(i)
    if t ==n:
        m.append(i)
print(min(m))