S,X = map(int, input().split())
n = int(input())
sp=list(map(int,input().split()))


itog=0
for i in range(len(sp)-1):
    summ=sp[i]
    flag=0
    if sp[i]==X:
        flag=1
    for k in range(i+1, len(sp)):
        summ+=sp[k]
        if sp[k]==X:
            flag=1
        if flag==1 and summ==S:
            itog+=1

print(itog)