k=int(input())
for i in range(2,1000):
    flag=0
    for p in range(1, round(i ** 0.5) + 1):
        if p!=i:
            if i%p==0:
                flag+=1
                s= i // p
                if s!=p:
                    flag+=1
    if flag==k:
        print(i)
        break