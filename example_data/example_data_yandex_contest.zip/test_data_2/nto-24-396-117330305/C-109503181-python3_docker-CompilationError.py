if 2<= k <= 16
	k = int(input())
	n = 2**(k-1)
print(n)