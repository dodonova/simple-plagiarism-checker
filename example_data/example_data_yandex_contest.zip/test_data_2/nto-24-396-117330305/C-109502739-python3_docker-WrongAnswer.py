k = int(input())
n = 2**(k-1)
print(n)