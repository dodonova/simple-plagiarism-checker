X, S = map(int,input().split())
sp = []
k = 0
n = int(input())
for i in range(n):
    sp.append(int(input()))
for element in sp:
    if element == X and sum(sp) == S:
        k += 1
print(k)