n, k = map(int, input().split())
if n == 1 and k < 3:
    for _ in range(n):
        print(k