koldel = int(input())
schet = 0
for n in range(1, 1000):
    for i in range(1, 100):
        if n % i == 0:
            schet += 1
    if schet == koldel:
        print(n)
        break
    else:
        schet = 0
