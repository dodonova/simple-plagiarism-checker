# put your python code here


n, m = map(int, input().split())
matrix = [list(map(int, input().split())) for _ in range(n)]

print(1)