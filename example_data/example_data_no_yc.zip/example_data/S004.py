n, m = map(int, input().split())

for _ in range(n): input()

print(1)