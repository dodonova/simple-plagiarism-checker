# put your python code here
n = int(input())
k = int(input())
for i in range(n):
    if n < 100000 & n > 1=:
        print(siuuu)